﻿using System.Diagnostics;
using System.ServiceModel;
using System.Threading;
using FASTWCFHelpers.DataObjects;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using System;
using SeleniumInternalHelpersSupportLibrary;

namespace FASTWCFHelpers
{
    public static class FileService
    {
        #region Creat File for CD tests
        /// <summary>
        /// Used in the Standalone CD screen tests. Creates an Order usgin a default File template
        /// </summary>
        /// <returns>Returns File Info</returns>
        public static FileInformation CreateFile_CDScreen()
        {
            var service = ServiceFactory.GetFileService();
            var createFilerequest = new CreateFileRequest();
            FastFile defaultFile = new FastFile();

            createFilerequest.formType = defaultFile.Request.formType;
            createFilerequest.EmployeeObjectCD = defaultFile.Request.EmployeeObjectCD;
            createFilerequest.Source = defaultFile.Request.Source;
            createFilerequest.Target = defaultFile.Request.Target;
            createFilerequest.File = FileRequestFactory.Create(defaultFile);

            var createFileResponse = service.CreateFile(createFilerequest);
            System.Diagnostics.Debug.Print("Requested File Creation");

            var searchFileResponse = service.GetOrderDetails((int)createFileResponse.FileID);
            service.Close();
            System.Diagnostics.Debug.Print("Requested Order Details using File ID");
            System.Diagnostics.Debug.Print("Got file # " + searchFileResponse.FileNumber);

            return new FileInformation()
            {
                FileID = searchFileResponse.FileID != null ? searchFileResponse.FileID.ToString() : "-1",
                FileNumber = searchFileResponse.FileNumber,
                RegionID = (int)searchFileResponse.Services[0].OfficeInfo.RegionID,
                OfficeID = (int)searchFileResponse.Services[0].OfficeInfo.BUID
            };
        }

        /// <summary>
        /// Used in the Standalone CD screen tests. Creates an Order using the custom file provided.
        /// </summary>
        /// <param name="file">Custom file to be created</param>
        /// <returns></returns>
        public static FileInformation CreateFile_CDScreen(FastFile file)
        {
            var service = ServiceFactory.GetFileService();
            var createFilerequest = new CreateFileRequest();

            createFilerequest.formType = file.Request.formType;
            createFilerequest.EmployeeObjectCD = file.Request.EmployeeObjectCD;
            createFilerequest.Source = file.Request.Source;
            createFilerequest.Target = file.Request.Target;
            createFilerequest.File = FileRequestFactory.Create(file);

            var createFileResponse = service.CreateFile(createFilerequest);
            System.Diagnostics.Debug.Print("Requested File Creation");

            var searchFileResponse = service.GetOrderDetails((int)createFileResponse.FileID);
            service.Close();
            System.Diagnostics.Debug.Print("Requested Order Details using File ID");
            System.Diagnostics.Debug.Print("Got File # " + searchFileResponse.FileNumber);
            System.Diagnostics.Debug.Print("File Created in Region/Office " + searchFileResponse.Services[0].OfficeInfo.RegionID.ToString() + "/" + searchFileResponse.Services[0].OfficeInfo.BUID);

            return new FileInformation()
            {
                FileID = searchFileResponse.FileID != null ? searchFileResponse.FileID.ToString() : "-1",
                FileNumber = searchFileResponse.FileNumber,
                RegionID = (int)searchFileResponse.Services[0].OfficeInfo.RegionID,
                OfficeID = (int)searchFileResponse.Services[0].OfficeInfo.BUID
            };
        }
        #endregion

        public static FileSearchResponse GetFilesByFileNum(string fileNo, int regionID, int userID, FileNumType eFileNumType = FileNumType.FileNo)
        {
            var client = ServiceFactory.GetFileService();

            return Execute<FileSearchResponse>(client, () => client.GetFilesByFileNum(fileNo, regionID, userID, eFileNumType));
        }

        public static CreateFileResponse CreateFile(CreateFileRequest request = null)
        {
            var client = ServiceFactory.GetFileService();

            var serviceRequest = request ?? RequestFactory.GetCreateFileDefaultRequest();

            return Execute<CreateFileResponse>(client, () => client.CreateFile(serviceRequest));
        }

        public static OperationResponse SetOrderSigning(OrderSigningRequest request)
        {
            var client = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(client, () => client.SetOrderSigning(request));
        }

        public static OperationResponse UpdateHUD1StatementDetails(HUDStatementRequest request)
        {
            var client = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(client, () => client.UpdateHUD1StatementDetails(request));
        }

        public static OrderDetailsResponse GetOrderDetails(int fileID)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.GetOrderDetails(fileID));
        }

        public static TermsDatesStatusResponse GetTermsDatesStatusDetails(int fileID)
        {
            var client = ServiceFactory.GetFileService();

            return Execute<TermsDatesStatusResponse>(client, () => client.GetTermsDatesStatusDetails(fileID));
        }

        public static BuyerSellerAttorneyResponse GetBuyerSellerAttorneyDetails(int fileID)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<BuyerSellerAttorneyResponse>(service, () => service.GetBuyerSellerAttorneyDetails(fileID));
        }

        public static CreateBuyerSellerAttorneyResponse GetBuyerSellerAttorneyDetails(CreateBuyerSellerAttorneyRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<CreateBuyerSellerAttorneyResponse>(service, () => service.UpdateBuyerSellerAttorney(request));
        }

        public static BuyerSellerSignaturesTypesResponse GetBuyerSellerAuthorizedSignatureType(BuyerSellerSignaturesTypesRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<BuyerSellerSignaturesTypesResponse>(service, () => service.GetBuyerSellerAuthorizedSignatureType(request));
        }

        public static SearchFileFeeResponse SearchFeeEntryFileFees(SearchFileFeeRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<SearchFileFeeResponse>(service, () => service.SearchFeeEntryFileFees(request));
        }

        public static MiscDisbResponse GetMiscellaneousDisbursement(int fileID, int seqNum)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<MiscDisbResponse>(service, () => service.GetMiscellaneousDisbursement(fileID, seqNum));
        }

        public static MiscDisbSummaryResponse GetMiscellaneousDisbursementSummary(MiscDisbSummaryRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<MiscDisbSummaryResponse>(service, () => service.GetMiscellaneousDisbursementSummary(request));
        }

        public static OperationResponse DeleteMiscellaneousDisbursement(DeleteMiscDisbRequest request)
        {
            var client = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(client, () => client.DeleteMiscellaneousDisbursement(request));
        }
        
        public static OperationResponse CreateMiscellaneousDisbursement(NewMiscDisbusementRequest request)
        {
            var client = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(client, () => client.CreateMiscellaneousDisbursement(request));
        }

        public static OperationResponse UpdateMiscellaneousDisbursement(NewMiscDisbusementRequest request)
        {
            var client = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(client, () => client.UpdateMiscellaneousDisbursement(request));
        }

        public static OperationResponse InitiatePayoffRequest(PayoffLoanRequest request)
        {
            var client = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(client, () => client.InitiatePayoffRequest(request));
        }

        public static UpdateFileResponse UpdateOrderDetails(UpdateFileRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<UpdateFileResponse>(service, () => service.UpdateOrderDetails(request));
        }

        public static DocumentResponse CreateDocument(CreateDocumentRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<DocumentResponse>(service, () => service.CreateDocument(request));
        }

        public static OperationResponse CreateImageDocument(CreateImageDocumentRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.CreateImageDocument(request));
        }

        public static DocumentDetailsResponse GetDocumentDetails(int fileID, int documentID)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<DocumentDetailsResponse>(service, () => service.GetDocumentDetails(fileID, documentID));
        }

        public static DocumentListResponse GetDocuments(int fileID)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<DocumentListResponse>(service, () => service.GetDocuments(fileID));
        }

        public static CopyDocumentsResponse CopyDocuments(CopyDocumentsRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.CopyDocuments(request));
        }

        public static StarterRefDocumentResponse GetDocumentsForStarterRef(StarterRefDocumentRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.GetDocumentsForStarterRef(request));
        }

        public static ImageDocumentDetailsResponse GetImageDocumentDetails(int fileID, int imageDocumentID)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.GetImageDocumentDetails(fileID, imageDocumentID));
        }

        public static GetImageDocument2Response GetImageDocument2(GetImageDocument2Request request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.GetImageDocument2(request));
        }

        public static StateListForDocTemplateResponse GetStateListForDocTemplate(StateListForDocTemplateRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.GetStateListForDocTemplate(request));
        }

        public static OperationResponse RemoveNewLoan(RemoveNewLoanRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.RemoveNewLoan(request));
        }

        public static OperationResponse RemoveNewLoanLenderInformation(RemoveNewLoanRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.RemoveNewLoanLenderInformation(request));
        }

        public static NewLoanResponse GetNewLoanDetails(int? fileID, int? seqNum)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<NewLoanResponse>(service, () => service.GetNewLoanDetails(fileID ?? 0, seqNum ?? 0));
        }

        public static AssociateDocPackageResponse GetAssociateDocPackages(int fileID)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.GetAssociateDocPackages(fileID));
        }

        public static OperationResponse AddDocumentsToAssociateDocPackage(AssociateDocPackage package)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.AddDocumentsToAssociateDocPackage(package));
        }

        public static OperationResponse RemoveDocumentsFromAssociateDocPackage(AssociateDocPackage package)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.RemoveDocumentsFromAssociateDocPackage(package));
        }

        public static OperationResponse RemoveAssociateDocPackage(AssociateDocPackage package)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.RemoveAssociateDocPackage(package));
        }

        public static OperationResponse ModifyAssociateDocPackage(AssociateDocPackage package)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.ModifyAssociateDocPackage(package));
        }

        public static DocumentResponse CreateAssociateDocPackage(AssociateDocPackage package)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.CreateAssociateDocPackage(package));
        }

        public static AuthorizedSignaturesResponse GetAuthorizedSignatures(int fileID)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<AuthorizedSignaturesResponse>(service, () => service.GetAuthorizedSignatures(fileID));
        }

        public static BSEntitySignatureResponse GetBSEntitySignature(int fileID)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<BSEntitySignatureResponse>(service, () => service.GetBSEntitySignature(fileID));
        }

        public static OperationResponse UpdateBSEntitySignature(BSEntitySignatureRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.UpdateBSEntitySignature(request));
        }

        public static ExchangeCompanyResponse GetExchangeCompany(int fileID)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<ExchangeCompanyResponse>(service, () => service.GetExchangeCompany(fileID));
        }

        public static OperationResponse DeleteExchangeCompany(int busPartyID)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.DeleteExchangeCompany(busPartyID));
        }

        public static DocPrepDocumentResponse GetDocPrepDocument(int docRequestID)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<DocPrepDocumentResponse>(service, () => service.GetDocPrepDocument(docRequestID));
        }

        public static EventLogResponse GetEventLogs(int fileID, int eventCategoryID)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<EventLogResponse>(service, () => service.GetEventLogs(fileID, eventCategoryID));
        }

        public static AddLenderLoanInvestorResponse AddLenderLoanInvestor(AddLenderLoanInvestorRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<AddLenderLoanInvestorResponse>(service, () => service.AddLenderLoanInvestor(request));
        }

        public static OperationResponse AddPhrase(AddPhraseRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.AddPhrase(request));
        }

        public static OperationResponse AddPhrasesToDocument(AddPhraseRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.AddPhrasesToDocument(request));
        }

        public static OperationResponse AddProcessEvent(AddProcessRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.AddProcessEvent(request));
        }

        public static OperationResponse AddProcessType(AddProcessType processType)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.AddProcessType(processType));
        }

        public static long AddTask(AddTaskRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<long>(service, () => service.AddTask(request));
        }

        public static GetTaskDetailsResponse GetTaskDetails(GetTaskDetailsRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<GetTaskDetailsResponse>(service, () => service.GetTaskDetails(request));
        }

        public static OperationResponse CreateNewLoan(NewLoanRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.CreateNewLoan(request));
        }

        public static OperationResponse NewLoanMBPayChargesAssociation(NewLoanPayChargeAssociationRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.NewLoanMBPayChargesAssociation(request));
        }

        public static OperationResponse NewLoanPayChargesAssociation(NewLoanPayChargeAssociationRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.NewLoanPayChargesAssociation(request));
        }

        public static OperationResponse DeletePhrases(DeletePhrasesRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.DeletePhrases(request));
        }

        public static OperationResponse EditDocument(EditDocumentRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.EditDocument(request));
        }

        public static DeliveryResponse EmailDelivery(EmailDeliveryRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<DeliveryResponse>(service, () => service.EmailDelivery(request));
        }

        public static DeliveryResponse FastWebDelivery(FastWebDeliveryRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<DeliveryResponse>(service, () => service.FastWebDelivery(request));
        }

        public static DeliveryResponse FeeEntryDelivery(FileFeeDeliveryRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<DeliveryResponse>(service, () => service.FeeEntryDelivery(request));
        }

        public static DeliveryResponse FaxDelivery(FaxDeliveryRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<DeliveryResponse>(service, () => service.FaxDelivery(request));
        }

        public static DeliveryResponse WintrackDelivery(WintrackDeliveryRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<DeliveryResponse>(service, () => service.WintrackDelivery(request));
        }

        public static DeliveryResponse LACOMDelivery(LACOMDeliveryRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<DeliveryResponse>(service, () => service.LACOMDelivery(request));
        }

        public static AddBuyerSellerResponse AddBuyerSeller(AddBuyerSellerRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<AddBuyerSellerResponse>(service, () => service.AddBuyerSeller(request));
        }

        public static OperationResponse UpdateNewLoan(NewLoanRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.UpdateNewLoan(request));
        }

        public static OperationResponse CreateOutsideEscrowCompany(OECRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.CreateOutsideEscrowCompany(request));
        }

        public static CreateOutsideTitleCompanyResponse CreateOutsideTitleCompany(CreateOutsideTitleCompanyRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<CreateOutsideTitleCompanyResponse>(service, () => service.CreateOutsideTitleCompany(request));
        }

        #region PayoffLoan
        public static OperationResponse CreatePayoffLoan(PayoffLoanRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.CreatePayOffLoan(request));
        }
        public static OperationResponse UpdatePayOffLoan(PayoffLoanRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.UpdatePayOffLoan(request));
        }
        public static OperationResponse RemovePayOffLoan(PayoffLoanRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.RemovePayOffLoan(request));
        }
        #endregion

        public static CreateBuyerSellerAttorneyResponse CreateBuyerSellerAttorney(CreateBuyerSellerAttorneyRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<CreateBuyerSellerAttorneyResponse>(service, () => service.CreateBuyerSellerAttorney(request));
        }

        public static CreateBuyerSellerAttorneyResponse UpdateBuyerSellerAttorney(CreateBuyerSellerAttorneyRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<CreateBuyerSellerAttorneyResponse>(service, () => service.UpdateBuyerSellerAttorney(request));
        }

        public static OperationResponse UpdateTermsDatesStatus(TermsDatesStatusRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.UpdateTermsDatesStatus(request));
        }

        public static UpdateBuyerSellerResponse UpdateBuyerSeller(UpdateBuyerSellerRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<UpdateBuyerSellerResponse>(service, () => service.UpdateBuyerSeller(request));
        }

        public static OperationResponse UpdateAuthorizedSignature(AuthorizedSignaturesRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.UpdateAuthorizedSignature(request));
        }

        public static UpdateFeeEntryResponse UpdateFeeEntryDetails(FeeEntryRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<UpdateFeeEntryResponse>(service, () => service.UpdateFeeEntryDetails(request));
        }

        public static FeeEntryResponse GetFeeEntryDetails(int fileId)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<FeeEntryResponse>(service, () => service.GetFeeEntryDetails(fileId, "FAST"));
        }

        public static ServiceFeeResponse GetServiceFeeDetails(int fileId)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<ServiceFeeResponse>(service, () => service.GetServiceFeeDetails(fileId));
        }

        public static InvoiceFeesResponse GetInvoiceDetails(int fileId)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.GetInvoiceDetails(fileId));
        }

        public static OperationResponse UpdateInvoiceDetails(UpdateInvoiceRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.UpdateInvoiceDetails(request));
        }

        public static UpdateSecondOrderSourceResponse UpdateSecondOrderSource(UpdateSecondOrderSourceRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<UpdateSecondOrderSourceResponse>(service, () => service.UpdateSecondOrderSource(request));
        }

        public static FileSearchResponse GetFilesBySearch(FileSearchRequest request)
        {
            var client = ServiceFactory.GetFileService();

            return Execute<FileSearchResponse>(client, () => client.GetFilesBySearch(request));
        }

        public static OperationResponse RemoveDocument(RemoveDocumentRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.RemoveDocument(request));
        }

        public static DocTemplateResponse GetDocTemplates(FASTWCFHelpers.FastFileService.DocTemplateRequest Request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<DocTemplateResponse>(service, () => service.GetDocTemplates(Request));
        }

        public static OperationResponse UnfinalizeDocument(UnfinalizeDocumentRequest Request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.UnfinalizeDocument(Request));
        }

        public static OperationResponse FinalizeDocument(FinalizeDocumentRequest Request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.FinalizeDocument(Request));
        }

        public static OperationResponse UpdateDocument(UpdateDocumentRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.UpdateDocument(request));
        }
        
        public static int SubmitDocRequest(int fileID, int documentID)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<int>(service, () => service.SubmitDocRequest(fileID, documentID));
        }

        public static OperationResponse AddProduct(AddProductRequest AddProductRequest)
        {
            var service = ServiceFactory.GetFileService();
            // var response = ServiceFactory.GetFileService().AddProduct(AddProductRequest);
            return Execute<OperationResponse>(service, () => service.AddProduct(AddProductRequest));
        }

        public static OperationResponse UpdateCompleteVesting(int fileID, int principalTypeCdID, string vestingText, string source = "famos", string loginName = @"fastts\fastqa07")
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.UpdateCompleteVesting(fileID, principalTypeCdID, vestingText, source, loginName));
        }

        public static OperationResponse GetImageDocument(int ImageDocumentID, int ImageDocumentVersionID)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.GetImageDocument(ImageDocumentID, ImageDocumentVersionID));
        }

        public static SearchFileResponse SearchFiles(SearchFileRequest Request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<SearchFileResponse>(service, () => service.SearchFiles(Request));
        }

        public static Boolean AddOrAppendServiceFileNotes(FileNotesRequest Request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.AddOrAppendServiceFileNotes(Request));
        }

        public static AddEventLogEntryResponse AddEventLogEntry(AddEventLogEntryRequest Request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<AddEventLogEntryResponse>(service, () => service.AddEventLogEntry(Request));
        }

        public static OperationResponse AddFileWorkflowReminderOrAlert(AlertOrReminderRequest Request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.AddFileWorkflowReminderOrAlert(Request));
        }

        public static OperationResponse UpdatePropertyTax(PropertyUpdateRequest Request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.UpdatePropertyTax(Request));
        }

        public static OperationResponse UpdateGFEDetails(GFELoanRequest Request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.UpdateGFEDetails(Request));
        }

        public static UpdateFileResponse UpdateChangeOwningOfficeAndServiceType(UpdateFileRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<UpdateFileResponse>(service, () => service.UpdateChangeOwningOfficeAndServiceType(request));
        }

        public static GFELoanResponse GetGFEDetails(int fileID)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<GFELoanResponse>(service, () => service.GetGFEDetails(fileID));
        }

        public static ServiceFileNotesResponse GetServiceFileNotes(int FileID)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<ServiceFileNotesResponse>(service, () => service.GetServiceFileNotes(FileID));
        }

        public static OperationResponse RemoveFileWorkflowReminderOrAlert(AlertOrReminderRequest Request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.RemoveFileWorkflowReminderOrAlert(Request));
        }

        public static TaskOfficeResponse GetTaskOffices(int fileID, int taskID)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<TaskOfficeResponse>(service, () => service.GetTaskOffices(fileID, taskID));
        }

        public static WorkFlowResponse GetWorkflowDetails(int fileID)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.GetWorkflowDetails(fileID));
        }

        public static CreateBuyerSellerAttorneyResponse RemoveBuyerSellerAttorney(CreateBuyerSellerAttorneyRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<CreateBuyerSellerAttorneyResponse>(service, () => service.RemoveBuyerSellerAttorney(request));
        }

        public static DeleteBuyerSellerResponse DeleteBuyerSeller(DeleteBuyerSellerRequest Request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<DeleteBuyerSellerResponse>(service, () => service.DeleteBuyerSeller(Request));
        }

        public static OperationResponse UploadImage(UploadImageRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.UploadImage(request));
        }

        public static UploadImage2Response UploadImage2(UploadImage2Request request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.UploadImage2(request));
        }

        public static OperationResponse UpdatePhrase(UpdatePhraseRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.UpdatePhrase(request));
        }

        public static OperationResponse MovePhrase(MovePhraseRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.MovePhrases(request));
        }

        public static ViewPhraseResponse ViewPhraseText(ViewPhraseRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<ViewPhraseResponse>(service, () => service.ViewPhraseText(request));
        }

        public static OperationResponse AddPhraseMarker(AddPhraseMarkerRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.AddPhraseMarker(request));
        }

        public static OperationResponse WaiveOrUnwaivePhrase(WaiveOrUnWaivePhraseRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.WaiveOrUnWaivePhrases(request));
        }

        public static OperationResponse NewPropertyAddress(PropertyAddressRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.NewPropertyAddress(request));
        }

        public static OperationResponse CopyPropertyAddress(CopyPropertyAddressRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute<OperationResponse>(service, () => service.CopyPropertyAddress(request));
        }

        public static OperationResponse RemovePropertyAddress(RemovePropertyAddressRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.RemovePropertyAddress(request));
        }

        public static OperationResponse RemoveProperty(RemovePropertyRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.RemoveProperty(request));
        }

        public static OperationResponse RemoveLenderThirdPartyPayee(RemoveThirdPartyPayee request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.RemoveLenderThirdPartyPayee(request));
        }

        public static SettlementStatementResponse GetSettlementStatementDetails(int fileId)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.GetSettlementStatementDetails(fileId));
        }

        public static GetSettlementStatementResponse GetSettlementStatementScreenDetails(GetSettlementStatementRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.GetSettlementStatementScreenDetails(request));
        }

        public static UpdateSettelementStatementResponse UpdateSettlementStatementDetails(UpdateSettelementStatementRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.UpdateSettlementStatementDetails(request));
        }

        public static OperationResponse RemoveNewLoanRelatedParty(RemoveRelatedPartyRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.RemoveNewLoanRelatedParty(request));
        }

        public static OperationResponse RemoveMortgageBrokerThirdPartyPayee(RemoveThirdPartyPayee request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.RemoveMortgageBrokerThirdPartyPayee(request));
        }

        public static OperationResponse RemoveMortgageBrokerInformation(RemoveNewLoanRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.RemoveMortgageBrokerInformation(request));
        }

        public static DeliveryResponse Hud1StatementDelivery(Hud1DeliveryRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.Hud1StatementDelivery(request));
        }

        public static DeliveryResponse InvoiceDelivery(InvoiceFeesDeliveryRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.InvoiceDelivery(request));
        }
        
        public static ActiveDisbSummaryResponse ActiveDisbSummaryResponse(int fileId)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.GetActiveDisbursementSummaryDetails(fileId, loginName: AutoConfig.UserName));
       
        }

        public static ActiveDisbSummaryResponse GetActiveDisbursementSummaryDetails(int fileId)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.GetActiveDisbursementSummaryDetails(fileId, loginName: AutoConfig.UserName));

        }

        public static DisbursementViewDetailsResponse GetDisbursementHistoryEditDetails(DisbursementEditDetailsRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.GetDisbursementHistoryEditDetails(request));

        }

        public static DisbursementViewDetailsResponse GetDisbursementHistoryViewDetails(int fileId, int disbursementID)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.GetDisbursementHistoryViewDetails(fileId,disbursementID));

        }

        public static OrderSigningResponse GetSignatureSigning(int fileId)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.GetSignatureSigning(fileId));
        }

        public static OperationResponse SetDeliverSigningPackage(DeliverSigningPackageRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.SetDeliverSigningPackage(request));
        }

        public static UpdateSignatureSigningResponse UpdateSignatureSigning(UpdateSignatureSigningRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.UpdateSignatureSigning(request));
        }

        public static OperationResponse FASSNotaryServices(SigningDetailRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.FASSNotaryServices(request));
        }

        public static DisbursementHistoryResponse GetDisbursementHistorySummary(int fileID, string loginName)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.GetDisbursementHistorySummary(fileID, loginName));
        }

        public static DocPhraseResponse GetPhraseWaivedorUnwaived(WaiveOrUnWaivePhraseRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.WaiveOrUnWaivePhrases(request));
        }

        public static AddProductionOfficeResponse AddProductionOffice(AddProductionOfficeRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.AddProductionOffice(request));
        }

        public static RemoveProductionOfficeResponse RemoveProductionOffice(RemoveProductionOfficeRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.RemoveProductionOffice(request));
        }


        public static OperationResponse ModifyGAB(GABRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.ModifyGAB(request));
        }

        public static GABResponse CreateGAB(GABRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.CreateGAB(request));
        }

        public static SearchTypesResponse GetSearchTypeInfo()
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.GetSearchTypeInfo());
        }

        public static OperationResponse UpdateExchangeCompany(ExchangeCompanyRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.UpdateExchangeCompany(request));
        }

        public static FABSearchResponse SearchFAB(int fileID)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.SearchFAB(fileID));
        }

        public static ReserveFileNumberResponse ReserveFileNumber(ReserveFileNumberRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.ReserveFileNumber(request));
        }

        public static OperationResponse LaunchFastSearch(FastSearchRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.LaunchFastSearch(request));
        }

        public static SearchInstructionsResponse GetSearchInstructionInfo(SearchInstructionsRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.GetSearchInstructionInfo(request));
        }

        public static OperationResponse StarterRefCopy(StarterRefRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.StarterRefCopy(request));
        }

        public static SetProjectFileResponse SetProjectFileID(SetProjectFileRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.SetProjectFileID(request));
        }

        public static OperationResponse SubscribeNotification(NotificationRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.SubscribeNotification(request));
        }

        public static OperationResponse UnSubscribeNotification(NotificationRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.UnSubscribeNotification(request));
        }

        public static OperationResponse DeArchiveFileService(DeArchiveFileRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.DeArchiveFileService(request));
        }


        public static OrderSummaryResponse GetOrderSummary(OrderSummaryRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.GetOrderSummary(request));
        }

        public static OperationResponse TriggerATPReview(TriggerATPReviewRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.TriggerATPReview(request));
        }

        public static OperationResponse TriggerTaskEvent(TriggerTaskEventRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.TriggerTaskEvent(request));
        }

        public static GetHudResponse GetHud(GetHudRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.GetHud(request));
        }

        public static HUDStatementResponse GetHUD1StatementDetails(int fileId)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.GetHUD1StatementDetails(fileId));
        }

        public static OperationResponse UpdateInterfaceOrder(InterfaceOrderRequest request)
        {
            var service = ServiceFactory.GetFileService();

            return Execute(service, () => service.UpdateInterfaceOrder(request));
        }

        internal static T Execute<T>(FastFileServiceClient client, Func<T> lambdaFunc)
        {
            //Based on recommended practice: https://msdn.microsoft.com/en-us/library/aa355056.aspx
            try
            {
                var r = lambdaFunc.Invoke();
                client.Close();
                return r;
            }
            catch (CommunicationException e)
            {
                Debug.WriteLine(e.Message);
                client.Abort();
                throw;
            }
            catch (TimeoutException e)
            {
                Debug.WriteLine("Timeout exception: " + e.Message);
                client.Abort();
                throw;
            }
            catch (Exception)
            {
                client.Abort();
                throw;
            }
        }

    }
}
