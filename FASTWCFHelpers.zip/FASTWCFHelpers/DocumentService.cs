﻿using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastDocumentService;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers
{
    public static class DocumentService
    {
        public static DocumentResponse SearchDepositList(CreateDocumentRequest request)
        {
            var client = ServiceFactory.GetDocumentService();
            return Execute(client, () => client.CreateDocument(request));
        }

        public static OperationResponse AddDocumentsToAssociateDocPackage(AssociateDocPackage request)
        {
            var client = ServiceFactory.GetDocumentService();
            return Execute(client, () => client.AddDocumentsToAssociateDocPackage(request));
        }

        public static DocTemplateResponse GetDocTemplates(DocTemplateRequest request)
        {
            var client = ServiceFactory.GetDocumentService();
            return Execute(client, () => client.GetDocTemplates(request));
        }

        public static DocumentResponse CreateDocument(CreateDocumentRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute<DocumentResponse>(service, () => service.CreateDocument(request));
        }

        public static OperationResponse AddPhrasesToDocument(AddPhraseRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute<OperationResponse>(service, () => service.AddPhrasesToDocument(request));
        }

        public static DocumentResponse CreateAssociateDocPackage(AssociateDocPackage package)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute(service, () => service.CreateAssociateDocPackage(package));
        }

        public static OperationResponse EditDocument(EditDocumentRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute(service, () => service.EditDocument(request));
        }

        public static OperationResponse FinalizeDocument(FinalizeDocumentRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute(service, () => service.FinalizeDocument(request));
        }

        public static AssociateDocPackageResponse GetAssociateDocPackages(ServiceFileRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute(service, () => service.GetAssociateDocPackages(request));
        }

        public static OperationResponse AddPhraseMarker(AddPhraseMarkerRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute<OperationResponse>(service, () => service.AddPhraseMarker(request));
        }

        public static DocumentDetailsResponse GetDocumentDetails(DocumentRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute<DocumentDetailsResponse>(service, () => service.GetDocumentDetails(request));
        }

        public static OperationResponse CreateImageDocument(CreateImageDocumentRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute<OperationResponse>(service, () => service.CreateImageDocument(request));
        }

        public static OperationResponse PurgeDocument(PurgeDocumentRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute(service, () => service.PurgeDocument(request));
            }

        public static OperationResponse DeletePhrases(DeletePhrasesRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute<OperationResponse>(service, () => service.DeletePhrases(request));
        }

        public static CreateRTMPackageResponse CreateRTMPackage(CreateRTMPackageRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute(service, () => service.CreateRTMPackage(request));
        }

        public static GetRTMPackageDetailsResponse GetRTMPackageDetails(GetRTMPackageDetailsRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute(service, () => service.GetRTMPackageDetails(request));
        }

        public static RTMFileBusinessPartyResponse GetRTMFileBusinessParties(RTMFileBusinessPartyRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute(service, () => service.GetRTMFileBusinessParties(request));
        }

        public static OperationResponse RemoveDocument(RemoveDocumentRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute<OperationResponse>(service, () => service.RemoveDocument(request));
        }

        public static OperationResponse MovePhrase(MovePhraseRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute<OperationResponse>(service, () => service.MovePhrases(request));
        }

        public static OperationResponse UpdatePhrase(UpdatePhraseRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute<OperationResponse>(service, () => service.UpdatePhrase(request));
        }

        public static DocPhraseResponse GetPhraseWaivedorUnwaived(WaiveOrUnWaivePhraseRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute(service, () => service.WaiveOrUnWaivePhrases(request));
        }

        public static OperationResponse GetDocumentRefreshed(DocumentRefreshRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute(service, () => service.DocumentRefresh(request));
        }

        public static GetDocPackageResponse GetDocPackageDeatails(GetDocPackageRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute(service, () => service.GetDocPackageDetails(request));
        }

        public static OperationResponse DeArchiveFileService(DeArchiveFileRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute(service, () => service.DeArchiveFileService(request));
        }

        public static OperationResponse ModifyAssociateDocPackage(AssociateDocPackage package)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute(service, () => service.ModifyAssociateDocPackage(package));
        }

        public static ImageDocumentResponse GetImageDocument(DocumentRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute(service, () => service.GetImageDocument(request));
        }

        public static ImageDocumentDetailsResponse GetImageDocumentDetails(DocumentRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute(service, () => service.GetImageDocumentDetails(request));
        }

        public static DocumentListResponse GetDocuments(ServiceFileRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute<DocumentListResponse>(service, () => service.GetDocuments(request));
        }

        public static DeliveryResponse EmailDelivery(EmailDeliveryRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute(service, () => service.EmailDelivery(request));
        }

        public static DeliveryResponse FaxDelivery(FaxDeliveryRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute(service, () => service.FaxDelivery(request));
        }

        public static DeliveryResponse FeeEntryDelivery(FileFeeDeliveryRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute(service, () => service.FeeEntryDelivery(request));
        }

        public static DeliveryResponse WintrackDelivery(WintrackDeliveryRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute(service, () => service.WintrackDelivery(request));
        }

        public static DeliveryResponse LACOMDelivery(LACOMDeliveryRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute(service, () => service.LACOMDelivery(request));
        }

        public static OperationResponse PublishDocument(PublishDocumentRequest request)
        {
            var service = ServiceFactory.GetDocumentService();

            return Execute<OperationResponse>(service, () => service.PublishDocument(request));
        }


        internal static T Execute<T>(FastDocumentServiceClient client, Func<T> lambdaFunc)
        {
            //Based on recommended practice: https://msdn.microsoft.com/en-us/library/aa355056.aspx
            try
            {
                var r = lambdaFunc.Invoke();
                client.Close();
                return r;
            }
            catch (CommunicationException e)
            {
                Debug.WriteLine(e.Message);
                client.Abort();
                throw;
            }
            catch (TimeoutException e)
            {
                Debug.WriteLine("Timeout exception: " + e.Message);
                client.Abort();
                throw;
            }
            catch (Exception)
            {
                client.Abort();
                throw;
            }
        }
    }
}
