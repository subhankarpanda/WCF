﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace FASTWCFHelpers.Utilities
{
    public class XmlType : ISerializer
    {
        string filePath = string.Empty;

        private XmlWriterSettings WriterSettings
        {
            get
            {
                return new XmlWriterSettings
                {
                    Indent = true,
                    IndentChars = "\t"
                };
            }
        }

        public XmlType()
        {

        }
        public XmlType(string outputPath)
        {
            this.filePath = outputPath;
        }

        public object Deserialize(Type objectType, string xmlSerializedObject)
        {
            object serviceRequest = new object();
            using (var fs = new StreamReader(xmlSerializedObject, Encoding.Default, true))
            {
                var reader = XmlReader.Create(fs);
                var serializer = new XmlSerializer(objectType);
                serviceRequest = serializer.Deserialize(reader);
                fs.Close();
            }
            return serviceRequest;
        }
        public T Deserialize<T>(string xmlSerializedObject)
        {
            try
            {
                object serviceRequest = typeof(T);

                var fs = new FileStream(xmlSerializedObject, FileMode.Open, FileAccess.ReadWrite);
                var reader = XmlReader.Create(fs);
                var serializer = new XmlSerializer(typeof(T));
                serviceRequest = serializer.Deserialize(reader);
                fs.Close();

                /*using (var fs = new StreamReader(xmlSerializedObject, Encoding.Default, true))
                {
                    var reader = XmlReader.Create(fs);
                    var serializer = new XmlSerializer(typeof(T));
                    serviceRequest = serializer.Deserialize(reader);
                    fs.Close();
                }*/

                return (T)serviceRequest;
            }
            catch
            {
                throw;
            }
        }

        public string Serialize<T>(T objectToSerialize)
        {
            string result = string.Empty;
            var serializer = new DataContractSerializer(typeof(T));
            using (var stream = new System.IO.MemoryStream())
            {
                using (var writer = XmlWriter.Create(this.filePath, WriterSettings))
                {
                    serializer.WriteObject(writer, objectToSerialize);
                }
                result = System.Text.Encoding.Default.GetString(stream.ToArray());
            }
            return result;

        }
    }
}
