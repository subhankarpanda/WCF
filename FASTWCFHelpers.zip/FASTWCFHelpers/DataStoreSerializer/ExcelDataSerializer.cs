﻿using System;
using System.IO;
using System.Linq;
using System.Xml;
using SeleniumInternalHelpersSupportLibrary;
using FASTWCFHelpers.Utilities;
using MyExcel = Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.Text.RegularExpressions;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using FASTWCFHelpers.Factories;



namespace FASTWCFHelpers
{
    public class ExcelDataSerializer
    {
        static bool displayeMessage = true;
       
        public static T GetRequestThruExcelDataStore<T>(WCFTestDataStoreEntity reqParams)
        {
            if (displayeMessage)
            {
                Reports.TestStep = "CHECK IF THE REQUIRED EXCEL FILE : [" + reqParams.workBookName + "] HAS BEEN COPIED TO THE DEPLOYMENT DIRECTORY.";
                displayeMessage = false;
            }

            if(File.Exists(Reports.DEPLOYDIR + "\\" + reqParams.workBookName))
            {
                Reports.StatusUpdate("THE REQUIRED EXCEL WORKBOOK IS AVAILABLE IN THE DEPLOYMENT DIRECTORY.", true);
            }
            else
            {
                Reports.StatusUpdate("THE REQUIRED EXCEL WORKBOOK IS NOT AVAILABLE IN THE DEPLOYMENT DIRECTORY ! ABORTING THE TEST...", false);
                throw new Exception("THE REQUIRED EXCEL WORKBOOK"+reqParams.workBookName+" IS NOT AVAILABLE IN THE DEPLOYMENT DIRECTORY !");
            }
            Reports.TestStep = "CREATE XML REQUEST WITH DATA FROM EXCEL WORKBOOK : [" + reqParams.workBookName + "] WORKSHEET : [" + reqParams.workSheetName + "] COLUMN NO : [" + reqParams.columnNo + "]";
            Reports.StatusUpdate("Beginning the creation of XML Request...!", true);
            string XMLFile = Construct_XML_From_XL(reqParams.workBookName, reqParams.workSheetName, reqParams.columnNo);
            ISerializer serializer = new XmlType();
            var serviceRequest = serializer.Deserialize<T>(XMLFile);
            return (T)serviceRequest;
        }




        public static string BuildXMLFromXLWithOpenXML(string excelfile, string sheetname, int datacolumn)
        {
            try
            {
                if (!File.Exists(excelfile))
                {
                    return "";
                }
                using (SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.Open(excelfile, true))
                {
                    //  workbookPart = spreadsheetDocument.WorkbookPart;
                    // worksheetPart = workbookPart.WorksheetParts.First();

                    // reader = OpenXmlReader.Create(worksheetPart);

                    //var xlApp = new Excel.Application { Visible = false };

                    //MyExcel.Workbook xlWorkBook = xlApp.Workbooks.Open(excelfile);

                    //var xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.Item[sheetname];

                    // var xmlFileName = ConfigurationManager.AppSettings["basePath"] + "\\last-request.xml";

                    var methodName = excelfile.Substring((excelfile.LastIndexOf("\\")) + 1);
                    string dateTimeUpdate = "__" + DateTime.Now.ToString("yyyy-MM-ddHH_mm_ss");
                    var xmlFileName = (Reports.RUNRESULTDIR + "\\Input\\Request-" + methodName).Replace(".xml", "__" + sheetname + dateTimeUpdate + ".xml");
                    xmlFileName = "C:\\Users\\myabdul\\Desktop\\IEMessages.xml";
                    var i = 2;
                    var isFirst = true;

                    while (true) // endoftest
                    {
                        //if (xlWorkSheet.Cells[i, 1].Value2 != null)
                        var firstColumnValue = new ExcelDocument(excelfile).GetCell(spreadsheetDocument, sheetname, i, "1").CellValue.Text;
                        if (firstColumnValue != null)
                        {
                            //string xPath = xlWorkSheet.Cells[i, 1].Value2.ToString();
                            string xPath = firstColumnValue;
                            if (xPath.Equals("endoftest"))
                            {
                                break;
                            }

                            Cell cellObject = new ExcelDocument(excelfile).GetCell(spreadsheetDocument, sheetname, i, datacolumn.ToString());

                            if (cellObject.CellValue.Text != null)
                            {
                                //string xPathValue = xlWorkSheet.Cells[i, datacolumn].Value2.ToString();
                                string xPathValue = cellObject.CellValue.Text;

                                var doc = new XmlDocument();
                                if (isFirst)
                                {
                                    using (var rfile = new FileStream(xmlFileName, FileMode.Create))
                                    {
                                        XmlNode docNode = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
                                        doc.AppendChild(docNode);

                                        string[] allNodes = xPath.Split('.');

                                        XmlNode xNode1 = doc.CreateElement(allNodes[0]);
                                        doc.AppendChild(xNode1);
                                        doc.Save(rfile);
                                    }
                                    isFirst = false;
                                }
                                doc.Load(xmlFileName);

                                string xPathString = "";

                                if (xPath.Contains("."))
                                {
                                    string[] allNodes = xPath.Split('.');
                                    var xNode = doc.SelectSingleNode("/" + allNodes[0]);
                                    for (int j = 0; j < allNodes.GetLength(0); j++)
                                    {
                                        xPathString = xPathString + "/" + allNodes[j];
                                        try
                                        {
                                            XmlNode iNode = doc.SelectSingleNode(xPathString);

                                            if (iNode == null)
                                            {
                                                XmlNode xNode1 = doc.CreateElement(allNodes[j]);
                                                if (xNode != null)
                                                    xNode = xNode.AppendChild(xNode1);
                                            }
                                            else
                                            {
                                                xNode = iNode;
                                            }
                                        }
                                        catch (Exception e) { string s = e.Message; }
                                    }

                                    if (xNode != null) xNode.InnerText = xPathValue;
                                }

                                doc.Save(xmlFileName);
                            }
                        }
                        else
                        {
                            break;
                        }

                        i = i + 1;
                    }

                    var contents = "";

                    using (var reader = new StreamReader(xmlFileName))
                    {
                        contents = reader.ReadToEnd();
                        contents = Regex.Replace(contents, "Array[0-9]", "");
                    }

                    using (var writer = new StreamWriter(xmlFileName))
                    {
                        writer.Write(contents);
                    }
                    //xlApp.Workbooks.Close();
                    //xlApp.Quit();
                    spreadsheetDocument.Close();

                    return xmlFileName;
                }
            }
            catch (Exception ex)
            {
                return "test";
            }
        }



        public static string Construct_XML_From_XL(string excelfile, string sheetname, int datacolumn)
        {
            try
            {
                if (!System.IO.Directory.Exists(Reports.RUNRESULTDIR + "\\Input"))
                {
                    System.IO.Directory.CreateDirectory(Reports.RUNRESULTDIR + "\\Input");
                }

                Support.CloseAllProcessStartingWith("EXCEL");

                MyExcel.Workbook xlWorkBook = null;
                var methodName = excelfile.Substring((excelfile.LastIndexOf("\\")) + 1);
                string dateTimeUpdate = "__" + DateTime.Now.ToString("yyyy-MM-dd_HH_mm_ss");
                var xmlFileName = (Reports.RUNRESULTDIR + "\\Input\\Request-" + methodName).Replace(".xml", "__" + sheetname + dateTimeUpdate + ".xml");
                var i = 2;
                var isFirst = true;

                var xlApp = new Excel.Application { Visible = false };
                try
                {
                    xlWorkBook = xlApp.Workbooks.Open(Reports.DEPLOYDIR + "\\" + excelfile);
                }
                catch(Exception e)
                {
                    Reports.StatusUpdate("Error in opening the Excel work book :" + excelfile + " from the Deployment Directory :" + Reports.DEPLOYDIR+"\n Message :"+e.Message, false);
                }
                 var xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.Item[sheetname];
                
                while (true) // endoftest
                {
                    if (xlWorkSheet.Cells[i, 1].Value2 != null)
                    {
                        string xPath = xlWorkSheet.Cells[i, 1].Value2.ToString();
                        if (xPath.Equals("endoftest"))
                        {
                            Reports.StatusUpdate("Reached the end of the file !", true);
                            break;
                        }

                        if (xlWorkSheet.Cells[i, datacolumn].Value2 != null)
                        {
                            string xPathValue = xlWorkSheet.Cells[i, datacolumn].Value2.ToString();

                            var doc = new XmlDocument();
                            if (isFirst)
                            {
                                using (var rfile = new FileStream(xmlFileName, FileMode.Create))
                                {
                                    XmlNode docNode = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
                                    doc.AppendChild(docNode);

                                    string[] allNodes = xPath.Split('.');

                                    XmlNode xNode1 = doc.CreateElement(allNodes[0]);
                                    doc.AppendChild(xNode1);
                                    doc.Save(rfile);
                                }
                                isFirst = false;
                            }
                            doc.Load(xmlFileName);

                            string xPathString = "";

                            if (xPath.Contains("."))
                            {
                                string[] allNodes = xPath.Split('.');
                                var xNode = doc.SelectSingleNode("/" + allNodes[0]);
                                for (int j = 0; j < allNodes.GetLength(0); j++)
                                {
                                    xPathString = xPathString + "/" + allNodes[j];
                                    try
                                    {
                                        XmlNode iNode = doc.SelectSingleNode(xPathString);

                                        if (iNode == null)
                                        {
                                            XmlNode xNode1 = doc.CreateElement(allNodes[j]);
                                            if (xNode != null)
                                                xNode = xNode.AppendChild(xNode1);
                                        }
                                        else
                                        {
                                            xNode = iNode;
                                        }
                                    }
                                    catch (Exception e) { string s = e.Message; }
                                }

                                if (xNode != null) xNode.InnerText = xPathValue;
                            }
                            doc.Save(xmlFileName);
                        }
                    }
                    else
                    {
                        break;
                    }

                    i = i + 1;
                }

                var contents = "";
                try
                {
                    using (var reader = new StreamReader(xmlFileName))
                    {
                        contents = reader.ReadToEnd();
                        contents = Regex.Replace(contents, "Array[0-9]", "");
                    }
                }
                catch(Exception e)
                {
                    Reports.StatusUpdate("Exception occurred while reading the contents of the XML Request file :"+xmlFileName +" created with the data from the Excel workbook :"+excelfile, false);
                }

                try
                {
                    using (var writer = new StreamWriter(xmlFileName))
                    {
                        writer.Write(contents);
                    }
                }
                catch (Exception e)
                {
                    Reports.StatusUpdate("Exception occurred while writing the contents back to the XML Request file :" + xmlFileName + " created with the data from the Excel workbook :" + excelfile, false);
                }

                xlApp.Workbooks.Close();
                xlApp.Quit();

                return xmlFileName;
            }
            catch(Exception ex)
            {
                Reports.StatusUpdate("Exception occurred while creating XML Request file from the Excel workbook :"+excelfile.Substring((excelfile.LastIndexOf("\\")) + 1) +"Details :" + ex.Message,false);
                return "";
            }
        }



      /*  public static object InvokeServiceMethodByInstanceAndRequest(object serviceInstance, string operationName, params object[] request)
        {

            object serviceResponse = new object();
            try
            {
                using (new Impersonator())
                {


                    serviceResponse = serviceInstance.GetType().GetMethod(operationName).Invoke(serviceInstance, request);
                    Reports.StatusUpdate("Service " + operationName + " Invoked Successfully", true);
                    //  CreateXML("Output", operationName, serviceInstance, serviceResponse);
                }
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Error Occured during Service Invocation" + ex.ToString(), false);
                // Assert.Fail("Error Occured during service invocation" + ex.ToString());
            }
            return serviceResponse;
        }*/

    }




    /// <summary>
    /// Interface defining Excel Document methods
    /// </summary>
    public interface IExcelDocument
    {
        /// <summary>
        /// Reads a value of a spreadsheet cell
        /// </summary>
        /// <param name="sheetName">Name of the spreadsheet</param>
        /// <param name="cellCoordinates">Cell coordinates e.g. A1</param>
        /// <returns>Value of the specified cell</returns>
        //CellValue ReadCell(string sheetName, string cellCoordinates);

        /// <summary>
        /// Updates a value of a spreadsheet cell
        /// </summary>
        /// <param name="sheetName">Name of the spreadsheet</param>
        /// <param name="cellCoordinates">Cell coordinates e.g. A1</param>
        /// <param name="cellValue">New cell value</param>
        //void UpdateCell(string sheetName, string cellCoordinates, object cellValue);

        /// <summary>
        /// Refreshes the workbook to recalculate all formula cell values
        /// </summary>
        // void Refresh();
    }




    public class ExcelDocument : IExcelDocument
    {
        private readonly string _filePath;

        public ExcelDocument(string filePath)
        {
            _filePath = filePath;
        }



        /// <see cref="IExcelDocument.ReadCell" />
        /* public CellValue ReadCell(string sheetName, string cellCoordinates)
         {
             using (SpreadsheetDocument excelDoc = SpreadsheetDocument.Open(_filePath, false))
             {
                 Cell cell = GetCell(excelDoc, sheetName, cellCoordinates);
                 return cell.CellValue;
             }
         }*/

        /// <see cref="IExcelDocument.UpdateCell" />
        /*  public void UpdateCell(string sheetName, string cellCoordinates, object cellValue)
          {
              using (SpreadsheetDocument excelDoc = SpreadsheetDocument.Open(_filePath, true))
              {
                  // tell Excel to recalculate formulas next time it opens the doc
                  excelDoc.WorkbookPart.Workbook.CalculationProperties.ForceFullCalculation = true;
                  excelDoc.WorkbookPart.Workbook.CalculationProperties.FullCalculationOnLoad = true;

                  WorksheetPart worksheetPart = GetWorksheetPart(excelDoc, sheetName);
                  Cell cell = GetCell(worksheetPart, cellCoordinates);
                  cell.CellValue = new CellValue(cellValue.ToString());
                  worksheetPart.Worksheet.Save();
              }
          }*/

        /// <summary>Refreshes an Excel document by opening it and closing in background by the Excep Application</summary>
        /// <see cref="IExcelDocument.Refresh" />
        /*    public void Refresh()
            {
                var excelApp = new Application();
                Workbook workbook = excelApp.Workbooks.Open(Path.GetFullPath(_filePath));
                workbook.Close(true);
                excelApp.Quit();
            }*/

        private WorksheetPart GetWorksheetPart(SpreadsheetDocument excelDoc, string sheetName)
        {
            Sheet sheet = excelDoc.WorkbookPart.Workbook.Descendants<Sheet>().SingleOrDefault(s => s.Name == sheetName);
            if (sheet == null)
            {
                throw new ArgumentException(
                    String.Format("No sheet named {0} found in spreadsheet {1}", sheetName, _filePath), "sheetName");
            }
            return (WorksheetPart)excelDoc.WorkbookPart.GetPartById(sheet.Id);
        }

        public Cell GetCell(SpreadsheetDocument excelDoc, string sheetName, int rowIndex, string columnName)
        {
            WorksheetPart worksheetPart = GetWorksheetPart(excelDoc, sheetName);
            return GetCell(worksheetPart, rowIndex, columnName);
        }

        private Cell GetCell(WorksheetPart worksheetPart, int rowIndex, string columnName)
        {
            //int rowIndex = int.Parse(cellCoordinates.Substring(1));
            Row row = GetRow(worksheetPart, rowIndex);
            if (row == null)
            {
                return null;
            }

            Cell cell = row.Elements<Cell>().FirstOrDefault(c => (columnName + rowIndex).Equals(c.CellReference.Value));
            if (cell == null)
            {
                throw new ArgumentException(String.Format("Cell {0} not found in spreadsheet", columnName + rowIndex));
            }
            return cell;
        }

        private Row GetRow(WorksheetPart worksheetPart, int rowIndex)
        {
            Row row = worksheetPart.Worksheet.GetFirstChild<SheetData>().
                                    Elements<Row>().FirstOrDefault(r => r.RowIndex == rowIndex);
            if (row == null)
            {
                throw new ArgumentException(String.Format("No row with index {0} found in spreadsheet", rowIndex));
            }
            return row;
        }
    }


    class MSDNOpenXMLExamples
    {
        static void ReadExcelFileSAX(string fileName)
        {
            using (SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.Open(fileName, false))
            {
                WorkbookPart workbookPart = spreadsheetDocument.WorkbookPart;
                WorksheetPart worksheetPart = workbookPart.WorksheetParts.First();

                OpenXmlReader reader = OpenXmlReader.Create(worksheetPart);
                string text;
                while (reader.Read())
                {
                    if (reader.ElementType == typeof(CellValue))
                    {
                        text = reader.GetText();
                        Console.Write(text + " ");
                    }
                }
                Console.WriteLine();
                Console.ReadKey();
            }
        }


        static void ReadExcelFileDOM(string fileName, string sheetName = "")
        {
            using (SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.Open(fileName, false))
            {
                WorkbookPart workbookPart = spreadsheetDocument.WorkbookPart;
                WorksheetPart worksheetPart = workbookPart.WorksheetParts.First();
                SheetData sheetData = worksheetPart.Worksheet.Elements<SheetData>().First();
                string text;
                foreach (Row r in sheetData.Elements<Row>())
                {
                    foreach (Cell c in r.Elements<Cell>())
                    {
                        text = c.CellValue.Text;
                        Console.Write(text + " ");
                    }
                }
                Console.WriteLine();
                Console.ReadKey();
            }
        }
    }



    //public static T GetBaseRequest<T>(string excelFile, string dataSheet, int dataColumn)
    //{
    //    object serviceRequest = new object();
    //    String Filepath = @"D:\TFS Map2\WorkCopy\FASTSelenium_FAMOS\TestData\";
    //    String XLFile = Filepath + excelFile;
    //    string XMLFile = Construct_XML_From_XL(XLFile, dataSheet, dataColumn);
    //    try
    //    {
    //        ISerializer serializer = new CustomXmlSerializer();
    //        var xmlFileName = XMLFile;

    //        if (!string.IsNullOrEmpty(xmlFileName))
    //        {
    //            var fs = new FileStream(xmlFileName, FileMode.Open);
    //            var reader = XmlReader.Create(fs);
    //            //var writer = XmlWriter.Create(Filepath + "temp.xml");
    //            //writer.WriteNode(reader, true);
    //            //writer.Close();
    //            ////    var serializer = new XmlSerializer(objectType);
    //            //serviceRequest = serializer.Deserialize<T>(Filepath + "temp.xml");
    //            serviceRequest = serializer.Deserialize<T>(reader.ToString());
    //            fs.Close();
    //        }
    //    }
    //    catch (Exception ex)
    //    {

    //    }
    //    return (T)serviceRequest;            
    //}

}
