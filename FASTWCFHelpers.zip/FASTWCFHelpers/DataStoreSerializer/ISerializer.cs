﻿using System;
namespace FASTWCFHelpers.Utilities
{
    public interface ISerializer
    {
        /// <summary>
        /// Generic DeSerialization if Type is known
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="serializedObject"></param>
        /// <returns></returns>
        T Deserialize<T>(string serializedObject);
        /// <summary>
        /// Serializate the Type Passed
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="objectToSerialize"></param>
        /// <returns></returns>
        string Serialize<T>(T objectToSerialize);
        /// <summary>
        /// Generic DeSerialization if Type is Unknown
        /// </summary>
        /// <param name="objectType"></param>
        /// <param name="xmlSerializedObject"></param>
        /// <returns></returns>
        object Deserialize(Type objectType, string xmlSerializedObject);
    }
}
