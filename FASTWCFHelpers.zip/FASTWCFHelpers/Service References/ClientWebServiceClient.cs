﻿using System.Diagnostics;
using System;
using System.Web.Services.Protocols;
using System.ComponentModel;
using System.Web.Services;
using System.Xml;


[DebuggerStepThrough()]
[DesignerCategory("code")]
[WebServiceBinding(Name = "FASTOrderEntryWebService_ReceiveOrderOrchestration_ReceiveRequestPortSoap", Namespace = "http://TitleBizTalk.FirstAm.net/")]
public class ClientWebServiceClient : SoapHttpClientProtocol
{
    public ClientWebServiceClient(string url)
    {
        this.Url = url;
    }

    [SoapDocumentMethod("http://TitleBizTalk.FirstAm.net/FASTOrderEntryWebService_ReceiveOrderOrchestratio" + "n_ReceiveRequestPort/ReceiveOrder", RequestNamespace = "http://TitleBizTalk.FirstAm.net/", ResponseNamespace = "http://TitleBizTalk.FirstAm.net/", Use = System.Web.Services.Description.SoapBindingUse.Literal, ParameterStyle = System.Web.Services.Protocols.SoapParameterStyle.Wrapped)]
    public void ReceiveOrder(ref string part)
    {
        object[] results = this.Invoke("ReceiveOrder", new object[] {
                    part});
        part = ((string)(results[0]));
    }

    public IAsyncResult BeginReceiveOrder(string part, AsyncCallback callback, object asyncState)
    {
        return this.BeginInvoke("ReceiveOrder", new object[] {
                    part}, callback, asyncState);
    }

    public void EndReceiveOrder(IAsyncResult asyncResult, out string part)
    {
        object[] results = this.EndInvoke(asyncResult);
        part = ((string)(results[0]));
    }

    public string GetRequestXML(string OfficeBUID, string SubmittingParty, string ExternalFileNumber)
    {
        XmlDocument m_RequestDoc = new XmlDocument();

        string requestXml = string.Empty;

        try
        {
            m_RequestDoc.Load(@".\DataFile\Request.xml");

            // Set Submitting Party for TITLE_REQUEST or CLOSING_REQUEST xml only
            if (SubmittingParty != string.Empty)
            {
                XmlNode submittingPartyNode = null;
                if (m_RequestDoc.DocumentElement.LocalName == "REQUEST_GROUP")
                {
                    submittingPartyNode = m_RequestDoc.SelectSingleNode("/REQUEST_GROUP/SUBMITTING_PARTY");
                }

                if (submittingPartyNode != null)
                {
                    submittingPartyNode.SelectSingleNode("@_Identifier").InnerText = SubmittingParty;
                    submittingPartyNode.SelectSingleNode("@_Name").InnerText = "";
                }
            }
            else
            {
                Debug.Write("Submitting party is empty.");
            }

            #region save for later
            // Set InternalAccountIdentifier for TITLE_REQUEST or CLOSING_REQUEST xml only
            //if (txtIntAccntID.Text.Trim() != string.Empty)
            //{
            //    if (m_RequestDoc.DocumentElement.LocalName == "REQUEST_GROUP")
            //    {
            //        m_RequestDoc.SelectSingleNode("/REQUEST_GROUP/REQUEST/@InternalAccountIdentifier").InnerText = txtIntAccntID.Text.Trim();
            //    }
            //}
            #endregion

            XmlNodeList collKeys = null;
            if (m_RequestDoc.DocumentElement.LocalName == "REQUEST_GROUP")
            {
                collKeys = m_RequestDoc.SelectNodes("/REQUEST_GROUP/REQUEST/KEY");
            }
            else
            {
                if (m_RequestDoc.DocumentElement.LocalName == "RESPONSE_GROUP")
                {
                    collKeys = m_RequestDoc.SelectNodes("/RESPONSE_GROUP/RESPONSE/KEY");
                }
            }

            // Set GlobalTransactionIdentifier
            if (ExternalFileNumber != string.Empty)
            {
                foreach (XmlNode keyNode in collKeys)
                {
                    if (keyNode.Attributes["_Name"].Value == "GlobalTransactionIdentifier")
                    {
                        keyNode.Attributes["_Value"].Value = ExternalFileNumber;
                    }
                }
            }

            // Set OrderIdentifier
            if (OfficeBUID != string.Empty)
            {
                foreach (XmlNode keyNode in collKeys)
                {
                    if (keyNode.Attributes["_Name"].Value == "OrderIdentifier")
                    {
                        keyNode.Attributes["_Value"].Value = OfficeBUID;
                    }
                }
            }

            XmlNode titleReqNode = m_RequestDoc.SelectSingleNode("/REQUEST_GROUP/REQUEST/REQUEST_DATA/TITLE_REQUEST");
            XmlNode closingReqNode = m_RequestDoc.SelectSingleNode("/REQUEST_GROUP/REQUEST/REQUEST_DATA/CLOSING_REQUEST");
            XmlNode titleRespNode = m_RequestDoc.SelectSingleNode("/RESPONSE_GROUP/RESPONSE/RESPONSE_DATA/TITLE_RESPONSE");
            XmlNode closingRespNode = m_RequestDoc.SelectSingleNode("/RESPONSE_GROUP/RESPONSE/RESPONSE_DATA/CLOSING_RESPONSE");

            // Set OfficeIdentifier for TITLE_REQUEST xml only
            if (OfficeBUID != string.Empty)
            {
                if (titleReqNode != null)
                {
                    titleReqNode.Attributes["OfficeIdentifier"].Value = OfficeBUID;
                }

            }

            // Set ClosingOfficeIdentifier for CLOSING_REQUEST or CLOSING_RESPONSE xml only
            if (OfficeBUID != string.Empty)
            {
                if (closingReqNode != null)
                {
                    closingReqNode.Attributes["ClosingOfficeIdentifier"].Value = OfficeBUID;
                }

                if (closingRespNode != null)
                {
                    closingRespNode.Attributes["ClosingOfficeIdentifier"].Value = OfficeBUID;
                }
            }

            #region save for later
            // Set VendorTransactionIdentifier
            //if (txtVendorTranID.Text.Trim() != string.Empty)
            //{
            //    if (titleReqNode != null)
            //    {
            //        titleReqNode.Attributes["VendorTransactionIdentifier"].Value = txtVendorTranID.Text;
            //    }

            //    if (closingReqNode != null)
            //    {
            //        closingReqNode.Attributes["VendorTransactionIdentifier"].Value = txtVendorTranID.Text;
            //    }

            //    if (titleRespNode != null)
            //    {
            //        titleRespNode.SelectSingleNode("PRODUCT_FULFILLMENT/@VendorTransactionIdentifier").InnerText = txtVendorTranID.Text;
            //    }

            //    if (closingRespNode != null)
            //    {
            //        closingRespNode.SelectSingleNode("PRODUCT_FULFILLMENT/@VendorTransactionIdentifier").InnerText = txtVendorTranID.Text;
            //    }
            //}

            // Set VendorOrderIdentifier
            //if (txtVendorOrderID.Text.Trim() != string.Empty)
            //{
            //    if (titleReqNode != null)
            //    {
            //        titleReqNode.Attributes["VendorOrderIdentifier"].Value = txtVendorOrderID.Text;
            //    }

            //    if (closingReqNode != null)
            //    {
            //        closingReqNode.Attributes["VendorOrderIdentifier"].Value = txtVendorOrderID.Text;
            //    }

            //    if (titleRespNode != null)
            //    {
            //        titleRespNode.SelectSingleNode("PRODUCT_FULFILLMENT/@VendorOrderIdentifier").InnerText = txtVendorOrderID.Text;
            //    }

            //    if (closingRespNode != null)
            //    {
            //        closingRespNode.SelectSingleNode("PRODUCT_FULFILLMENT/@VendorOrderIdentifier").InnerText = txtVendorOrderID.Text;
            //    }
            //}

            #endregion

            requestXml = m_RequestDoc.OuterXml;
        }
        catch (Exception ex)
        {
            Debug.Write(ex.Message);
            requestXml = string.Empty;
            return requestXml;
        }

        return requestXml;
    }

    public void Close()
    {
        base.Dispose();
    }
}
