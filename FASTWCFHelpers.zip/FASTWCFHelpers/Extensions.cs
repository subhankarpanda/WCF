﻿using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers
{
    public static class FastEscrowServiceExtensions
    {
        public static void CompareTo(this FASTWCFHelpers.FastEscrowService.FACCSummary received, FASTWCFHelpers.FastEscrowService.FACCSummary expected)
        {
            Reports.TestStep = "Verify FACC Summary";
            Support.AreEqual(received.BuyerCharge.ToString("N2"), expected.BuyerCharge.ToString("N2"), "BuyerCharge");
            Support.AreEqual(received.CalculatedRate.ToString("N2"), expected.CalculatedRate.ToString("N2"), "CalculatedRate");
            Support.AreEqual(received.ChargeTo, expected.ChargeTo, "ChargeTo");
            Support.AreEqual(received.ChargeToCdID.ToString(), expected.ChargeToCdID.ToString(), "ChargeToCdID");
            Support.AreEqual(received.FACCFeeDescription, expected.FACCFeeDescription, "FACCFeeDescription");
            Support.AreEqual(received.FASTFeeDescription, expected.FASTFeeDescription, "FASTFeeDescription");
            Support.AreEqual(received.FASTProductCategory.ToString(), expected.FASTProductCategory.ToString(), "FASTProductCategory");
            Support.AreEqual(received.FeeCalcTypeCdID.ToString(), expected.FeeCalcTypeCdID.ToString(), "FeeCalcTypeCdID");
            Support.AreEqual(received.FeeTypeCdID.ToString(), expected.FeeTypeCdID.ToString(), "FeeTypeCdID");
            Support.AreEqual(received.IsFACCCalculated.ToString(), expected.IsFACCCalculated.ToString(), "IsFACCCalculated");
            Support.AreEqual(received.OverrideAmount.ToString("N2"), expected.OverrideAmount.ToString("N2"), "OverrideAmount");
            Support.AreEqual(received.OverrideID.ToString(), expected.OverrideID.ToString(), "OverrideID");
            Support.AreEqual(received.OverrideReason.ToString(), expected.OverrideReason.ToString(), "OverrideReason");
            Support.AreEqual(received.TotalCharge.ToString("N2"), expected.TotalCharge.ToString("N2"), "");
        }

        public static void CompareTo(this FASTWCFHelpers.FastEscrowService.FACCRecordingFee received, FASTWCFHelpers.FastEscrowService.FACCRecordingFee expected)
        {
            Reports.TestStep = "Verify FACC Recording Fee";
            Support.AreEqual(received.ConsiderationAmnt.ToString("N2"), expected.ConsiderationAmnt.ToString("N2"), "ConsiderationAmnt");
            Support.AreEqual(received.IsFACCCalculated.ToString(), expected.IsFACCCalculated.ToString(), "IsFACCCalculated");
            Support.AreEqual(received.Pages.ToString(), expected.Pages.ToString(), "Pages");
            Support.AreEqual(received.RecordDocumentFACCDescr, expected.RecordDocumentFACCDescr, "RecordDocumentFACCDescr");
            Support.AreEqual(received.RecordDocumentName, expected.RecordDocumentName, "RecordDocumentName");
            Support.AreEqual(received.RecordDocumentObjectCD, expected.RecordDocumentObjectCD, "RecordDocumentObjectCD");
            Support.AreEqual(received.RecordDocumentTypeID.ToString(), expected.RecordDocumentTypeID.ToString(), "RecordDocumentTypeID");
        }

        public static void CompareTo(this FASTWCFHelpers.FastEscrowService.TransactionInformation received, FASTWCFHelpers.FastEscrowService.TransactionInformation expected)
        {
            Reports.TestStep = "Verify Transaction Information";
            Support.AreEqual(received.City, expected.City, "City");
            Support.AreEqual(received.County, expected.County, "County");
            Support.AreEqual(received.FirstNewLoanLiabilityAmnt.ToString("N2"), expected.FirstNewLoanLiabilityAmnt.ToString("N2"), "FirstNewLoanLiabilityAmnt");
            Support.AreEqual(received.FirstOwnerPolicyLiabilityAmnt.ToString("N2"), expected.FirstOwnerPolicyLiabilityAmnt.ToString("N2"), "FirstOwnerPolicyLiabilityAmnt");
            Support.AreEqual(received.LoanAmount.ToString("N2"), expected.LoanAmount.ToString("N2"), "LoanAmount");
            Support.AreEqual(received.SalesPriceAmount.ToString("N2"), expected.SalesPriceAmount.ToString("N2"), "SalesPriceAmount");
            Support.AreEqual(received.State, expected.State, "State");
            Support.AreEqual(received.TransactionTypeDescr, expected.TransactionTypeDescr, "TransactionTypeDescr");
            Support.AreEqual(received.TransactionTypeID.ToString(), expected.TransactionTypeID.ToString(), "TransactionTypeID");
            Support.AreEqual(received.UnderWriterDescr, expected.UnderWriterDescr, "UnderWriterDescr");
            Support.AreEqual(received.UnderWriterID.ToString(), expected.UnderWriterID.ToString(), "UnderWriterID");
            Support.AreEqual(received.ZipCode, expected.ZipCode, "ZipCode");
        }

        public static void CompareTo(this FASTWCFHelpers.FastFileService.LicenseDetails received, FASTWCFHelpers.FastFileService.LicenseDetails expected)
        {
            Support.AreEqual(expected.NMLSLicenseNo, received.NMLSLicenseNo, "NMLSLicenseNo");
            Support.AreEqual(expected.StateLicenseNo, expected.StateLicenseNo, "StateLicenseNo");
        }

        public static void CompareTo(this FASTWCFHelpers.FastFileService.OfficeInfo received, FASTWCFHelpers.FastFileService.OfficeInfo expected)
        {
            Support.AreEqual(expected.OfficeSTLicenseNo, expected.OfficeSTLicenseNo, "StateLicenseNo");
        }
    }

    public static class DecimalExtension
    {
        internal static string ToString(this decimal? num, string format)
        {
            return num == null ? "" : ((Decimal)num).ToString(format);
        }

        public static bool HasProperty(this object obj, string propertyName)
        {
            return obj.GetType().GetProperty(propertyName) != null;
        }
    }
}
