﻿using System.Diagnostics;
using System.ServiceModel;
using System.Threading;
using FASTWCFHelpers.DataObjects;
using FASTWCFHelpers.Factories;
using System;
using FASTWCFHelpers.FastEscrowService;
using SeleniumInternalHelpersSupportLibrary;


namespace FASTWCFHelpers
{
    public static class EscrowService
    {
        #region Adjustments
        public static AdjustmentResponse GetAdjustmentDetails(ServiceFileRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<AdjustmentResponse>(client, () => client.GetAdjustmentDetails(request));
        }
        public static OperationResponse UpdateAdjustments(AdjustmentRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.UpdateAdjustments(request));
        }
        #endregion

        #region Deposit In Escrow
        public static DepositHistoryResponse GetDepositHistorySummary(ServiceFileRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<DepositHistoryResponse>(client, () => client.GetDepositHistorySummary(request));
        }

        public static DepositViewdetailsResponse GetDepositHistoryViewDetails(DepositImagesRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<DepositViewdetailsResponse>(client, () => client.GetDepositHistoryViewDetails(request));
        }

        public static DepositListDetailsResponse GetDepositList(DepositListDetailsRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<DepositListDetailsResponse>(client, () => client.GetDepositList(request));
        }
        public static DepositInEscrowResponse CreateDepositInEscrow(DepositInEscrowRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<DepositInEscrowResponse>(client, () => client.CreateDepositInEscrow(request));
        }
        public static DepositInEscrowResponse UpdateDepositInEscrow(DepositInEscrowRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<DepositInEscrowResponse>(client, () => client.UpdateDepositInEscrow(request));
        }
        #endregion

        public static DepositListSaveDetailsResponse SaveDepositList(DepositListSaveDetailsRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<DepositListSaveDetailsResponse>(client, () => client.SaveDepositList(request));
        }
        public static DocumentTypesResponse GetDocTypeAndDocNames(DocumentTypeRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<DocumentTypesResponse>(client, () => client.GetDocTypeAndDocNames(request));
        }

        public static GFELoanResponse GetGFEDetails(GFEDetailsRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<GFELoanResponse>(client, () => client.GetGFEDetails(request));
        }

        public static OperationResponse UpdateGFEDetails(GFELoanRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.UpdateGFEDetails(request));
        }

        public static RealEstateBrokerResponse GetRealStateBroker(ServiceFileRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<RealEstateBrokerResponse>(client, () => client.GetRealEstateBroker(request));
        }

        public static NewLoanResponse GetNewLoanDetails(NewLoanDetailsRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<NewLoanResponse>(client, () => client.GetNewLoanDetails(request));
        }

        #region File Fees
        public static FeesCalculationSummaryResponse GetCalculationFees(GetCalculationFeesRequest request)
        { 
            var client = ServiceFactory.GetEscrowService();

            return Execute<FeesCalculationSummaryResponse>(client, () => client.GetCalculationFees(request));
        }

        public static FastFeeDescriptionResponse GetFastFeeDescription(FastFeeDescriptionRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<FastFeeDescriptionResponse>(client, () => client.GetFastFeeDescription(request));
        }
        #endregion

        #region Insurance
        public static OperationResponse CreateInsurance(InsuranceRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.CreateInsurance(request));

        }
        public static InsuranceResponse GetInsuranceDetails(ServiceFileRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<InsuranceResponse>(client, () => client.GetInsuranceDetails(request));

        }
        public static OperationResponse UpdateInsurance(InsuranceRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.UpdateInsurance(request));

        }
        public static OperationResponse RemoveInsurance(InsuranceRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.RemoveInsurance(request));

        }
        #endregion

        #region Inspection Repair
        public static OperationResponse UpdateInspectionRepairOther(InspectionRepairRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.UpdateInspectionRepairOther(request));
        }
        public static InspectionRepairPestResponse UpdateInspectionRepairPest(InspectionRepairPestRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<InspectionRepairPestResponse>(client, () => client.UpdateInspectionRepairPest(request));
        }
        public static InspectionRepairSepticSaveResponse UpdateInspectionRepairSeptic(InspectionRepairSepticSaveRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<InspectionRepairSepticSaveResponse>(client, () => client.UpdateInspectionRepairSeptic(request));
        }
        public static OperationResponse CreateInspectionRepairOther(InspectionRepairRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.CreateInspectionRepairOther(request));
        }
        public static InspectionRepairPestResponse CreateInspectionRepairPest(InspectionRepairPestRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<InspectionRepairPestResponse>(client, () => client.CreateInspectionRepairPest(request));
        }
        public static InspectionRepairSepticSaveResponse CreateInspectionRepairSeptic(InspectionRepairSepticSaveRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<InspectionRepairSepticSaveResponse>(client, () => client.CreateInspectionRepairSeptic(request));
        }
        public static InspectionRepairResponse GetInspectionRepairOtherDetails(ServiceFileRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<InspectionRepairResponse>(client, () => client.GetInspectionRepairOtherDetails(request));
        }
        public static InspectionRepairPestDetailsResponse GetInspectionRepairPestDetails(InspectionRepairPestDetailsRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<InspectionRepairPestDetailsResponse>(client, () => client.GetInspectionRepairPestDetails(request));
        }
        public static InspectionRepairSepticDetailsResponse GetInspectionRepairSepticDetails(InspectionRepairSepticDetailsRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<InspectionRepairSepticDetailsResponse>(client, () => client.GetInspectionRepairSepticDetails(request));
        }
        public static InspectionRepairPestSummaryResponse GetInspectionRepairPestSummary(InspectionRepairPestSummaryRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<InspectionRepairPestSummaryResponse>(client, () => client.GetInspectionRepairPestSummary(request));
        }
        public static InspectionRepairSepticSummaryResponse GetInspectionRepairSepticSummary(InspectionRepairSepticSummaryRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<InspectionRepairSepticSummaryResponse>(client, () => client.GetInspectionRepairSepticSummary(request));
        }
        public static OperationResponse RemoveInspectionRepairOther(InspectionRepairRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.RemoveInspectionRepairOther(request));
        }
        public static InspectionRepairPestResponse RemoveInspectionRepairPest(InspectionRepairPestRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<InspectionRepairPestResponse>(client, () => client.RemoveInspectionRepairPest(request));
        }
        public static InspectionRepairSepticRemoveResponse RemoveInspectionRepairSeptic(InspectionRepairSepticRemoveRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<InspectionRepairSepticRemoveResponse>(client, () => client.RemoveInspectionRepairSeptic(request));
        }
        #endregion

        #region Outside Escrow Company
        public static OperationResponse CreateOutsideEscrowCompany(OECRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.CreateOutsideEscrowCompany(request));
        }

        public static CreateOutsideTitleCompanyResponse CreateOutsideTitleCompany(OutsideTitleCompanyRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<CreateOutsideTitleCompanyResponse>(client, () => client.CreateOutsideTitleCompany(request));
        }
        public static OperationResponse UpdateOutsideEscrowCompany(OECRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.UpdateOutsideEscrowCompanyDetails(request));
        }

        public static OperationResponse UpdateOutsideEscrowCompanyDetails(OECRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.UpdateOutsideEscrowCompanyDetails(request));
        }
        public static OECResponse GetOutsideEscrowCompanyDetails(ServiceFileRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OECResponse>(client, () => client.GetOutsideEscrowCompanyDetails(request));
        }
        public static OperationResponse DeleteOutsideEscrowCompany(OECRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.DeleteOutsideEscrowCompany(request));
        }
        #endregion

        #region Outside Title Company
        public static OTCResponse GetOutsideTitleCompanyDetails(ServiceFileRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OTCResponse>(client, () => client.GetOutsideTitleCompanyDetails(request));
        }
        public static OperationResponse UpdateOutsideTitleCompanyDetails(OTCRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.UpdateOutsideTitleCompanyDetails(request));
        }
        public static OperationResponse DeleteOutsideTitleCompany(OTCRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.DeleteOutsideTitleCompany(request));
        }
        #endregion

        public static SplitDisbDetailResponse GetSplitDisbursementDetail(SplitDisbDetailRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<SplitDisbDetailResponse>(client, () => client.GetSplitDisbursementDetail(request));
        }

        public static UpdateSplitDisbResponse UpdateSplitDisbursement(UpdateSplitDisbRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<UpdateSplitDisbResponse>(client, () => client.UpdateSplitDisbursement(request));
        }

        public static OperationResponse UpdateSiteFileStatus(UpdateSFStatus request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.UpdateSiteFileStatus(request));
        }

        public static DepositImagesResponse GetDepositImages(DepositImagesRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<DepositImagesResponse>(client, () => client.GetDepositImages(request));
        }

        public static DisbTrackResponse GetDisbursementTrackDetails(DisbTrackRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<DisbTrackResponse>(client, () => client.GetDisbursementTrackDetails(request));
        }

        public static UpdateDisbTrackResponse UpdateDisbursementTrackDetails(UpdateDisbTrackRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<UpdateDisbTrackResponse>(client, () => client.UpdateDisbursementTrackDetails(request));
        }

        public static UpdateExternalServiceNumResponse UpdateExternalServiceNumber(UpdateExternalServiceNumRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<UpdateExternalServiceNumResponse>(client, () => client.UpdateExternalServiceNumber(request));
        }
        
        public static OperationResponse InitiatePayoffRequest(PayoffLoanRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.InitiatePayoffRequest(request));
        }

        public static OperationResponse CreatePayoffLoan(PayoffLoanRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.CreatePayOffLoan(request));
        }

        public static OperationResponse UpdatePayoffLoan(PayoffLoanRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.UpdatePayOffLoan(request));
        }

        public static PayOffLoanResponse GetPayoffLoanDetails(ServiceFileRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<PayOffLoanResponse>(client, () => client.GetPayOffLoanDetails(request));
        }

        public static OperationResponse PayOffLoanPayChargesAssociation(PayOffLoanPayChargeAssociationRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.PayOffLoanPayChargesAssociation(request));
        }

        #region Property Tax Check
        public static OperationResponse UpdatePropertyTaxCheck(PropertyTaxCheckRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.UpdatePropertyTaxCheck(request));
        }

        public static OperationResponse CreatePropertyTaxCheck(PropertyTaxCheckRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.CreatePropertyTaxCheck(request));
        }

        public static OperationResponse RemovePropertyTaxCheck(PropertyTaxCheckRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.RemovePropertyTaxCheck(request));
        }

        public static PropertyTaxCheckResponse GetPropertyTaxCheckDetails(int? fileId = null)
        {
            var request = new ServiceFileRequest() {
                FileId = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
            var client = ServiceFactory.GetEscrowService();

            return Execute<PropertyTaxCheckResponse>(client, () => client.GetPropertyTaxCheckDetails(request));
        }
        #endregion

        #region Survey
        public static OperationResponse CreateSurvey(SurveyRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.CreateSurvey(request));
        }
        public static OperationResponse UpdateSurvey(SurveyRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.UpdateSurvey(request));
        }
        public static SurveyResponse GetSurveyDetails(ServiceFileRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<SurveyResponse>(client, () => client.GetSurveyDetails(request));
        }
        public static OperationResponse RemoveSurvey(SurveyRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.RemoveSurvey(request));
        }
        #endregion

        #region Utilities
        public static CreateUtilityResponse CreateUtility(UtilityRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<CreateUtilityResponse>(client, () => client.CreateUtility(request));
        }
        public static UpdateUtilityResponse UpdateUtility(UtilityRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<UpdateUtilityResponse>(client, () => client.UpdateUtility(request));
        }
        public static RemoveUtilityResponse RemoveUtility(RemoveUtilityRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<RemoveUtilityResponse>(client, () => client.RemoveUtility(request));
        }
        public static UtilityResponse GetUtilityDetails(GetUtilityRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<UtilityResponse>(client, () => client.GetUtilityDetails(request));
        }

        public static UtilitySummaryResponse GetUtilitySummaryResponse(GetUtilitySummaryRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<UtilitySummaryResponse>(client, () => client.GetUtilitySummary(request));
        }
        #endregion

        #region Prorations
        public static ProrationResponse GetProrationDetails(ServiceFileRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<ProrationResponse>(client, () => client.GetProrationDetails(request));
        }
        public static OperationResponse CreateProration(ProrationRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.CreateProration(request));
        }
        public static OperationResponse UpdateProration(ProrationRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.UpdateProration(request));
        }
        public static OperationResponse DeleteProration(ProrationRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.DeleteProration(request));
        }
        #endregion

        #region Homeowner Association
        public static OperationResponse RemoveHomeownerAssociation(HomeownerAssociationRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.RemoveHomeownerAssociation(request));
        }
        public static OperationResponse CreateHomeownerAssociation(HomeownerAssociationRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.CreateHomeownerAssociation(request));
        }
        public static OperationResponse UpdateHomeownerAssociation(HomeownerAssociationRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.UpdateHomeownerAssociation(request));
        }
        public static HomeownerAssociationResponse GetHomeownerAssociation(ServiceFileRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<HomeownerAssociationResponse>(client, () => client.GetHomeownerAssociationDetails(request));
        }
        #endregion

        public static OperationResponse CreateRealEstateBroker(RealEstateBrokerRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.CreateRealEstateBroker(request));
        }

        public static OperationResponse UpdateRealEstateBroker(RealEstateBrokerRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.UpdateRealEstateBroker(request));
        }

        public static OperationResponse RemoveRealEstateBroker(RealEstateBrokerRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.RemoveRealEstateBroker(request));
        }

        public static OperationResponse CreateAssumptionLoan(AssumptionLoanSaveRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.CreateAssumptionLoan(request));
        }

        public static AssumptionLoanDetailsResponse GetAssumptionLoanDetails(AssumptionLoanDetailsRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<AssumptionLoanDetailsResponse>(client, () => client.GetAssumptionLoanDetails(request));
        }

        public static OperationResponse UpdateAssumptionLoanDetails(AssumptionLoanSaveRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.UpdateAssumptionLoan(request));
        }

        public static AssumptionLoanSummaryResponse AssumptionLoanSummaryResponse(AssumptionLoanSummaryRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<AssumptionLoanSummaryResponse>(client, () => client.GetAssumptionLoanSummary(request));
        }

        public static RemoveAssumptionLoanResponse RemoveAssumptionLoanResponse(RemoveAssumptionLoanRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<RemoveAssumptionLoanResponse>(client, () => client.RemoveAssumptionLoanDetails(request));
        }
    
        public static DepositListDetailsResponse ReadDepositListDetails(DepositListDetailsRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<DepositListDetailsResponse>(client, () => client.ReadDepositListDetails(request));
        }

        public static GABRefreshResponse RefreshGABInfo(GABRefreshRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<GABRefreshResponse>(client, () => client.RefreshGABInfo(request));
        }

        public static OperationResponse RemoveLenderThirdPartyPayee(RemoveThirdPartyPayee request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.RemoveLenderThirdPartyPayee(request));
        }

        public static OperationResponse RemoveMortgageBrokerInformation(RemoveNewLoanRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.RemoveMortgageBrokerInformation(request));
        }

        public static OperationResponse RemoveMortgageBrokerThirdPartyPayee(RemoveThirdPartyPayee request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.RemoveMortgageBrokerThirdPartyPayee(request));
        }

        #region Subordination
        public static SubordinationSaveResponse AddSubordination(SubordinationRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.AddSubordination(request));
        }

        public static SubordinationSaveResponse UpdateSubordination(SubordinationRequest request) {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.UpdateSubordination(request));
        }

        public static DeleteSubordinationResponse DeleteSubordination(DeleteSubordinationRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.DeleteSubordination(request));
        }

        public static SubordinationDetailsResponse GetSubordinationDetails(SubordinationDetailsRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.GetSubordinationDetails(request));
        }

        public static SubordinationSummaryResponse GetSubordinationSummary(SubordinationSummaryRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.GetSubordinationSummary(request));
        }
        #endregion

        #region New Loan
        public static OperationResponse CreateNewLoan(NewLoanRequest request)
        {
            var service = ServiceFactory.GetEscrowService();

            return Execute(service, () => service.CreateNewLoan(request));
        }

        public static OperationResponse UpdateNewLoan(NewLoanRequest request)
        {
            var service = ServiceFactory.GetEscrowService();

            return Execute(service, () => service.UpdateNewLoan(request));
        }

        public static OperationResponse NewLoanMBPayChargesAssociation(NewLoanPayChargeAssociationRequest request)
        {
            var service = ServiceFactory.GetEscrowService();

            return Execute(service, () => service.NewLoanMBPayChargesAssociation(request));
        }

        public static OperationResponse NewLoanPayChargesAssociation(NewLoanPayChargeAssociationRequest request)
        {
            var service = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(service, () => service.NewLoanPayChargesAssociation(request));
        }

        public static AddLenderLoanInvestorResponse AddLenderLoanInvestor(AddLenderLoanInvestorRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.AddLenderLoanInvestor(request));
        }

        public static LoanStatusResponse GetRestrictLenderUpdateStatus(LoanStatusRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.GetRestrictLenderUpdateStatus(request));
        }

        #endregion

        #region Deposit Outside Escrow

        public static DepositOutsideEscrowResponse GetDepositOE(DepositOutsideEscrowRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.GetDepositOutSideEscrow(request));
        }

        public static OperationResponse CreateDepositOutSideEscrow(DepositOutsideEscrowSaveRequest request)
        {
            var service = ServiceFactory.GetEscrowService();

            return Execute(service, () => service.CreateDepositOutSideEscrow(request));
        }

        public static OperationResponse UpdateDepositOutSideEscrow(DepositOutsideEscrowSaveRequest request)
        {
            var service = ServiceFactory.GetEscrowService();

            return Execute(service, () => service.UpdateDepositOutSideEscrow(request));
        }
        #endregion

        #region Escrow Deposit
        public static AdjustEscrowDepositResponse AdjustEscrowDeposit(AdjustEscrowDepositRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.AdjustEscrowDeposit(request));
        }
        #endregion

        public static HoldFundsSummaryResponse GetHoldFundsSummary(HoldFundsSummaryRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.GetHoldFundsSummary(request));
        }

        public static GetHoldFundsResponse GetHoldFundsDetails(GetHoldFundsRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.GetHoldFundsDetails(request));
        }

        public static HoldFundsRemoveResponse RemoveHoldFunds(HoldFundsRemoveRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.RemoveHoldFunds(request));
        }

        public static UpdateSecondOrderSourceResponse UnlinkSecondOrderSource(UpdateSecondOrderSourceRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.UnlinkSecondOrderSource(request));
        }

        public static EditDisbursementResponse SaveEditDisbursementDetails(EditDisbursementRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.SaveEditDisbursementDetails(request));
        }

        public static OperationResponse SplitImageDocument(SplitImageDocument request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.SplitImageDocument(request));
        }

        public static OperationResponse SetCalculationFees(UpdateFeesCalculationRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.SetCalculationFees(request));
        }

        public static HoldFundsSaveResponse CreateHoldFunds(HoldFundsSaveRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.CreateHoldFunds(request));
        }

        public static HoldFundsSaveResponse UpdateHoldFunds(HoldFundsSaveRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.UpdateHoldFunds(request));
        }

        public static OperationResponse CreateInsuranceResponse(InsuranceRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.CreateInsurance(request));
        
        }

        public static InsuranceResponse GetInsuranceDetilsResponse(ServiceFileRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<InsuranceResponse>(client, () => client.GetInsuranceDetails(request));

        }

        public static OperationResponse UpdateInsuranceDetilsResponse(InsuranceRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<OperationResponse>(client, () => client.UpdateInsurance(request));

        }

        public static ExcludedReceiptLoadResponse GetExcludedReceipts(ExcludedReceiptLoadRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute<ExcludedReceiptLoadResponse>(client, () => client.GetExcludedReceipts(request));

        }

        public static SDNTrackingSummary GetSDNTrackingSummaryDetails(SDNSearchRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.GetSDNTrackingSummaryDetails(request));
        }

        public static DuplicateFileSearchResponse GetDuplicateFileSearchResults(DuplicateFileSearchRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.DuplicateFileSearch(request));
        }

        #region Work Queue
        public static OperationResponse UploadWorkQFile(WorkQueueUploadRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.UploadWorkQFile(request));
        }

        public static WorkQListResponse GetWorkQueueList(WorkQListRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.GetWorkQueueList(request));
        }

        public static OperationResponse AttachMessage(WorkQueueAttachRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.AttachMessage(request));
        }

        public static OperationResponse UpdateWorkQueueMessage(WorkQueueUpdateRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.UpdateWorkQueueMessage(request));
        }

        public static WorkQMessageLogDetailsResponse GetWorkQueueMessageLogDetails(WorkQMessageLogDetailsRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.GetWorkQueueMessageLogDetails(request));
        }

        public static WorkQueueNameResponse GetWorkQueueNames(WorkQueueNameRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.GetWorkQueueNames(request));
        }

        public static WorkQueueTriggerList GetWorkQueueTriggers(DocumentTypeRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.GetWorkQueueTriggers(request));
        }

        public static WorkQueueMessageResponse GetWorkQueueMessageDocument(WorkQueueMessageRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.GetWorkQueueMessageDocument(request));
        }
        #endregion

        public static HUDEscrowChargeResponse GetHUDEscrowCharges(GetHUDEscrowChargeRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.GetHUDEscrowCharges(request));
        }

        public static Hud1LineNumberResponse GetHud1LineNumberDetails(ServiceFileRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.GetHud1LineNumberDetails(request));
        }

        public static OperationResponse UpdateHud1LineNumbers(Hud1LineNumberRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.UpdateHud1LineNumbers(request));
        }

        public static ALTASettlementStatementResponse GetALTASettlementStatement(ALTASettlementStatementRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.GetALTASettlementStatement(request));
        }

        public static AssumptionLoanDisbursementDetailsResponse GetAssumptionLoanDisbursementDetails(AssumptionLoanDisbursementDetailsRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.GetAssumptionLoanDisbursementDetails(request));
        }

        public static OrderDetailsResponse[] GetOrderDetailsByFileIDs(int[] fileIDs)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.GetOrderDetailsByFileIDs(fileIDs));
        }

        public static FileBalanceSummaryResponse GetFileBalanceSummary(FileBalanceSummaryRequest request)
        {
            var client = ServiceFactory.GetEscrowService();
            return Execute(client, () => client.GetFileBalanceSummary(request));
        }

        public static AssumptionLoanDisbSaveResponse UpdateAssumptionLoanDisbDetails(AssumptionLoanDisbSaveRequest request)
        {
            var client = ServiceFactory.GetEscrowService();

            return Execute(client, () => client.UpdateAssumptionLoanDisbDetails(request));
        }

        public static DepositSearchResponse SearchDepositList(DepositListSearchRequest request)
        {
            var client = ServiceFactory.GetEscrowService();
            return Execute(client, () => client.SearchDepositList(request));
        }

        internal static T Execute<T>(FastEscrowServiceClient client, Func<T> lambdaFunc)
        {
            //Based on recommended practice: https://msdn.microsoft.com/en-us/library/aa355056.aspx
            try
            {
                var r = lambdaFunc.Invoke();
                client.Close();
                return r;
            }
            catch (CommunicationException e)
            {
                Debug.WriteLine(e.Message);
                client.Abort();
                throw;
            }
            catch (TimeoutException e)
            {
                Debug.WriteLine("Timeout exception: " + e.Message);
                client.Abort();
                throw;
            }
            catch (Exception)
            {
                client.Abort();
                throw;
            }
        }
    }
}
