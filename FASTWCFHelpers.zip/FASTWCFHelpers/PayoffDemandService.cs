﻿using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FISPayoffDemandClient;
using System;
using System.Diagnostics;
using System.IO;
using System.ServiceModel;
using System.Xml;
using System.Xml.Serialization;

namespace FASTWCFHelpers
{
    public class PayoffDemandService
    {
        public static ResponseStatus__Type SendRequest(int requestId, string xmlPath)
        {
            var client = ServiceFactory.GetPayoffDemandService();

            return Execute(client, () => client.notify(GetRequest(requestId, xmlPath)));
        }

        private static NotificationRequest GetRequest(int orderId, string xmlPath)
        {
            NotificationRequest notificationRequest;
            using (StreamReader streamReader = new StreamReader(xmlPath))
            {
                StringReader objStringReader = new StringReader(RemoveNamespace(streamReader.ReadToEnd()));
                XmlSerializer serializer = new XmlSerializer(typeof(NotificationRequest));
                notificationRequest = (NotificationRequest)serializer.Deserialize(objStringReader);
                notificationRequest.OrderId = (uint)orderId;
            }
            return notificationRequest;
        }

        private static string RemoveNamespace(string strXml)
        {
            XmlDocument oXMLDoc = new XmlDocument();
            oXMLDoc.LoadXml(strXml);

            string strName = oXMLDoc.DocumentElement.Name;

            int intStart = strXml.IndexOf(strName);
            string strTempXml = strXml.Substring(intStart);
            intStart = strTempXml.IndexOf(">");
            int intLen = strTempXml.Length;
            string strFinalXml = strTempXml.Remove(intStart, intLen - intStart);
            strFinalXml = strXml.Replace(strFinalXml, strName);
            oXMLDoc = null;
            return strFinalXml;
        }

        internal static T Execute<T>(FAFFISOrderNotificationSoapClient client, Func<T> lambdaFunc)
        {
            //Based on recommended practice: https://msdn.microsoft.com/en-us/library/aa355056.aspx
            try
            {
                var ret = lambdaFunc.Invoke();
                client.Close();
                return ret;
            }
            catch (CommunicationException e)
            {
                Debug.WriteLine(e.Message);
                client.Abort();
                throw;
            }
            catch (TimeoutException e)
            {
                Debug.WriteLine("Timeout exception: " + e.Message);
                client.Abort();
                throw;
            }
            catch (Exception)
            {
                client.Abort();
                throw;
            }
        }
    }
}
