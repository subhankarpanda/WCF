﻿using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastAdminService;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers
{
    public static class AdminService
    {
        public static int? GetGABAddressBookEntryId(string gabCode, int? regionBUID = null)
        {
            var gabRequest = new GABSearchRequest();
            gabRequest.BusinessUnitID = regionBUID ?? int.Parse(AutoConfig.SelectedRegionBUID);
            gabRequest.GABCode = gabCode;

            GABSearchResponse response = GABSearch(gabRequest);

            List<GABResult> allGABs = new List<GABResult>();
            allGABs.AddRange(response.GABResults);

            var activeGABs = allGABs.Where(gab => gab.StatusCD == "1").ToList();

            if (activeGABs.Count > 0)
                return activeGABs.First().GABAddrBookEntryID;
            else
                throw new Exception(string.Format("GAB code '{0}' not found.", gabCode));
        }


        public static GABSearchResponse GABSearch(GABSearchRequest gabRequest)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute<GABSearchResponse>(service, () => service.SearchGABorGABContact(gabRequest));
        }

        public static GABInfo GetGABByAddressBookEntryID(int addressBookID)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute<GABInfo>(service, () => service.GetGABByAddressBookEntryID(addressBookID));
        }

        public static ProductsResponse GetAllProducts()
        {
            var service = ServiceFactory.GetAdminService();

            return Execute<ProductsResponse>(service, () => service.GetProducts());
        }

        public static BusUnitResponse GetOffices(int regionID, Nullable<eActiveOrHiddenOffice> eActiveOrHiddenOfficeFlag)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute<BusUnitResponse>(service, () => service.GetOffices(regionID, eActiveOrHiddenOfficeFlag));
        }

        public static Countries GetCountries()
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetCountries());
        }

        public static GeoRegionResponse GetStates()
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetStates());
        }

        public static LicenseTypeResponse GetLicenseTypes(LicenseTypeRequest request)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetLicenseTypes(request));
        }

        public static GeoRegionResponse GetCounties(int stateID)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetCounties(stateID));
        }

        public static OfficeResponse GetOfficeAddress(int BUID) 
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetOfficeAddresses(BUID));
        }

        public static GeoRegionResponse GetCanadaProvinces()
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetCanadaProvinces());
        }

        public static GeoRegionResponse GetCities(int countyID)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetCities(countyID));
        }

        public static GABDetailsResponse GetGABDetails(int addressBookID, GABType eGABType)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetGABDetails(addressBookID, eGABType));
        }

        public static BusUnitResponse GetRegions(int coporateID)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetRegions(coporateID));
        }

        public static GetRegionByOfficeResponse GetRegionByOffice(GetRegionByOfficeRequest request)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetRegionByOffice(request));
        }

        public static GetSalesRepsResponse GetSalesReps(int regionID)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetSalesReps(regionID));
        }

        public static GetGABorGABContactDetailsResponse GetGABorGABContactDetails(GetGABorGABContactDetailsRequest request)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetGABorGABContactDetails(request));
        }

        public static EmployeeInfo GetEmployeeByLoginName(string loginName)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetEmployeeByLoginName(loginName));
        }

        public static ProgramTypeResponse GetProgramTypes(int regionID)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetProgramTypes(regionID));
        }

        public static EmployeeInfo GetEmployeeByEmployeeID(int employeeID)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetEmployeeByEmployeeID(employeeID));
        }

        public static EmployeeSearchResponse SearchEmployeeByType(EmployeeSearchRequest request)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.SearchEmployeeByType(request));
        }

        public static GABorGABContactsResponse GetGABorGABContactsByRegionID(GABAndGABContactsRequest request)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetGABorGABContactsByRegionId(request));
        }

        public static OfficeBankAccountResponse GetOfficeBankAccountsByOfficeID(AllOfficeBankAccountsRequest request)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetOfficeBankAccountsByOfficeID(request));
        }

        public static TaskCategoryResponse GetTaskCategoriesByRegionID(int regionID)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetTaskCategoriesByRegionID(regionID));
        }

        public static BusSourceTypeResponse GetBusinessSourceTypesByRegionID(BusSourceTypeRequest request)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetBusinessSourceTypesByRegionID(request));
        }

        public static TemplateResponse GetTaskTemplatesByCategoryID(int categoryID)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetTaskTemplatesByCategoryID(categoryID));
        }

        public static MDMContactCollection GetContactsByBusOrgId(GABRequest request)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetContactsByBusOrgId(request));
        }

        public static WorkFlowResponse GetWorkFlowTemplates(int regionID, int webCustomerTypeCDID)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetWorkFlowTemplates(regionID, webCustomerTypeCDID));
        }

        public static TaskTemplateResponse GetTaskTemplates(int workFlowTemplateID)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetTaskTemplates(workFlowTemplateID));
        }

        public static TaskTemplateCommentCodesResponse GetCommentCodesByTaskTemplateID(TaskTemplateCommentCodesRequest request)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetCommentCodesByTaskTemplateID(request));
        }

        public static VersionGABInfoResponse GetVersionedGABInfo(VersionGABInfoRequest request)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetVersionedGABInfo(request));
        }

        public static GetEmployeesByFunctionTypesResponse GetEmployeesByFunctionTypes(GetEmployeesByFunctionTypesRequest request)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetEmployeesByFunctionTypes(request));
        }

        public static GABAltAddresses GetAltAddressesByBusOrgId(GABRequest request)
        {
            var service = ServiceFactory.GetAdminService();

            return Execute(service, () => service.GetAltAddressesByBusOrgId(request));
        }

        public static T Execute<T>(FastAdminServiceClient client, Func<T> lambdaFunc)
        {
            //Based on recommended practice: https://msdn.microsoft.com/en-us/library/aa355056.aspx
            try
            {
                var r = lambdaFunc.Invoke();
                client.Close();
                return r;
            }
            catch (CommunicationException e)
            {
                Debug.WriteLine(e.Message);
                client.Abort();
                throw;
            }
            catch (TimeoutException e)
            {
                Debug.WriteLine("Timeout exception: " + e.Message);
                client.Abort();
                throw;
            }
            catch (Exception)
            {
                client.Abort();
                throw;
            }
        }
    }
}
