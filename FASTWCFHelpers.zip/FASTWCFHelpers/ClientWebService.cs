﻿using System.Diagnostics;
using System.ServiceModel;
using System;
using FASTWCFHelpers.Factories;

namespace FASTWCFHelpers
{
    public class ClientWebService
    {
        public static void SubmitRequest(string xmlRequest)
        {
            var client = ServiceFactory.GetClientWebService();
            Execute(client, () => client.ReceiveOrder(ref xmlRequest));
        }

        internal static void Execute(ClientWebServiceClient client, Action lambdaFunc)
        {
            //Based on recommended practice: https://msdn.microsoft.com/en-us/library/aa355056.aspx
            try
            {
                lambdaFunc.Invoke();
                client.Close();
            }
            catch (CommunicationException e)
            {
                Debug.WriteLine(e.Message);
                client.Abort();
                throw;
            }
            catch (TimeoutException e)
            {
                Debug.WriteLine("Timeout exception: " + e.Message);
                client.Abort();
                throw;
            }
            catch (Exception)
            {
                client.Abort();
                throw;
            }
        }
    }
}
