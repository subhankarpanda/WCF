﻿using FASTWCFHelpers.FastFileService;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers
{
    public class ClosingDisclosureSupport
    {
        public static FormType FormType
        {
            get
            {
                FastFileService.FormType formTypeInConfig;

                switch (IMDFormType)
                {
                    case "HUD":
                        formTypeInConfig = FastFileService.FormType.HUD;
                        break;
                    case "CD":
                        formTypeInConfig = FastFileService.FormType.CD;
                        break;
                    default:
                        formTypeInConfig = FastFileService.FormType.HUD;
                        break;
                }

                return formTypeInConfig;
                //return UseIMDRegion ? formTypeInConfig : FastFileService.FormType.HUD;
            }
        }

        public static string IMDFormType
        {
            get
            {
                var ret = AutoConfig.FormType;
                return string.IsNullOrEmpty(ret) ? "HUD" : ret;
            }
        }

        public static bool UseIMDRegion
        {
            get
            {
                string val = AutoConfig.UseCDRegion.ToString();
                bool res;

                return bool.TryParse(val, out res) ? res : false;
            }
        }

        public static string IMDRegion
        {
            get
            {
                var ret =  AutoConfig.SelectedRegionName;
                return ret ?? "QA Automation Region - DO NOT TOUCH";
            }
        }

        public static string IMDRegionBUID
        {
            get
            {
                var ret = AutoConfig.SelectedRegionBUID;
                return string.IsNullOrEmpty(ret) ? "1486" : ret;
            }
        }

        public static string IMDOffice
        {
            get
            {
                var ret = AutoConfig.SelectedOfficeName;
                return string.IsNullOrEmpty(ret) ? "QA Automation Office - DO NOT TOUCH" : ret;
            }
        }

        public static string IMDOfficeBUID
        {
            get
            {
                var ret = AutoConfig.SelectedOfficeBUID;
                return string.IsNullOrEmpty(ret) ? "1487" : ret;
            }
        }
    }
}
