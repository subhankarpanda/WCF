﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers.DataObjects
{
    public struct LoanTermInterestTypeCdID
    {
        public const int Annual = 2648;
        public const int AtMaturity = 2649;
        public const int BiWeekly = 2589;
        public const int Monthly = 2610;
        public const int Other = 2593;
        public const int Quarterly = 2591;
        public const int SemiAnnual = 2592;
        public const int SemiMonthly = 2650;
        public const int Weekly = 2651;
    }

    public struct LoanTermInterestTypeOCD
    {
        public const string Annual = "CDLNANNUAL";
        public const string AtMaturity = "CDLNATMATY";
        public const string BiWeekly = "CDLNBIWKLY";
        public const string Monthly = "CDLNMTHLY";
        public const string Other = "CDLNOTHER";
        public const string Quarterly = "CDLNBIQTLY";
        public const string SemiAnnual = "CDLNSMIANU";
        public const string SemiMonthly = "CDLNSEMTLY";
        public const string Weekly = "CDLNWEEKLY";
    }
}
