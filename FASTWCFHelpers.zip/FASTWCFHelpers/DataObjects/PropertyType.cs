﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers.DataObjects
{
    public abstract class PropertyTypeOCD
    {
        public const string ApartmentBuilding = "APT";
        public const string TBD = "COMM";
        public const string Condominium = "CONDO";
        public const string FarmHomesite = "FARM";
        public const string SingleFamilyResidence = "SF";
        public const string MobileHome = "MOBLHOME";
        public const string MultiFamilyResidence = "MF";
        public const string VacantLand = "VACANT";
        public const string Tract = "TRACT";
        public const string CoOp = "COOP";
        public const string CommunicationSite = "COMMSITE";
        public const string ConvenienceStoreMarket = "STOREMKT";
        public const string ConventionFacility = "COFACILITY";
        public const string EducationalFacility = "EDFACILITY";
        public const string EnergyFacility = "ENFACILITY";
        public const string EntertainmentTheatre = "ENTTHEATR";
        public const string GolfCourse = "GOLF";
        public const string GovernmentFacility = "GOFACILITY";
        public const string HealthCareFacility = "HCFACILITY";
        public const string HotelMotel = "HOTELMOTEL";
        public const string Industrial = "INDUSTRIAL";
        public const string Office = "OFFICE";
        public const string PetroliumOilCompany = "PETOILCO";
        public const string RestaurantFastFood = "FASTFOOD";
        public const string Retail = "RETAIL";
        public const string SelfStorage = "SELFSTORE";
        public const string SportsFacilityStadium = "SPFACILITY";
        public const string TimberLand = "TIMBERLAND";
        public const string TransportationFacility = "TRFACILITY";
        public const string ChurchReligiousFacility = "RELFAC";
        public const string Townhouse = "TWNHSE";
        public const string AgriculturalLand = "AGRLLAND";
        public const string CommercialStructure = "COMSRTE";
        public const string PlannedUnitDevelopment = "PUDPMT";
    }

    public abstract class PropertyTypeCdID
    {
        public const int ApartmentBuilding = 11;
        public const int TBD = 12;
        public const int Condominium = 13;
        public const int FarmHomesite = 14;
        public const int SingleFamilyResidence = 15;
        public const int MobileHome = 16;
        public const int MultiFamilyResidence = 17;
        public const int VacantLand = 18;
        public const int Tract = 19;
        public const int CoOp = 840;
        public const int CommunicationSite = 843;
        public const int ConvenienceStoreMarket = 844;
        public const int ConventionFacility = 845;
        public const int EducationalFacility = 846;
        public const int EnergyFacility = 847;
        public const int EntertainmentTheatre = 848;
        public const int GolfCourse = 849;
        public const int GovernmentFacility = 850;
        public const int HealthCareFacility = 851;
        public const int HotelMotel = 852;
        public const int Industrial = 853;
        public const int Office = 854;
        public const int PetroliumOilCompany = 855;
        public const int RestaurantFastFood = 856;
        public const int Retail = 857;
        public const int SelfStorage = 858;
        public const int SportsFacilityStadium = 859;
        public const int TimberLand = 860;
        public const int TransportationFacility = 861;
        public const int ChurchReligiousFacility = 933;
        public const int Townhouse = 934;
        public const int AgriculturalLand = 1836;
        public const int CommercialStructure = 1887;
        public const int PlannedUnitDevelopment = 1888;
    }
}
