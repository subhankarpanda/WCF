﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers.DataObjects
{
    public abstract class TransactionTypeOCD
    {
        public const string Accommodation = "ACCOMODAT";
        public const string BulkSale = "BULK";
        public const string ConstructionDisbursement = "CD";
        public const string ConstructionLoan = "CON";
        public const string EquityLoan = "LOAN";
        public const string Foreclosure = "FORECLOSE";
        public const string LimitedEscrow = "LTDESCROW";
        public const string MortgageModification = "MORTGMODI";
        public const string Refinance = "REFI";
        public const string REO = "REO";
        public const string REOSaleMortgage = "REOMORTG";
        public const string REOSaleCash = "REOCASH";
        public const string SaleMortgage = "SALE";
        public const string SaleCash = "CASH";
        public const string SaleExchange = "EXCHANGE";
        public const string SearchPackage = "SEARCH";
        public const string SecondMortgage = "SM";
        public const string SettlementStatementOnly = "SSO";
        public const string ShortSale = "SHTSALE";
        public const string ShortSaleMortgage = "SHTSALEMG";
        public const string ShortSaleCash = "SHTSALECH";
    }
}
