﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers.DataObjects
{
    public struct EmployeeFunctionTypeOCD
    {
        public const string SalesRep = "SALESREP";
        public const string TitleOfficer = "TITLEOFFR";
        public const string EscrowOfficer = "ESCROWOFFR";
        public const string Other = "OTHER";
        public const string TitleAssistant = "TITLEASST";
        public const string EscrowAssistant = "ESCROWASST";
        public const string UCCSpecialist = "UCCSPCLST";
    }

    public struct EmployeeFunctionTypeCdID
    {
        public const int SalesRep = 812;
        public const int TitleOfficer = 78;
        public const int EscrowOfficer = 79;
        public const int Other = 80;
        public const int TitleAssistant = 237;
        public const int EscrowAssistant = 238;
        public const int UCCSpecialist = 272;
    }
}
