﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers.DataObjects
{
    public struct LoanProductTypeCdID
    {
        public const int AdjustableRate = 2568;
        public const int FixedRate = 2570;
        public const int Other = 2567;
        public const int StepRate = 2569;
    }

    public struct LoanProductTypeOCD
    {
        public const string AdjustableRate = "LNPRDADRAT";
        public const string FixedRate = "LNPRDFDRAT";
        public const string Other = "LNPRDTOTHR";
        public const string StepRate = "LNPRDSTRAT";
    }
}
