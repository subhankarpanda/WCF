﻿using FASTWCFHelpers.FastFileService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers.DataObjects
{
    public struct AuthorizedSignatureTypeCdID
    {
        public const int Administrator = 1176;
        public const int AttorneyInFact = 1490;
        public const int CoTrustee = 156;
        public const int Executor = 1175;
        public const int Other = 158;
        public const int PersonalRepresentative = 1177;
        public const int SuccessorTrustee = 157;
        public const int Trustee = 155;
    }

    public struct AuthorizedSignatureTypeOCD
    {
        public const string AttorneyInFact = "ATTINFACT";
        public const string Administrator = "ADMNSTRTR";
        public const string CoTrustee = "COTRUSTEE";
        public const string Executor = "EXCUTR";
        public const string Other = "OTHER";
        public const string PersonalRepresentative = "PRSNLREP";
        public const string SuccesorTrustee = "SUCCTRSTEE";
        public const string Trustee = "TRUSTEE";
    }

    public struct AuthorizedSignatureTypes
    {
        public static IndividualSignatureType[] Individual = new IndividualSignatureType[]{
            new IndividualSignatureType()
            {
                Description = "Attorney In Fact",
                ObjectCD = AuthorizedSignatureTypeOCD.AttorneyInFact,
                TypeCdID = AuthorizedSignatureTypeCdID.AttorneyInFact
            },
        };

        public static HusbandWifeSignatureType[] HusbandWife = new HusbandWifeSignatureType[]{
            new HusbandWifeSignatureType()
            {
                Description = "Attorney In Fact",
                ObjectCD = AuthorizedSignatureTypeOCD.AttorneyInFact,
                TypeCdID = AuthorizedSignatureTypeCdID.AttorneyInFact
            },
        };

        public static TrustEstateSignatureType[] Trustee = new TrustEstateSignatureType[]{
            new TrustEstateSignatureType()
            {
                Description = "Administrator",
                ObjectCD = AuthorizedSignatureTypeOCD.Administrator,
                TypeCdID = AuthorizedSignatureTypeCdID.Administrator
            },
            new TrustEstateSignatureType()
            {
                Description = "Co-Trustee",
                ObjectCD = AuthorizedSignatureTypeOCD.CoTrustee,
                TypeCdID = AuthorizedSignatureTypeCdID.CoTrustee
            },
            new TrustEstateSignatureType()
            {
                Description = "Executor",
                ObjectCD = AuthorizedSignatureTypeOCD.Executor,
                TypeCdID = AuthorizedSignatureTypeCdID.Executor
            },
            new TrustEstateSignatureType()
            {
                Description = "Other",
                ObjectCD = AuthorizedSignatureTypeOCD.Other,
                TypeCdID = AuthorizedSignatureTypeCdID.Other
            },
            new TrustEstateSignatureType()
            {
                Description = "Personal Representative",
                ObjectCD = AuthorizedSignatureTypeOCD.PersonalRepresentative,
                TypeCdID = AuthorizedSignatureTypeCdID.PersonalRepresentative
            },
            new TrustEstateSignatureType()
            {
                Description = "Successor Trustee",
                ObjectCD = AuthorizedSignatureTypeOCD.SuccesorTrustee,
                TypeCdID = AuthorizedSignatureTypeCdID.SuccessorTrustee
            },
            new TrustEstateSignatureType()
            {
                Description = "Trustee",
                ObjectCD = AuthorizedSignatureTypeOCD.Trustee,
                TypeCdID = AuthorizedSignatureTypeCdID.Trustee
            },
        };
    }
}
