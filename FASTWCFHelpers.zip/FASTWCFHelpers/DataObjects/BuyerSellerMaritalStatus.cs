﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers.DataObjects
{
    public struct BuyerSellerMaritalStatusCdID
    {
        public const int ToBeDetermined = 46;
        public const int MarriedCouple = 3257;
        public const int MarriedMan = 37;
        public const int MarriedWoman = 38;
        public const int RegisteredDomesticPartner = 1162;
        public const int SingleMan = 41;
        public const int SinglePerson = 43;
        public const int SingleWoman = 42;
        public const int Widow = 44;
        public const int Widower = 45;
        public const int UnmarriedMan = 39;
        public const int UnmarriedPerson = 862;
        public const int UnmarriedWoman = 40;
        public const int RegisteredDomesticPartners = 1163;
        public const int HusbandAndWife = 35;
        public const int MarriedSpouses = 2073;
        public const int WifeAndHusband = 36;
    }
}
