﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers.DataObjects
{
    public struct BuyerSellerVestingCdID
    {
        public const int ToBeDetermined = 53;
        public const int AsCommunityProperty = 47;
        public const int AsCommunityPropertyWithRightOfSurvivorship = 224;
        public const int AsHerSoleAndSeparateProperty = 52;
        public const int AsHisSoleAndSeparateProperty = 51;
        public const int AsJointTenants = 48;
        public const int AsJointTenantsWithRightOfSurvivorship = 49;
        public const int AsSurvivorshipMaritalProperty = 1785;
        public const int AsTenantInSeveralty = 1203;
        public const int AsTenantsByTheEntirety = 225;
        public const int AsTenantsByTheEntiretyWithTheCommonLawRightsOfSurvivorship = 865;
        public const int AsTenantsInCommon = 50;
        public const int NotAsTenantsInCommon = 863;
        public const int NotAsTenantsInCommonButWithRightsOfSurvivorship = 864;
    }
}
