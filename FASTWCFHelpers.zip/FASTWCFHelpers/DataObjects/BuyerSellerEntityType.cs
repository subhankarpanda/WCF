﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers.DataObjects
{
    public struct BuyerSellerEntityTypeCdID
    {
        public const int NoValue = 0;
        public const int BusinessTrust = 288;
        public const int Corporation = 160;
        public const int GeneralPartnership = 159;
        public const int JointVenture = 164;
        public const int LimitedLiabilityCompany = 165;
        public const int LimitedLiabilityPartnership = 2819;
        public const int LimitedPartnership = 161;
        public const int NonProfitCorporation = 163;
        public const int Other = 287;
        public const int ProfessionalCorporation = 162;
    }
}
