﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers.DataObjects
{
    public struct BuyerSellerStateOfIncorporationCdID
    {
        public const int AA = 65075;
        public const int AE = 65076;
        public const int Alaska = 1;
        public const int Alabama = 2;
        public const int AP = 65077;
        public const int Arkansas = 3;
        public const int AmericanSamoa = 4;
        public const int Arizona = 5;
        public const int California = 6;
        public const int Colorado = 7;
        public const int Connecticut = 8;
        public const int DistrictOfColumbia = 9;
        public const int Delaware = 10;
        public const int Florida = 11;
        public const int FederatedStatesOfMicronesia = 12;
        public const int Georgia = 13;
        public const int Guam = 14;
        public const int Hawaii = 15;
        public const int Iowa = 16;
        public const int Idaho = 17;
        public const int Illinois = 18;
        public const int Indiana = 19;
        public const int Kansas = 20;
        public const int Kentucky = 21;
        public const int Louisiana = 22;
        public const int Massachusetts = 23;
        public const int Maryland = 24;
        public const int Maine = 25;
        public const int MarshallIslands = 26;
        public const int Michigan = 27;
        public const int Minnesota = 28;
        public const int Missouri = 29;
        public const int NorthernMarianaIslands = 30;
        public const int Mississippi = 31;
        public const int Montana = 32;
        public const int NorthCarolina = 33;
        public const int NorthDakota = 34;
        public const int Nebraska = 35;
        public const int NewHampshire = 36;
        public const int NewJersey = 37;
        public const int NewMexico = 38;
        public const int Nevada = 39;
        public const int NewYork = 40;
        public const int Ohio = 41;
        public const int Oklahoma = 42;
        public const int Oregon = 43;
        public const int Pennsylvania = 44;
        public const int PuertoRico = 45;
        public const int Palau = 46;
        public const int RhodeIsland = 47;
        public const int SouthCarolina = 48;
        public const int SouthDakota = 49;
        public const int Tennessee = 50;
        public const int Texas = 51;
        public const int Utah = 52;
        public const int Virginia = 53;
        public const int VirginIslands = 54;
        public const int Vermont = 55;
        public const int Washington = 56;
        public const int Wisconsin = 57;
        public const int WestVirginia = 58;
        public const int Wyoming = 59;
    }
}
