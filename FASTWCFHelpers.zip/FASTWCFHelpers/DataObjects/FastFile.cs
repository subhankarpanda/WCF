﻿using FASTWCFHelpers.FastFileService;
using System;

namespace FASTWCFHelpers.DataObjects
{
    public class FastFileCD
    {
        public string TransactionTypeObjectCD = "SALE";
        public string BusinessSegmentObjectCD = "COMMERCIAL";
        public string ExternalFileNumber = "123456789";
        public bool AutoNumberIndicator = true;
        public CreateFileRequest Request = new CreateFileRequest() { EmployeeObjectCD = "1", Source = "FAMOS", Target = "FAST", formType = FormType.CD };
        public FileBusinessParty[] BusinessParties = { new FileBusinessParty() { AddrBookEntryID = 8836264, RoleTypeObjectCD = "BUSSOURCE" } };
        public Service[] Services = { new Service() { OfficeInfo = new OfficeInfo() { RegionID = 1486, BUID = 1487, ProductionOffices = new ProductionOffice[] { new ProductionOffice() { BUID = 0, OfficeCode = 0, RegionID = 0, SeqNum = 0 } } }, ServiceTypeObjectCD = "TO" } };
        public Property[] Properties = { new Property() { PropertyAddress = new PhysicalAddress[] { new PhysicalAddress() { State = "CA", City = "ALBANY", County = "ALAMEDA", Country = "USA" } } } };
        public BuyerSeller[] Buyers = { new BuyerSeller() { FirstName = "BuyerName", LastName = "BuyerLastName", EntityTypeID = 48, Type = "Individual" } };
        public BuyerSeller[] Sellers = { new BuyerSeller() { FirstName = "SellerName", LastName = "SellerLastName", EntityTypeID = 48, Type = "Individual" } };
        public NewLoan NewLoan = new NewLoan() { LoanNumber = "WCF_DefaultLoanNumber", FundAmount = 50.00m, LiabilityAmount = 100.00m, BenMortgageeTextID = 0, FileBusinessParty = new FileBusinessParty { Name = "Nhat Nguyen", AddrBookEntryID = 8835227, }, LoanTypeCdID = 0, FundDate = DateTime.Today, };
    }

    public class FastFile
    {
        public string TransactionTypeObjectCD = "SALE";
        public string BusinessSegmentObjectCD = "COMMERCIAL";
        public string ExternalFileNumber = "123456789";
        public bool AutoNumberIndicator = true;
        public CreateFileRequest Request = new CreateFileRequest() { EmployeeObjectCD = "1", Source = "FAMOS", Target = "FAST", formType = FormType.CD };
        public FileBusinessParty[] BusinessParties = { new FileBusinessParty() { AddrBookEntryID = 261994, RoleTypeObjectCD = "BUSSOURCE" } };
        public Service[] Services = { new Service() { OfficeInfo = new OfficeInfo() { RegionID = 349, BUID = 12849, ProductionOffices = new ProductionOffice[] { new ProductionOffice() { BUID = 0, OfficeCode = 0, RegionID = 0, SeqNum = 0 } } }, ServiceTypeObjectCD = "TO" } };
        public Property[] Properties = { new Property() { PropertyAddress = new PhysicalAddress[] { new PhysicalAddress() { State = "CA", City = "ALBANY", County = "ALAMEDA", Country = "USA" } } } };
        public BuyerSeller[] Buyers = { new BuyerSeller() { FirstName = "BuyerName", LastName = "BuyerLastName", EntityTypeID = 48, Type = "Individual" } };
        public BuyerSeller[] Sellers = { new BuyerSeller() { FirstName = "SellerName", LastName = "SellerLastName", EntityTypeID = 48, Type = "Individual" } };
        public NewLoan NewLoan = new NewLoan() { LoanNumber = "WCF_DefaultLoanNumber", FundAmount = 50.00m, LiabilityAmount = 100.00m, BenMortgageeTextID = 0, FileBusinessParty = new FileBusinessParty { Name = "Nhat Nguyen", AddrBookEntryID = 261994, }, LoanTypeCdID = 0, FundDate = DateTime.Today, };
    }
        
}
