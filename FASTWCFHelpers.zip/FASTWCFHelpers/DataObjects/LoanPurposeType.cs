﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers.DataObjects
{
    public struct LoanPurposeTypeCdID
    {
        public const int Construction = 2573;
        public const int HomeEquityLoan = 2574;
        public const int Other = 2575;
        public const int Purchase = 2571;
        public const int Refinance = 2572;
    }

    public struct LoanPurposeTypeOCD
    {
        public const string Construction = "LNPURCNSTN";
        public const string HomeEquityLoan = "LNPURHMEQT";
        public const string Other = "LNPUROTHER";
        public const string Purchase = "LNPURPRCHS";
        public const string Refinance = "LNPURREFNC";
    }
}
