﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers.DataObjects
{
    public struct FileInformation
    {
        public string FileNumber { get; set; }
        public string FileID { get; set; }
        public int RegionID { get; set; }
        public int OfficeID{ get; set; }
        public string UserID { get; set; }
    }
}
