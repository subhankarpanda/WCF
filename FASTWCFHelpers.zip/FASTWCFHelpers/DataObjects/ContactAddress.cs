﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers.DataObjects
{
    public struct ContactAddressTypeCdID
    {
        public const int BusinessPhone = 122;
        public const int BusinessFax = 124;
        public const int EMail = 127;
        public const int Pager = 126;
        public const int Cellular = 125;
        public const int HomePhone = 121;
        public const int HomeFax = 123;
        public const int CFNotification = 1719;
    }

    public struct ContextTypeCdID
    {
        public const int Current = 190;
        public const int Forwarding = 191;
    }
}
