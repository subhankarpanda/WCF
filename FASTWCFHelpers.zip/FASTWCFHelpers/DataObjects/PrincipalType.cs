﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers.DataObjects
{
    public struct PrincipalTypeCdID
    {
        public const int Buyer = 113;
        public const int PrincipalDebtor = 262;
        public const int Seller = 114;
    }
}
