﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers.DataObjects
{
    public struct ProcessEventCdID
    {
        public const int AgentNetAmend = 3236;
        public const int AgentNetDateDown = 3237;
        public const int AgentNetUpdate = 3238;
    }
}
