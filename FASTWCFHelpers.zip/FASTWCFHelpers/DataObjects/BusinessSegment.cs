﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers.DataObjects
{
    public struct BusinessSegmentOCD
    {
        public const string Commercial = "COMMERCIAL";
        public const string Residential = "RESIDENTAL";
        public const string NewHomeSubdivision = "NEWHMSUBDN";
        public const string TimeShare = "TIMESHARE";
        public const string ControlledResidential = "CNTLRESDTL";
        public const string ControlledCommercial = "CNTLCOMMCL";
        public const string DefaultResidential = "DFTRESI";
        public const string DefaultCommercial = "DFTCOM";
        public const string NewHome = "NEWHM";
        public const string Subdivision = "SUBDN";
    }

    public struct BusinessSegmentCdID
    {
        public const int Commercial = 838;
        public const int Residential = 839;
        public const int NewHomeSubdivision = 841;
        public const int TimeShare = 842;
        public const int ControlledResidential = 1201;
        public const int ControlledCommercial = 1202;
        public const int DefaultResidential = 1850;
        public const int DefaultCommercial = 1851;
        public const int NewHome = 1834;
        public const int Subdivision = 1835;
    }
}
