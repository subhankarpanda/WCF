﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers.DataObjects
{
    public struct AdditionalEstimateCostOtherTypeCdID
    {
        public const int CondominiumAssociationDues = 2984;
        public const int CondominiumAssociationSpecialAssessment = 2985;
        public const int CooperativeAssociationDues = 2986;
        public const int CooperativeAssociationSpecialAssessment = 2987;
        public const int GroundRent = 2988;
        public const int HomeownersAssociationDues = 2989;
        public const int HomeownersAssociationSpecialAssessment = 2990;
        public const int LeaseholdPayment = 2991;
        public const int Other = 2992;
    }

    public struct AdditionalEstimateCostOtherTypeOCD
    {
        public const string CondominiumAssociationDues = "CDPPMTCADU";
        public const string CondominiumAssociationSpecialAssessment = "CDPPMTCASA";
        public const string CooperativeAssociationDues = "CDPPMTCOAD";
        public const string CooperativeAssociationSpecialAssessment = "CDPPMTCOSA";
        public const string GroundRent = "CDPPMTGRRT";
        public const string HomeownersAssociationDues = "CDPPMTHADU";
        public const string HomeownersAssociationSpecialAssessment = "CDPPMTHASP";
        public const string LeaseholdPayment = "CDPPMTLPMT";
        public const string Other = "CDPPMTOTHR";
    }
}
