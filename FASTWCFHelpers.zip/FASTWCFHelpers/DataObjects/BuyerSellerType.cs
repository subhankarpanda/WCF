﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers.DataObjects
{
    public struct BuyerSellerTypeOCD
    {
        public const string Individual = "Individual";
        public const string HusbandAndWife = "Husband and Wife";
        public const string TrustEstate = "Trust";
        public const string BusinessEntity = "Business Entity";
    }

    public struct BuyerSellerTypeCdID
    {
        public const int Individual = 48;
        public const int HusbandAndWife = 49;
        public const int TrustEstate = 50;
        public const int BusinessEntity = 51;
    }
    
    public struct BuyerSellerPrincipalTypeOCD
    {
        public const string Buyer = "BUYER";
        public const string Seller = "SELLER";
    }
}
