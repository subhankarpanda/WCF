﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers.DataObjects
{
    public abstract class QCClosingTransactionTypeCdID
    {
        public const int None = 0;
        public const int Refinance = 3;
        public const int Purchase = 1868;
        public const int Construction = 446;
        public const int Equity = 150;
        public const int HELOC = 1869;
        public const int Reverse = 1870;
        public const int TexasEquity = 2209;
        public const int REO = 2210;
    }

    public abstract class QCClosingLoanInterestTypeCdID
    {
        public const int None = 0;
        public const int FixedRate = 1860;
        public const int ARM = 1861;
        public const int InterestOnly = 1862;
    }

    public abstract class QCClosingOccupancyTypeCdID
    {
        public const int None = 0;
        public const int PrincipalResidence = 1863;
        public const int SecondHome = 1864;
        public const int Investment = 1865;
    }

    public abstract class QCClosingGovtProgramCdID
    {
        public const int None = 0;
        public const int VA = 442;
        public const int FHA = 441;
        public const int USDA = 1871;
    }

    public abstract class QCClosingSourceOfFundsCdID
    {
        public const int None = 0;
        public const int Borrower = 1872;
        public const int PersonalGifts = 1873;
        public const int Donations = 1874;
        public const int EmployerAssistance = 1875;
        public const int CommunitySeconds = 1876;
    }

    public abstract class QCClosingInvestorNameCdID
    {
        public const int None = 0;
        public const int FannieMae = 1877;
        public const int FreddieMac = 1878;
        public const int VA = 442;
        public const int FHA = 441;
        public const int USDA = 1871;
    }

    public abstract class QCClosingSpecialInvProdNameCdID
    {
        public const int None = 0;
        //  TODO: update as needed
    }

    public abstract class QCClosingSecondaryLienInfoCdID
    {
        public const int None = 0;
        public const int Subordinate = 1885;
        public const int PayOff = 1748;
    }
}
