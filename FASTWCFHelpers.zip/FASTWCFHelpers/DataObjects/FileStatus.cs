﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers.DataObjects
{
    public struct FileStatusOCD
    {
        public const string Open = "OPEN";
        public const string OpenInError = "ERROR";
        public const string Cancelled = "CANCELLED";
        public const string Closed = "CLOSED";
        public const string Pending = "PENDING";
        public const string PCancelled = "PCANCELLED";
        public const string POpenInError = "PERROR";
    }

    public struct FileStatusCdID
    {
        public const int Open = 151;
        public const int OpenInError = 152;
        public const int Cancelled = 153;
        public const int Closed = 154;
        public const int Pending = 1507;
        public const int PCancelled = 1528;
        public const int POpenInError = 1529;
    }
}
