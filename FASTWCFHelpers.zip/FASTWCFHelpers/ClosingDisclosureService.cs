﻿using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastClosingDisclosureService;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace FASTWCFHelpers
{
    public class ClosingDisclosureService
    {
        public static ClosingDisclosure GetClosingDisclosure(ServiceFileRequest request)
        {
            var service = ServiceFactory.GetClosingDisclosureService();

            return Execute<ClosingDisclosure>(service, () => service.GetClosingDisclosure(request));
        }

        public static CDDeliveryOptionsResponse GetClosingDisclosureDeliveryOptions(CDDeliveryOptionsRequest request)
        {
            var service = ServiceFactory.GetClosingDisclosureService();

            return Execute<CDDeliveryOptionsResponse>(service, () => service.GetClosingDisclosureDeliveryOptions(request));
        }

        public static DeliveryResponse CDFormDelivery(CDDeliveryRequest request)
        {
            var service = ServiceFactory.GetClosingDisclosureService();

            return Execute<DeliveryResponse>(service, () => service.CDFormDelivery(request));
        }

        public static ConvertToMismoResponse ConvertCDDataContractToMismo(ConvertCDDataContractToMismoRequest request)
        {
            var service = ServiceFactory.GetClosingDisclosureService();

            return Execute<ConvertToMismoResponse>(service, () => service.ConvertCDDataContractToMismo(request));
        }

        public static ConvertToMismoResponse GetMismoWithPDFByFileId(MismoWithPDFByFileIdRequest request)
        {
            var service = ServiceFactory.GetClosingDisclosureService();

            return Execute<ConvertToMismoResponse>(service, () => service.GetMismoWithPDFByFileId(request));
        }

        public static OperationResponse PostMismoClosingDisclosure(PostMismoClosingDisclosureRequest request)
        {
            var service = ServiceFactory.GetClosingDisclosureService();

            return Execute<OperationResponse>(service, () => service.PostMismoClosingDisclosure(request));
        }

        public static ClosingDisclosure GetCDDetails(ClosingDisclosureRequest request)
        {
            var service = ServiceFactory.GetClosingDisclosureService();

            return Execute<ClosingDisclosure>(service, () => service.GetCDDetails(request));
        }

        public static OperationResponse UpdateCDDetails(ClosingDisclosureUpdateRequest request)
        {
            var service = ServiceFactory.GetClosingDisclosureService();

            return Execute<OperationResponse>(service, () => service.UpdateCDDetails(request));
        }

        public static GetCDWithPDFByMismoServiceResponse GetCDWithPDFByMismo(GetCDWithPDFByMismoServiceRequest request)
        {
            var service = ServiceFactory.GetClosingDisclosureService();

            return Execute<GetCDWithPDFByMismoServiceResponse>(service, () => service.GetCDWithPDFByMismo(request));
        }

        internal static T Execute<T>(ClosingDisclosureServiceClient client, Func<T> lambdaFunc)
        {
            //Based on recommended practice: https://msdn.microsoft.com/en-us/library/aa355056.aspx
            try
            {
                var r = lambdaFunc.Invoke();
                client.Close();
                return r;
            }
            catch (CommunicationException e)
            {
                Debug.WriteLine(e.Message);
                client.Abort();
                throw;
            }
            catch (TimeoutException e)
            {
                Debug.WriteLine("Timeout exception: " + e.Message);
                client.Abort();
                throw;
            }
            catch (Exception)
            {
                client.Abort();
                throw;
            }
        }


 public static ConvertToMismoResponse GenerateMismo(int fileId) 
        {   

            var getCDDetailsRequest = new FASTWCFHelpers.FastClosingDisclosureService.ServiceFileRequest() 
            { 
                FileId=fileId, 
                Source = "FAST",    // hardcode for now. we can chage later if need to 
                Target = "FAST",    // same here 
                LoginName = @"fastts\fastqa07", 
                EmployeeObjectCD = "1" 
            }; 

            var cdToMismoReq = new FASTWCFHelpers.FastClosingDisclosureService.ConvertCDDataContractToMismoRequest() 
            { 
                Source = "FAST", 
                Target = "FAST", 
                EmployeeObjectCD = "1", 
                MismoVersion = "3.3.1", 
                // Generate DataContract 
                ClosingDisclosureData = ClosingDisclosureService.GetClosingDisclosure((getCDDetailsRequest)) 
            }; 

            // Generate Mismo 
            return ClosingDisclosureService.ConvertCDDataContractToMismo(cdToMismoReq); 

        }

        public static OperationResponse PostMismoClosingDisclosure(string mismoXML)
        {
            var mismoRequest = new FASTWCFHelpers.FastClosingDisclosureService.PostMismoClosingDisclosureRequest()
            {
                Source = "FAST",
                Target = "FAST",
                EmployeeObjectCD = "1",
                MismoVersion = "3.3.1",
                MismoXml = mismoXML
            };

            // Post Mismo
            return FASTWCFHelpers.ClosingDisclosureService.PostMismoClosingDisclosure(mismoRequest);

        }
        //
        public static OperationResponse PostQCStaging(PostQCStagingServiceRequest request)
        {
            var service = ServiceFactory.GetClosingDisclosureService();

            return Execute<OperationResponse>(service, () => service.PostQCStaging(request));
        }




    }
}
