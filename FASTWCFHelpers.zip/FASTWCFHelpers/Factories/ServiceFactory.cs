﻿using FASTWCFHelpers.FastAdminService;
using FASTWCFHelpers.FastClosingDisclosureService;
using FASTWCFHelpers.FastDocumentService;
using FASTWCFHelpers.FastEscrowService;
using FASTWCFHelpers.FastFileService;
using FASTWCFHelpers.FISPayoffDemandClient;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Diagnostics;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;

namespace FASTWCFHelpers.Factories
{
    public class ServiceFactory
    {
        private static Endpoint _endpoint = Endpoint.basicWindowsAuth;

        private enum Service
        {
            File,
            Admin,
            CD,
            Escrow,
            Document
        }

        private enum Endpoint
        {
            basicWindowsAuth,
            wsWindowsAuth,
            None
        }

        public static FastFileServiceClient GetFileService()
        {
            string username = AutoConfig.InterfaceUsername;
            string password = AutoConfig.InterfaceUserPassword;
            string domain = AutoConfig.InterfaceUserDomain;

            var ws = new FastFileServiceClient(GetBinding(_endpoint), GetAddress(Service.File, _endpoint));
            ws.ClientCredentials.Windows.ClientCredential = new System.Net.NetworkCredential(username, password, domain);
            return ws;
        }

        public static FastAdminServiceClient GetAdminService()
        {
            string username = AutoConfig.InterfaceUsername;
            string password = AutoConfig.InterfaceUserPassword;
            string domain = AutoConfig.InterfaceUserDomain;

            var ws = new FastAdminServiceClient(GetBinding(_endpoint), GetAddress(Service.Admin, _endpoint));
            ws.ClientCredentials.Windows.ClientCredential = new System.Net.NetworkCredential(username, password, domain);
            return ws;
        }

        public static FastEscrowServiceClient GetEscrowService()
        {
            string username = AutoConfig.InterfaceUsername;
            string password = AutoConfig.InterfaceUserPassword;
            string domain = AutoConfig.InterfaceUserDomain;

            var ws = new FastEscrowServiceClient(GetBinding(_endpoint), GetAddress(Service.Escrow, _endpoint));
            ws.ClientCredentials.Windows.ClientCredential = new System.Net.NetworkCredential(username, password, domain);
            return ws;
        }

        public static ClosingDisclosureServiceClient GetClosingDisclosureService()
        {
            string username = AutoConfig.InterfaceUsername;
            string password = AutoConfig.InterfaceUserPassword;
            string domain = AutoConfig.InterfaceUserDomain;

            var ws = new ClosingDisclosureServiceClient(GetBinding(_endpoint), GetAddress(Service.CD, _endpoint));
            ws.ClientCredentials.Windows.ClientCredential = new System.Net.NetworkCredential(username, password, domain);
            return ws;
        }

        public static FastDocumentServiceClient GetDocumentService()
        {
            string username = AutoConfig.InterfaceUsername;
            string password = AutoConfig.InterfaceUserPassword;
            string domain = AutoConfig.InterfaceUserDomain;

            var ws = new FastDocumentServiceClient(GetBinding(_endpoint), GetAddress(Service.Document, _endpoint));
            ws.ClientCredentials.Windows.ClientCredential = new System.Net.NetworkCredential(username, password, domain);
            return ws;
        }

        public static ClientWebServiceClient GetClientWebService()
        {
            try
            {
                string host = (AutoConfig.InterfaceURL == "wsinterfaces") ? "wsinterfaces.fast.firstam.net" : AutoConfig.InterfaceURL + ".FASTTS.FIRSTAM.NET";
                string url = "http://" + host + "/FASTOrderEntryWebService/FASTOrderEntryWebService_ReceiveOrderOrchestration_ReceiveRequestPort.asmx";

                return new ClientWebServiceClient(url);
            }
            catch (Exception ex)
            {
                Debug.Print(ex.Message);
                throw new Exception("Error initializing ClientWeb service. See debug log for detailed error information.");
            }
        }

        public static FAFFISOrderNotificationSoapClient GetPayoffDemandService()
        {
            try
            {
                string server = (AutoConfig.InterfaceURL == "wsinterfaces") ? "wsinterfaces.fast.firstam.net" : AutoConfig.InterfaceURL + ".FASTTS.FIRSTAM.NET";
                string url = "http://" + server + "/FAFFISORDERNOTIFICATIONWS/FAFFISOrderNotification.asmx";

                return new FAFFISOrderNotificationSoapClient(GetBinding(Endpoint.None), new EndpointAddress(url));
            }
            catch (Exception ex)
            {
                Debug.Print(ex.Message);
                throw new Exception("Error initializing PayoffDemand service. See debug log for detailed error information.");
            }
        }

        private static EndpointAddress GetAddress(Service service, Endpoint endpoint)
        {
            string servicePath;
            switch (service)
            {
                case Service.File:
                    servicePath = "File/FastFileService.svc";
                    break;
                case Service.Admin:
                    servicePath = "Admin/FastAdminService.svc";
                    break;
                case Service.CD:
                    servicePath = "ClosingDisclosure/ClosingDisclosureService.svc";
                    break;
                case Service.Escrow:
                    servicePath = "Escrow/FastEscrowService.svc";
                    break;
                case Service.Document:
                    servicePath = "Document/FastDocumentService.svc";
                    break;
                default:
                    servicePath = "";
                    break;
            }

            string _endpoint;
            switch (endpoint)
            {
                case Endpoint.basicWindowsAuth:
                    _endpoint = "/basicWindowsAuth";
                    break;
                case Endpoint.wsWindowsAuth:
                    _endpoint = "/wsWindowsAuth";
                    break;
                default:
                    _endpoint = "";
                    break;
            }

            var uriBuilder = new UriBuilder()
            {
                Scheme = "http",
                Host = (AutoConfig.InterfaceURL == "wsinterfaces") ? "wsinterfaces.fast.firstam.net" : AutoConfig.InterfaceURL + ".FASTTS.FIRSTAM.NET", //Handle production BigIP
                                                                                                                                                        //Host = AutoConfig.InterfaceURL + ".FASTTS.FIRSTAM.NET",
                Path = "/ServiceHosts/" + servicePath + _endpoint
            };

            return new EndpointAddress(uriBuilder.ToString());
        }

        private static Binding GetBinding(Endpoint endpoint)
        {
            Binding binding;

            switch (endpoint)
            {
                case Endpoint.None:
                    binding = new BasicHttpBinding();
                    break;
                case Endpoint.basicWindowsAuth:
                    binding = new BasicHttpBinding()
                    {
                        Security = new BasicHttpSecurity()
                        {
                            Transport = new HttpTransportSecurity()
                            {
                                ClientCredentialType = HttpClientCredentialType.Ntlm,
                                ProxyCredentialType = HttpProxyCredentialType.None,
                                Realm = ""
                            },
                            Mode = BasicHttpSecurityMode.TransportCredentialOnly,
                        },
                        Name = "bsWindowsAuth_Service",
                        OpenTimeout = new TimeSpan(0, 1, 0),
                        ReceiveTimeout = new TimeSpan(0, 5, 0),
                        SendTimeout = new TimeSpan(0, 1, 0),
                        AllowCookies = false,
                        BypassProxyOnLocal = false,
                        HostNameComparisonMode = System.ServiceModel.HostNameComparisonMode.StrongWildcard,
                        TextEncoding = Encoding.UTF8,
                        TransferMode = System.ServiceModel.TransferMode.Buffered,
                        UseDefaultWebProxy = true,
                        MaxBufferPoolSize = 524288,
                        MaxBufferSize = int.MaxValue,
                        MaxReceivedMessageSize = int.MaxValue,
                        MessageEncoding = WSMessageEncoding.Mtom,
                        ReaderQuotas = new System.Xml.XmlDictionaryReaderQuotas
                        {
                            MaxDepth = 32,
                            MaxStringContentLength = 2147483647,
                            MaxArrayLength = 2147483647,
                            MaxBytesPerRead = 4096,
                            MaxNameTableCharCount = 16384
                        }
                    };
                    break;
                case Endpoint.wsWindowsAuth:
                    binding = new WSHttpBinding()
                    {
                        Name = "wsWindowsAuth_Service",
                        CloseTimeout = new TimeSpan(0, 1, 0),
                        OpenTimeout = new TimeSpan(0, 1, 0),
                        ReceiveTimeout = new TimeSpan(0, 5, 0),
                        SendTimeout = new TimeSpan(0, 1, 0),
                        BypassProxyOnLocal = false,
                        TransactionFlow = false,
                        HostNameComparisonMode = System.ServiceModel.HostNameComparisonMode.StrongWildcard,
                        MaxBufferPoolSize = 524288,
                        MaxReceivedMessageSize = int.MaxValue,
                        MessageEncoding = WSMessageEncoding.Mtom,
                        TextEncoding = Encoding.UTF8,
                        UseDefaultWebProxy = true,
                        AllowCookies = false,
                        ReaderQuotas = new System.Xml.XmlDictionaryReaderQuotas
                        {
                            MaxDepth = 32,
                            MaxStringContentLength = 2147483647,
                            MaxArrayLength = 2147483647,
                            MaxBytesPerRead = 4096,
                            MaxNameTableCharCount = 16384
                        },
                        ReliableSession = new OptionalReliableSession()
                        {
                            Ordered = true,
                            InactivityTimeout = new TimeSpan(0, 10, 0),
                            Enabled = false
                        },
                        Security = new WSHttpSecurity()
                        {
                            Mode = SecurityMode.Message,
                            Transport = new HttpTransportSecurity()
                            {
                                ClientCredentialType = HttpClientCredentialType.Windows,
                                ProxyCredentialType = HttpProxyCredentialType.None,
                                Realm = ""
                            },
                            Message = new NonDualMessageSecurityOverHttp()
                            {
                                ClientCredentialType = MessageCredentialType.Windows,
                                NegotiateServiceCredential = true,
                                AlgorithmSuite = System.ServiceModel.Security.SecurityAlgorithmSuite.Default,
                                EstablishSecurityContext = false
                            }
                        }
                    };
                    break;
                default:
                    binding = null;
                    break;
            }
            return binding;
        }
    }

}
