﻿using FASTWCFHelpers.FastAdminService;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace FASTWCFHelpers.Factories
{
    public class AdminRequestFactory
    {
        public static LicenseTypeRequest GetLicenseTypesRequest(int state)
        {
            return new LicenseTypeRequest
            {
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS",
                EmployeeObjectCD = "1", 
                StateID = state,
                CountyID = 0
            };
        }

        public static GABSearchRequest GetGABSearchRequest(int businessUnitID, string gabCode)
        {
            return new GABSearchRequest
            {
                BusinessUnitID = businessUnitID,
                CountryTypeCdId = 0,
                EnterpriseID = 0,
                GABCode = gabCode,
                IsEnterpriseId = false,
                IsMailingOrBusiness = 0,
                OrgTypeCdID = 0,
                StatusCd = 0,
                WebCustomerType = 0
            };
        }

        public static GetRegionByOfficeRequest GetRegionByOfficeRequest(int officeID)
        {
            return new GetRegionByOfficeRequest
            {
                officeID = officeID
            };
        }

        public static GetGABorGABContactDetailsRequest GetGABorGABContactDetailsRequest(int addrBookEntryID)
        {
            return new GetGABorGABContactDetailsRequest
            {
                AddrBookEntryID = addrBookEntryID,
                GABContactId = 0,
                GABId = 0
            };
        }

        public static EmployeeSearchRequest GetSearchEmployeeByTypeRequest(int employeeID)
        {
            return new EmployeeSearchRequest
            {
                EmployeeID = employeeID,
                RegionID = Convert.ToInt32(AutoConfig.SelectedRegionBUID),
                OfficeID = Convert.ToInt32(AutoConfig.SelectedOfficeBUID)
                
            };
        }

        public static GABAndGABContactsRequest GetGABAndGABContactsRequest(int regionID)
        {
            return new GABAndGABContactsRequest
            {
                SalesRepId = 0,
                BusinessUnitID = regionID,
                CountryTypeCdId = 0,
                EnterpriseID = 0,
                IsMailingOrBusiness = 0,
                OrgTypeCdID = 0,
                StatusCd = 0,
                WebCustomerType = 0
            };
        }

        public static AllOfficeBankAccountsRequest GetOfficeBankAccountsByOfficeIDRequest(int officeID)
        {
            return new AllOfficeBankAccountsRequest
            {
                OfficeID = officeID,
                EmployeeObjectCD = "1",
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static BusSourceTypeRequest GetBusSourceTypeRequest(int regionID)
        {
            return new BusSourceTypeRequest
            {
                RegionID = regionID
            };
        }

        public static GABRequest GetGABRequest(int busOrgID)
        {
            return new GABRequest
            {
                BusOrgID = busOrgID
            };
        }

        public static TaskTemplateCommentCodesRequest GetTaskTemplateCommentCodesRequest(int taskTemplateID)
        {
            return new TaskTemplateCommentCodesRequest
            {
                TaskTemplateID = taskTemplateID
            };
        }

        public static VersionGABInfoRequest GetVersionedGABInfoRequest(int addrBookEntryID)
        {
            return new VersionGABInfoRequest
            {
                AddrBookEntryID = addrBookEntryID
            };
        }

        public static GetEmployeesByFunctionTypesRequest GetEmployeesByFunctionTypesRequest(int[] functionTypes, int officeID)
        {
            return new GetEmployeesByFunctionTypesRequest
            {
                FunctionTypes = functionTypes,
                OfficeID = officeID,
                StatusCD = 0
            };
        }
    }
}
