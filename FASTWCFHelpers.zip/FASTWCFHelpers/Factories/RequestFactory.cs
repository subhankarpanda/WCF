﻿using FASTWCFHelpers.DataObjects;
using FASTWCFHelpers.FastFileService;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace FASTWCFHelpers.Factories
{
    [Obsolete("RequestFactory is obsolete. Use FileRequestFactory instead, or any other factory depending on the service you are consuming.")]
    public class RequestFactory
    {
        public static CreateFileRequest GetCreateFileDefaultRequest(int? regionBUID = null, int? officeBUID = null)
        {
            return new CreateFileRequest()
            {
                EmployeeObjectCD = "1",
                Source = "FAST",
                Target = "FAST",
                formType = AutoConfig.UseCDFormType ? FormType.CD : FormType.HUD,
                File = new File()
                {
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "RESIDENTAL",
                    ExternalFileNumber = "123456789",
                    AutoNumberIndicator = true,
                    BusinessParties = new FileBusinessParty[]
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionBUID),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.None
                            }
                        }
                    },
                    Services = new Service[]
                    {
                        GetService("TO", regionBUID, officeBUID),
                        GetService("EO", regionBUID, officeBUID),
                    },
                    Properties = new Property[]
                    {
                        new Property()
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[]
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress()
                                {
                                    State = "CA",
                                    City = "ALBANY",
                                    County = "ALAMEDA",
                                    Country = "USA"
                                }
                            }
                        }
                    },
                    Buyers = new BuyerSeller[]
                    {
                        new BuyerSeller()
                        {
                            FirstName = "BuyerName",
                            LastName = "BuyerLastName",
                            EntityTypeID = 48,
                            Type = "Individual"
                        }

                    },
                    Sellers = new BuyerSeller[]
                    {
                        new BuyerSeller()
                        {
                            FirstName = "SellerName",
                            LastName = "SellerLastName",
                            EntityTypeID = 48,
                            Type = "Individual"
                        }

                    }
                }
            };
        }

        public static CreateFileRequest GetDetailedCreateFileDefaultRequest(int? regionBUID = null, int? officeBUID = null)
        {
            return new CreateFileRequest()
            {
                EmployeeObjectCD = "1",
                Source = "FAST",
                Target = "FAST",
                formType = AutoConfig.UseCDFormType ? FormType.CD : FormType.HUD,
                File = new File()
                {
                    SalesPriceAmount = 5000,
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "COMMERCIAL",
                    ExternalFileNumber = "123456789",
                    AutoNumberIndicator = true,
                    BusinessParties = new FileBusinessParty[]
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1", regionBUID),
                            RoleTypeObjectCD = "BUSSOURCE"
                        }
                    },
                    Services = new Service[]
                    {
                        GetService("TO", regionBUID, officeBUID),
                        GetService("EO", regionBUID, officeBUID)
                    },
                    Properties = new Property[]
                    {
                        new Property()
                        {
                            Name = "J305",
                            Lot = "Lot1",
                            Block = "Block1",
                            Unit = "Unit1",
                            ProperyTypeCdID = 15, //Single Family Residence
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[]
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress()
                                {
                                    AddrLine1 = "J305",
                                    AddrLine2 = "JJEJAMQ",
                                    AddrLine3 = "JJEJAMQ",
                                    State = "CA",
                                    City = "ALBANY",
                                    County = "ALAMEDA",
                                    Zip = "92707",
                                    Country = "USA"
                                }
                            }
                        }
                    },
                    Buyers = new BuyerSeller[]
                    {
                        new BuyerSeller()
                        {
                            Type = "Individual",
                            SSN = "123-45-6789",
                            FirstName = "Buyer1Firstname",
                            LastName = "Buyer1Lastname",
                        },
                        new BuyerSeller()
                        {
                            Type = "Husband and Wife",
                            FirstName = "Buyer2Firstname",
                            LastName = "Buyer2Lastname",
                            SpouseFirstName = "Buyer2SpouseName",
                            SpouseLastName = "Buyer2Lastname"
                        }
                    },
                    Sellers = new BuyerSeller[]
                    {
                        new BuyerSeller()
                        {
                            Type = "Individual",
                            SSN = "987-65-4321",
                            FirstName = "Seller1FirstName",
                            LastName = "Seller1Lastname",
                        },
                        new BuyerSeller()
                        {
                            Type = "Husband and Wife",
                            FirstName = "Seller2Firstname",
                            LastName = "Seller2Lastname",
                            SpouseFirstName = "Seller2SpouseName",
                            SpouseLastName = "Seller2Lastname"
                        }
                    },
                    NewLoan = new NewLoan()
                    {
                        LoanNumber = "WCF_DefaultLoanNumber",
                        NewLoanAmount = 5000.00m,
                        LiabilityAmount = 5000.00m,
                        BenMortgageeTextID = 0,
                        FileBusinessParty = new FileBusinessParty
                        {
                            Name = "Nhat Nguyen",
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", regionBUID),
                        },
                        LoanTypeCdID = 0,
                        FundDate = DateTime.Today
                    },
                    FileNotes = new FileNote[]
                    {
                        new FileNote()
                        {
                            TypeCdID = 695, //EPIC
                            Note = @"Notes Data including - * # Specialcharacter :) !"
                        }
                    }
                }
            };
        }

        public static DeleteBuyerSellerRequest GetDeleteBuyerSellerRequest(int fileID, string principalType, int seqNum)
        {
            return new DeleteBuyerSellerRequest()
            {
                FileID = fileID,
                BuyerSeller = new FASTWCFHelpers.FastFileService.BuyerSeller()
                {
                    SeqNum = seqNum
                },
                PrincipalType = principalType,
                LoginName = "fastts\\fastqa07",
                Source = "FAMOS"
            };
        }

        public static Service[] GetServices(bool isTO, bool isEO, bool isSEO, int? regionBUID = null, int? officeBUID = null)
        {
            if (isTO & !isEO & !isSEO)
                return new Service[]
                {
                    RequestFactory.GetService("TO", regionBUID, officeBUID)
                };
            else if (!isTO & isEO & !isSEO)
                return new Service[]
                {
                    RequestFactory.GetService("EO", regionBUID, officeBUID)
                };
            else if (!isTO & !isEO & isSEO)
                return new Service[]
                {
                    RequestFactory.GetService("SEO", regionBUID, officeBUID)
                };
            else if (isTO & isEO & !isSEO)
                return new Service[]
                {
                    RequestFactory.GetService("TO", regionBUID, officeBUID),
                    RequestFactory.GetService("EO", regionBUID, officeBUID)
                };
            else if (isTO & !isEO & isSEO)
                return new Service[]
                {
                    RequestFactory.GetService("TO", regionBUID, officeBUID),
                    RequestFactory.GetService("SEO", regionBUID, officeBUID)
                };
            else if (!isTO & isEO & isSEO)
                return new Service[]
                {
                    RequestFactory.GetService("EO", regionBUID, officeBUID),
                    RequestFactory.GetService("SEO", regionBUID, officeBUID)
                };
            else
                return new Service[] { };
        }

        public static Service GetService(string typeObjectCD, int? regionBUID = null, int? officeBUID = null)
        {
            return new Service()
            {
                OfficeInfo = new OfficeInfo()
                {
                    RegionID = regionBUID ?? int.Parse(AutoConfig.SelectedRegionBUID),
                    BUID = officeBUID ?? int.Parse(AutoConfig.SelectedOfficeBUID),
                    ProductionOffices = new ProductionOffice[]
                    {
                        new ProductionOffice()
                        {
                            BUID = 0,
                            OfficeCode = 0,
                            RegionID = 0,
                            SeqNum = 0
                        }
                    }
                },
                ServiceTypeObjectCD = typeObjectCD
            };
        }

        public static DocTemplateRequest GetDocTemplateRequest(int documentId, int regionId)
        {
            return new DocTemplateRequest()
            {
                DocTemplateTypeCdID = documentId,
                DocumentSource = DocSource.Both,
                RegionID = regionId,
                LoginName = @"fastts\fastqa07",
                Source = "FAMOS"
            };
        }

        public static CreateFileRequest GetCreateFileDefaultRequest2BuyersSellers()
        {
            #region CreateFileRequest
            return new CreateFileRequest()
            {
                EmployeeObjectCD = "1",
                Source = "FAST",
                Target = "FAST",
                formType = ClosingDisclosureSupport.FormType,
                File = new File()
                {
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "RESIDENTAL",
                    ExternalFileNumber = "123456789",
                    AutoNumberIndicator = true,
                    BusinessParties = new FileBusinessParty[]
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.None
                            }
                        }
                    },
                    Services = new Service[]
                    {
                        new Service()
                        {
                            OfficeInfo = new OfficeInfo()
                            {
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID),
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID),
                                ProductionOffices = new ProductionOffice[]
                                {
                                    new ProductionOffice()
                                    {
                                        BUID = 0,
                                        OfficeCode = 0,
                                        RegionID = 0,
                                        SeqNum = 0
                                    }
                                }
                            },
                        ServiceTypeObjectCD = "TO"
                        },
                        new Service()
                        {
                            OfficeInfo = new OfficeInfo()
                            {
                                RegionID = int.Parse(AutoConfig.SelectedRegionBUID),
                                BUID = int.Parse(AutoConfig.SelectedOfficeBUID),
                                ProductionOffices = new ProductionOffice[]
                                {
                                    new ProductionOffice()
                                    {
                                        BUID = 0,
                                        OfficeCode = 0,
                                        RegionID = 0,
                                        SeqNum = 0
                                    }
                                }
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },
                    Properties = new Property[]
                    {
                        new Property()
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[]
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress()
                                {
                                    State = "CA",
                                    City = "ALBANY",
                                    County = "ALAMEDA",
                                    Country = "USA"
                                }
                            }
                        }
                    },
                    Buyers = new BuyerSeller[]
                    {
                        new BuyerSeller()
                        {
                            FirstName = "BuyerName",
                            LastName = "BuyerLastName",
                            EntityTypeID = 48,
                            Type = "Individual"
                        },
                        new BuyerSeller()
                        {
                            FirstName = "BuyerName2",
                            LastName = "BuyerLastName2",
                            EntityTypeID = 48,
                            Type = "Individual"
                        }
                    },
                    Sellers = new BuyerSeller[]
                    {
                        new BuyerSeller()
                        {
                            FirstName = "SellerName",
                            LastName = "SellerLastName",
                            EntityTypeID = 48,
                            Type = "Individual"
                        },
                        new BuyerSeller()
                        {
                            FirstName = "SellerName2",
                            LastName = "SellerLastName2",
                            EntityTypeID = 48,
                            Type = "Individual"
                        }

                    }
                }
            };
            #endregion
        }

        public static SearchFileFeeRequest GetSearchFeeEntryFileFeesRequest(int fileID, bool forFACCCal, FeeType efeetype)
        {
            return new SearchFileFeeRequest()
            {
                FileID = fileID,
                ForFaccCalc = forFACCCal,
                eFeeType = efeetype
            };
        }

        public static FeeEntryRequest GetUpdateFeeEntry_DDRequest(int fileID, int columnIndex)
        {
            var reqParams = new WCFTestDataStoreEntity
            {
                workBookName = "FileFees.xml",
                workSheetName = "UpdateFeeEntryDetails",
                columnNo = columnIndex
            };

            FeeEntryRequest Req = ExcelDataSerializer.GetRequestThruExcelDataStore<FeeEntryRequest>(reqParams);
            Req.FileID = fileID;
            return Req;
        }

        public static FeeEntryRequest GetUpdateFeeEntry_DDRequest(int fileID, string workSheetName, int columnIndex)
        {
            var reqParams = new WCFTestDataStoreEntity
            {
                workBookName = "FileFees.xml",
                workSheetName = workSheetName,
                columnNo = columnIndex
            };

            FeeEntryRequest Req = ExcelDataSerializer.GetRequestThruExcelDataStore<FeeEntryRequest>(reqParams);
            Req.FileID = fileID;
            return Req;
        }

        public static CreateOutsideTitleCompanyRequest GetOTCRequest(int fileId)
        {
            #region CreateOutsideTitleCompanyRequest
            var addressBookEntryId = (int)AdminService.GetGABAddressBookEntryId("415");
            return new CreateOutsideTitleCompanyRequest()
            {
                FileID = fileId,
                OTCDetails = new OTCDetails()
                {
                    ChargesRetained = (decimal)1300000,
                    eOTCType = OTCType.Attorney,
                },
                OTCLendersPolicyAndEndorsementChargesCD = GetOTCLendersPolicyAndEndorsementChargesCD(),
                OTCOwnersPolicyAndEndorsementChargesCD = GetCDChargePaymentDetailsList(),
                //OTCRecordingFeesAndTransferTaxesCD = GetOTCRecordingFeesAndTransferTaxesCD(),
                OTCTitleServiceChargesCD = GetCDChargePaymentDetailsList(),
                OutsideTitleCompanyParty = new FileBusinessParty()
                {
                    AddrBookEntryID = addressBookEntryId,
                    //LicenseInfo = GetLicenseDetails(119247),
                    BusOrgContact = new BusOrgContact()
                    {
                        ContactID = AdminService.GetGABByAddressBookEntryID(addressBookEntryId).GABContactID ?? 0,
                        //LicenseInfo = GetLicenseDetails(119248),
                    }
                },
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
            #endregion
        }

        public static PayoffLoanRequest GetPayOffLoanRequest(int? fileId, int? seqNum)
        {
            #region CreatePayOffLoanRequest
            return new PayoffLoanRequest()
            {
                CDInterestCalculationSummary = GetCDPayOffLoanInterestChargesetList(),
                CDLoanCharges = GetCDChargePaymentDetails(),
                CDPayoffLoanCharges = GetCDChargePaymentDetailsList(),
                FileID = fileId,
                GoodThroughDate = DateTime.Today.AddDays(28),
                InstrumentNumber = "1",
                LenderAttentionContacID = AdminService.GetGABByAddressBookEntryID(415).GABContactID,
                LoanTypeCdID = 668,
                LoginName = AutoConfig.UserName,
                PayOffLenderAddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"),
                PayOffLenderOrigPrincipalBal = 1500000,
                RecordedBook = "1",
                RecordedBookPageNumber = "1",
                RecordingDate = DateTime.Today,
                SeqNum = seqNum,
                Source = "FAMOS",
                TrustDeedDate = DateTime.Today,
                TrusteeAddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"),
                TrusteeAttentionContacID = AdminService.GetGABByAddressBookEntryID(415).GABContactID
            };
            #endregion
        }

        public static PayoffLoanRequest GetPayoffLoanRequest(int fileId, int lenderID)
        {
            return new PayoffLoanRequest()
            {
                FileID = fileId,
                GoodThroughDate = DateTime.Today.AddDays(28),
                LoanTypeCdID = 667,
                LoginName = AutoConfig.UserName,
                PayOffLenderAddrBookEntryID = AdminService.GetGABByAddressBookEntryID(lenderID).GABAddrBookEntryID,
                RecordedBook = "1",
                RecordedBookPageNumber = "1",
                RecordingDate = DateTime.Today.AddDays(7),
                RestrictDemandUpdates = 0,
                SeqNum = 1,
                Source = "FAMOS",
            };
        }

        public static CDPayOffLoanInterestChargeset[] GetCDPayOffLoanInterestChargesetList()
        {
            return new CDPayOffLoanInterestChargeset[]
                {
                    new CDPayOffLoanInterestChargeset(){
                        AnnualInterestRate = 2,
                        CDChargePaymentDetails = GetCDChargePaymentDetails(),
                        CalendarBaseDays = 365,
                        Description = "test-interest-charge",
                        FromDate = DateTime.Today,
                        FromDateInclusive = 1,
                        InterestType = 433,
                        PerDiemAmount = 0,
                        PerDiemFlag = 0,
                        SeqNum = 1,
                        ToDate = DateTime.Today.AddDays(28),
                        ToDateInclusive = 1,
                        TotalInterest = 0,
                    }
                };
        }

        public static LicenseDetails GetLicenseDetails(int licenseId)
        {
            return new LicenseDetails()
            {
                LicenseEntityType = LicenseEntityType.Busorg,
                StateLicenseInformationID = licenseId,
                StateLicenseNo = "CA, TEST04STTITLEINS"
            };
        }

        public static OTCRecordingFeesAndTransferTaxesCD GetOTCRecordingFeesAndTransferTaxesCD()
        {
            return new OTCRecordingFeesAndTransferTaxesCD()
            {
                OTCRecordingFeesAndTransferTaxesCDList = GetCdFeePaymentDetailsList(),
                OTCRecordingFeesLoanEstimateUnrounded = (decimal)999999.99,
                OTCTransferTaxesLoanEstimateUnrounded = (decimal)999999.99,
            };
        }

        public static OTCLendersPolicyAndEndorsementChargesCD GetOTCLendersPolicyAndEndorsementChargesCD()
        {
            return new OTCLendersPolicyAndEndorsementChargesCD()
            {
                DisplayAggregateOnCD = true,
                OTCLendersPolicyAndEndorsementChargesListCD = GetCDChargePaymentDetailsList(),
                TitlePremiumAdjustment = true,
            };
        }

        public static CdFeePaymentDetails[] GetCdFeePaymentDetailsList()
        {
            return new CdFeePaymentDetails[] { GetCdFeePaymentDetails() };
        }

        public static CDChargePaymentDetails[] GetCDChargePaymentDetailsList()
        {
            return new CDChargePaymentDetails[] { GetCDChargePaymentDetails() };
        }

        public static CdChargeDetails GetCdChargeDetails()
        {
            return new CdChargeDetails()
            {
                ChargeAmount = (decimal)1000000,
                PaidByAtClosing = (decimal)900000.00,
                PaidByBeforeClosing = (decimal)99999.99,
                PaidByOthers = (decimal)0.01,
                PaidByOthersPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                ePaymentMethod = PaymentMethodType.CHK,
            };
        }
        public static CdFeePaymentDetails GetCdFeePaymentDetails()
        {
            return new CdFeePaymentDetails()
            {
                Description = "test-description",
                BuyerCredit = (decimal)1000000,
                BuyerDetails = GetCdChargeDetails(),
                BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                //LoanEstimateUnrounded = (decimal)999999.99,
                SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                SellerDetails = GetCdChargeDetails(),
                PartOf = false,
                FeeID = 0,
                ServiceFileFeeId = 0,
                ePaymentMethodType = PaymentMethodType.FEE
            };
        }

        public static CdFileFee[] GetCdFileFeeList()
        {
            return new CdFileFee[] {
                new CdFileFee(){ FeePaymentDetails = GetCdFeePaymentDetails() },
            };
        }

        public static CDChargePaymentDetails GetCDChargePaymentDetails()
        {
            return new CDChargePaymentDetails()
            {
                AdditionalDescription = "test-description",
                AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                BuyerCharge = (decimal)1000000,
                BuyerCredit = (decimal)1000000,
                BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                LEAmount = (decimal)999999.99,
                PBBuyerAtClosing = (decimal)900000.00,
                PBBuyerBeforeClosing = (decimal)99999.99,
                PBOthersForBuyer = (decimal)0.01,
                PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                SellerCharge = (decimal)1000000,
                SellerCredit = (decimal)1000000,
                SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                PBSellerAtClosing = (decimal)900000.00,
                PBSellerBeforeClosing = (decimal)99999.99,
                PBOthersForSeller = (decimal)0.01,
                PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                PartOf = false,
                SeqNum = 1,
                eSectionShop = FASTWCFHelpers.FastFileService.SectionsShoppedFor.None,
            };
        }

        public static CreateDocumentRequest GetCreateDocumentDefaultRequest(int fileId, int templateId)
        {
            return new CreateDocumentRequest()
            {
                FileID = fileId,
                TemplateID = templateId,
                EmployeeID = 1,
                Source = "FAMOS",
            };
        }

        public static CreateDocumentRequest GetCreateDocumentRequest(int fileId)
        {
            return new CreateDocumentRequest()
            {
                DocTemplateTypeCode = "7",
                EmployeeID = 1,
                FileID = fileId,
                TemplateRegionID = 1486,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static CreateImageDocumentRequest GetCreateImageDocumentDefaultRequest()
        {
            return new CreateImageDocumentRequest()
            {
                //Missing fields: FileID, TemplateID
                Source = "FAMOS",
                //TemplateID = 22136,
                //TemplateID = 22649,
            };
        }

        public static CreateImageDocumentRequest GetCreateImageDocumentDefaultRequest(int fileID, int documentID)
        {
            return new CreateImageDocumentRequest()
            {
                FileID = fileID,
                DocumentID = documentID,
                Source = "FAMOS",
                Target = "FAST"
            };
        }

        public static CopyDocumentsRequest GetCopyDocumentDefaultRequest(string starterFileNum, string targetFileNum, int regionID, int[] documentIDs, int[] imageDocIDs)
        {
            return new CopyDocumentsRequest()
            {
                RegionID = regionID,
                StarterFileNum = starterFileNum,
                TargetFileNum = targetFileNum,
                DocumentIDs = documentIDs,
                ImageDocumentIDs = imageDocIDs,

                LoginName = AutoConfig.UserName,
                EmployeeID = 1,
                Source = "FAMOS",
                Target = "FAST"
            };
        }

        public static StarterRefDocumentRequest GetStarterRefDocumentDefaultRequest(int fileID)
        {
            return new StarterRefDocumentRequest
            {
                fileID = fileID,
                Source = "FAMOS",
                Target = "FAST",
                LoginName = AutoConfig.UserName
            };
        }

        public static GetImageDocument2Request GetImageDocument2DefaultRequest(int imageDocId)
        {
            return new GetImageDocument2Request
            {
                ImageDocumentID = imageDocId,
                Source = "FAMOS",
                Target = "FAST",
                LoginName = AutoConfig.UserName
            };
        }

        public static UploadImageRequest GetUploadImageDefaultRequest(int fileID, string documentName, string documentType, int documentTypeID, byte[] image)
        {
            return new UploadImageRequest
            {
                FileID = fileID,
                DocumentName = documentName,
                DocumentType = documentType,
                DocumentTypeID = documentTypeID,
                Document = image,
                Source = "FAMOS",
                Target = "FAST",
                LoginName = AutoConfig.UserName
            };
        }

        public static UploadImage2Request GetUploadImage2DefaultRequest(int fileID, string documentName, string documentType, int documentTypeID, byte[] image)
        {
            return new UploadImage2Request
            {
                FileID = fileID,
                DocumentName = documentName,
                DocumentType = documentType,
                DocumentTypeID = documentTypeID,
                Document = image,
                Source = "FAMOS",
                Target = "FAST",
                LoginName = AutoConfig.UserName
            };
        }

        public static EditDocumentRequest GetEditDocumentDefaultRequest(int fileID, int documentID, string editDocumentName)
        {
            return new EditDocumentRequest
            {
                FileID = fileID,
                DocumentID = documentID,
                EditDocumentName = editDocumentName,
                Source = "FAMOS",
                Target = "FAST",
                LoginName = AutoConfig.UserName
            };
        }

        public static StateListForDocTemplateRequest GetStateListForDocTemplateDefaultRequest(int templateID)
        {
            return new StateListForDocTemplateRequest
            {
                TemplateID = templateID,
                Source = "FAMOS",
                Target = "FAST",
                LoginName = AutoConfig.UserName
            };
        }

        public static AssociateDocPackage GetCreateAssociateDocPackageDefaultRequest(int fileID, Document[] docs, string packageName = null)
        {
            return GetAssociateDocPackageDefaultRequest(fileID, docs, packageName);
        }

        public static AssociateDocPackage GetAddDocumentToAssociateDocPackageDefaultRequest(int fileID, Document[] docs, string packageName = null)
        {
            return GetAssociateDocPackageDefaultRequest(fileID, docs, packageName);
        }

        public static AssociateDocPackage GetRemoveDocumentsFromAssociateDocPackageDefaultRequest(int fileID, Document[] docs, string packageName = null)
        {
            return GetAssociateDocPackageDefaultRequest(fileID, docs, packageName);
        }

        public static AssociateDocPackage GetModifyAssociateDocPackageDefaultRequest(int fileID, Document[] docs, string packageName = null)
        {
            return GetAssociateDocPackageDefaultRequest(fileID, docs, packageName);
        }

        public static AssociateDocPackage GetRemoveAssociateDocPackageDefaultRequest(int fileID, Document[] docs, string packageName = null)
        {
            return GetAssociateDocPackageDefaultRequest(fileID, docs, packageName);
        }

        private static AssociateDocPackage GetAssociateDocPackageDefaultRequest(int fileID, Document[] docs, string packageName = null)
        {
            return new AssociateDocPackage()
            {
                DocumentList = docs,
                FileID = fileID,
                PackageName = packageName ?? "PackageName_WCFTest",
                LoginName = @"fastts\fastqa07",
                Source = "FAMOS",
                Target = "FAST"
            };
        }

        public static AddLenderLoanInvestorRequest GetAddLenderLoanInvestorDefaultRequest(int fileID, int OrgLenderAddrBookID = 516787, int InvestorAddrBookID = 1256)
        {
            return new AddLenderLoanInvestorRequest()
            {
                FileID = fileID,
                LoanNum = "0123456789",
                LenderLoanInvestor = new LenderLoanInvestor()
                {
                    AddrBookEntryID = InvestorAddrBookID,
                    LenderLoanInvestorContacts = new LenderLoanInvestorContact[]
                    {
                        new LenderLoanInvestorContact()
                        {
                            AddrBookEntryID = InvestorAddrBookID
                        }
                    }
                },
                OrgLoanInvestorAddrBookEntryID = OrgLenderAddrBookID,
                Source = "FAMOS"
            };
        }

        public static AddPhraseRequest GetAddPhraseDefaultRequest()
        {
            return new AddPhraseRequest()
            {
                //Missing fields: FileID, DocumentID
                Source = "FAMOS",
                Phrases = new Phrase[] { new Phrase() { PhraseCode = "84227" } }
            };
        }

        public static AddPhraseRequest GetAddPhraseDefaultRequest(int fileID, int documentID)
        {
            return new AddPhraseRequest()
            {
                FileID = fileID,
                DocumentID = documentID,
                Source = "FAMOS",
                Target = "FAST",
                Phrases = new Phrase[] { new Phrase() { PhraseCode = "84227" } }
            };
        }

        public static AddPhraseRequest GetAddPhrasesToDocumentDefaultRequest()
        {
            return new AddPhraseRequest()
            {
                //Missing fields: FileID, DocumentID
                Source = "FAMOS",
                Phrases = new Phrase[] { new Phrase() { PhraseCode = "84227" } }
            };
        }

        public static AddProcessRequest GetAddProcessDefaultRequest()
        {
            return new AddProcessRequest()
            {
                //Missing fields: FileID, ProcessEventID, ProcessTriggerEventID
                Source = "FAMOS"
            };
        }

        public static AddProcessType GetAddProcessTypeDefaultRequest()
        {
            return new AddProcessType()
            {
                //Missing fields: FileID, ProcessTypeID
                //ProcessTypeID = 
                Source = "FAMOS"
            };
        }

        public static AddBuyerSellerRequest GetAddBuyerSellerRequest(string buyerSellerType)
        {
            #region AddBuyerSellerRequest
            AddBuyerSellerRequest buyerSeller = new AddBuyerSellerRequest();
            switch (buyerSellerType.ToLowerInvariant())
            {
                case "individual":
                    buyerSeller = SetValuesForAddBuyerSellerRequest(buyerSellerType, 48);
                    return buyerSeller;

                case "husband/wife":
                    buyerSeller = SetValuesForAddBuyerSellerRequest(buyerSellerType, 49);
                    buyerSeller.BuyerSeller.ShortName = "TrustShortName";
                    buyerSeller.BuyerSeller.SpouseFirstName = "SpouseFN";
                    buyerSeller.BuyerSeller.SpouseLastName = "SpouseLN";
                    buyerSeller.BuyerSeller.TrustNumber = "123456";
                    buyerSeller.BuyerSeller.SeqNum = 2;

                    return buyerSeller;

                case "trust":
                    buyerSeller = SetValuesForAddBuyerSellerRequest(buyerSellerType, 50);
                    buyerSeller.BuyerSeller.TrustNumber = "112";
                    buyerSeller.BuyerSeller.ShortName = "Trust";
                    return buyerSeller;

                case "business entity":
                    buyerSeller = SetValuesForAddBuyerSellerRequest(buyerSellerType, 51);
                    buyerSeller.BuyerSeller.ShortName = "BusinessEntity";
                    return buyerSeller;
            }
            return new AddBuyerSellerRequest();
            #endregion
        }

        public static AuthorizedSignaturesRequest GetAuthorizedSignatureRequest(int? principalId, int employeeId = 1)
        {
            return new AuthorizedSignaturesRequest()
            {
                EmployeeID = employeeId,
                PrincipalID = principalId ?? 0,
                LoginName = @"fastts\fastqa07",
                Source = "FAMOS",
            };
        }

        public static BuyerSellerSignaturesTypesRequest GetBuyerSellerSignaturesTypesRequest()
        {
            return new BuyerSellerSignaturesTypesRequest()
            {
                LoginName = @"fastts\fastqa07",
                Source = "FAMOS",
            };
        }

        public static UpdateBuyerSellerRequest GetUpdateBuyerSellerRequest(string buyerSellerType)
        {
            #region UpdateBuyerSellerRequest
            return new UpdateBuyerSellerRequest()
            {
                BuyerSeller = new BuyerSeller()
                {
                    BuyerSellerTypeID = 48,

                    CurrentAddress = new BuyerSellerAddress()
                    {
                        AddrLine1 = "CurrentAddress",
                        BuyerSellerAddressTypeCdID = 80,
                        City = "CurrentCity",
                        Country = "USA",
                        County = "NewOrange",
                        State = "CA",
                    },
                    FirstName = "UpdatedBuyerName",
                    ForwardingAddress = new BuyerSellerAddress()
                    {
                        AddrLine1 = "Forwading Address",
                        BuyerSellerAddressTypeCdID = 80,
                        City = "ForwardCity",
                        Country = "USA",
                        County = "Orange",
                        State = "CA",
                    },
                    LastName = "LastUpdated",
                    SeqNum = 1,
                    SpouseFirstName = "SpouseUpdatedFN",
                    SpouseLastName = "SpouseUpdatedLN",
                },
                FileID = 0,
                PrincipalType = "BUYER",
                LoginName = "fastts\fastqa07",
                Source = "famos",
            };
            #endregion
        }

        public static AddTaskRequest GetAddTaskDefaultRequest()
        {
            return new AddTaskRequest()
            {
                //
                EmployeeObjectCD = "1",
                oTaskTemplate = new TaskTemplate() { TaskTemplateID = -1 },
                Source = "FAMOS"
            };
        }

        public static GetTaskDetailsRequest GetTaskDetailsDefaultRequest()
        {
            return new GetTaskDetailsRequest()
            {
                //Missing fields: FileID, TaskID
            };
        }

        public static NewLoanPayChargeAssociationRequest GetNewLoanPayChargeAssociationRequest(int fileID, int seqNum, DisbursementCharge charge, PayChargeFileBusinessParty fileBusParty)
        {
            return new NewLoanPayChargeAssociationRequest()
            {
                EmployeeID = 1,
                FileID = fileID,
                SeqNum = seqNum,
                LoginName = AutoConfig.UserName,
                Source = "FAMOS",
                Target = "FAST",
                ChargeDetails = new NewLoanDisbursementCharge[]{
                   new NewLoanDisbursementCharge(){
                      ChargeId = charge != null ? charge.ChargeID : 0,
                      IsSelected = true,
                      AddressBookEntryId = fileBusParty != null ? fileBusParty.AddrBookEntryID : 0,
                   }
                },
                PayeeInformation = new NewLoanDisbursementPayeeInformation[]{
                    new NewLoanDisbursementPayeeInformation(){
                       eOperationType = OperationType.Update,
                       FileBusinessParty = new FileBusinessParty(){
                           FileBusinessPartyID = fileBusParty != null ? fileBusParty.FileBusinessPartyID : 0,
                       }
                    }
                },
            };
        }

        public static NewLoanRequest GetNewLoanDefaultRequest(string fileID, int? seqNum)
        {
            return new NewLoanRequest()
            {
                FileID = int.Parse(fileID),
                LoanDetails = new NewLoanDetail()
                {
                    LoanNumber = "NewLoan_FromWCF_UsingNewLoanRequest",
                    LoanAmount = 55.00m,
                    LenderInformation = new PayChargeFileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247")
                    }
                },
                SeqNum = seqNum,
                EmployeeID = 1,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static NewLoanRequest GetNewLoanRequest(int? fileID, int? seqNum)
        {
            return new NewLoanRequest()
            {
                FileID = fileID,
                LoanCharges = new LoanCharge() { },
                SeqNum = seqNum,
                EmployeeID = 1,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static RemoveNewLoanRequest GetRemoveNewLoanRequest(int? fileID, int? seqNum)
        {
            return new RemoveNewLoanRequest()
            {
                FileID = fileID,
                SeqNum = seqNum,
                EmployeeID = 1,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static LoanCharge GetCDLoanCharge()
        {
            return new LoanCharge()
            {
                CDCreditOrChargePoints = new CDCreditOrChargePoints()
                {
                    CDChargePaymentDetails = new CDChargePaymentDetails()
                    {
                        BuyerCharge = 1000,
                        SellerCharge = 1000,
                        LEAmount = 1000,
                        SeqNum = 1
                    },
                    CDSelectedDispFrmt = 2475,
                    DiscountPointAdjAmt = 0,
                    DiscountPointPercent = 10,
                    IRSDiscountPoints = 1
                },
                CDFutureRecordingFeesCollectedByLender = new CDChargePaymentDetails[]{
                    new CDChargePaymentDetails(){
                        BuyerCharge = 1000,
                        SeqNum = 1
                    }
                },
                CDImpoundCharges = new CDImpoundCharge()
                {
                    AAACreditChargeFlag = 1,
                    AggregateAccountingAdjustment = new CDChargePaymentDetails()
                    {
                        BuyerCharge = 1000,
                        SellerCharge = 1000,
                        SeqNum = 1,
                    },
                    Impounds = new CDChargePaymentDetails[]{
                        new CDChargePaymentDetails(){
                            Months = 5,
                            MonthlyCharge = 200,
                            BuyerCharge = 1000,
                            SellerCharge = 1000,
                            LEAmount = 1000,
                            SeqNum = 1
                        }
                    }
                },
                CDInterestCalculationSummary = new CDInterestCalculationSummary()
                {
                    CDChargePaymentDetails = new CDChargePaymentDetails()
                    {
                        BuyerCharge = 1000,
                        SellerCharge = 1000,
                        LEAmount = 1000
                    },
                    InterestCalculation = new InterestCalculation()
                    {
                        BasedOnDays = 365,
                        From = DateTime.UtcNow,
                        FromInclusive = false,
                        InterestFlag = 1,
                        InterestTypeCdID = 433,
                        PercentageRate = 2,
                        To = DateTime.UtcNow.AddDays(28),
                        ToInclusive = false
                    }
                },
                CDLenderCredits = new CDChargePaymentDetails[] {
                    new CDChargePaymentDetails() {
                        BuyerCredit = 1000,
                        BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        LEAmount = 1000,
                        SeqNum = 1
                    }
                },
                CDNewLoanCharges = new CDChargePaymentDetails[] {
                    new CDChargePaymentDetails() {
                        BuyerCharge = 1000,
                        SellerCharge = 1000,
                        LEAmount = 1000,
                        SeqNum = 1
                    }
                },
                CDOriginationCharges = new CDChargePaymentDetails[] {
                    new CDChargePaymentDetails() {
                        BuyerCharge = 1000,
                        SellerCharge = 1000,
                        LEAmount = 1000,
                        SeqNum = 1
                    }
                },
                CDPrincipalBalanceCharges = new CDChargePaymentDetails()
                {
                    BuyerCredit = 1500000,
                    BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                    SellerCharge = 1000,
                    LEAmount = 1500000,
                },
                CDPrincipalReductionOrConstructionHoldBack = new CDChargePaymentDetails[] {
                    new CDChargePaymentDetails() {
                        BuyerCharge = 1000,
                        SellerCharge = 1000,
                        LEAmount = 1000,
                        SeqNum = 1
                    }
                },
            };
        }

        public static LoanCharge GetHUDLoanCharge()
        {
            return new LoanCharge()
            {
                //  AdjustedOriginationCharges is read-only
                CreditOrChargePoints = new CreditOrChargePoints()
                {
                    CCPCreditChargeFlag = 1,
                    DiscountPointPercent = 10,
                    GFEAmount = 1000,
                    PaymentDetail = new PaymentDetailsWithGFE()
                    {
                        LenderSelectedProvider = true,
                        PaidOnBehalfOfBorrower = false,
                        BuyerCharge = 1000,
                        GfeEntryTypeCdID = 1592,
                        SeqNum = 30,
                        UseDefault = true,
                    },
                    PointFlag = 1,
                },
                GFE3LoanCharges = new GFELoanCharges[]{
                    new GFELoanCharges(){
                        GFEAmount = 1000,
                        PaymentDetail = new PaymentDetailsWithGFEAndPOC(){
                            BuyerCharge = 1000,
                            BuyerCredit = 1000,
                            SellerCharge = 1000,
                            SellerCredit = 1000,
                            SeqNum = 90,
                        }
                    }
                },
                GFE6LoanCharges = new GFELoanCharges[]{
                    new GFELoanCharges(){
                        GFEAmount = 1000,
                        PaymentDetail = new PaymentDetailsWithGFEAndPOC(){
                            BuyerCharge = 1000,
                            BuyerCredit = 1000,
                            SellerCharge = 1000,
                            SellerCredit = 1000,
                            SeqNum = 210,
                        }
                    }
                },
                GFE7LoanCharges = new GFE7LoanCharges[]{
                    new GFE7LoanCharges(){
                        GFEAmount = 1000,
                        PaymentDetail = new PaymentDetailsWithGFE(){
                            BuyerCharge = 1000,
                            SeqNum = 10,
                        }
                    }
                },
                ImpoundCharges = new ImpoundCharge()
                {
                    AAACreditChargeFlag = 1,
                    AggrAcctAdjBuyerChargeAmount = 1000,
                    AggrAcctAdjSellerChargeAmount = 1000,
                    GFEAmount = 1000,
                    Impounds = new Impound[] {
                        new Impound() {
                            MonthlyCharge = 200,
                            Months = 5,
                            PaymentDetails = new PaymentDetailsWithGFE(){
                                BuyerCharge = 1000,
                                SellerCharge = 1000,
                                SeqNum = 60,
                            }
                        }
                    },
                    InitialDepositBuyerChargeAmount = 2000,
                    InitialDepositSellerChargeAmount = 2000,
                },
                InterestCalculationSummary = new InterestCalculationSummary()
                {
                    InterestCalculation = new InterestCalculation()
                    {
                        BasedOnDays = 365,
                        From = DateTime.UtcNow,
                        FromInclusive = false,
                        InterestFlag = 1,
                        InterestTypeCdID = 433,
                        PercentageRate = 10,
                        To = DateTime.UtcNow.AddDays(28),
                        ToInclusive = false
                    }
                },
                ItemisedOrgCharges = new ItemisedOriginationCharge[] {
                    new ItemisedOriginationCharge() {
                        IsReadOnly = true,
                        PaymentDetail = new PaymentDetailsWithGFE() {
                            LenderSelectedProvider = true,
                            PaidOnBehalfOfBorrower = false,
                            Description = "test-charge",
                            BuyerCharge = 1000,
                        }
                    },
                },
                OriginationCharges = new OriginationCharge()
                {
                    GFEAmount = 1000000,
                    OriginationFeePercent = 10,
                    OriginationFlag = 1,
                    PaymentDetails = new PaymentDetailsWithGFE()
                    {
                        LenderSelectedProvider = true,
                        PaidOnBehalfOfBorrower = false,
                        BuyerCharge = 1000000,
                        SellerCharge = null,
                        SeqNum = 10,
                        UseDefault = true,
                    }
                },
                PrincipalBalanceCharges = new PaymentDetails()
                {
                    BuyerCharge = 1000000,
                    BuyerCredit = 1000000,
                    SellerCharge = 1000,
                    SellerCredit = 1000,
                    SeqNum = 1,
                },
                PrincipalReductionOrConstructionHoldBack = new PaymentDetailsWithGFE[] {
                    new PaymentDetailsWithGFE() {
                        BuyerCharge = 1000,
                        BuyerCredit = 1000,
                        SellerCharge = 1000,
                        SellerCredit = 1000,
                        SeqNum = 10,
                    }
                }
            };
        }

        public static LoanCharge GetCD2ndLoanCharge()
        {
            return new LoanCharge()
            {
                CDInterestCalculationSummary = new CDInterestCalculationSummary()
                {
                    CDChargePaymentDetails = new CDChargePaymentDetails()
                    {
                        BuyerCharge = 1000,
                        SellerCharge = 1000,
                        LEAmount = 1000
                    },
                    InterestCalculation = new InterestCalculation()
                    {
                        BasedOnDays = 365,
                        From = DateTime.UtcNow,
                        FromInclusive = false,
                        InterestFlag = 1,
                        InterestTypeCdID = 433,
                        PercentageRate = 2,
                        To = DateTime.UtcNow.AddDays(28),
                        ToInclusive = false
                    }
                },
                CDNewLoanCharges = new CDChargePaymentDetails[] {
                    new CDChargePaymentDetails() {
                        BuyerCharge = 1000,
                        BuyerCredit = 1000,
                        BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        SellerCharge = 1000,
                        SellerCredit = 1000,
                        SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        LEAmount = 1000,
                        SeqNum = 1
                    }
                },
                CDPrincipalBalanceCharges = new CDChargePaymentDetails()
                {
                    BuyerCredit = 1500000,
                    BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                    LEAmount = 1500000,
                    SeqNum = 1,
                },
            };
        }

        public static LoanCharge GetHUD2ndLoanCharge()
        {
            return new LoanCharge()
            {
                ImpoundCharges = new ImpoundCharge()
                {
                    Impounds = new Impound[] {
                        new Impound() {
                            MonthlyCharge = 200,
                            Months = 5,
                            PaymentDetails = new PaymentDetailsWithGFE(){
                                BuyerCharge = 1000,
                                SellerCharge = 1000,
                                SeqNum = 10,
                            }
                        }
                    },
                    InitialDepositBuyerChargeAmount = 2000,
                    InitialDepositSellerChargeAmount = 2000,
                },
                InterestCalculationSummary = new InterestCalculationSummary()
                {
                    InterestCalculation = new InterestCalculation()
                    {
                        BasedOnDays = 365,
                        From = DateTime.UtcNow,
                        FromInclusive = false,
                        InterestFlag = 1,
                        InterestTypeCdID = 433,
                        PercentageRate = 10,
                        To = DateTime.UtcNow.AddDays(28),
                        ToInclusive = false
                    }
                },
                NewLoanCharges = new PaymentDetailsWithGFE[] {
                    new PaymentDetailsWithGFE() {
                        BuyerCharge = 1000,
                        BuyerCredit = 1000,
                        SellerCharge = 1000,
                        SellerCredit = 1000,
                        SeqNum = 80,
                    }
                },
                PrincipalBalanceCharges = new PaymentDetails()
                {
                    BuyerCharge = 1000000,
                    BuyerCredit = 1000000,
                    SellerCharge = 1000,
                    SellerCredit = 1000,
                    SeqNum = 10,
                },
            };
        }

        public static CDCreditOrChargePoints GetCDCreditOrChargePoints()
        {
            return new CDCreditOrChargePoints()
            {
                CDChargePaymentDetails = GetCDChargePaymentDetails(),
                CDSelectedDispFrmt = 2475,
                DiscountPointAdjAmt = null,
                DiscountPointPercent = 10,
                IRSDiscountPoints = 1
            };
        }

        public static NewMiscDisbusementRequest GetNewMiscDisbursementRequest(int? fileID = null, int? seqNum = null)
        {
            return new NewMiscDisbusementRequest()
            {
                CheckAmount = (decimal)1500000,
                FileBusinessParty = new FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415") },
                FileID = fileID,
                SeqNum = seqNum,
                EmployeeID = 1,
                Source = @"FAMOS"
            };
        }

        public static DeleteMiscDisbRequest GetDeleteMiscDisbRequest(int? fileID = null, int? seqNum = null)
        {
            return new DeleteMiscDisbRequest()
            {
                FileID = fileID,
                SeqNum = seqNum,
                EmployeeID = 1,
                Source = @"FAMOS"
            };
        }

        public static MiscDisbSummaryRequest GetMiscDisbSummaryRequest(int? fileID)
        {
            return new MiscDisbSummaryRequest()
            {
                FileID = fileID,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static FeeEntryRequest GetFeeEntryRequest(int? fileId = null)
        {
            return new FeeEntryRequest()
            {
                EmployeeID = 1,
                FileID = fileId,
                RecordingAndTax = new RecordingAndTax()
                {
                    GovernmentRecordingAndTransferTaxes = new GovernmentRecordingAndTransferTaxes()
                    {
                        CdTransferTax = new LoanEstimateRAndUR() { },
                        GovernmentCdRecordingCharges = new LoanEstimateRAndUR() { }
                    },
                },
                TitleAndEscrow = new TitleAndEscrow()
                {
                    TitlePolicyCalculationsForCD = new CdTitlePolicyCalculations()
                    {
                        DisclosedOwnerPremium = new CdFeeInformation() { },
                        FullLoanPremium = new CdFeeInformation() { }
                    },
                    TitleServicesAndTitleInsurance = new TitleServicesAndTitleInsurance()
                    {
                        OwnersTitleInsurance = new GFEInformation() { },
                        TitleServicesOrLenderTitleIns = new GFEInformation() { }
                    },
                },
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static OrderSigningRequest GetOrderSigningRequest(int fileId, int signingID)
        {
            return new OrderSigningRequest
            {
                EmployeeID = 1,
                FileID = fileId,
                SigningID = signingID,
                Source = "FAST"
            };
        }
        // Added by Jimmy to Update 2nd Ordersource with Wintrack, Agennet, Lvis..etc..
        public static UpdateSecondOrderSourceRequest GetUpdateSecondOrderSourceRequest(int fileId, int appID, string Source = "WINTACK", string secondExternalFileNum = "ext123456789")
        {
            return new UpdateSecondOrderSourceRequest
            {
                FileID = fileId,
                SecondSourceApplID = appID,
                SecondExternalFileNum = secondExternalFileNum,
                SecondSourceApplQueueName = @"DIRECT=OS:SERVER\Private$\UpdateStatus",
                Source = Source,
                Target = "FAST"
            };
        }

        public static NewLoanRequest GetNewLoanCreateRequest(string fileID, int? seqNum)
        {
            return new NewLoanRequest()
            {
                FileID = int.Parse(fileID),
                LoanDetails = new NewLoanDetail()
                {
                    LoanNumber = "NewLoan_FromWCF_UsingNewLoanRequest",
                    LoanAmount = 1000.01m,
                    LoanDates = new LoanDates()
                    {
                        RescissionDays = 3
                    },
                    LenderInformation = new PayChargeFileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247")
                    },
                    MortgageInsuranceCaseNumber = "123425"
                },
                LoanCharges = new LoanCharge()
                {

                    CDPrincipalBalanceCharges = new CDChargePaymentDetails()
                    {
                        AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.RBL,
                        Description = "UpdateBal",
                        LEAmount = 11.11m,
                        PBOthersForSeller = 1.01m,
                        PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POCMB,
                        PBSellerAtClosing = 5.01m,
                        PBSellerBeforeClosing = 6.01m,
                        SellerCharge = 12.03m,
                        SeqNum = 1

                    },

                    CDInterestCalculationSummary = new CDInterestCalculationSummary()
                    {
                        CDChargePaymentDetails = new CDChargePaymentDetails()
                        {
                            AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.RBL,
                            BuyerCharge = 12.04m,
                            Description = "Test",
                            LEAmount = 5.06m,
                            PBBuyerAtClosing = 6.02m,
                            PBBuyerBeforeClosing = 4.01m,
                            PBOthersForBuyer = 2.01m,
                            PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                            SeqNum = 1
                        },
                        InterestCalculation = new InterestCalculation()
                        {
                            BasedOnDays = 365,
                            FromInclusive = false,
                            PerDiemAmount = 100.02m,
                            ToInclusive = true,
                            UsePerDiemFlag = true
                        },
                    },


                    CDNewLoanCharges = new CDChargePaymentDetails[] {
                          new CDChargePaymentDetails()
                            {
                                AtClosingBuyerPaymentMethodTypeID=FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.RBL,
                                AtClosingSellerPaymentMethodTypeID=FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.RBL,
                                BuyerCharge=12.03m,
                                Description="NewLoanChargeUpdate",
                                LEAmount=5.02m,
                                PBBuyerAtClosing=5.01m,
                                PBBuyerBeforeClosing=5.01m,
                                PBOthersForBuyer=2.01m,
                                PBOthersForBuyerPMTypeCdID=FASTWCFHelpers.FastFileService.OtherPaymentMethods.POCMB,
                                PBOthersForSeller=1.01m,
                                PBOthersForSellerPMTypeCdID=FASTWCFHelpers.FastFileService.OtherPaymentMethods.POCL,
                                PBSellerAtClosing=2.01m,
                                PBSellerBeforeClosing=3.01m,
                                SellerCharge=6.03m,
                                SeqNum=1
                            },
                            new CDChargePaymentDetails()
                            {
                                AdhocFlag=1,
                                AtClosingBuyerPaymentMethodTypeID=FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.RBL,
                                AtClosingSellerPaymentMethodTypeID=FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.RBL,
                                BuyerCharge=30.03m,
                                Description="Check LoanUpdate",
                                LEAmount=2.66m,
                                PBBuyerAtClosing=10.01m,
                                PBBuyerBeforeClosing=10.01m,
                                PBOthersForBuyer=10.01m,
                                PBOthersForBuyerPMTypeCdID=FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                                PBOthersForSeller=5.01m,
                                PBOthersForSellerPMTypeCdID=FASTWCFHelpers.FastFileService.OtherPaymentMethods.POCL,
                                PBSellerAtClosing=5.01m,
                                PBSellerBeforeClosing=5.01m,
                                SellerCharge=15.03m,

                            },
                        },
                },

                MortgageBroker = new MortgageBroker()
                {
                    CDBrokerFee = new BrokerFee()
                    {
                        Description = "Check BrokerFeeNew",
                        FileCharge = 14.33m,
                        PaymentMethodTypeID = 2390
                    },

                    CDMortgageBrokerCharges = new CDChargePaymentDetails[]
                        {
                            new CDChargePaymentDetails()
                            {
                             AtClosingBuyerPaymentMethodTypeID=FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.RBL,
                             AtClosingSellerPaymentMethodTypeID=FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.RBL,
                             BuyerCharge=22.05m,
                             Description="Check",
                             LEAmount = 5.03m,
                             PBBuyerAtClosing=10.01m,
                             PBOthersForBuyer=12.04m,
                             PBOthersForBuyerPMTypeCdID=FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                             PBOthersForSeller=3.01m,
                             PBOthersForSellerPMTypeCdID=FASTWCFHelpers.FastFileService.OtherPaymentMethods.POCL,
                             PBSellerAtClosing=1.01m,
                             PBSellerBeforeClosing=5.01m,
                             SellerCharge = 9.03m,
                             SeqNum=1
                            },

                            new CDChargePaymentDetails()
                            {
                                AdhocFlag=1,
                             AtClosingBuyerPaymentMethodTypeID=FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.RBL,
                             AtClosingSellerPaymentMethodTypeID=FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.RBL,
                             BuyerCharge=12.03m,
                             Description="Adhoc MortgageCharge",
                             LEAmount = 5.03m,
                             PBBuyerAtClosing=4.01m,
                             PBBuyerBeforeClosing=4.01m,
                             PBOthersForBuyer=4.01m,
                             PBOthersForBuyerPMTypeCdID=FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                             PBOthersForSeller=2.01m,
                             PBOthersForSellerPMTypeCdID=FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                             PBSellerAtClosing=2.01m,
                             PBSellerBeforeClosing=2.01m,
                             SellerCharge = 6.03m,
                            },
                        },
                    MorgageBrokerInformation = new FileBusinessParty()
                    {
                        AddrBookEntryID = 8835488
                    },
                },

                SeqNum = seqNum,
                EmployeeID = 1,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        #region GetNewLoanUpdateRequest
        public static NewLoanRequest GetNewLoanUpdateRequest(string fileID, int? seqNum)
        {
            return new NewLoanRequest()
            {
                FileID = int.Parse(fileID),
                SeqNum = seqNum,
                LoanDetails = new NewLoanDetail()
                {
                    HazardInsuranceLossPayee = new HazardInsuranceLossPayee
                    {
                        Text = "Hazard"
                    },
                    LoanNumber = "NewLoan_FromWCF_UsingNewLoanRequest",
                    LoanTypeID = 444,
                    LoanAmount = 55555555555m,
                    LiabilityAmount = 55555555555m,
                    MortgageInsuranceCaseNumber = "123425",
                    LoanDates = new LoanDates()
                    {
                        RescissionDays = 3
                    },
                    LenderInformation = new PayChargeFileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247")
                    },
                },
                LoanCharges = new LoanCharge()
                {
                    #region HUD
                    CreditOrChargePoints = new CreditOrChargePoints
                    {
                        CCPCreditChargeFlag = 2,
                        PaymentDetail = new PaymentDetailsWithGFE
                        {
                            BuyerCharge = 10.01m
                        }
                    },
                    GFE3LoanCharges = new GFELoanCharges[]
                    {
                        new GFELoanCharges
                        {
                            PaymentDetail = new PaymentDetailsWithGFEAndPOC
                            {
                                BuyerCharge = 10.02m,
                                BuyerPaymentMethodTypeID = 385,
                                SellerCharge = 22.01m,
                                SellerPaymentMethodTypeID = 385
                            }
                        },
                        new GFELoanCharges
                        {
                            PaymentDetail = new PaymentDetailsWithGFEAndPOC
                            {
                                BuyerCharge = 122.01m,
                                BuyerPaymentMethodTypeID = 385,
                                Description = "GFE3Adhoc",
                                SellerCharge = 201.01m,
                                SellerPaymentMethodTypeID = 385
                            }
                        }
                    },
                    GFE6LoanCharges = new GFELoanCharges[]
                    {
                        new GFELoanCharges
                        {
                            PaymentDetail = new PaymentDetailsWithGFEAndPOC
                            {
                                Description = "GFE6 Description",
                                AdhocFlag = 1,
                                BuyerCharge = 10.02m,
                                BuyerPaymentMethodTypeID = 385,
                                SellerCharge = 22.01m,
                                SellerPaymentMethodTypeID = 385
                            }
                        },
                        new GFELoanCharges
                        {
                            PaymentDetail = new PaymentDetailsWithGFEAndPOC
                            {
                                AdhocFlag = 1,
                                BuyerCharge = 150.02m,
                                BuyerPaymentMethodTypeID = 385,
                                Description = "GFE6Adhoc",
                                SellerCharge = 202.01m,
                                SellerPaymentMethodTypeID = 385
                            }
                        }
                    },
                    ImpoundCharges = new ImpoundCharge
                    {
                        AAACreditChargeFlag = 1,
                        Description = "Impound",
                        GFEAmount = 1020.01m,
                        Impounds = new Impound[]
                        {
                            new Impound
                            {
                                MonthlyCharge = 88.03m,
                                Months = 6,
                                PaymentDetails = new PaymentDetailsWithGFE
                                {
                                    AdhocFlag = 1,
                                    BuyerPaymentMethodTypeID = 385,
                                    Description = "Impound",
                                    SellerPaymentMethodTypeID = 385
                                }
                            }
                        }
                    },
                    InterestCalculationSummary = new InterestCalculationSummary
                    {
                        InterestCalculation = new InterestCalculation
                        {
                            BasedOnDays = 365,
                            FromInclusive = true,
                            InterestFlag = 1,
                            InterestTypeCdID = 431,
                            PerDiemAmount = 201.01m,
                            ToInclusive = true,
                            UsePerDiemFlag = true
                        }
                    },
                    OriginationCharges = new OriginationCharge
                    {
                        GFEAmount = 1100.02m,
                        OriginationFeePercent = 1,
                        OriginationFlag = 1
                    },
                    PayCharges = new PayCharge
                    {
                        DisbursementCharges = new DisbursementCharge[]
                        {
                            new DisbursementCharge
                            {
                                BuyerCharge = 2131.01m,
                                Description = "Test",
                            },
                            new DisbursementCharge
                            {
                                BuyerCharge = 2013.04m,
                                Description = "New Loan"
                            }
                        }
                    },
                    #endregion
                    #region CD
                    CDCreditOrChargePoints = new CDCreditOrChargePoints()
                    {
                        CDChargePaymentDetails = new CDChargePaymentDetails()
                        {
                            AtClosingSellerPaymentMethodTypeID = AtClosingPaymentMethods.RBL,
                            AtClosingBuyerPaymentMethodTypeID = AtClosingPaymentMethods.RBL,
                            BuyerCharge = 11.04m,
                            Description = "Validate",
                            LEAmount = 6.22m,
                            PBBuyerAtClosing = 6.02m,
                            PBBuyerBeforeClosing = 5.02m,
                            PBOthersForSeller = 2.01m,
                            PBOthersForSellerPMTypeCdID = OtherPaymentMethods.POC,
                            PBSellerAtClosing = 2.02m,
                            PBSellerBeforeClosing = 2.01m,
                            SellerCharge = 6.04m,
                            SeqNum = 1,
                        },
                        CDSelectedDispFrmt = 2474,
                        DiscountPointAdjAmt = 2,
                        IRSDiscountPoints = 1
                    },
                    CDFutureRecordingFeesCollectedByLender = new CDChargePaymentDetails[]
                    {
                        new CDChargePaymentDetails()
                        {
                            AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            BuyerCharge=12.03m,
                            SeqNum=1
                        },
                    },
                    CDImpoundCharges = new CDImpoundCharge()
                    {
                        AggregateAccountingAdjustment = new CDChargePaymentDetails()
                        {
                            AtClosingBuyerPaymentMethodTypeID = AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID = AtClosingPaymentMethods.RBL,
                            BuyerCharge = 1.01m
                        },
                        Impounds = new CDChargePaymentDetails[]
                        {
                            new CDChargePaymentDetails()
                            {
                                AdhocFlag=0,
                                AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                                AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                                MonthlyCharge=12.01m,
                                Months=3,
                                PBOthersForSeller=1.01m,
                                PBOthersForSellerPMTypeCdID=OtherPaymentMethods.POC,
                                PBSellerAtClosing=5.01m,
                                PBSellerBeforeClosing=5.01m,
                                SellerCharge=11.03m,
                                SeqNum=1
                            },
                            new CDChargePaymentDetails()
                            {
                                AdhocFlag=1,
                                AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                                AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                                Description="Check Impound",
                                LEAmount=11.02m,
                                MonthlyCharge=10.02m,
                                Months=2,
                                SellerCharge=22.01m,
                            },
                        },
                    },
                    CDInterestCalculationSummary = new CDInterestCalculationSummary()
                    {
                        CDChargePaymentDetails = new CDChargePaymentDetails()
                        {
                            AtClosingBuyerPaymentMethodTypeID = AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID = AtClosingPaymentMethods.RBL,
                            BuyerCharge = 12.04m,
                            Description = "Test",
                            LEAmount = 5.06m,
                            PBBuyerAtClosing = 6.02m,
                            PBBuyerBeforeClosing = 4.01m,
                            PBOthersForBuyer = 2.01m,
                            PBOthersForBuyerPMTypeCdID = OtherPaymentMethods.POC,
                            SeqNum = 1
                        },
                        InterestCalculation = new InterestCalculation()
                        {
                            BasedOnDays = 365,
                            FromInclusive = false,
                            PerDiemAmount = 100.02m,
                            ToInclusive = true,
                            UsePerDiemFlag = true
                        },
                    },
                    CDLenderCredits = new CDChargePaymentDetails[]
                    {
                        new CDChargePaymentDetails()
                        {
                            BuyerCredit=2.01m,
                            BuyerCreditPaymentMethodTypeCdID=CreditPaymentMethods.Lender,
                            Description="Check",
                            LEAmount=1.01m,
                            SeqNum=1
                        },
                    },
                    CDNewLoanCharges = new CDChargePaymentDetails[]
                    {
                        new CDChargePaymentDetails()
                        {
                            AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            BuyerCharge=12.03m,
                            Description="NewLoanChargeUpdate",
                            LEAmount=5.02m,
                            PBBuyerAtClosing=5.01m,
                            PBBuyerBeforeClosing=5.01m,
                            PBOthersForBuyer=2.01m,
                            PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.POCMB,
                            PBOthersForSeller=1.01m,
                            PBOthersForSellerPMTypeCdID=OtherPaymentMethods.POCL,
                            PBSellerAtClosing=2.01m,
                            PBSellerBeforeClosing=3.01m,
                            SellerCharge=6.03m,
                            SeqNum=1
                        },
                        new CDChargePaymentDetails()
                        {
                            AdhocFlag=1,
                            AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            BuyerCharge=30.03m,
                            Description="Check LoanUpdate",
                            LEAmount=2.66m,
                            PBBuyerAtClosing=10.01m,
                            PBBuyerBeforeClosing=10.01m,
                            PBOthersForBuyer=10.01m,
                            PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.POC,
                            PBOthersForSeller=5.01m,
                            PBOthersForSellerPMTypeCdID=OtherPaymentMethods.POCL,
                            PBSellerAtClosing=5.01m,
                            PBSellerBeforeClosing=5.01m,
                            SellerCharge=15.03m,
                        },
                    },
                    CDOriginationCharges = new CDChargePaymentDetails[]
                    {
                        new CDChargePaymentDetails()
                        {
                            AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            BuyerCharge=16.04m,

                            LEAmount=5.02m,
                            PBBuyerAtClosing=8.02m,
                            PBBuyerBeforeClosing=4.01m,
                            PBOthersForBuyer=4.01m,
                            PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.POC,
                            PBOthersForSeller=3.01m,
                            PBOthersForSellerPMTypeCdID=OtherPaymentMethods.POC,
                            PBSellerAtClosing=2.01m,
                            PBSellerBeforeClosing=3.01m,
                            SellerCharge=8.03m,
                            SeqNum=1
                        },
                        new CDChargePaymentDetails()
                        {
                            AdhocFlag=1,
                            AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            BuyerCharge=22.05m,
                            Description="Adhoc OrgCharge",
                            LEAmount=2.66m,
                            PBBuyerAtClosing=7.02m,
                            PBBuyerBeforeClosing=8.02m,
                            PBOthersForBuyer=7.01m,
                            PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.POC,
                            PBOthersForSeller=4.02m,
                            PBOthersForSellerPMTypeCdID=OtherPaymentMethods.POC,
                            PBSellerAtClosing=1.01m,
                            PBSellerBeforeClosing=5.02m,
                            SellerCharge=10.05m
                        },
                    },
                    CDPrincipalBalanceCharges = new CDChargePaymentDetails()
                    {
                        AtClosingSellerPaymentMethodTypeID = AtClosingPaymentMethods.RBL,
                        Description = "Update(Bal)",
                        LEAmount = 11.11m,
                        PBOthersForSeller = 1.01m,
                        PBOthersForSellerPMTypeCdID = OtherPaymentMethods.POCMB,
                        PBSellerAtClosing = 5.01m,
                        PBSellerBeforeClosing = 6.01m,
                        SellerCharge = 12.03m
                    },
                    CDPrincipalReductionOrConstructionHoldBack = new CDChargePaymentDetails[]
                    {
                        new CDChargePaymentDetails()
                        {
                            BuyerCharge = 22.01m,
                            SellerCharge = 12.01m,
                            SeqNum=1
                        },
                        new CDChargePaymentDetails()
                        {
                            AdhocFlag=1,
                            BuyerCharge = 10.03m,
                            Description ="Adhoc PriciRed",
                            LEAmount = 5.03m,
                            PBBuyerAtClosing=2.01m,
                            PBBuyerBeforeClosing=5.01m,
                            PBOthersForBuyer=3.01m,
                            PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.POC,
                            PBOthersForSeller=1.01m,
                            PBOthersForSellerPMTypeCdID=OtherPaymentMethods.POC,
                            PBSellerAtClosing=1.02m,
                            PBSellerBeforeClosing=2.03m,
                            SellerCharge = 4.06m,
                        },
                    },
                    #endregion
                },
                MortgageBroker = new MortgageBroker()
                {
                    #region CD
                    CDBrokerFee = new BrokerFee()
                    {
                        Description = "Check BrokerFeeNew",
                        FileCharge = 3600m,
                        //PaymentMethodTypeID = 2390
                    },
                    CDFutureRecordingFeescollectedbyMB = new CDChargePaymentDetails[]
                    {
                        new CDChargePaymentDetails()
                        {
                            AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            BuyerCharge=22.12m,
                            SeqNum=1
                        },
                    },
                    CDLenderCredits = new CDChargePaymentDetails[]
                    {
                        new CDChargePaymentDetails()
                        {
                            BuyerCredit=10.01m,
                            BuyerCreditPaymentMethodTypeCdID=CreditPaymentMethods.Lender,
                            SeqNum=1
                        },
                    },
                    CDMortgageBrokerCharges = new CDChargePaymentDetails[]
                    {
                        new CDChargePaymentDetails()
                        {
                            AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            BuyerCharge=22.05m,
                            Description="Check",
                            LEAmount = 5.03m,
                            PBBuyerAtClosing=10.01m,
                            PBOthersForBuyer=12.04m,
                            PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.POC,
                            PBOthersForSeller=3.01m,
                            PBOthersForSellerPMTypeCdID=OtherPaymentMethods.POCL,
                            PBSellerAtClosing=1.01m,
                            PBSellerBeforeClosing=5.01m,
                            SellerCharge = 9.03m,
                            SeqNum=1
                        },
                        new CDChargePaymentDetails()
                        {
                            AdhocFlag=1,
                            AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            BuyerCharge=12.03m,
                            Description="Adhoc MortgageCharge",
                            LEAmount = 5.03m,
                            PBBuyerAtClosing=4.01m,
                            PBBuyerBeforeClosing=4.01m,
                            PBOthersForBuyer=4.01m,
                            PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.POC,
                            PBOthersForSeller=2.01m,
                            PBOthersForSellerPMTypeCdID=OtherPaymentMethods.POC,
                            PBSellerAtClosing=2.01m,
                            PBSellerBeforeClosing=2.01m,
                            SellerCharge = 6.03m,
                        },
                    },
                    #endregion
                    #region HUD
                    GFE3Charges = new GFELoanCharges[]
                    {
                        new GFELoanCharges
                        {
                            PaymentDetail = new PaymentDetailsWithGFEAndPOC
                            {
                                BuyerCharge = 22.22m,
                                BuyerPaymentMethodTypeID = 385,
                                SellerCharge = 21.12m,
                                SellerPaymentMethodTypeID = 385,
                                SeqNum = 40
                            }
                        }
                    },
                    MortgageBrokerCharges = new PaymentDetailsWithGFE[]
                    {
                        new PaymentDetailsWithGFE
                        {
                            BuyerCharge = 120.01m,
                        }
                    },
                    PayCharges = new PayCharge
                    {
                        DisbursementCharges = new DisbursementCharge[]
                        {
                            new DisbursementCharge
                            {
                                BuyerCharge = 100,
                                SeqNum = 40
                            }
                        }
                    },
                    YieldSpreadPremium = new YieldSpreadPremium
                    {
                        Description = "Test",
                        FileCharge = 5000.02m
                    },
                    #endregion
                    MorgageBrokerInformation = new FileBusinessParty()
                    {
                        AddrBookEntryID = 8835488
                    },
                },
                EmployeeID = 1,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }
        #endregion

        public static NewLoanRequest GetNewLoanRequest(int fileID, int seqNum)
        {
            return new NewLoanRequest()
            {
                FileID = fileID,
                LoanCharges = new LoanCharge() { },
                SeqNum = seqNum,
                EmployeeID = 1,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static DocTemplateRequest GetDocTemplatesDefaultRequest()
        {
            return new DocTemplateRequest()
            {
                DocTemplateTypeCdID = 7,
                DocumentSource = DocSource.Regional,
                RegionID = 1486,
                LoginName = @"fastts\fastqa07",
                Source = "FAMOS"
            };
        }

        public static CreateBuyerSellerAttorneyRequest GetCreateBuyerSellerAttorneyRequest(int fileID, int seqNum)
        {
            return new CreateBuyerSellerAttorneyRequest()
            {
                AttorneyTypeObjectCD = "BUYERATTY",
                FileID = fileID,
                SeqNum = seqNum,
                Source = @"FAMOS",
                UseLatestGabVersion = true,
            };
        }

        public static CreateBuyerSellerAttorneyRequest GetCreateBuyerSellerAttorneyRequest(string fileID, int? seqNum, string roleType)
        {
            return new CreateBuyerSellerAttorneyRequest()
            {

                FileID = int.Parse(fileID),

                AttorneyParty = new FileBusinessParty()
                {
                    AddrBookEntryID = 8835488,
                    RoleTypeObjectCD = roleType
                },
                AttorneyTypeObjectCD = "701",
                CDChargeList = new CDChargePaymentDetails[]
                {
                    new CDChargePaymentDetails()
                    {
                         AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                         AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                         BuyerCharge = 11.04m,
                         LEAmount = 6.22m,
                         PBBuyerAtClosing = 6.02m,
                         PBBuyerBeforeClosing = 5.02m,
                         PBOthersForSeller = 2.01m,
                         PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                         PBSellerAtClosing = 2.02m,
                         PBSellerBeforeClosing = 2.01m,
                         SellerCharge=6.04m,
                         SeqNum = 1,
                    },
                    new CDChargePaymentDetails()
                    {
                        AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        BuyerCharge = 14.05m,
                        Description = "Validate",
                        LEAmount = 6.22m,
                        PBBuyerAtClosing = 7.02m,
                        PBBuyerBeforeClosing = 6.02m,
                        PBOthersForBuyer=1.01m,
                        PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        PBOthersForSeller = 2.01m,
                        PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        PBSellerAtClosing = 2.02m,
                        PBSellerBeforeClosing = 2.01m,
                        SellerCharge = 6.04m,
                        SeqNum =2
                    },
                },
                SeqNum = seqNum,
                Source = @"FAMOS"
            };
        }

        public static PayoffLoanRequest GetDefaultPayoffLoanRequestWithCharge(String fileId)
        {
            #region CreatePayOffLoanRequestWithCharge

            return new PayoffLoanRequest()
            {
                FileID = int.Parse(fileId),
                PayOffLenderAddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                PayOffLenderOrigPrincipalBal = 400.01m,
                LoanTypeCdID = 667,

                CDInterestCalculationSummary = new CDPayOffLoanInterestChargeset[]
                {

                    new CDPayOffLoanInterestChargeset()
                    {
                        InterestType = 433,
                        PerDiemFlag = 1,
                        PerDiemAmount = 10.02m,
                        CalendarBaseDays = 365,
                        FromDate = DateTime.Today,
                        ToDate = DateTime.Now.AddDays(10),
                        ToDateInclusive = 1,
                        FromDateInclusive = 0,
                        Description = "Interest on Payoff Loan",
                        SeqNum = 1,

                    CDChargePaymentDetails = new CDChargePaymentDetails()
                       {
                        AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        Description = "Interest on Payoff Loan",
                        BuyerCharge = 9.03m,
                        BuyerCredit = 5.01m,
                        PBBuyerAtClosing = 2.01m,
                        PBBuyerBeforeClosing = 3.01m,
                        PBOthersForBuyer = 4.01m,
                        PBOthersForSeller = 4.01m,
                        PBSellerAtClosing = 100.20m,
                        PBSellerBeforeClosing = 3.01m,
                        SellerCharge = 107.22m,
                        SellerCredit = 5.01m,
                        LEAmount = 10.01m,
                       }
                    }
                },

                CDLoanCharges = new CDChargePaymentDetails()
                {
                    AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                    AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                    PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                    PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                    Description = "Principal Balance",
                    BuyerCharge = 9.03m,
                    BuyerCredit = 4.12m,
                    PBBuyerAtClosing = 2.01m,
                    PBBuyerBeforeClosing = 3.01m,
                    PBOthersForBuyer = 4.01m,
                    PBOthersForSeller = 4.01m,
                    PBSellerAtClosing = 2.01m,
                    PBSellerBeforeClosing = 3.01m,
                    SellerCharge = 9.03m,
                    SellerCredit = 10.30m,
                    LEAmount = 10.01m,
                },

                CDPayoffLoanCharges = new CDChargePaymentDetails[]
                {
                    new CDChargePaymentDetails()
                    {
                        AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        Description = "Statement/Forwarding Fee",
                        BuyerCharge = 9.03m,
                        BuyerCredit = 5.01m,
                        PBBuyerAtClosing = 2.01m,
                        PBBuyerBeforeClosing = 3.01m,
                        PBOthersForBuyer = 4.01m,
                        PBOthersForSeller = 4.01m,
                        PBSellerAtClosing = 2.01m,
                        PBSellerBeforeClosing = 3.01m,
                        SellerCharge = 9.03m,
                        SellerCredit = 5.01m,
                        LEAmount = 10.01m,
                        SeqNum = 1,
                    },

                    new CDChargePaymentDetails()
                    {
                        AdhocFlag = 1,
                        AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        Description = "Adhoc",
                        BuyerCharge = 9.03m,
                        BuyerCredit = 5.01m,
                        PBBuyerAtClosing = 2.01m,
                        PBBuyerBeforeClosing = 3.01m,
                        PBOthersForBuyer = 4.01m,
                        PBOthersForSeller = 4.01m,
                        PBSellerAtClosing = 2.01m,
                        PBSellerBeforeClosing = 3.01m,
                        SellerCharge = 9.03m,
                        SellerCredit = 5.01m,
                        LEAmount = 10.01m,
                        SeqNum = 9,
                    }
                },
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
            #endregion
        }

        public static CreateBuyerSellerAttorneyRequest GetUpdateBuyerSellerAttorneyRequest(string fileID, int? seqNum, string roleType)
        {
            return new CreateBuyerSellerAttorneyRequest()
            {

                FileID = int.Parse(fileID),

                AttorneyParty = new FileBusinessParty()
                {
                    AddrBookEntryID = 8835488,
                    RoleTypeObjectCD = roleType
                },
                AttorneyTypeObjectCD = "701",
                CDChargeList = new CDChargePaymentDetails[]
            {
                    new CDChargePaymentDetails()
                    {
                         AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                         AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                         BuyerCharge = 14.04m,
                         LEAmount = 6.22m,
                         PBBuyerAtClosing = 7.02m,
                         PBBuyerBeforeClosing = 7.02m,
                         PBOthersForSeller = 3.01m,
                         PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                         PBSellerAtClosing = 1.02m,
                         PBSellerBeforeClosing = 1.01m,
                         SellerCharge=5.04m,
                         SeqNum = 1,
                    },
                    new CDChargePaymentDetails()
                    {
                        AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        BuyerCharge = 11.05m,
                        Description = "AdhocUpdated",
                        LEAmount = 6.22m,
                        PBBuyerAtClosing = 6.02m,
                        PBBuyerBeforeClosing = 4.02m,
                        PBOthersForBuyer=1.01m,
                        PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        PBOthersForSeller = 1.01m,
                        PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        PBSellerAtClosing = 1.02m,
                        PBSellerBeforeClosing = 1.01m,
                        SellerCharge = 3.04m,
                        SeqNum =2
                    },
                },
                SeqNum = seqNum,
                Source = @"FAMOS"
            };
        }

        public static CreateBuyerSellerAttorneyRequest GetRemoveBuyerSellerAttorneyRequest(string fileID, int? seqNum, string roleType)
        {
            return new CreateBuyerSellerAttorneyRequest()
            {

                FileID = int.Parse(fileID),
                AttorneyParty = new FileBusinessParty()
                {
                    RoleTypeObjectCD = roleType
                },
                SeqNum = seqNum,
                Source = @"FAMOS"
            };
        }

        public static FeeEntryRequest GetFeeEntryRequest()
        {
            return new FeeEntryRequest()
            {
                EmployeeID = 1,
                FileID = 0,
                RecordingAndTax = new RecordingAndTax()
                {
                    GovernmentRecordingAndTransferTaxes = new GovernmentRecordingAndTransferTaxes()
                    {
                        CdTransferTax = new LoanEstimateRAndUR() { },
                        GovernmentCdRecordingCharges = new LoanEstimateRAndUR() { }
                    }
                },
                TitleAndEscrow = new TitleAndEscrow()
                {
                    TitlePolicyCalculationsForCD = new CdTitlePolicyCalculations()
                    {
                        DisclosedOwnerPremium = new CdFeeInformation() { },
                        FullLoanPremium = new CdFeeInformation() { }
                    },
                    TitleServicesAndTitleInsurance = new TitleServicesAndTitleInsurance()
                    {
                        OwnersTitleInsurance = new GFEInformation() { },
                        TitleServicesOrLenderTitleIns = new GFEInformation() { }
                    }
                },
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        #region AlertOrReminderRequest
        public static AlertOrReminderRequest GetAddFileWorkflowReminderOrAlert(int? fileID)
        {
            return new AlertOrReminderRequest()
            {
                FileID = fileID,
                Note = "Reminder Message",
                VisibilityTypeCDID = 1,
                LoginName = @"fastts\fastqa07",
                Source = @"FAST"
            };
        }
        #endregion

        public static DocTemplateRequest GetDocTemplateRequest()
        {
            return new DocTemplateRequest()
            {
                DocTemplateTypeCdID = 7,
                DocumentSource = DocSource.Regional,
                RegionID = 1486,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        #region GetFileSearchRequest
        public static FileSearchRequest GetFileSearchRequest(string fileNum)
        {
            return new FileSearchRequest
            {
                FileNumber = fileNum,
                RegionID = 1486,
                eFileType = FileType.FileNo
            };
        }
        #endregion

        #region Private Functions
        private static AddBuyerSellerRequest SetValuesForAddBuyerSellerRequest(string buyerSellerType, int typeID)
        {
            return new AddBuyerSellerRequest()
            {
                BuyerSeller = new BuyerSeller()
                {
                    AddtlVestingInfo = "Full Vesting",
                    BuyerSellerTypeID = typeID,

                    CurrentAddress = new BuyerSellerAddress()
                    {
                        AddrLine1 = "CurrentAddress",
                        BuyerSellerAddressTypeCdID = 80,
                        City = "CurrentCity",
                        Country = "USA",
                        County = "Orange",
                        State = "CA",
                    },
                    FirstName = "BuyerFirst",
                    ForwardingAddress = new BuyerSellerAddress()
                    {
                        AddrLine1 = "ForwardAddress",
                        BuyerSellerAddressTypeCdID = 80,
                        City = "City",
                        Country = "USA",
                        County = "Orange",
                        State = "CA",
                    },
                    LastName = "BuyerLast",
                },
                PrincipalType = "BUYER",
                LoginName = "fastts\fastqa07",
                Source = "famos",
            };
        }
        #endregion

        public static UpdateDocumentRequest GetUpdateDocumentDefaultRequest(int DocumentID, int FileID)
        {
            return new UpdateDocumentRequest()
            {
                DocumentID = DocumentID,
                FileID = FileID,
                LoginName = @"fastts\fastqa07",
                Source = "FAMOS"
            };
        }

        public static RemoveDocumentRequest GetRemoveDocumentDefaultRequest(int FileID)
        {
            return new RemoveDocumentRequest()
            {
                FileID = FileID,
                LoginName = @"fastts\fastqa07",
                Source = "FAMOS"
            };
        }

        public static UpdateBuyerSellerRequest GetUpdateBuyerSellerRequest(string buyerSellerType = "BUYER", int buyerSellerTypeID = 48, int? fileId = null)
        {
            #region UpdateBuyerSellerRequest
            return new UpdateBuyerSellerRequest()
            {
                BuyerSeller = new BuyerSeller()
                {
                    BuyerSellerTypeID = buyerSellerTypeID,
                    CurrentAddress = GetBuyerSellerAddress(),
                    FirstName = "UpdatedBuyerName",
                    ForwardingAddress = GetBuyerSellerAddress(),
                    LastName = "LastUpdated",
                    SeqNum = 1,
                    SpouseFirstName = "SpouseUpdatedFN",
                    SpouseLastName = "SpouseUpdatedLN",
                },
                FileID = fileId ?? 0,
                PrincipalType = buyerSellerType,
                LoginName = "fastts\fastqa07",
                Source = "famos",
            };
            #endregion
        }

        public static BuyerSellerAddress GetBuyerSellerAddress()
        {
            return new BuyerSellerAddress()
            {
                AddrLine1 = "Forwading Address",
                BuyerSellerAddressTypeCdID = 80,
                City = "ForwardCity",
                Country = "USA",
                County = "Orange",
                State = "CA",
            };
        }

        public static UnfinalizeDocumentRequest GetUnfinalizeDocumentRequest(int fileID, int DocumentID)
        {
            return new UnfinalizeDocumentRequest()
            {
                Comments = "Test Comment",
                FileID = fileID,
                DocumentID = DocumentID,
                LoginName = @"fastts\fastqa07",
                Source = @"FAMOS"
            };
        }

        public static FinalizeDocumentRequest GetFinalizeDocumentRequest(int? fileID, int DocumentID)
        {
            return new FinalizeDocumentRequest()
            {
                Comments = "Test Comment",
                FileID = fileID,
                DocumentID = DocumentID,
                LoginName = @"fastts\fastqa07",
                Source = @"FAMOS"
            };
        }

        public static AddEventLogEntryRequest GetAddEventLogDefaultRequest(int fileID, int eventId)
        {
            return new AddEventLogEntryRequest()
            {
                FileID = fileID,
                EventID = eventId,
                Comments = "Test Event Log Entry",
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static SearchFileRequest GetSearchFilesDefaultRequest(DateTime dFromDate, DateTime dToDate)
        {
            return new SearchFileRequest()
            {
                FromDate = dFromDate,
                MaxRecordCount = 10,
                RegionID = 1486,
                ToDate = dToDate,
                eFileStatus = FileStatus.Any,
                eServiceType = ServiceType.None,
                LoginName = @"fastts\fastqa07",
                Source = @"FAMOS"
            };
        }

        public static PropertyUpdateRequest GetUpdatePropertyTaxDefaultRequest(int fileID)
        {
            return new PropertyUpdateRequest()
            {
                FileID = fileID,
                Property = new Property()
                {
                    AdditionalInstructions = "Additional Instruction",
                    AmendUpdateDetails = "Amend",
                    Block = "Block1",
                    Book = "Book1",
                    Borough = "Borough1",
                    Building = "Building1",
                    Comments = "Test Comments",
                    CompleteLegalDescr = "Complete Legal Description",
                    Condominium = "Condominium1",
                    ConversionRequiredFlag = 1,
                    ERegFlag = 1,
                    EstateInterest = "Estate Interest",
                    EstateTypeCdID = 1914,
                    EstateTypeObjectCD = "Fee Simple",
                    Fee = "Fee1",
                    GovernmentLotNum = "GvtLotNo1",
                    Lot = "Lot1",
                    Name = "Test Name",
                    Page = "Page1",
                    Parcel = "Parcel1",
                    Parish = "Parish1",
                    Phase = "Phase1",
                    PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[]
                    {
                        new FASTWCFHelpers.FastFileService.PhysicalAddress()
                        {
                            AddrLine1 = "Address1",
                            AddrLine2 = "Address2",
                            AddrLine3 = "Address3",
                            AddrLine4 = "Address4",
                            City = "Santa Ana",
                            Country = "USA",
                            County = "Orange",
                            State = "CA",
                            Zip = "92701",
                        }
                    },
                    PropertyTypeObjectCD = "SF",
                    ProperyTypeCdID = 15,
                    Province = "Province1",
                    Range = "Range1",
                    RecordingInfo = new RecordingInfo
                    {
                        BookOrLiber = "Liber",
                        MapNum = "32",
                        Page = "32",
                    },
                    ReRecordingInfo = new RecordingInfo
                    {
                        BookOrLiber = "Book",
                        MapNum = "23",
                        Page = "23",
                    },
                    SearchInstructions = new SearchInstruction[]
                    {
                        new SearchInstruction()
                        {
                            SearchInstructionID = 8,
                        }
                    },
                    SearchTypeID = 85,
                    Section = "Section1",
                    SeqNum = 1,
                    ShortLegal = "Short Legal",
                    Taxes = new Taxes[]
                    {
                        new Taxes()
                        {
                            APN = "APN123",
                            Annuals = new PropertyTaxInfo[]
                            {
                                new PropertyTaxInfo()
                                {
                                    CertificateofPurchaseNo = "CertNo123",
                                    Homeowner = Convert.ToDecimal(1000.01),
                                    ImprovementValue = Convert.ToDecimal(1001.01),
                                    InstallmentAmount = Convert.ToDecimal(1002.1),
                                    InstallmentNo = 0,
                                    Interest = Convert.ToDecimal(1.11),
                                    LandValue = Convert.ToDecimal(1003.03),
                                    Other1 = Convert.ToDecimal(1004.04),
                                    Other2 = Convert.ToDecimal(1005.05),
                                    PartialPaymentAmount = Convert.ToDecimal(500.01),
                                    Penalty = Convert.ToDecimal(1.11),
                                    PersonalPropValue = Convert.ToDecimal(15000.05),
                                    Status = 2391,
                                    VolumeNum = "1001",
                                }
                            },
                            GenTaxCheck = true,
                            MiscNo = "MiscNo123",
                            Special = new PropertySplAndSupplTaxInfo[]
                            {
                                new PropertySplAndSupplTaxInfo()
                                {
                                    CertificateofPurchaseNo = "CertNo123",
                                    InstallmentAmount = Convert.ToDecimal(1000.01),
                                    InstallmentNo = 0,
                                    Interest = Convert.ToDecimal(1.11),
                                    PartialPaymentAmount = Convert.ToDecimal(600.01),
                                    Penalty = Convert.ToDecimal(3.33),
                                    Status = 130,
                                    VolumeNum = "1003",
                                }
                            },
                            SuppleNo = "SuplNo123",
                            Supplemental = new PropertySplAndSupplTaxInfo[]
                            {
                                new PropertySplAndSupplTaxInfo()
                                {
                                    CertificateofPurchaseNo = "CertNo123",
                                    InstallmentAmount = Convert.ToDecimal(1000.01),
                                    InstallmentNo = 0,
                                    Interest = Convert.ToDecimal(1.11),
                                    PartialPaymentAmount = Convert.ToDecimal(500.01),
                                    Penalty = Convert.ToDecimal(2.22),
                                    Status = 260,
                                    VolumeNum = "1002",
                                }
                            },
                            TRANo = "TRA123",
                            TaxYear = "2015-2016",
                        }
                    },
                    TitleMortgageInsurance = "Title Mortgage Insurance",
                    TitleVesting = "Title Vesting",
                    Township = "Township1",
                    Tract = "Tract1",
                    UnincorporatedFlag = 1,
                    Unit = "Unit1",
                },
                UpdatedEmployeeID = 1,
                LoginName = @"fastts\fastqa07",
                Source = "FAMOS"
            };
        }


        public static GFELoanRequest GetUpdateGFEDetailsRequest(int fileID)
        {
            return new GFELoanRequest()
            {
                FileID = fileID,
                LoginName = @"fastts\fastqa07",
                Source = @"FAMOS",
                Sec_10_TotalMonthlyAmountDetails = new Sec_10_TotalMonthlyAmountDetails
                {
                    AddlMonthlyEscrowAmt = "100",
                    GFEImpoundDetails = new GFEImpound
                    {
                        FloodInsuranceFlag = true,
                        HomeOwnerInsuranceFlag = true,
                        PropTaxFlag = true,
                        UserDefined1 = "UD1"
                    },
                    IncludeEscrowPayments = true,
                    TotalInitialMonthlyAmt = "500"
                },
                Sec_2_LoanTerm = "2",
                Sec_3_InitialIntRate = 10,
                Sec_4_InitialMonthlyDetails = new Sec_4_InitialMonthlyDetails
                {
                    Amount = "1000",
                    InterestFlag = true,
                    MortgageInsuranceFlag = true,
                    PrincipalFlag = true
                },
                Sec_5_InterestRateDetails = new Sec_5_InterestRateDetails
                {
                    AfterPeriod = "1",
                    BeforePeriod = "4",
                    ChangedIntRate = "4",
                    HigherIntRate = 6,
                    IncrFlag = true,
                    LowerIntRate = 1,
                    MaxIntRate = 6
                },
                Sec_6_LoanBalanceDetails = new Sec_6_LoanBalanceDetails
                {
                    IncrFlag = true,
                    MaximumAmount = "5000"
                },
                Sec_7_MonthlyAmountDetails = new Sec_7_MonthlyAmountDetails
                {
                    IncrFlag = true,
                    IncrementAmount = 500,
                    MaximumAmount = 10000
                },
                Sec_8_PrepaymentDetails = new Sec_8_PrepaymentDetails
                {
                    MaximumAmount = 6000,
                    PenaltyFlag = true
                },
                Sec_9_BalloonPaymentDetails = new Sec_9_BalloonPaymentDetails
                {
                    DuePeriod = 1,
                    MaximumAmount = 4000,
                    PaymentFlag = true
                },
                GFE_10_Daily_interest_charges = 10,
                GFE_10_Daily_interest_charges_Flag = GFEChargeFlags.Credit,
                GFE_11_Required_Lender_selected_services = new GFE_11_Required_Lender_selected_services
                {
                    GFE_11 = new GFERequiredLender[]
                    {
                        new GFERequiredLender()
                        {
                            ChargeDescription = "Charge Description",
                            GFEAmount = "4000",
                            GFEEntryTypeCdID = 1591,
                            ProcessTypeDescription = "Insurance - Flood"
                        },
                    },
                    TotalGFE11 = 60000
                },
                GFE_1_Origination_Charge = 2000,
                GFE_1_Origination_Charge_Flag = GFEChargeFlags.Charge,
                GFE_2_Points = 2,
                GFE_2_Points_Flag = GFEChargeFlags.Credit,
                GFE_3_Required_Lender_selected_services = new GFE_3_Required_Lender_selected_services
                {
                    GFE_3 = new GFERequiredLender[]
                    {
                        new GFERequiredLender()
                        {
                            ChargeDescription = "GFE3",
                            GFEAmount = "2000",
                            GFEEntryTypeCdID = 1589,
                            ProcessTypeDescription = "Inspection/Repair - Septic"
                        },
                    },
                    TotalGFE3 = 40000
                },
                GFE_4_Title_services_and_Lenders_title_insurance = 500,
                GFE_5_Owners_title_insurance = 700,
                GFE_6_Required_Lender_selected_services = new GFE_6_Required_Lender_selected_services
                {
                    GFE_6 = new GFERequiredLender[]
                    {
                        new GFERequiredLender()
                        {
                            ChargeDescription = "GFE6",
                            GFEAmount = "9000",
                            GFEEntryTypeCdID = 1590,
                            ProcessTypeDescription = "Inspection/repair - Other"
                        },
                    },
                    TotalGFE6 = 3000
                },
                GFE_7_Government_recording_charges = 1000,
                GFE_8_Transfer_taxes = 40,
                GFE_9_Initial_deposit_for_escrow_account = 5000,
                SplitLSPFlag = 1,
                isGFE4Updated = 1
            };
        }

        public static BSEntitySignatureRequest GetBSEntitySignatureRequest(int fileID, PrincipalTypes principalType)
        {
            var orderDetails = FileService.GetOrderDetails(fileID);
            var bsEntitySignature = FileService.GetBSEntitySignature(fileID);

            var request = new BSEntitySignatureRequest()
            {
                ByEntities = new ByEntities()
                {
                    ByEntitySummaries = bsEntitySignature.BSEntitySignatures[0].ByEntities.ByEntitySummaries,
                },
                EmployeeID = 1,
                Entity = bsEntitySignature.BSEntitySignatures[0].NameEntity,
                FileID = fileID,
                LoginName = @"fastts\fastqa07",
                ePrincipalType = principalType,
                PrincipalID = principalType == PrincipalTypes.Buyer ? orderDetails.Buyers[0].PrincipalID : orderDetails.Sellers[0].PrincipalID,
                TitleEscrowInfoID = bsEntitySignature.BSEntitySignatures[0].TitleEscrowInfoID,
                Source = @"FAMOS",
            };
            request.ByEntities.ByEntitySummaries[0].authorizedSignatures[0].eunmOperationType = OperationType.Update;
            request.ByEntities.ByEntitySummaries[0].eOperationType = OperationType.Update;
            request.ByEntities.ByEntitySummaries[0].objEntityOrByEntity.StateOrProvinenceOfIncorporationGeoRegionID = BuyerSellerStateOfIncorporationCdID.California;
            request.Entity.authorizedSignatures[0].eunmOperationType = OperationType.Update;
            request.Entity.objEntityOrByEntity.StateOrProvinenceOfIncorporationGeoRegionID = BuyerSellerStateOfIncorporationCdID.California;

            return request;
        }

        public static OECRequest GetCreateOECDefaultRequest(int? fileID)
        {
            return new OECRequest()
            {
                FileID = fileID,
                OECInformation = new OECInformation
                {
                    OECCharges = new OECCharge
                    {
                        CDPaymentDetails = new CDChargePaymentDetails[]
                        {
                            new CDChargePaymentDetails()
                            {
                                AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                                AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.NoCheck,
                                BuyerCharge = Convert.ToDecimal(15.50),
                                Description = "OEC1",
                                SellerCharge = Convert.ToDecimal(15.60),
                                SeqNum = 1,
                                LEAmount = Convert.ToDecimal(31.10),
                            },
                            new CDChargePaymentDetails()
                            {
                                AdhocFlag = 1,
                                AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                                AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.NoCheck,
                                BuyerCharge = Convert.ToDecimal(20.20),
                                Description = "OEC2",
                                SellerCharge = Convert.ToDecimal(20.40),
                                SeqNum = 2,
                                LEAmount = Convert.ToDecimal(40.60),
                            },
                        },
                    },
                    OECFileBusinessParty = new FileBusinessParty
                    {
                        AddrBookEntryID = 8835183,
                    },
                },
                LoginName = @"fastts\fastqa07",
                Source = @"FAMOS"
            };
        }

        public static UpdatePhraseRequest GetDefaultUpdatePhraseRequest(int fileID, int docID, long phraseID)
        {
            return new UpdatePhraseRequest()
            {
                DocPhraseElements = new DocPhraseElement[]
                {
                    new DocPhraseElement()
                    {
                        FormDisplayName = "1BUFNAMa",
                        FormFieldName = "1BUFNAMa",
                        FormFieldValue = "BuyerFirstName"
                    },
                },
                UpdatedEmployeeID = 1,
                LoginName = @"fastts\fastqa07",
                Source = @"FAMOS",
                FileID = fileID,
                DocumentID = docID,
                DocPhraseID = phraseID,
                Target = "FAST",
            };
        }

        public static PayoffLoanRequest GetUpdatePayoffLoanRequestWithCharge(String fileId)
        {
            #region UpdatePayOffLoanRequestWithCharge
            return new PayoffLoanRequest()
            {
                FileID = int.Parse(fileId),
                PayOffLenderAddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"),

                PayOffLenderOrigPrincipalBal = 500.05m,
                LoanTypeCdID = 667,

                CDInterestCalculationSummary = new CDPayOffLoanInterestChargeset[]
                {
                    new CDPayOffLoanInterestChargeset()
                    {
                        InterestType = 433,
                        PerDiemFlag = 1,
                        PerDiemAmount = 15.02m,
                        CalendarBaseDays = 360,
                        FromDate = DateTime.Today,
                        ToDate = DateTime.Now.AddDays(8),
                        ToDateInclusive = 1,
                        FromDateInclusive = 1,
                        Description = "Interest on Payoff Loan",
                        SeqNum = 1,

                    CDChargePaymentDetails = new CDChargePaymentDetails()
                       {
                        AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        Description = "Interest on Payoff Loan",
                        BuyerCharge = 10.06m,
                        BuyerCredit = 4.01m,
                        PBBuyerAtClosing = 3.02m,
                        PBBuyerBeforeClosing = 3.02m,
                        PBOthersForBuyer = 4.02m,
                        PBOthersForSeller = 7.02m,
                        PBSellerAtClosing = 8.02m,
                        PBSellerBeforeClosing = 5.02m,
                        SellerCharge = 20.06m,
                        SellerCredit = 4.01m,
                        LEAmount = 30.15m,
                       }
                    }
                },

                CDLoanCharges = new CDChargePaymentDetails()
                {
                    AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                    AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                    PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                    PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                    Description = "Principal Balance",
                    BuyerCharge = 20.06m,
                    BuyerCredit = 5.01m,
                    PBBuyerAtClosing = 5.02m,
                    PBBuyerBeforeClosing = 4.02m,
                    PBOthersForBuyer = 11.02m,
                    PBOthersForSeller = 4.02m,
                    PBSellerAtClosing = 6.02m,
                    PBSellerBeforeClosing = 10.02m,
                    SellerCharge = 20.06m,
                    SellerCredit = 8.01m,
                    LEAmount = 100.01m,
                },
                CDPayoffLoanCharges = new CDChargePaymentDetails[]
                {
                    new CDChargePaymentDetails()
                    {
                        AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        Description = "Statement/Forwarding Fee",
                        BuyerCharge = 19.06m,
                        BuyerCredit = 8.01m,
                        PBBuyerAtClosing = 4.02m,
                        PBBuyerBeforeClosing = 5.02m,
                        PBOthersForBuyer = 10.02m,
                        PBOthersForSeller = 4.02m,
                        PBSellerAtClosing = 5.02m,
                        PBSellerBeforeClosing = 10.02m,
                        SellerCharge = 19.06m,
                        SellerCredit = 5.01m,
                        LEAmount = 50.01m,
                        SeqNum = 1,
                    },

                    new CDChargePaymentDetails()
                    {
                        AdhocFlag = 1,
                        AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        Description = "Adhoc",
                        BuyerCharge = 25.12m,
                        BuyerCredit = 8.01m,
                        PBBuyerAtClosing = 8.04m,
                        PBBuyerBeforeClosing = 7.04m,
                        PBOthersForBuyer = 10.04m,
                        PBOthersForSeller = 8.04m,
                        PBSellerAtClosing = 10.04m,
                        PBSellerBeforeClosing = 7.04m,
                        SellerCharge = 25.12m,
                        SellerCredit = 7.01m,
                        LEAmount = 10.01m,
                        SeqNum = 9,
                    }
                },

                LoginName = AutoConfig.UserName,
                Source = @"FAMOS",
                SeqNum = 1
            };
            #endregion
        }

        public static TermsDatesStatusRequest GetTermsDatesStatusRequest(int? fileId)
        {
            return new TermsDatesStatusRequest()
            {
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS",
                UpdatedEmployeeID = 1,
            };
        }

        public static AddPhraseMarkerRequest GetAddPhraseMarkerDefaultRequest(int fileID, int documentID)
        {
            return new AddPhraseMarkerRequest()
            {
                DocumentID = documentID,
                FileID = fileID,
                PositionToInsert = 0,
                LoginName = @"fastts\fastqa07",
                Source = @"FAMOS"
            };
        }

        public static MovePhraseRequest GetMovePhraseRequest(DocumentDetailsResponse response)
        {

            return new MovePhraseRequest
            {

                DocPhrase = new MovePhrase[]
                {
                    new MovePhrase()
                    {
                        DocPhraseID=response.Phrases[0].DocPhraseID,
                        DocPhraseName=response.Phrases[0].Name,
                        SeqNumber=response.Phrases[0].SeqNum,
                    },
                    new MovePhrase()
                    {
                        DocPhraseID=response.Phrases[1].DocPhraseID,
                        DocPhraseName=response.Phrases[1].Name,
                        SeqNumber=response.Phrases[1].SeqNum,
                    },
                    new MovePhrase()
                    {
                        DocPhraseID=response.Phrases[2].DocPhraseID,
                        DocPhraseName=response.Phrases[2].Name,
                        SeqNumber=response.Phrases[3].SeqNum,
                    },
                    new MovePhrase()
                    {
                        DocPhraseID=response.Phrases[3].DocPhraseID,
                        DocPhraseName=response.Phrases[3].Name,
                        SeqNumber=response.Phrases[2].SeqNum,
                    }
                },
                DocumentID = response.DocumentID,
                EmployeeID = 0,
                FileID = response.FileID,
                EmployeeObjectCD = null,
                LoginName = @"fastts\fastqa07",
                Source = @"FAMOS",
                Target = "FAST",
            };
        }

        public static DeletePhrasesRequest GetDeletePhraseRequest(int fileID, int documentID, long PhraseID)
        {
            long[] iPhraseID = new long[1] { PhraseID };
            return new DeletePhrasesRequest()
            {
                DocPhraseList = iPhraseID,
                DocumentID = documentID,
                FileID = fileID,
                EmployeeID = 1,
                LoginName = @"fastts\fastqa07",
                Source = @"FAMOS"
            };
        }

        public static WaiveOrUnWaivePhraseRequest GetWaiveOrUnWaivePhraseRequest(int fileID, int documentID, long phraseID, Boolean bWaiveFlag)
        {
            return new WaiveOrUnWaivePhraseRequest()
            {
                DocPhrases = new DocPhrase[]
                {
                    new DocPhrase()
                    {
                        DocPhraseID = phraseID,
                        DocumentID = documentID,
                        WaiveFlag = bWaiveFlag,
                        WaiveReasonComment = "Test"
                    },
                },
                DocumentID = documentID,
                FileID = fileID,
                LoginName = @"fastts\fastqa07",
                Source = @"FAMOS"
            };
        }

        public static ViewPhraseRequest GetViewPhraseTextRequest(string phraseCode, int phraseRegionID)
        {
            return new ViewPhraseRequest
            {
                NextGenFlag = false,
                PhraseCode = phraseCode,
                PhraseRegionID = phraseRegionID,
                LoginName = "fastts\fastqa07",
                Source = "FAMOS",
                Target = "FAST"
            };
        }

        public static UpdateFileRequest GetUpdateOrderDetailsRequest(int fileId)
        {
            return new UpdateFileRequest()
            {
                FileID = fileId,
                formType = ClosingDisclosureSupport.FormType,
                Source = "FAMOS",
                File = new File()
                {
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "NEWHM",
                    SalesPriceAmount = 800.05m,
                    Services = new Service[]
                    {
                        new Service
                        {
                            OfficeInfo = new OfficeInfo
                            {
                                BUID = 1487
                            },
                            PolicyIssuerTypeCdID = 2562,
                            ServiceTypeObjectCD = "TO"
                        }
                    },
                    BusinessParties = new FileBusinessParty[]
                    {
                       new FileBusinessParty()
                       {
                           AddrBookEntryID = AdminService.GetGABAddressBookEntryId("504"),
                           RoleTypeObjectCD = "BUSSOURCE",
                           EditElectronicAddress = true,
                           StatusEmail = 0,
                           ElectronicAddress = new ElectronicAddress()
                           {
                               BusinessFax = "9876543211",
                               BusinessPhone = "9876543211",
                               Cellular = "9876543211",
                               EmailAddress = "abcd@aol.com",
                               Extension = "1234",
                               Pager = "9876543211",
                           },
                           BusOrgContact = new BusOrgContact()
                           {
                               ContactName = "Test",
                               EditContactName = true,
                               EditElectronicAddress = true,
                               StatusEmail = 1,
                               ElectronicAddress = new ElectronicAddress()
                               {
                                    BusinessFax = "1234567899",
                                    BusinessPhone = "1234567899",
                                    Cellular = "1234567899",
                                    EmailAddress = "abc@aol.com",
                                    Enddated = false,
                                    EnterpriseID = 0,
                                    Extension = "12345",
                                    Pager = "1234567899",
                               }
                           }
                        },
                        new FileBusinessParty()
                        {
                           AddrBookEntryID = AdminService.GetGABAddressBookEntryId("506"),
                           RoleTypeObjectCD = "DIRECTEDBY",
                           BusOrgContact = new BusOrgContact()
                           {
                               ContactName = "Test2",
                               EditContactName = true,
                               EditElectronicAddress = true,
                               ElectronicAddress = new ElectronicAddress()
                               {
                                    BusinessFax = "8529637411",
                                    BusinessPhone = "7418529633",
                                    Cellular = "4567891233",
                                    EmailAddress = "abcd@ebay.com",
                                    Enddated = false,
                                    Extension = "12345",
                                    Pager = "9638521477",
                               },
                               StatusEmail = 1
                           },
                           EditElectronicAddress = true,
                           ElectronicAddress = new ElectronicAddress()
                           {
                               BusinessFax = "4567896225",
                               BusinessPhone = "7485963852",
                               Cellular = "4567892586",
                               EmailAddress = "a1b2@ebay.com",
                               Enddated = false,
                               Extension = "123",
                               Pager = "4124523652",
                           },
                        }
                    },
                },
            };
        }

        public static RemoveThirdPartyPayee GetRemoveThirdPartyPayeeRequest(int fileId, int seqNum, int fileBusinessPartyID)
        {
            return new RemoveThirdPartyPayee()
            {
                FileID = fileId,
                FileBusinessPartyID = fileBusinessPartyID,
                SeqNum = seqNum,
                LoginName = AutoConfig.UserName,
                EmployeeID = 1,
                Target = "FAST",
                Source = "FAMOS"
            };
        }

        public static UpdateInvoiceRequest GetUpdateInvoiceRequest(int fileId, Operation operation)
        {
            return new UpdateInvoiceRequest()
            {
                FileID = fileId,
                eOperation = operation,
                LoginName = AutoConfig.UserName,
                EmployeeID = 1,
                Target = "FAST",
                Source = "FAMOS"
            };
        }

        public static GetSettlementStatementRequest GetSettlementStatementRequest(int fileId)
        {
            return new GetSettlementStatementRequest()
            {
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Target = "FAST",
                Source = "FAMOS"
            };
        }

        public static UpdateSettelementStatementRequest GetUpdateSettelementStatementRequest(int fileId, UpdateSettelementStatementRequestInfo info)
        {
            return new UpdateSettelementStatementRequest()
            {
                FileId = fileId,
                UpdateSettelementStatementRequestInfo = info,
                LoginName = AutoConfig.UserName,
                Target = "FAST",
                Source = "FAMOS"
            };
        }

        public static RemoveRelatedPartyRequest GetRemoveRelatedPartyRequest(int fileId, int seqNum, int fileBusinessPartyId)
        {
            return new RemoveRelatedPartyRequest()
            {
                FileID = fileId,
                SeqNum = seqNum,
                FileBusinessPartyID = fileBusinessPartyId,
                EmployeeID = 1,
                LoginName = AutoConfig.UserName,
                Target = "FAST",
                Source = "FAMOS"
            };
        }


    }


    public class WCFTestDataStoreEntity
    {
        public int fileID { get; set; }
        public string FilePath { get; set; }
        public string workBookName { get; set; }
        public string workSheetName { get; set; }
        public int columnNo { get; set; }
    }
}
