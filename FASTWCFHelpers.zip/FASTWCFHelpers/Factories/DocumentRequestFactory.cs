﻿using FASTWCFHelpers.FastClosingDisclosureService;
using SeleniumInternalHelpersSupportLibrary;
using System;
using FASTWCFHelpers.FastDocumentService;

namespace FASTWCFHelpers.Factories
{
    public class DocumentRequestFactory
    {
        public static AssociateDocPackage GetAddDocumentToAssociateDocPackageDefaultRequest(int fileID, Document[] docs, string packageName = null)
        {
            return GetAssociateDocPackageDefaultRequest(fileID, docs, packageName);
        }

        public static AssociateDocPackage GetAddDocumentToAssociateDocPackageRequest(int fileID, Document[] docs, string packageName = null)
        {
            return GetAssociateDocPackageDefaultRequest(fileID, docs, packageName);
        }

        public static AssociateDocPackage GetCreateAssociateDocPackageDefaultRequest(int fileID, Document[] docs, string packageName = null)
        {
            return GetAssociateDocPackageDefaultRequest(fileID, docs, packageName);
        }

        public static AssociateDocPackage GetCreateAssociateDocPackageRequest(int fileID, Document[] docs, string packageName = null)
        {
            return GetAssociateDocPackageDefaultRequest(fileID, docs, packageName);
        }

        public static CreateDocumentRequest GetCreateDocumentRequest(int fileId)
        {
            return new CreateDocumentRequest()
            {
                DocTemplateTypeCode = "7",
                EmployeeID = 1,
                FileID = fileId,
                TemplateRegionID = 1486,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static FASTWCFHelpers.FastFileService.DocTemplateRequest GetDocTemplatesDefaultRequest(int DocTemplateTypeId, int Region, string tempdesc, string empobjcd)
        {
            return new FASTWCFHelpers.FastFileService.DocTemplateRequest()
            {
                CityID = null,
                CountyID = null,
                DocTemplateTypeCdID = DocTemplateTypeId,
                DocumentSource = FastFileService.DocSource.Both,
                RegionID = Region,
                StateID = 0,
                NextGenFlag = true,
                TemplateDescription = tempdesc,
                EmployeeObjectCD = empobjcd,
                LoginName = @"fastts\fastqa07",
                Source = "FAMOS",

            };
        }

        public static EditDocumentRequest GetEditDocumentRequest(int fileID, int documentID, string editDocumentName)
        {
            return new EditDocumentRequest
            {
                FileID = fileID,
                DocumentID = documentID,
                EditDocumentName = editDocumentName,
                Source = "FAMOS",
                Target = "FAST",
                LoginName = AutoConfig.UserName
            };
        }

        public static FinalizeDocumentRequest GetFinalizeDocumentRequest(int? fileID, int DocumentID)
        {
            return new FinalizeDocumentRequest()
            {
                Comments = "Test Comment",
                FileID = fileID,
                DocumentID = DocumentID,
                LoginName = @"fastts\fastqa07",
                Source = @"FAMOS"
            };
        }

        private static AssociateDocPackage GetGetAssociateDocPackagesRequest(int fileID, Document[] docs, string packageName = null)
        {
            return new AssociateDocPackage()
            {
                DocumentList = docs,
                FileID = fileID,
                PackageName = packageName ?? "PackageName_WCFTest",
                LoginName = @"fastts\fastqa07",
                Source = "FAMOS",
                Target = "FAST"
            };
        }

        private static AssociateDocPackage GetAssociateDocPackageDefaultRequest(int fileID, Document[] docs, string packageName = null)
        {
            return new AssociateDocPackage()
            {
                DocumentList = docs,
                FileID = fileID,
                PackageName = packageName ?? "PackageName_WCFTest",
                LoginName = @"fastts\fastqa07",
                Source = "FAMOS",
                Target = "FAST"
            };
        }

        public static DocTemplateRequest GetDocTemplatesDefaultRequest()
        {
            return new DocTemplateRequest()
            {
                DocTemplateTypeCdID = 7,
                DocumentSource = DocSource.Regional,
                RegionID = 1486,
                LoginName = @"fastts\fastqa07",
                Source = "FAMOS"
            };
        }

        public static CreateDocumentRequest GetCreateDocumentDefaultRequest(int fileId, int templateId)
        {
            return new CreateDocumentRequest()
            {
                FileID = fileId,
                TemplateID = templateId,
                EmployeeID = 1,
                Source = "FAMOS",
                LoginName = "fastts\fastqa07",
                Target = "FAST"
            };
        }

        public static AddPhraseRequest GetAddPhraseDefaultRequest(int fileID, int documentID)
        {
            return new AddPhraseRequest()
            {
                FileID = fileID,
                DocumentID = documentID,
                Source = "FAMOS",
                Target = "FAST",
                Phrases = new Phrase[] { new Phrase() { PhraseCode = "84227" } }
            };
        }

        public static EditDocumentRequest GetEditDocumentDefaultRequest(int fileID, int documentID, string editDocumentName)
        {
            return new EditDocumentRequest
            {
                FileID = fileID,
                DocumentID = documentID,
                EditDocumentName = editDocumentName,
                Source = "FAMOS",
                Target = "FAST",
                LoginName = AutoConfig.UserName
            };
        }

        public static FASTWCFHelpers.FastDocumentService.ServiceFileRequest GetServiceFileRequest(int fileID)
        {
            return new FASTWCFHelpers.FastDocumentService.ServiceFileRequest
            {
                FileId = fileID,
                Source = "FAMOS",
                Target = "FAST",
                LoginName = AutoConfig.UserName
            };
        }

        public static PurgeDocumentRequest PurgeDocumentReqt(int fileID, int DocID)
        {
            return new PurgeDocumentRequest
            {
                FileID = fileID,
                DocumentID = DocID,
                Source = "FAMOS",
                Target = "FAST",
                LoginName = AutoConfig.UserName
            };
        }

        public static DocumentRequest GetDocumentRequest(int fileID, int docID)
        {
            return new DocumentRequest
            {
                DocumentID = docID,
                FileID = fileID,
                EmployeeObjectCD = "1",
                LoginName = AutoConfig.UserName,
                Source = "FAMOS",
                Target = "FAST"
            };
        }

        public static AddPhraseMarkerRequest GetAddPhraseMarkerDefaultRequest(int fileID, int docID)
        {
            return new AddPhraseMarkerRequest()
            {
                DocumentID = docID,
                FileID = fileID,
                PositionToInsert = 0,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static CreateImageDocumentRequest GetCreateImageDocumentDefaultRequest()
        {
            return new CreateImageDocumentRequest()
            {
                Comments=null,
                DocumentID=0,
                EmployeeObjectCD="1",
                FileID=0,
                LoginName=AutoConfig.UserName,
                MarkAsDraft=false,
                Publish=false,
                Source="FAMOS",
                Target="FAST"
            };
        }

        public static DeletePhrasesRequest GetDeletePhraseRequest(int fileID, int documentID, long PhraseID)
        {
            long[] iPhraseID = new long[1] { PhraseID };
            return new DeletePhrasesRequest()
            {
                DocPhraseList = iPhraseID,
                DocumentID = documentID,
                FileID = fileID,
                EmployeeID = 1,
                LoginName = @"fastts\fastqa07",
                Source = @"FAMOS"
            };
        }

        public static CreateRTMPackageRequest CreateRTMPackageReq(int fileID, int DocID)
        {
            return new CreateRTMPackageRequest
            {
                rtmPackage = new RTMPackage()
                {
                    Descr = "RTM",
                    FileID = fileID,

                    RTMDocuments = new RTMDocument[]
                    {
                        new RTMDocument()
                        {
                            ColorYesNo = 1,
                            DocID = DocID,
                            DocTypeCdID = 7,
                            NumOfCopies = 10,
                            SeqNum = 1,
                            TabName = "TestRTM"
                        }
                    },
                    RTMMailToAddresses = new RTMMailTo[]
                    {
                        new RTMMailTo()
                        {
                            CourierType = 1312,
                            NumOfCopies = 7,
                            OwningProductionOffice = 1,
                            OwningProductionOfficeID = 191,
                            PackageType = 1279,
                            Attention = "TestAttention123",                        }
                    },
                    RTMReturnToAddresses = new RTMReturnTo[] 
                    {
                        new RTMReturnTo()
                        {
                            OwningProductionOffice = 1,
                            OwningProductionOfficeID = 191
                        }
                    }
                },
                Source = "FAMOS",
                Target = "FAST",
                LoginName = AutoConfig.UserName
            };
        }

        public static GetRTMPackageDetailsRequest GetRTMpackageDetails(int fileID)
        {
            return new GetRTMPackageDetailsRequest
            {
                FileID = fileID,
                Source = "FAMOS",
                Target = "FAST",
                LoginName = AutoConfig.UserName
            };
        }

        public static RTMFileBusinessPartyRequest GetRTMFileBusinessPartyRequest(int fileID, int packageID)
        {
            return new RTMFileBusinessPartyRequest
            {
                FileID = fileID,
                PackageID = packageID,
                Source = "FAMOS",
                Target = "FAST",
                LoginName = AutoConfig.UserName
            };
        }

        public static MovePhraseRequest GetMovePhraseRequest(DocumentDetailsResponse response)
        {

            return new MovePhraseRequest
            {

                DocPhrase = new MovePhrase[]
                {
                    new MovePhrase()
                    {
                        DocPhraseID=response.Phrases[0].DocPhraseID,
                        DocPhraseName=response.Phrases[0].Name,
                        SeqNumber=response.Phrases[0].SeqNum,
                    },
                    new MovePhrase()
                    {
                        DocPhraseID=response.Phrases[1].DocPhraseID,
                        DocPhraseName=response.Phrases[1].Name,
                        SeqNumber=response.Phrases[1].SeqNum,
                    },
                    new MovePhrase()
                    {
                        DocPhraseID=response.Phrases[2].DocPhraseID,
                        DocPhraseName=response.Phrases[2].Name,
                        SeqNumber=response.Phrases[3].SeqNum,
                    },
                    new MovePhrase()
                    {
                        DocPhraseID=response.Phrases[3].DocPhraseID,
                        DocPhraseName=response.Phrases[3].Name,
                        SeqNumber=response.Phrases[2].SeqNum,
                    }
                },
                DocumentID = response.DocumentID,
                EmployeeID = 0,
                FileID = response.FileID,
                EmployeeObjectCD = null,
                LoginName = @"fastts\fastqa07",
                Source = @"FAMOS",
                Target = "FAST",
            };
        }

        public static UpdatePhraseRequest GetDefaultUpdatePhraseRequest(int fileID, int docID, long phraseID)
        {
            return new UpdatePhraseRequest()
            {
                DocPhraseElements = new DocPhraseElement[]
                {
                    new DocPhraseElement()
                    {
                        FormDisplayName = "1BUFNAMa",
                        FormFieldName = "1BUFNAMa",
                        FormFieldValue = "BuyerFirstName"
                    },
                },
                UpdatedEmployeeID = 1,
                LoginName = @"fastts\fastqa07",
                Source = @"FAMOS",
                FileID = fileID,
                DocumentID = docID,
                DocPhraseID = phraseID,
                Target = "FAST",
            };
        }

        public static WaiveOrUnWaivePhraseRequest GetWaiveOrUnWaivePhraseRequest(int fileID, int documentID, long phraseID, Boolean bWaiveFlag)
        {
            return new WaiveOrUnWaivePhraseRequest()
            {
                DocPhrases = new DocPhrase[]
                {
                    new DocPhrase()
                    {
                        DocPhraseID = phraseID,
                        DocumentID = documentID,
                        WaiveFlag = bWaiveFlag,
                        WaiveReasonComment = "Test"
                    },
                },
                DocumentID = documentID,
                FileID = fileID,
                LoginName = @"fastts\fastqa07",
                Source = @"FAMOS"
            };
        }

        public static DocumentRefreshRequest GetDocumentRefreshRequest(int? fileID, int? documentID)
        {
            return new DocumentRefreshRequest
            {
                DocumentId = documentID,
                FileId = fileID,
                Source = "FAMOS",
                Target = "FAST",
                EmployeeObjectCD = "1",
                LoginName = AutoConfig.UserName,
                Phrases = new RefreshPhrase[] 
                { 
                    new RefreshPhrase
                    {
                        DocPhraseId=0,
                        PhraseElements=new RefreshPhraseElement[]
                        {
                            new RefreshPhraseElement
                            {
                                DocPraseElementId=0,
                            }
                        }
                    }
                }
            };
        }

        public static RemoveDocumentRequest GetRemoveDocumentDefaultRequest(int FileID)
        {
            return new RemoveDocumentRequest()
            {
                FileID = FileID,
                LoginName = @"fastts\fastqa07",
                Source = "FAMOS"
            };
        }

        public static GetDocPackageRequest GetDocPackageRequest(int FileID, int PackageID)
        {
            return new GetDocPackageRequest()
            {
                FileID = FileID,
                LoginName = @"fastts\fastqa07",
                Source = "FAMOS",
                PackageID = PackageID
            };
        }

        public static AssociateDocPackage GetModifyAssociateDocPackageDefaultRequest(int fileID, Document[] docs, string packageName = null)
        {
            return GetAssociateDocPackageDefaultRequest(fileID, docs, packageName);
        }

        public static DeArchiveFileRequest GetDeArchiveFileRequest(int fileID, string source = "famos", string loginName = null, string target = null, string employeeObjectCD = null)
        {
            return new DeArchiveFileRequest
            {
                FileID = fileID,
                Source = source,
                Target = target,
                EmployeeObjectCD = employeeObjectCD,
                LoginName = loginName
            };
        }

        public static EmailDeliveryRequest GetEmailDeliveryRequest(int fileID, int docID)
        {
            return new EmailDeliveryRequest
            {
                Documents = new DocumentList[] 
                { 
                    new DocumentList()
                    {
                        DocumentID = docID,  
                    },
                },
                EmployeeID = 1,
                FileID = fileID,
                Message = "WS Automation Test Message",
                SenderEmail = "ckurian@firstam.com",
                Subject = "FAST WS Automation",
                TOs = new TOList[]
                {
                    new TOList()
                    {
                        TO = "ckurian@firstam.com"  
                    },
                },
                eFormat = FastDocumentService.DocumentFormat.PDF,
                LoginName = AutoConfig.UserName,
                Source = "FAMOS"
            };
        }

        public static FaxDeliveryRequest GetFaxDeliveryRequest(int fileID, int docID)
        {
            return new FaxDeliveryRequest
            {
                Documents = new DocumentList[] 
                { 
                    new DocumentList()
                    {
                        DocumentID = docID
                    },
                },
                EmployeeID = 1,
                FaxRecipients = new FaxRecipientList[] 
                {
                    new FaxRecipientList()
                    {
                        FAXNumber = "7148001570",
                        Name = "Test Name"
                    },
                },
                FileID = fileID,
                Message = "WS Automation Test Message",
                SenderName = "Test Sender Name",
                LoginName = AutoConfig.UserName,
                Source = "FAMOS"
            };
        }

        public static FileFeeDeliveryRequest GetEmailFeeEntryDeliveryRequest(int fileID)
        {
            return new FileFeeDeliveryRequest
            {
                EmailDeliveryRequest = new EmailDelivery
                {
                    ImageDoc = true,
                    Message = "WS Automation Test Message",
                    SenderEmail = "ckurian@firstam.com",
                    Subject = "WS Automation Test Subject",
                    TOs = new TOList[] 
                    { 
                        new TOList()
                        {
                            TO = "ckurian@firstam.com"    
                        }
                    },
                    eFormat = FastDocumentService.DocumentFormat.PDF
                },
                EmployeeID = 1,
                FileID = fileID,
                eDeliveryMethod = FastDocumentService.DeliveryMethod.Email,
                LoginName = AutoConfig.UserName,
                Source = "FAMOS"
            };
        }

        public static WintrackDeliveryRequest GetWintrackDeliveryRequest(int? fileID, DocumentList[] documents)
        {
            return new WintrackDeliveryRequest()
            {
                Documents = documents,
                EmployeeID = 1,
                FileID = fileID,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static LACOMDeliveryRequest GetLACOMDeliveryRequest(int? fileID, DocumentList[] documents)
        {
            return new LACOMDeliveryRequest()
            {
                Documents = documents,
                EmployeeID = 1,
                FileID = fileID,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static PublishDocumentRequest GetPublishDocumentRequest(int? fileID)
        {
            return new PublishDocumentRequest
            {
                FileId = fileID,
                MarkAsDraft = false,
                LoginName = AutoConfig.UserName,
                Target = "FAST",
                Source = "FAMOS",
                EmployeeObjectCD = "1",
                FileRolesToPublish = new FileRole[]
                {
                    new FileRole
                    {
                        eFileRoleType=FileRoleType.Buyer,
                    }
                },
                ImageDocIds = new ImageDoc[]
                {
                    new ImageDoc
                    {
                        ImageDocId=0,
                    }
                }
            };
        }


    }
}
