﻿using FASTWCFHelpers.FastClosingDisclosureService;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace FASTWCFHelpers.Factories
{
    public class CDRequestFactory
    {
        public static ClosingDisclosureRequest GetCDDetailsRequest(int? fileId = null, eCDFilterSection filter = eCDFilterSection.All)
        {
            return new ClosingDisclosureRequest()
            {
                CDFilter = filter,
                CDRefType = eCDRefType.Charge,
                FileID = fileId ?? 0,
                EmployeeObjectCD = "1",
                LoginName = AutoConfig.UserName,
                Source = "FAMOS"
            };
        }

        public static ClosingDisclosureRequest GetCDRequest(int? fileId, eCDFilterSection filter = eCDFilterSection.All)
        {
            return new ClosingDisclosureRequest()
            {
                CDFilter = filter,
                FileID = fileId ?? 0,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static ClosingDisclosureUpdateRequest GetUpdateCDDetailsRequest(int? fileId)
        {
            return new ClosingDisclosureUpdateRequest()
            {
                ClosingDisclosure = new ClosingDisclosureNewRequest(),
                FileID = fileId ?? 0,
                isPartialSave = true,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static ClosingDisclosureUpdateRequest GetCDLoanCalculationsRequest(int fileID)
        {
            return new ClosingDisclosureUpdateRequest()
            {
                ClosingDisclosure = new ClosingDisclosureNewRequest()
                {
                    LoanCalculations = new ClosingDisclosureLoanCalculations()
                    {
                        AmountFinanced = 0,
                        AnnualPercentageRate = 0,
                        FinanceCharge = 0,
                        TotalInterestPercentage = (decimal)12.75,
                        TotalOfPayments = 1400000,
                    }
                },
                FileID = fileID,
                isPartialSave = true,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static ClosingDisclosureUpdateRequest GetCDLoanDisclosuresRequest(int fileID)
        {
            return new ClosingDisclosureUpdateRequest()
            {
                ClosingDisclosure = new ClosingDisclosureNewRequest()
                {
                    LoanDisclosures = new ClosingDisclosureLoanDisclosuresSection()
                    {
                        AcceptPayments = 0,
                        AllowAssumption = 0,
                        Declined = 0,
                        DelayedbyDays = 0,
                        DontAllowAssumption = 0,
                        EscrowedPropertyCostForYear = 0,
                        EstimatedPropertyCostsForyear = 0,
                        HasDemandFeature = 0,
                        HasEscrowAccount = 0,
                        HasScheduledPayments = 0,
                        HoldinSeparateAccount = 0,
                        InitialEscrowPayment = 0,
                        IsMonthlyEscrow = true,
                        LateFeeAmountInDollars = 0,
                        MayHaveScheduledPayments = 0,
                        MonthlyEscrowPayment = 0,
                        NoDemandFeature = 0,
                        NoEscrowAccount = 0,
                        NoNegativeAmortization = 0,
                        NoOfferbyLender = 0,
                        NoPartialPayments = 0,
                        NonEscrowedPropertyCostForYear = 0,
                    }
                },
                FileID = fileID,
                isPartialSave = true,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static ClosingDisclosureUpdateRequest GetCDApAirRequest(int fileID, bool withAP = false, bool withAIR = false)
        {
            return new ClosingDisclosureUpdateRequest()
            {
                ClosingDisclosure = new ClosingDisclosureNewRequest()
                {
                    ClosingDisclosureApAir = new ClosingDisclosureApAir()
                    {
                        AdjustableIntrestRate = withAIR ? GetCDAdjustableInterestRate() : null,
                        AdjustablePayment = withAP ? GetCDAdjustablePayment() : null,
                    },
                    ClosingDisclosureHeader = !withAIR ? null : new ClosingDisclosureHeader()
                    {
                        LoanProductTypeCDID = 2570,
                        LoanProductTypeDescription = "Fixed Rate",
                        LoanPurposeOtherDescription = "Purchase",
                        LoanPurposeTypeCDID = 2571,
                        LoanTermMonth = 0,
                        LoanTermYear = 0,
                    },
                    ClosingDisclosureLoanTerm = !withAIR ? null : new ClosingDisclosureLoanTerm() { InterestRate = 20 },
                },
                FileID = fileID,
                isPartialSave = true,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static ClosingDisclosureAdjustableIntrestRate GetCDAdjustableInterestRate()
        {
            return new ClosingDisclosureAdjustableIntrestRate()
            {
                FirstChange = GetCDAdjustableInterestRateItem("12", 2619, null),
                IncludeAdjustableInterestRateAIRTable = true,
                IncludeAdjustableIntrestRatechk = "2616",
                Index = GetCDAdjustableInterestRateItem("3091|123456789012345678901234567890", 2644, null),
                IndexDropdownTypeCDID = null,
                IndexMargin = GetCDAdjustableInterestRateItem("Index + Margin", 2617, null),
                LimitFirstChange = GetCDAdjustableInterestRateItem("3.9999", 2621, null),
                LimitSubsequentChanges = GetCDAdjustableInterestRateItem("0.9999", 2622, null),
                Margin = GetCDAdjustableInterestRateItem("5", 2645, null),
                MaxIntrestRate = GetCDAdjustableInterestRateItem("29.9999", 3083, null),
                MinIntrestRate = GetCDAdjustableInterestRateItem("2", 2618, null),
                SubsequentChangesEveryMonth = GetCDAdjustableInterestRateItem("12", 2620, null),
            };
        }

        public static ClosingDisclosureAdjustableIntrestRateItem GetCDAdjustableInterestRateItem(string amount, int? typeID, int? interestRateID)
        {
            return new ClosingDisclosureAdjustableIntrestRateItem()
            {
                AIRAmount = amount,
                AIRTypeCdID = typeID,
                CDAdjustableInterestRateID = interestRateID,
            };
        }

        public static ClosingDisclosureAdjustablePayment GetCDAdjustablePayment()
        {
            return new ClosingDisclosureAdjustablePayment()
            {
                IncludeAdjustablePaymentAPTable = true,
                IncludeAdjustablePaymentchk = "2624",
                InterestOnlyPayments = GetCDAdjustablePaymentItem("test-payment-description", 2973, 2625, value1: "test-value1", status: 1),
                InterestOnlyPaymentsOption = "YES",
                OptionalPayments = GetCDAdjustablePaymentItem("test-payment-description", 2973, 2626, value1: "test-value1", status: 1),
                OptionalPaymentsOption = "YES",
                StepPayments = GetCDAdjustablePaymentItem("test-payment-description", 2973, 2627, value1: "test-value1", status: 1),
                StepPaymentsOption = "YES",
                SeasonalPayments = GetCDAdjustablePaymentItem("test-payment-description", 2973, 2628, value1: "test-value1", status: 1),
                SeasonalPaymentsOption = "YES",
                FirstChangeAmounts = GetCDAdjustablePaymentItem("1,500.00|12", 3107, 2629),
                MaximumPayment = GetCDAdjustablePaymentItem("150.00|50", 3112, 2631),
                SubSequentChanges = GetCDAdjustablePaymentItem("1", 3109, 2630),
            };
        }

        public static ClosingDisclosureAdjustablePaymentItem GetCDAdjustablePaymentItem(string description, int scheduleId, int typeId, string value1 = "", string value2 = "", string value3 = "", int? status = null)
        {
            return new ClosingDisclosureAdjustablePaymentItem()
            {
                APDescr = description,
                APPaymentScheduleTypeCdID = scheduleId,
                APPopUpValue1 = value1,
                APPopUpValue2 = value2,
                APPopUpValue3 = value3,
                APStatus = status,
                APTypeCdID = typeId,
            };
        }

        public static ServiceFileRequest GetServiceFileRequest(int fileId, string target = null, string source = null)
        {
            return new ServiceFileRequest()
            {
                Target = target ?? "FAST",
                Source = source ?? "FAST",
                FileId = fileId,
                LoginName = AutoConfig.UserName
            };
        }

        public static ConvertCDDataContractToMismoRequest GetConvertCDDataContractToMismoRequest(ClosingDisclosure cdDataContract, string mismoVer = null, string target = null, string source = null)
        {
            return new ConvertCDDataContractToMismoRequest()
            {
                Target = target ?? "FAST",
                Source = source ?? "FAST",
                MismoVersion = mismoVer ?? "3.3.1",
                ClosingDisclosureData = cdDataContract
            };
        }

        public static GetCDWithPDFByMismoServiceRequest GetCDWithPDFByMismoServiceRequest(string mismoXml, int docTypeCdID = 144, string mismoVer = null, string target = null, string source = null)
        {
            return new GetCDWithPDFByMismoServiceRequest()
            {
                Target = target ?? "FAST",
                Source = source ?? "CDX",
                MismoVersion = mismoVer ?? "3.3.1",
                DocTypeCdID = docTypeCdID,
                MismoXml = mismoXml.Replace("&", "&amp;").Replace("'", "&apos;").Replace("\"", "&quot;").Replace("<", "&lt;").Replace(">", "&gt;"),
                DeliveryOptions = new ClosingDisclosureDeliveryOptions()
            };
        }
    
        public static CDDeliveryRequest GetCDFormDeliveryRequest(int? fileId)
        {
            return new CDDeliveryRequest()
            {
                DeliveryOptions = new ClosingDisclosureDeliveryOptions()
                {
                    IsInitialClosingDisclosure = 1,
                    IsLenderIssueorProvided = 1,
                    IsDeliveryTypePersonal = 1,
                    DateIssued = DateTime.Today.ToString("MM/dd/yyyy"),
                    Closing_ConsummationDate = DateTime.Today.ToString("MM/dd/yyyy"),
                    DisbursementDate = DateTime.Today.ToString("MM/dd/yyyy"),
                    DateReceived = DateTime.Today.ToString("MM/dd/yyyy"),
                    IsCombined = 1,
                    IsCombinedConfirmReceipt = 1,
                    IsIncludeAppraisalStatement = 1,
                    IsDateReceivedAck = 1,
                },
                EmailOptions = null,
                EmployeeID = 1,
                FaxOptions = null,
                FileId = fileId ?? 0,
                ImageDocOptions = null,
                eDeliveryMethod = DeliveryMethod.Preview,
                LoginName = AutoConfig.UserName,
                Source = "FAMOS"
            };
        }

        public static EmailOption GetEmailOptions()
        {
            return new EmailOption()
            {
                Attachments = new Attachment() 
                { 
                    Format = eFormat.PDF,
                    Message = "This is Testing Mail. Please ignore it...",
                    Subject = "CDFormDelivery",
                },
                To = new string[] { AutoConfig.DeliverEmailTo }
            };
        }

        public static FaxOption GetFaxOptions()
        {
            return new FaxOption()
            {
                Attachments = new Attachment()
                {
                    Format = eFormat.PDF,
                    Message = "This is Testing Fax. Please ignore it...",
                    Subject = "CDFormDelivery",
                },
                FaxRecipientList = new FaxRecipient[] 
                { 
                    new FaxRecipient()
                    {
                        Attention = AutoConfig.UserName,
                        FaxNumber = AutoConfig.DeliverFaxTo,
                        Name = "John Smith"
                    }
                },
                From = "000-000-0000"
            };
        }

        public static ImageDocOptions GetImageDocOptions()
        {
            return new ImageDocOptions()
            {
                Comments = "Test ImageDoc",
            };
        }

        public static CDDeliveryOptionsRequest GetCDDeliveryOptionsRequest(int? fileId)
        {
            return new CDDeliveryOptionsRequest()
            {
                FileID = fileId ?? 0,
                LoginName = AutoConfig.UserName,
                Source = "FAMOS"
            };
        }
    }
}
