﻿using FASTWCFHelpers.FastEscrowService;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace FASTWCFHelpers.Factories
{
    public class EscrowRequestFactory
    {
        #region Adjustments
        public static AdjustmentRequest GetAdjustmentRequest(int? fileId, AdjustmentType type)
        {
            return new AdjustmentRequest()
            {
                FileID = fileId,
                eAdjustmentType = type,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }
        #endregion

        public static FileBusinessParty GetFileBusinessParty(string gabCode = "BOA")
        {
            return new FASTWCFHelpers.FastEscrowService.FileBusinessParty() { AddrBookEntryID = (int)AdminService.GetGABAddressBookEntryId(gabCode) };
        }

        public static ServiceFileRequest GetServiceFileRequest(int? fileId)
        {
            return new ServiceFileRequest()
            {
                FileId = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static SplitDisbDetailRequest GetSplitDisbDetailRequest(int? fileId, int disbursementId)
        {
            return new SplitDisbDetailRequest()
            {
                DisbursementID = disbursementId,
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static UpdateSplitDisbRequest GetUpdateSplitDisbRequest(int fileId, int superDisbursementID)
        {
            return new UpdateSplitDisbRequest()
            {
                FileID = fileId,
                SuperDisbursementID = superDisbursementID,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static UpdateSFStatus GetUpdateSFStatus(int siteFileId, int status)
        {
            return new UpdateSFStatus()
            {
                SFFields = new SFField[]
                {
                    new SFField()
                    {
                        FieldName = "Test",
                        Value = 0
                    }
                },
                SiteFileStatus = new SiteFileStatus[]
                {
                    
                    new SiteFileStatus()
                    {
                        SiteFileID = siteFileId,
                        Status = status
                    }
                },
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static DisbTrackRequest GetDisbTrackRequest(int fileId, int disbursementId)
        {
            return new DisbTrackRequest()
            {
                DisbursementID = disbursementId,
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static UpdateDisbTrackRequest GetUpdateDisbTrackRequest(int fileId, int disbursementId)
        {
            return new UpdateDisbTrackRequest()
            {
                DisbursementID = disbursementId,
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static UpdateExternalServiceNumRequest GetUpdateExternalServiceNumRequest(int fileId, string serviceTypeObjectCD = "TO", string externalServiceNumber = "12345")
        {
            return new UpdateExternalServiceNumRequest()
            {
                ExternalServiceNumber = externalServiceNumber,
                FileID = fileId,
                ServiceTypeObjectCD = serviceTypeObjectCD,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static HoldFundsSummaryRequest GetHoldFundsSummaryRequest(int fileId)
        {
            return new HoldFundsSummaryRequest()
            {
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static GetHoldFundsRequest GetGetHoldFundsRequest(int fileId, int seqNum)
        {
            return new GetHoldFundsRequest()
            {
                FileID = fileId,
                SeqNum = seqNum,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static HoldFundsRemoveRequest GetHoldFundsRemoveRequest(int fileId, short seqNum)
        {
            return new HoldFundsRemoveRequest()
            {
                FileID = fileId,
                SeqNum = seqNum,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static UpdateSecondOrderSourceRequest GetUpdateSecondOrderSourceRequest(int fileId, int secondSourceAppID)
        {
            return new UpdateSecondOrderSourceRequest()
            {
                FileID = fileId,
                SecondSourceApplID = secondSourceAppID,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static EditDisbursementRequest GetEditDisbursementRequest(int fileId)
        {
            return new EditDisbursementRequest()
            {
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static SplitImageDocument GetSplitImageDocument(long imageID, string docName = "Test", string pageRange = "1")
        {
            return new SplitImageDocument()
            {
                DocumentName = docName,
                ElectronicFileID = imageID,
                EmployeeID = 1,
                PageRange = pageRange,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static UpdateFeesCalculationRequest GetUpdateFeesCalculationRequest(int fileId, string faccRequestXML = "Test", string faccResponseXML = "Test")
        {
            return new UpdateFeesCalculationRequest()
            {
                FileID = fileId,
                RateEffectiveDate = DateTime.Now.ToString("M/d/yyyy"),
                EmployeeID = 1,
                FACCRequestXML = faccRequestXML,
                FACCResponseXML = faccResponseXML,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        #region File Fees
        public static GetCalculationFeesRequest GetCalculationFeesRequest(int? fileId)
        {
            return new GetCalculationFeesRequest()
            {
                fileID = fileId ?? 0,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS",
                Target = "FAST"
            };
        }

        public static FastFeeDescriptionRequest GetFastFeeDescriptionRequest(int? fileID, string feeDescription)
        {
            return new FastFeeDescriptionRequest
            {
                FileID = fileID,
                EmployeeObjectCD = "1",
                LoginName = AutoConfig.UserName,
                Target = "FAST",
                Source = "FAMOS",
                FeeDescriptionInputParamLists = new FeeDescriptionInputParam[]
                {
                   new FeeDescriptionInputParam
                   {
                       FACCKey="",
                       FASTFeeDescription=feeDescription,
                       FASTProductCategory=0,
                       FeeCalcTypeCDID=0,
                       FeeID=0,
                       FeeTypeCDID=0
                   }
                }
            };
        }
        #endregion

        #region Outside Escrow Company
        public static OECRequest GetOECRequest(int? fileId, int? seqNum, string gabCode = "BOA")
        {
            return new OECRequest()
            {
                FileID = fileId,
                OECInformation = new OECInformation()
                {
                    SeqNum = seqNum,
                    OECFileBusinessParty = new FileBusinessParty()
                    {
                        IDCode = gabCode,
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId(gabCode, Convert.ToInt32(AutoConfig.SelectedRegionBUID))
                    }
                },
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }
        #endregion

        #region Outside Title Company
        public static OTCRequest GetOTCRequest(int? fileId, int? seqNum)
        {
            return new OTCRequest()
            {
                FileID = fileId,
                OTCInformation = new OTCInformation()
                {
                    SeqNum = seqNum,
                },
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static OutsideTitleCompanyRequest GetOutsideTitleCompanyRequest(int? fileId, int? seqNum, string gabCode = "BOA")
        {
            return new OutsideTitleCompanyRequest()
            {
                FileID = fileId,
                OTCFileBusinessPartyInfo = new OTCFileBusinessParty()
                {
                    FileBusinessParty = new FileBusinessParty()
                    {
                        IDCode = gabCode,
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId(gabCode, Convert.ToInt32(AutoConfig.SelectedRegionBUID))
                    }
                },
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }
        #endregion

        #region Deposit In Escrow
        public static DepositInEscrowRequest GetDepositInEscrowRequest(int? fileId)
        {
            return new DepositInEscrowRequest()
            {
                FileId = fileId,
                DepositInEscrow = new DepositInEscrow()
                {
                    DepositEscrow = new DepositEscrow()
                    {
                        AfterHoursFlag = false,
                        Amount = (decimal)5000,
                        BankAcctID = 2946,
                        CreationEmployeeID = 1,
                        CreditToTypeCdID = 329, //   Buyer:113 Seller:114 Other: 329
                        DepositorTypeCdID = 329, //   Buyer:113 Seller:114 Other: 329
                        PaymentMethodTypeCdID = 340,
                        RepresentingTypeCdID = 305,
                        UpdatedEmployeeID = 1,
                        ManualReceiptReason = "test-reason",
                        ReceiptNumber = "1020304",
                        Description = "representing-other",
                        Payor = "test-payor",
                    }
                },
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }


        public static DepositInEscrowRequest UpdateDepositInEscrowRequest(int? fileId, int? InEscrowId)
        {
            return new DepositInEscrowRequest()
            {
                FileId = fileId,
                DepositInEscrow = new DepositInEscrow()
                {
                    DepositEscrow = new DepositEscrow()
                    {
                        Amount = (decimal)100000,
                        BankAcctID = 2946,
                        CreationEmployeeID = 1,
                        CreditToTypeCdID = 114, //   Buyer:113 Seller:114 Other: 329
                        DepositorTypeCdID = 113, //   Buyer:113 Seller:114 Other: 329
                        PaymentMethodTypeCdID = 340,
                        RepresentingTypeCdID = 305,
                        UpdatedEmployeeID = 1,
                        ManualReceiptReason = "Update test-reason",
                        ReceiptNumber = "1020304",
                        Description = "Update representing-other",
                        Payor = "test-payor",
                        InEscrowID = InEscrowId,
                    }
                },
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }



        public static DepositImagesRequest GetDepositImagesRequest(int fileId, int depositId)
        {
            return new DepositImagesRequest()
            {
                DepositID = depositId,
                EmployeeID = 1,
                FileID = fileId,
                ImageType = FastEscrowService.ImageType.DepositedCheck,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static ServiceFileRequest GetDepositHistorySummaryRequest(int fileId)
        {
            return new ServiceFileRequest
            {
                FileId = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }
        #endregion

        #region Inspection Repair

        #region Inspection Repair Others
        public static InspectionRepairRequest GetIRORequest(int? fileId, int? seqNum)
        {
            return new InspectionRepairRequest()
            {
                EmployeeID = 1,
                oInspectionRepairDetails = GetInspectionRepairDetails(seqNum),
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }
        #endregion

        public static InspectionRepairPestRequest GetIRPRequest(int? fileId, int? seqNum)
        {
            return new InspectionRepairPestRequest()
            {
                EmployeeID = 1,
                oInspectionRepairDetails = GetInspectionRepairDetails(seqNum),
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static InspectionRepairPestRequest GetInspectionRepairPestRequest(int? fileId, int? seqNum, string gabCode = "BOA", DateTime? datetime = null, int? within = 5)
        {
            return new InspectionRepairPestRequest()
            {
                FileID = fileId,
                oInspectionRepairDetails = new InspectionRepairDetails()
                {
                    CDChargeList = new CDChargePaymentDetails[]
                    {
                        new CDChargePaymentDetails
                        {
                            Description = "Test1",
                            UseDefault = false,
                            SeqNum = 1,

                            BuyerCharge = 12345678901m,
                            AtClosingBuyerPaymentMethodTypeID = AtClosingPaymentMethods.CHK,

                            SellerCharge = 12345678901m,
                            AtClosingSellerPaymentMethodTypeID = AtClosingPaymentMethods.CHK,
                        },
                        new CDChargePaymentDetails
                        {
                            Description = "Test2",
                            SeqNum = 2,

                            BuyerCharge = 12345678901m,
                            AtClosingBuyerPaymentMethodTypeID = AtClosingPaymentMethods.CHK,

                            SellerCharge = 12345678901m,
                            AtClosingSellerPaymentMethodTypeID = AtClosingPaymentMethods.CHK,
                        }
                    },
                    SeqNum = seqNum,
                    FileBusinessParty = new FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId(gabCode) },
                    ReportInfo = !datetime.HasValue ? new ReportInformation() : new ReportInformation
                    {
                        FurnishedType = FurnishedType.Buyer,
                        DateOrdered = datetime,
                        DueDate = datetime.Value.AddDays(within.Value),
                        CompletionDate = datetime.Value.AddDays(within.Value),
                        FollowUpDate = datetime.Value.AddDays(within.Value),
                        ReportDate = datetime.Value.AddDays(within.Value),
                        Within = within
                    }
                },
                EmployeeID = 1,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static InspectionRepairSepticSaveRequest GetIRSRequest(int? fileId, int? seqNum)
        {
            return new InspectionRepairSepticSaveRequest()
            {
                EmployeeID = 1,
                oInspectionRepairDetails = GetInspectionRepairDetails(seqNum),
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static InspectionRepairSepticSaveRequest GetInspectionRepairSepticRequest(int? fileId, int? seqNum, string gabCode = "BOA", DateTime? datetime = null, int? within = 5)
        {
            return new InspectionRepairSepticSaveRequest()
            {
                EmployeeID = 1,
                oInspectionRepairDetails = new InspectionRepairDetails()
                {
                    CDChargeList = new CDChargePaymentDetails[]
                    {
                        new CDChargePaymentDetails
                        {
                            Description = "Test1",
                            UseDefault = false,
                            SeqNum = 1,

                            BuyerCharge = 12345678901m,
                            AtClosingBuyerPaymentMethodTypeID = AtClosingPaymentMethods.CHK,

                            SellerCharge = 12345678901m,
                            AtClosingSellerPaymentMethodTypeID = AtClosingPaymentMethods.CHK,
                        }
                    },
                    SeqNum = seqNum,
                    FileBusinessParty = new FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId(gabCode) },
                    ReportInfo = !datetime.HasValue ? new ReportInformation() : new ReportInformation
                    {
                        FurnishedType = FurnishedType.Buyer,
                        DateOrdered = datetime,
                        DueDate = datetime.Value.AddDays(within.Value),
                        CompletionDate = datetime.Value.AddDays(within.Value),
                        FollowUpDate = datetime.Value.AddDays(within.Value),
                        ReportDate = datetime.Value.AddDays(within.Value),
                        Within = within
                    }
                },
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static InspectionRepairPestSummaryRequest GetIRPSRequest(int? fileId)
        {
            return new InspectionRepairPestSummaryRequest()
            {
                FileId = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static InspectionRepairSepticSummaryRequest GetIRSSRequest(int? fileId)
        {
            return new InspectionRepairSepticSummaryRequest()
            {
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static InspectionRepairPestDetailsRequest GetIRPestDetailsRequest(int? fileId, int? seqNum)
        {
            return new InspectionRepairPestDetailsRequest()
            {
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                SeqNum = seqNum,
                Source = @"FAMOS"
            };
        }

        public static InspectionRepairSepticDetailsRequest GetIRSepticDetailsRequest(int? fileId, int? seqNum)
        {
            return new InspectionRepairSepticDetailsRequest()
            {
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                SeqNum = seqNum,
                Source = @"FAMOS"
            };
        }

        public static RemoveThirdPartyPayee GetRemoveThirdPartyPayeeRequest(int? fileId, int? seqNum, int? fileBusinessPartyID)
        {
            return new RemoveThirdPartyPayee()
            {
                FileBusinessPartyID = fileBusinessPartyID,
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                SeqNum = seqNum,
                EmployeeID = 1,
                Source = @"FAMOS",
                Target = "FAST"
            };
        }

        public static RemoveNewLoanRequest GetRemoveNewLoanRequest(int? fileId, int? seqNum)
        {
            return new RemoveNewLoanRequest()
            {
                EmployeeID = 1,
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                SeqNum = seqNum,
                Source = @"FAMOS"
            };
        }

        public static InspectionRepairSepticRemoveRequest GetIRSRemoveRequest(int? fileId, int? seqNum)
        {
            return new InspectionRepairSepticRemoveRequest()
            {
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                SeqNum = seqNum,
                Source = @"FAMOS"
            };
        }

        public static InspectionRepairDetails GetInspectionRepairDetails(int? seqNum)
        {
            return new InspectionRepairDetails()
            {
                CDChargeList = new CDChargePaymentDetails[] { GetCDChargePaymentDetails() },
                FileBusinessParty = new FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("501") },
                ReportInfo = new ReportInformation()
                {
                    CompletionDate = DateTime.Today.AddDays(70),
                    ReportDate = DateTime.Today.AddDays(77),
                    FurnishedType = FurnishedType.Other,
                    Within = 28,
                },
                SeqNum = seqNum,
            };
        }
        #endregion

        #region Insurance
        public static InsuranceRequest GetInsuranceRequest(int? fileId, int? seqNum)
        {
            return new InsuranceRequest()
            {
                FileID = fileId,
                InsuranceInformation = new InsuranceInformation() { InsuranceTypeOthersSeqNum = seqNum },
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }
        #endregion

        public static NewLoanDetailsRequest GetNewLoanDetailsRequest(int fileId, int seqNum)
        {
            return new NewLoanDetailsRequest()
            {
                fileID = fileId,
                seqNum = seqNum,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static CDChargePaymentDetails GetCDChargePaymentDetails()
        {
            return new CDChargePaymentDetails()
            {
                AdditionalDescription = "test-description",
                AtClosingBuyerPaymentMethodTypeID = AtClosingPaymentMethods.CHK,
                AtClosingSellerPaymentMethodTypeID = AtClosingPaymentMethods.CHK,
                BuyerCharge = (decimal)1000000,
                BuyerCredit = (decimal)1000000,
                BuyerCreditPaymentMethodTypeCdID = CreditPaymentMethods.AtClosing,
                LEAmount = (decimal)999999.99,
                PBBuyerAtClosing = (decimal)900000.00,
                PBBuyerBeforeClosing = (decimal)99999.99,
                PBOthersForBuyer = (decimal)0.01,
                PBOthersForBuyerPMTypeCdID = OtherPaymentMethods.POC,
                SellerCharge = (decimal)1000000,
                SellerCredit = (decimal)1000000,
                SellerCreditPaymentMethodTypeCdID = CreditPaymentMethods.AtClosing,
                PBSellerAtClosing = (decimal)900000.00,
                PBSellerBeforeClosing = (decimal)99999.99,
                PBOthersForSeller = (decimal)0.01,
                PBOthersForSellerPMTypeCdID = OtherPaymentMethods.POC,
                PartOf = false,
                SeqNum = 1,
                eSectionShop = SectionsShoppedFor.None,
            };
        }

        public static PropertyTaxCheckRequest GetPropertyTaxCheckRequest(int? fileId, int? seqNum, string gabCode = "BOA")
        {
            return new PropertyTaxCheckRequest()
            {
                EmployeeID = 1,
                FileID = fileId,
                oPropertyTaxCheckDetails = new PropertyTaxCheckDetails()
                {
                    SeqNum = seqNum,
                    FileBusinessParty = new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId(gabCode, Convert.ToInt32(AutoConfig.SelectedRegionBUID))
                    }
                },
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        #region Survey
        public static SurveyRequest GetSurveyRequest(int? fileId, int? seqNum, string gabCode = "BOA")
        {
            return new SurveyRequest()
            {
                FileID = fileId,
                oSurvey = new Survey()
                {
                    SeqNum = seqNum,
                    SurveyFileBusinessParty = new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId(gabCode, Convert.ToInt32(AutoConfig.SelectedRegionBUID))
                    }
                },
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }
        #endregion

        #region Utilities
        public static RemoveUtilityRequest GetRemoveUtilityRequest(int? fileId, int? seqNum)
        {
            return new RemoveUtilityRequest()
            {
                EmployeeID = 1,
                FileID = fileId,
                SeqNum = seqNum,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }
        public static GetUtilityRequest GetUtilityRequest(int? fileId, int? seqNum)
        {
            return new GetUtilityRequest()
            {
                FileID = fileId,
                SeqNum = seqNum,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }
        public static UtilityRequest GetCreateUtilityRequest(int? fileId, int? seqNum)
        {
            return new UtilityRequest()
            {
                EmployeeID = 1,
                FileID = fileId,
                Utility = new Utility()
                {
                    Proration = GetProration(),
                    SeqNum = seqNum,
                    UtilityCharges = new UtilityCharges()
                    {
                        UtilityCDChargesList = new CDChargePaymentDetails[] { GetCDChargePaymentDetails(), }
                    },
                    UtilityFileBusinessParty = new FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415") }
                },
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }
        public static UtilityRequest GetUpdateUtilityRequest(int? fileId, int? seqNum)
        {
            return new UtilityRequest()
            {
                EmployeeID = 1,
                FileID = fileId,
                Utility = new Utility()
                {
                    Proration = GetProration(),
                    SeqNum = seqNum,
                    UtilityCharges = new UtilityCharges()
                    {

                        UtilityCDChargesList = new CDChargePaymentDetails[]
            {
                new CDChargePaymentDetails()
                {
                AtClosingBuyerPaymentMethodTypeID = AtClosingPaymentMethods.NoCheck,
                AtClosingSellerPaymentMethodTypeID = AtClosingPaymentMethods.NoCheck,
                 AdditionalDescription = "test-description",
                BuyerCharge = (decimal)1000000,
                BuyerCredit = (decimal)1000000,
                BuyerCreditPaymentMethodTypeCdID = CreditPaymentMethods.AtClosing,
                LEAmount = (decimal)999999.99,
                PBBuyerAtClosing = (decimal)900000.00,
                PBBuyerBeforeClosing = (decimal)99999.99,
                PBOthersForBuyer = (decimal)0.01,
                PBOthersForBuyerPMTypeCdID = OtherPaymentMethods.POC,
                SellerCharge = (decimal)1000000,
                SellerCredit = (decimal)1000000,
                SellerCreditPaymentMethodTypeCdID = CreditPaymentMethods.AtClosing,
                PBSellerAtClosing = (decimal)900000.00,
                PBSellerBeforeClosing = (decimal)99999.99,
                PBOthersForSeller = (decimal)0.01,
                PBOthersForSellerPMTypeCdID = OtherPaymentMethods.POC,
                PartOf = false,
                SeqNum = 1,
                eSectionShop = SectionsShoppedFor.None,
                }
            },
                    },
                    UtilityFileBusinessParty = new FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247") }
                },
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }
        public static GetUtilitySummaryRequest GetUtilitySymmaryRequest(int? fileId)
        {
            return new GetUtilitySummaryRequest()
            {

                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS",
                EmployeeObjectCD = "1",
                Target = "fast",
            };
        }


        #endregion

        #region Proration
        public static ProrationRequest GetProrationRequest(int? fileId, int? seqNum, FastEscrowService.ProrationType type)
        {
            return new ProrationRequest()
            {
                EmployeeID = 1,
                FileID = fileId,
                ProrDetailsForCD = GetProrationDetailsForCD(seqNum, type),
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }
        public static ProrationDetailsForCD GetProrationDetailsForCD(int? seqNum, FastEscrowService.ProrationType type)
        {
            return new ProrationDetailsForCD()
            {
                Amount = (decimal)50000.00,
                AmountPeriod = DuePeriod.MONTH,
                BasedOnDays = 365,
                BuyerCharge = (decimal)5000.00,
                BuyerCredit = (decimal)10000.00,
                CreditSeller = true,
                DayOfClosePaidbySeller = true,
                Description = "ProrationCharge",
                FromDate = DateTime.UtcNow,
                FromDateInclusive = true,
                FromDateIsProrateDate = false,
                LEAmount = (decimal)9999.99,
                ProrationType = type,
                SeqNum = seqNum,
                SellerCharge = (decimal)5000.00,
                SellerCredit = (decimal)10000.00,
                ToDate = DateTime.UtcNow.AddDays(28),
                ToDateInclusive = false,
                ToDateIsProrateDate = false,
            };
        }
        public static Proration GetProration()
        {
            return new Proration()
            {
                Amount = (decimal)50000.00,
                AmountPeriod = DuePeriod.MONTH,
                BasedOnDays = 365,
                BuyerCharge = (decimal)5000.00,
                BuyerCredit = (decimal)10000.00,
                CreditSeller = true,
                DayOfClosePaidbySeller = true,
                FromDate = DateTime.Today,
                FromDateInclusive = true,
                FromDateIsProrateDate = false,
                LEAmount = (decimal)9999.99,
                ProrationType = FastEscrowService.ProrationType.NONE,
                SellerCharge = (decimal)5000.00,
                SellerCredit = (decimal)10000.00,
                ToDate = DateTime.Today.AddDays(28),
                ToDateInclusive = false,
                ToDateIsProrateDate = false,
            };
        }
        public static ProrationRequest UpdateProrationRequest(int? fileId, int? seqNum, FastEscrowService.ProrationType type)
        {
            return new ProrationRequest()
            {
                EmployeeID = 1,
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS",
                ProrDetailsForCD = new ProrationDetailsForCD()
                {
                    SeqNum = seqNum,
                    BuyerCharge = 100,
                    BuyerCredit = 100,
                    SellerCharge = 100,
                    SellerCredit = 100,
                    ProrationType = type,
                    FromDate = DateTime.UtcNow,
                    ToDate = DateTime.UtcNow.AddDays(28),
                }


            };
        }
        #endregion

        #region Homeowner Association

        public static HomeownerAssociationRequest GetHomeownerAssociationRequest(int? fileId, int? seqNum)
        {
            return new HomeownerAssociationRequest()
            {
                EmployeeID = 1,
                FileID = fileId,
                oHOADetails = new HOADetails() { SeqNum = seqNum },
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static HomeownerAssociationRequest GetHomeOwnerAssociationRequestWithCharge(int? fileID, int seqNum = 1)
        {
            return new HomeownerAssociationRequest
            {
                EmployeeID = 1,
                FileID = fileID,
                LoginName = AutoConfig.UserName,
                Source = "FAMOS",
                Target = "FAST",
                oHOADetails = new HOADetails()
                {
                    SeqNum = seqNum,
                    HOAInformation = new HomeownerAssociationInformation()
                    {
                        HOAFileBusinessParty = new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HOA1"),
                        },
                    },
                    Proration = new Proration()
                    {
                        Amount = 2500.01m,
                        AmountPeriod = DuePeriod.MONTH,
                        CreditSeller = true,
                        BuyerCharge = 50.01m,
                        SellerCharge = 50.02m,
                        FromDateInclusive = true,
                        FromDate = DateTime.Now.ToUniversalTime(),
                        ToDateInclusive = true,
                        ToDate = DateTime.Now.AddDays(4).ToUniversalTime(),
                        BasedOnDays = 360,
                    },

                    AssocDues = new AssociationDues()
                    {
                        Dues = 2345.01m,
                        eDuesPeriod = DuePeriod.MONTH
                    },

                    AssocCharges = new AssociationCharges()
                    {
                        AssociationChargesListForCD = new CDChargePaymentDetails[]
                        {
                            new CDChargePaymentDetails()
                            {
                                BuyerCharge=10.01m,
                                Description="Association Charge Instance",
                                IsDisbursed=0,
                                SellerCharge=10.03m,
                                SeqNum=1,
                                PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.None,
                                PBOthersForSellerPMTypeCdID=OtherPaymentMethods.None,
                                AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.CHK,
                                AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.CHK,
                                BuyerCreditPaymentMethodTypeCdID=CreditPaymentMethods.POC,
                                SellerCreditPaymentMethodTypeCdID=CreditPaymentMethods.POC,
                            }
                        }
                    },

                    HOALienPayoff = new LienPayoff()
                    {
                        HOALienPayoffListForCD = new CDChargePaymentDetails[]
                        {
                            new CDChargePaymentDetails()
                            {
                                BuyerCharge=20.01m,
                                Description="Lein Payoff Instance",
                                IsDisbursed=0,
                                SellerCharge=20.03m,
                                SeqNum=1,
                                PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.None,
                                PBOthersForSellerPMTypeCdID=OtherPaymentMethods.None,
                                AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.CHK,
                                AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.CHK,
                                BuyerCreditPaymentMethodTypeCdID=CreditPaymentMethods.POC,
                                SellerCreditPaymentMethodTypeCdID=CreditPaymentMethods.POC,
                            }
                        }
                    },

                    MgmtCompanyCharges = new ManagementCompanyCharges()
                    {
                        MgmtCompanyChargesListForCD = new CDChargePaymentDetails[]
                        {
                            new CDChargePaymentDetails()
                            {
                                BuyerCharge=30.01m,
                                Description="MangmentCompanyChrg Instance",
                                IsDisbursed=0,
                                SellerCharge=30.03m,
                                SeqNum=1,
                                PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.None,
                                PBOthersForSellerPMTypeCdID=OtherPaymentMethods.None,
                                AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.CHK,
                                AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.CHK,
                                BuyerCreditPaymentMethodTypeCdID=CreditPaymentMethods.POC,
                                SellerCreditPaymentMethodTypeCdID=CreditPaymentMethods.POC,
                            }
                        }
                    }
                },
            };
        }

        #endregion

        public static ChargeSet GetChargeSet(int seqNum = 0, short adhocFlag = 0, decimal bCharge = 0, decimal bCredit = 0, string desc = null, decimal sCharge = 0, decimal sCredit = 0)
        {
            return new ChargeSet()
            {
                AdhocFlag = adhocFlag,
                BuyerCharge = bCharge,
                BuyerCredit = bCredit,
                Description = desc,
                SellerCharge = sCharge,
                SellerCredit = sCredit,
                SeqNum = seqNum,
            };
        }

        #region PayOff
        public static ServiceFileRequest GetGetPayoffLoanRequest(int? fileID)
        {
            return new ServiceFileRequest()
            {
                FileId = fileID,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }
        //
        public static PayOffLoanPayChargeAssociationRequest PayOffLoanPayChargesAssociationReq(int? FileId, int? AddrBookEntryID, int? ChargeID, int? SeqNum = 1)
        {
            Reports.TestStep = "Associate PayoffLoan charges using to payee web service";
            FASTWCFHelpers.FastEscrowService.PayOffLoanPayChargeAssociationRequest PayChargeAssociationRequest = new FASTWCFHelpers.FastEscrowService.PayOffLoanPayChargeAssociationRequest();
            PayChargeAssociationRequest.FileID = FileId;
            PayChargeAssociationRequest.EmployeeID = 1;
            PayChargeAssociationRequest.fileBusinessParty = new FASTWCFHelpers.FastEscrowService.FileBusinessParty();
            PayChargeAssociationRequest.fileBusinessParty.AddrBookEntryID = AddrBookEntryID;
            //
            PayChargeAssociationRequest.LoginName = @"fastts\fastqa07";
            PayChargeAssociationRequest.SeqNum = SeqNum;
            PayChargeAssociationRequest.Source = "Famos";
            PayChargeAssociationRequest.ChargeIDs = new FASTWCFHelpers.FastEscrowService.ChargeIDCollection()
            {
                IsExistingPayee = false,
                ChargeID = ChargeID,
                IsAddorRemove = true
            };
            return PayChargeAssociationRequest;
        }

        public static PayoffLoanRequest GetDefaultPayoffLoanRequestWithCharge(String fileId)
        {
            #region CreatePayOffLoanRequestWithCharge

            return new PayoffLoanRequest()
            {
                FileID = int.Parse(fileId),
                PayOffLenderAddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                PayOffLenderOrigPrincipalBal = 400.01m,
                LoanTypeCdID = 667,

                CDInterestCalculationSummary = new CDPayOffLoanInterestChargeset[]
                {

                    new CDPayOffLoanInterestChargeset()
                    {
                        InterestType = 433,
                        PerDiemFlag = 1,
                        PerDiemAmount = 10.02m,
                        CalendarBaseDays = 365,
                        FromDate = DateTime.Now.ToUniversalTime(),
                        ToDate = DateTime.Now.ToUniversalTime().AddDays(10),
                        ToDateInclusive = 1,
                        FromDateInclusive = 0,
                        Description = "Interest on Payoff Loan",
                        SeqNum = 1,

                    CDChargePaymentDetails = new CDChargePaymentDetails()
                       {
                        AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastEscrowService.AtClosingPaymentMethods.CHK,
                        AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastEscrowService.AtClosingPaymentMethods.CHK,
                        BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastEscrowService.CreditPaymentMethods.AtClosing,
                        SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastEscrowService.CreditPaymentMethods.AtClosing,
                        PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastEscrowService.OtherPaymentMethods.POC,
                        PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastEscrowService.OtherPaymentMethods.POC,
                        Description = "Interest on Payoff Loan",
                        BuyerCharge = 9.03m,
                        BuyerCredit = 5.01m,
                        PBBuyerAtClosing = 2.01m,
                        PBBuyerBeforeClosing = 3.01m,
                        PBOthersForBuyer = 4.01m,
                        PBOthersForSeller = 4.01m,
                        PBSellerAtClosing = 100.20m,
                        PBSellerBeforeClosing = 3.01m,
                        SellerCharge = 107.22m,
                        SellerCredit = 5.01m,
                        LEAmount = 10.01m,
                       }
                    }
                },

                CDLoanCharges = new CDChargePaymentDetails()
                {
                    AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastEscrowService.AtClosingPaymentMethods.CHK,
                    AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastEscrowService.AtClosingPaymentMethods.CHK,
                    PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastEscrowService.OtherPaymentMethods.POC,
                    PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastEscrowService.OtherPaymentMethods.POC,
                    Description = "Principal Balance",
                    BuyerCharge = 9.03m,
                    BuyerCredit = 4.12m,
                    PBBuyerAtClosing = 2.01m,
                    PBBuyerBeforeClosing = 3.01m,
                    PBOthersForBuyer = 4.01m,
                    PBOthersForSeller = 4.01m,
                    PBSellerAtClosing = 2.01m,
                    PBSellerBeforeClosing = 3.01m,
                    SellerCharge = 9.03m,
                    SellerCredit = 10.30m,
                    LEAmount = 10.01m,
                },

                CDPayoffLoanCharges = new CDChargePaymentDetails[]
                {
                    new CDChargePaymentDetails()
                    {
                        AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastEscrowService.AtClosingPaymentMethods.CHK,
                        AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastEscrowService.AtClosingPaymentMethods.CHK,
                        BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastEscrowService.CreditPaymentMethods.AtClosing,
                        SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastEscrowService.CreditPaymentMethods.AtClosing,
                        PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastEscrowService.OtherPaymentMethods.POC,
                        PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastEscrowService.OtherPaymentMethods.POC,
                        Description = "Statement/Forwarding Fee",
                        BuyerCharge = 9.03m,
                        BuyerCredit = 5.01m,
                        PBBuyerAtClosing = 2.01m,
                        PBBuyerBeforeClosing = 3.01m,
                        PBOthersForBuyer = 4.01m,
                        PBOthersForSeller = 4.01m,
                        PBSellerAtClosing = 2.01m,
                        PBSellerBeforeClosing = 3.01m,
                        SellerCharge = 9.03m,
                        SellerCredit = 5.01m,
                        LEAmount = 10.01m,
                        SeqNum = 1,
                    },

                    new CDChargePaymentDetails()
                    {
                        AdhocFlag = 1,
                        AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastEscrowService.AtClosingPaymentMethods.CHK,
                        AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastEscrowService.AtClosingPaymentMethods.CHK,
                        BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastEscrowService.CreditPaymentMethods.AtClosing,
                        SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastEscrowService.CreditPaymentMethods.AtClosing,
                        PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastEscrowService.OtherPaymentMethods.POC,
                        PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastEscrowService.OtherPaymentMethods.POC,
                        Description = "Adhoc",
                        BuyerCharge = 9.03m,
                        BuyerCredit = 5.01m,
                        PBBuyerAtClosing = 2.01m,
                        PBBuyerBeforeClosing = 3.01m,
                        PBOthersForBuyer = 4.01m,
                        PBOthersForSeller = 4.01m,
                        PBSellerAtClosing = 2.01m,
                        PBSellerBeforeClosing = 3.01m,
                        SellerCharge = 9.03m,
                        SellerCredit = 5.01m,
                        LEAmount = 10.01m,
                        SeqNum = 9,
                    }
                },
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
            #endregion
        }

        public static PayoffLoanRequest GetUpdatePayoffLoanRequestWithCharge(String fileId)
        {
            #region UpdatePayOffLoanRequestWithCharge

            return new PayoffLoanRequest()
            {
                FileID = int.Parse(fileId),
                PayOffLenderAddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"),

                PayOffLenderOrigPrincipalBal = 500.05m,
                LoanTypeCdID = 667,

                CDInterestCalculationSummary = new CDPayOffLoanInterestChargeset[]
                {
                    new CDPayOffLoanInterestChargeset()
                    {
                        InterestType = 433,
                        PerDiemFlag = 1,
                        PerDiemAmount = 15.02m,
                        CalendarBaseDays = 360,

                        FromDate =DateTime.Now.ToUniversalTime(),
                        ToDate = DateTime.Now.ToUniversalTime().AddDays(8),
                        ToDateInclusive = 1,
                        FromDateInclusive = 1,
                        Description = "Interest on Payoff Loan",
                        SeqNum = 1,

                    CDChargePaymentDetails = new CDChargePaymentDetails()
                       {
                        AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastEscrowService.AtClosingPaymentMethods.CHK,
                        AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastEscrowService.AtClosingPaymentMethods.CHK,
                        BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastEscrowService.CreditPaymentMethods.AtClosing,
                        SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastEscrowService.CreditPaymentMethods.AtClosing,
                        PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastEscrowService.OtherPaymentMethods.POC,
                        PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastEscrowService.OtherPaymentMethods.POC,
                        Description = "Interest on Payoff Loan",
                        BuyerCharge = 10.06m,
                        BuyerCredit = 4.01m,
                        PBBuyerAtClosing = 3.02m,
                        PBBuyerBeforeClosing = 3.02m,
                        PBOthersForBuyer = 4.02m,
                        PBOthersForSeller = 7.02m,
                        PBSellerAtClosing = 8.02m,
                        PBSellerBeforeClosing = 5.02m,
                        SellerCharge = 20.06m,
                        SellerCredit = 4.01m,
                        LEAmount = 30.15m,
                       }
                    }
                },

                CDLoanCharges = new CDChargePaymentDetails()
                {
                    AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastEscrowService.AtClosingPaymentMethods.CHK,
                    AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastEscrowService.AtClosingPaymentMethods.CHK,
                    PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastEscrowService.OtherPaymentMethods.POC,
                    PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastEscrowService.OtherPaymentMethods.POC,
                    Description = "Principal Balance",
                    BuyerCharge = 20.06m,
                    BuyerCredit = 5.01m,
                    PBBuyerAtClosing = 5.02m,
                    PBBuyerBeforeClosing = 4.02m,
                    PBOthersForBuyer = 11.02m,
                    PBOthersForSeller = 4.02m,
                    PBSellerAtClosing = 6.02m,
                    PBSellerBeforeClosing = 10.02m,
                    SellerCharge = 20.06m,
                    SellerCredit = 8.01m,
                    LEAmount = 100.01m,
                },
                CDPayoffLoanCharges = new CDChargePaymentDetails[]
                {
                    new CDChargePaymentDetails()
                    {
                        AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastEscrowService.AtClosingPaymentMethods.CHK,
                        AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastEscrowService.AtClosingPaymentMethods.CHK,
                        BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastEscrowService.CreditPaymentMethods.AtClosing,
                        SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastEscrowService.CreditPaymentMethods.AtClosing,
                        PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastEscrowService.OtherPaymentMethods.POC,
                        PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastEscrowService.OtherPaymentMethods.POC,
                        Description = "Statement/Forwarding Fee",
                        BuyerCharge = 19.06m,
                        BuyerCredit = 8.01m,
                        PBBuyerAtClosing = 4.02m,
                        PBBuyerBeforeClosing = 5.02m,
                        PBOthersForBuyer = 10.02m,
                        PBOthersForSeller = 4.02m,
                        PBSellerAtClosing = 5.02m,
                        PBSellerBeforeClosing = 10.02m,
                        SellerCharge = 19.06m,
                        SellerCredit = 5.01m,
                        LEAmount = 50.01m,
                        SeqNum = 1,
                    },

                    new CDChargePaymentDetails()
                    {
                        AdhocFlag = 1,
                        AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastEscrowService.AtClosingPaymentMethods.CHK,
                        AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastEscrowService.AtClosingPaymentMethods.CHK,
                        BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastEscrowService.CreditPaymentMethods.AtClosing,
                        SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastEscrowService.CreditPaymentMethods.AtClosing,
                        PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastEscrowService.OtherPaymentMethods.POC,
                        PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastEscrowService.OtherPaymentMethods.POC,
                        Description = "Adhoc",
                        BuyerCharge = 25.12m,
                        BuyerCredit = 8.01m,
                        PBBuyerAtClosing = 8.04m,
                        PBBuyerBeforeClosing = 7.04m,
                        PBOthersForBuyer = 10.04m,
                        PBOthersForSeller = 8.04m,
                        PBSellerAtClosing = 10.04m,
                        PBSellerBeforeClosing = 7.04m,
                        SellerCharge = 25.12m,
                        SellerCredit = 7.01m,
                        LEAmount = 10.01m,
                        SeqNum = 9,
                    }
                },

                LoginName = AutoConfig.UserName,
                Source = @"FAMOS",
                SeqNum = 1
            };
            #endregion
        }

        #endregion

        #region Assumption Loan

        public static AssumptionLoanSaveRequest GetDefaultAssumptionLoanRequestWithCharge(int? fileId)
        {

            return new AssumptionLoanSaveRequest()
            {

                EmployeeID = 11345,
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = "FAMOS",

                AssumtionLoanDetails = new AssumptionLoanDetail()
                {

                    LenderInformation = new PayChargeFileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),

                    },
                    LoanDetail = new LoanDetails()
                    {
                        LoanType = eAssumptionLoanType.Assumption,
                        UnpaidPrincipalBalance = 1000.01m,

                    },

                    NoteDetails = new NoteDetails()
                    {
                        LateChargeAfterDays = 5,
                        LateChargeAmount = 10.01m,
                        LateChargeFlag = true,
                        OptLateChargeAmtFlag = true,
                        OriginalNoteAmount = 10.01m,
                        PaymentAmount = 11.01m,
                        PaymentType = eAssumptionPaymentType.InterestOnly,
                        payablePer = DuePeriod.MONTH,
                    },


                },

                Charges = new AssumptionLoanCharges()
                {
                    CDAssumptionLoanCharge = new CDChargePaymentDetails[]
                    {

                        new CDChargePaymentDetails()
                        {

                            BuyerCharge=11111111111.11m,
                            BuyerCredit=22222222222.22m,
                            Description="Create Instance",
                            IsDisbursed=0,
                            SellerCharge=44444444444.44m,
                            SellerCredit=33333333333.33m,
                            SeqNum=1,
                            PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.None,
                            PBOthersForSellerPMTypeCdID=OtherPaymentMethods.None,
                                AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.CHK,
                                AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.CHK,
                                BuyerCreditPaymentMethodTypeCdID=CreditPaymentMethods.POC,
                                SellerCreditPaymentMethodTypeCdID=CreditPaymentMethods.POC,
                        },
                    },


                    CDInterestProration = new CDInterestProrationSummary()
                    {

                        InterestCalculation = new InterestCalculation()
                        {
                            BasedOnDays = 365,
                            CreditSellerFlag = true,
                            FromInclusive = true,
                            InterestTypeCdID = 434,
                            PerDiemAmount = 10.01m,
                            ToInclusive = true,

                        },
                    },

                    CDUnPaidPrincipalLoanCharges = new CDChargePaymentDetails[]
                    {
                        new CDChargePaymentDetails()
                        {
                          BuyerCredit=1000.01m,
                            BuyerCharge=1.01m,
                            SellerCredit=1.01m,
                            SellerCharge=1000.01m,
                            SeqNum=1,
                            AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.CHK,
                            AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.CHK,
                            BuyerCreditPaymentMethodTypeCdID=CreditPaymentMethods.POC,
                        }

                    },
                },

            };
        }

        public static AssumptionLoanDetailsRequest GetAssumptionLoanDetailsRequest(int? fileId)
        {
            return new AssumptionLoanDetailsRequest()
            {
                FileID = fileId,
                SeqNum = 1,
                LoginName = AutoConfig.UserName,
                Source = "FAMOS",

            };
        }

        public static AssumptionLoanSaveRequest GetDefaultUpdateAssmptionLoanDetails(int? fileId)
        {
            return new AssumptionLoanSaveRequest()
            {

                EmployeeID = 11345,
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = "FAMOS",
                SeqNum = 1,
                AssumtionLoanDetails = new AssumptionLoanDetail()
                {

                    LenderInformation = new PayChargeFileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),

                    },
                    LoanDetail = new LoanDetails()
                    {
                        LoanType = eAssumptionLoanType.SubjectTo,
                        UnpaidPrincipalBalance = 11.11m,

                    },

                    NoteDetails = new NoteDetails()
                    {
                        LateChargeAfterDays = 4,
                        LateChargeFlag = true,
                        LateChargePercentage = 10.1234m,
                        OptLateChargeAmtFlag = false,
                        OriginalNoteAmount = 11.01m,
                        PaymentAmount = 12.01m,
                        PaymentType = eAssumptionPaymentType.PrincipalInterestTaxInsurance,
                        payablePer = DuePeriod.TRIMESTER,
                    },


                },

                Charges = new AssumptionLoanCharges()
                {


                    CDAssumptionLoanCharge = new CDChargePaymentDetails[]
                    {

                        new CDChargePaymentDetails()
                        {
                            AdhocFlag=1,
                           AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.NoCheck,
                            BuyerCharge=10.01m,
                            Description="Adhoc01",
                            SellerCharge=10.01m,
                            SeqNum=6,


                        },
                    },


                    CDInterestProration = new CDInterestProrationSummary()
                    {

                        InterestCalculation = new InterestCalculation()
                        {
                            BasedOnDays = 360,
                            CreditSellerFlag = false,
                            FromInclusive = true,
                            InterestTypeCdID = 433,
                            PercentageRate = 99.9888m,
                            UsePerDiemFlag = false,


                        },
                    },

                    CDUnPaidPrincipalLoanCharges = new CDChargePaymentDetails[]
                    {
                        new CDChargePaymentDetails()
                        {
                          BuyerCredit=11.11m,
                            BuyerCharge=10.11m,
                            SellerCredit=21.11m,
                            SellerCharge=11.11m,
                            SeqNum=1,
                            AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.NoCheck,
                            AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.NoCheck,
                            BuyerCreditPaymentMethodTypeCdID=CreditPaymentMethods.AtClosing,
                        }

                    },
                },

            };
        }

        public static AssumptionLoanSummaryRequest GetDefaultAssumptionLoanSummaryRequest(int? fileId)
        {
            return new AssumptionLoanSummaryRequest()
            {
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = "FAMOS",

            };
        }

        public static RemoveAssumptionLoanRequest GetDefaultRemoveAssumptionLoanRequest(int? fileId)
        {
            return new RemoveAssumptionLoanRequest()
            {
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = "FAMOS",
                SeqNo = 1,

            };
        }

        public static AssumptionLoanDisbursementDetailsRequest GetAssumptionLoanDisbursementDetailsRequest(int? fileID, int? seqNum)
        {
            return new AssumptionLoanDisbursementDetailsRequest
            {
                FileID = fileID,
                SeqNum = seqNum,
                EmployeeObjectCD = "1",
                LoginName = AutoConfig.UserName,
                Source = "FAMOS",
                Target = "FAST"
            };
        }

        public static AssumptionLoanDisbSaveRequest GetAssumptionLoanDisbSaveRequest(AssumptionLoanDisbursementDetailsResponse response, int? fileID, int SeqNum)
        {
            return new AssumptionLoanDisbSaveRequest
            {
                FileID = fileID,
                SeqNum = SeqNum,
                EmployeeID = 1,
                Target = "FAST",
                LoginName = AutoConfig.UserName,
                Source = "FAMOS",
                CDChargeDetails = response.ChargeDetails,
                PayeeInformation = new AssumptionLoanDisbursementPayeeInformation[]
                {
                    new AssumptionLoanDisbursementPayeeInformation()
                    {
                        eOperationType = OperationType.None,
                        FBPOverrideFlag = false,
                        FileBusinessParty = response.PayeeInformation[0].FileBusinessParty
                    },
                }
            };
        }

        public static AssumptionLoanDisbSaveRequest GetAssumptionLoanDisbSaveRequest(int fileID, int SeqNum)
        {
            return new AssumptionLoanDisbSaveRequest
            {
                FileID = fileID,
                SeqNum = SeqNum,
                EmployeeID = 1,
                Target = "FAST",
                LoginName = AutoConfig.UserName,
                Source = "FAMOS",
            };
        }

        #endregion

        public static NewLoanRequest GetNewLoanCreateRequest(string fileID, int? seqNum)
        {
            return new NewLoanRequest()
            {
                FileID = int.Parse(fileID),
                LoanDetails = new NewLoanDetail()
                {
                    LoanNumber = "NewLoan_FromWCF_UsingNewLoanRequest",
                    LoanAmount = 1000.01m,
                    LoanDates = new LoanDates()
                    {
                        RescissionDays = 3
                    },
                    LenderInformation = new PayChargeFileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247")
                    },
                    MortgageInsuranceCaseNumber = "123425"
                },
                LoanCharges = new LoanCharge()
                {
                    NewLoanCharges = AutoConfig.UseCDFormType ? null : new PaymentDetailsWithGFE[1]
                    {
                        new PaymentDetailsWithGFE
                        {
                            BuyerCharge = 100.02m,
                            BuyerPaymentMethodTypeID = 385,
                            SellerCharge = 10.02m,
                            SellerPaymentMethodTypeID = 385,
                            SeqNum = 1
                        }
                    },
                    PayCharges = AutoConfig.UseCDFormType ? null : new PayCharge
                    {
                        DisbursementCharges = new DisbursementCharge[2]
                        {
                            new DisbursementCharge
                            {
                                Description = "Test",
                                BuyerCharge = 1341.01m
                            },
                            new DisbursementCharge
                            {
                                Description = "New Loan",
                                BuyerCharge = 2003.01m
                            }
                        }
                    },
                    ImpoundCharges = AutoConfig.UseCDFormType ? null : new ImpoundCharge
                    {
                        Description = "Impound",
                        GFEAmount = 1002.01m,
                        Impounds = new Impound[1]
                        {
                            new Impound
                            {
                                MonthlyCharge = 188.03m,
                                Months = 6,
                                PaymentDetails = new PaymentDetailsWithGFE
                                {
                                    AdhocFlag = 1,
                                    BuyerPaymentMethodTypeID = 385,
                                    Description = "Impound",
                                    SellerPaymentMethodTypeID = 385
                                }
                            }
                        }
                    },
                    InterestCalculationSummary = AutoConfig.UseCDFormType ? null : new InterestCalculationSummary
                    {
                        InterestCalculation = new InterestCalculation
                        {
                            BasedOnDays = 365,
                            FromInclusive = true,
                            InterestFlag = 1,
                            InterestTypeCdID = 431,
                            PerDiemAmount = 102.1m,
                            ToInclusive = true,
                            UsePerDiemFlag = true
                        }
                    },
                    CDPrincipalBalanceCharges = AutoConfig.UseCDFormType ? new CDChargePaymentDetails()
                    {
                        AtClosingSellerPaymentMethodTypeID = AtClosingPaymentMethods.RBL,
                        Description = "UpdateBal",
                        LEAmount = 11.11m,
                        PBOthersForSeller = 1.01m,
                        PBOthersForSellerPMTypeCdID = OtherPaymentMethods.POCMB,
                        PBSellerAtClosing = 5.01m,
                        PBSellerBeforeClosing = 6.01m,
                        SellerCharge = 12.03m,
                        SeqNum = 1
                    } : null,
                    CDInterestCalculationSummary = AutoConfig.UseCDFormType ? new CDInterestCalculationSummary()
                    {
                        CDChargePaymentDetails = new CDChargePaymentDetails()
                        {
                            AtClosingBuyerPaymentMethodTypeID = AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID = AtClosingPaymentMethods.RBL,
                            BuyerCharge = 12.04m,
                            Description = "Test",
                            LEAmount = 5.06m,
                            PBBuyerAtClosing = 6.02m,
                            PBBuyerBeforeClosing = 4.01m,
                            PBOthersForBuyer = 2.01m,
                            PBOthersForBuyerPMTypeCdID = OtherPaymentMethods.POC,
                            SeqNum = 1
                        },
                        InterestCalculation = new InterestCalculation()
                        {
                            BasedOnDays = 365,
                            FromInclusive = false,
                            PerDiemAmount = 100.02m,
                            ToInclusive = true,
                            UsePerDiemFlag = true
                        },
                    } : null,
                    CDNewLoanCharges = AutoConfig.UseCDFormType ? new CDChargePaymentDetails[]
                    {
                        new CDChargePaymentDetails()
                        {
                            AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            BuyerCharge=12.03m,
                            Description="NewLoanChargeUpdate",
                            LEAmount=5.02m,
                            PBBuyerAtClosing=5.01m,
                            PBBuyerBeforeClosing=5.01m,
                            PBOthersForBuyer=2.01m,
                            PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.POCMB,
                            PBOthersForSeller=1.01m,
                            PBOthersForSellerPMTypeCdID=OtherPaymentMethods.POCL,
                            PBSellerAtClosing=2.01m,
                            PBSellerBeforeClosing=3.01m,
                            SellerCharge=6.03m,
                            SeqNum=1
                        },
                        new CDChargePaymentDetails()
                        {
                            AdhocFlag=1,
                            AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            BuyerCharge=30.03m,
                            Description="Check LoanUpdate",
                            LEAmount=2.66m,
                            PBBuyerAtClosing=10.01m,
                            PBBuyerBeforeClosing=10.01m,
                            PBOthersForBuyer=10.01m,
                            PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.POC,
                            PBOthersForSeller=5.01m,
                            PBOthersForSellerPMTypeCdID=OtherPaymentMethods.POCL,
                            PBSellerAtClosing=5.01m,
                            PBSellerBeforeClosing=5.01m,
                            SellerCharge=15.03m,
                        },
                    } : null,
                },
                MortgageBroker = new MortgageBroker()
                {
                    YieldSpreadPremium = !AutoConfig.UseCDFormType ? new YieldSpreadPremium
                    {
                        Description = "Test",
                        FileCharge = 510.02m
                    } : null,
                    CDBrokerFee = new BrokerFee()
                    {
                        Description = "Check BrokerFeeNew",
                        FileCharge = 14.33m,
                        PaymentMethodTypeID = 2390
                    },
                    CDMortgageBrokerCharges = new CDChargePaymentDetails[]
                    {
                        new CDChargePaymentDetails()
                        {
                            AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            BuyerCharge=22.05m,
                            Description="Check",
                            LEAmount = 5.03m,
                            PBBuyerAtClosing=10.01m,
                            PBOthersForBuyer=12.04m,
                            PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.POC,
                            PBOthersForSeller=3.01m,
                            PBOthersForSellerPMTypeCdID=OtherPaymentMethods.POCL,
                            PBSellerAtClosing=1.01m,
                            PBSellerBeforeClosing=5.01m,
                            SellerCharge = 9.03m,
                            SeqNum=1
                    },
                    new CDChargePaymentDetails()
                    {
                            AdhocFlag=1,
                            AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            BuyerCharge=12.03m,
                            Description="Adhoc MortgageCharge",
                            LEAmount = 5.03m,
                            PBBuyerAtClosing=4.01m,
                            PBBuyerBeforeClosing=4.01m,
                            PBOthersForBuyer=4.01m,
                            PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.POC,
                            PBOthersForSeller=2.01m,
                            PBOthersForSellerPMTypeCdID=OtherPaymentMethods.POC,
                            PBSellerAtClosing=2.01m,
                            PBSellerBeforeClosing=2.01m,
                            SellerCharge = 6.03m,
                        },
                    },
                    MorgageBrokerInformation = new FileBusinessParty()
                    {
                        AddrBookEntryID = 8835488
                    },
                },
                SeqNum = seqNum,
                EmployeeID = 1,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static NewLoanRequest GetNewLoanUpdateRequest(string fileID, int? seqNum)
        {
            return new NewLoanRequest()
            {
                FileID = int.Parse(fileID),
                SeqNum = seqNum,
                LoanDetails = new NewLoanDetail()
                {
                    HazardInsuranceLossPayee = new HazardInsuranceLossPayee
                    {
                        Text = "Hazard"
                    },
                    LoanNumber = "NewLoan_FromWCF_UsingNewLoanRequest",
                    LoanTypeID = 444,
                    LoanAmount = 55555555555m,
                    LiabilityAmount = 55555555555m,
                    MortgageInsuranceCaseNumber = "123425",
                    LoanDates = new LoanDates()
                    {
                        RescissionDays = 3
                    },
                    LenderInformation = new PayChargeFileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247")
                    }
                },
                LoanCharges = new LoanCharge()
                {
                    #region HUD
                    CreditOrChargePoints = new CreditOrChargePoints
                    {
                        CCPCreditChargeFlag = 2,
                        PaymentDetail = new PaymentDetailsWithGFE
                        {
                            BuyerCharge = 10.01m
                        }
                    },
                    GFE3LoanCharges = new GFELoanCharges[]
                    {
                        new GFELoanCharges
                        {
                            PaymentDetail = new PaymentDetailsWithGFEAndPOC
                            {
                                BuyerCharge = 10.02m,
                                BuyerPaymentMethodTypeID = 385,
                                SellerCharge = 22.01m,
                                SellerPaymentMethodTypeID = 385
                            }
                        },
                        new GFELoanCharges
                        {
                            PaymentDetail = new PaymentDetailsWithGFEAndPOC
                            {
                                Description = "GFE3Adhoc",
                                AdhocFlag = 1,
                                BuyerCharge = 122.01m,
                                BuyerPaymentMethodTypeID = 385,
                                SellerCharge = 201.01m,
                                SellerPaymentMethodTypeID = 385
                            }
                        }
                    },
                    GFE6LoanCharges = new GFELoanCharges[]
                    {
                        new GFELoanCharges
                        {
                            PaymentDetail = new PaymentDetailsWithGFEAndPOC
                            {
                                BuyerCharge = 10.02m,
                                BuyerPaymentMethodTypeID = 385,
                                SellerCharge = 22.01m,
                                SellerPaymentMethodTypeID = 385
                            }
                        },
                        new GFELoanCharges
                        {
                            PaymentDetail = new PaymentDetailsWithGFEAndPOC
                            {
                                Description = "GFE6Adhoc",
                                AdhocFlag = 1,
                                BuyerCharge = 150.02m,
                                BuyerPaymentMethodTypeID = 385,
                                SellerCharge = 202.01m,
                                SellerPaymentMethodTypeID = 385
                            }
                        }
                    },
                    ImpoundCharges = new ImpoundCharge
                    {
                        AAACreditChargeFlag = 1,
                        Description = "Impound",
                        GFEAmount = 1020.01m,
                        Impounds = new Impound[]
                        {
                            new Impound
                            {
                                MonthlyCharge = 88.03m,
                                Months = 6,
                                PaymentDetails = new PaymentDetailsWithGFE
                                {
                                    AdhocFlag = 1,
                                    BuyerPaymentMethodTypeID = 385,
                                    Description = "Impound",
                                    SellerPaymentMethodTypeID = 385
                                }
                            }
                        }
                    },
                    InterestCalculationSummary = new InterestCalculationSummary
                    {
                        InterestCalculation = new InterestCalculation
                        {
                            BasedOnDays = 365,
                            FromInclusive = true,
                            InterestFlag = 1,
                            InterestTypeCdID = 431,
                            PerDiemAmount = 201.01m,
                            ToInclusive = true,
                            UsePerDiemFlag = true
                        }
                    },
                    OriginationCharges = new OriginationCharge
                    {
                        GFEAmount = 1100.02m,
                        OriginationFeePercent = 1,
                        OriginationFlag = 1
                    },
                    PayCharges = new PayCharge
                    {
                        DisbursementCharges = new DisbursementCharge[]
                        {
                            new DisbursementCharge
                            {
                                BuyerCharge = 2131.01m,
                                Description = "Test",
                            },
                            new DisbursementCharge
                            {
                                BuyerCharge = 2013.04m,
                                Description = "New Loan"
                            }
                        }
                    },
                    #endregion
                    #region CD
                    CDCreditOrChargePoints = new CDCreditOrChargePoints()
                    {
                        CDChargePaymentDetails = new CDChargePaymentDetails()
                        {
                            AtClosingSellerPaymentMethodTypeID = AtClosingPaymentMethods.RBL,
                            AtClosingBuyerPaymentMethodTypeID = AtClosingPaymentMethods.RBL,
                            BuyerCharge = 11.04m,
                            Description = "Validate",
                            LEAmount = 6.22m,
                            PBBuyerAtClosing = 6.02m,
                            PBBuyerBeforeClosing = 5.02m,
                            PBOthersForSeller = 2.01m,
                            PBOthersForSellerPMTypeCdID = OtherPaymentMethods.POC,
                            PBSellerAtClosing = 2.02m,
                            PBSellerBeforeClosing = 2.01m,
                            SellerCharge = 6.04m,
                            SeqNum = 1,
                        },
                        CDSelectedDispFrmt = 2474,
                        DiscountPointAdjAmt = 2,
                        IRSDiscountPoints = 1
                    },
                    CDFutureRecordingFeesCollectedByLender = new CDChargePaymentDetails[]
                    {
                        new CDChargePaymentDetails()
                        {
                            AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            BuyerCharge=12.03m,
                            SeqNum=1
                        },
                    },
                    CDImpoundCharges = new CDImpoundCharge()
                    {
                        AggregateAccountingAdjustment = new CDChargePaymentDetails()
                        {
                            AtClosingBuyerPaymentMethodTypeID = AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID = AtClosingPaymentMethods.RBL,
                            BuyerCharge = 1.01m
                        },
                        Impounds = new CDChargePaymentDetails[]
                        {
                            new CDChargePaymentDetails()
                            {
                                AdhocFlag=0,
                                AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                                AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                                MonthlyCharge=12.01m,
                                Months=3,
                                PBOthersForSeller=1.01m,
                                PBOthersForSellerPMTypeCdID=OtherPaymentMethods.POC,
                                PBSellerAtClosing=5.01m,
                                PBSellerBeforeClosing=5.01m,
                                SellerCharge=11.03m,
                                SeqNum=1
                            },
                            new CDChargePaymentDetails()
                            {
                                AdhocFlag=1,
                                AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                                AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                                Description="Check Impound",
                                LEAmount=11.02m,
                                MonthlyCharge=10.02m,
                                Months=2,
                                SellerCharge=22.01m,
                            },
                        },
                    },
                    CDInterestCalculationSummary = new CDInterestCalculationSummary()
                    {
                        CDChargePaymentDetails = new CDChargePaymentDetails()
                        {
                            AtClosingBuyerPaymentMethodTypeID = AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID = AtClosingPaymentMethods.RBL,
                            BuyerCharge = 12.04m,
                            Description = "Test",
                            LEAmount = 5.06m,
                            PBBuyerAtClosing = 6.02m,
                            PBBuyerBeforeClosing = 4.01m,
                            PBOthersForBuyer = 2.01m,
                            PBOthersForBuyerPMTypeCdID = OtherPaymentMethods.POC,
                            SeqNum = 1
                        },
                        InterestCalculation = new InterestCalculation()
                        {
                            BasedOnDays = 365,
                            FromInclusive = false,
                            PerDiemAmount = 100.02m,
                            ToInclusive = true,
                            UsePerDiemFlag = true
                        },
                    },
                    CDLenderCredits = new CDChargePaymentDetails[]
                    {
                        new CDChargePaymentDetails()
                        {
                            BuyerCredit=2.01m,
                            BuyerCreditPaymentMethodTypeCdID=CreditPaymentMethods.Lender,
                            Description="Check",
                            LEAmount=1.01m,
                            SeqNum=1
                        },
                    },
                    CDNewLoanCharges = new CDChargePaymentDetails[]
                    {
                        new CDChargePaymentDetails()
                        {
                            AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            BuyerCharge=12.03m,
                            Description="NewLoanChargeUpdate",
                            LEAmount=5.02m,
                            PBBuyerAtClosing=5.01m,
                            PBBuyerBeforeClosing=5.01m,
                            PBOthersForBuyer=2.01m,
                            PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.POCMB,
                            PBOthersForSeller=1.01m,
                            PBOthersForSellerPMTypeCdID=OtherPaymentMethods.POCL,
                            PBSellerAtClosing=2.01m,
                            PBSellerBeforeClosing=3.01m,
                            SellerCharge=6.03m,
                            SeqNum=1
                        },
                        new CDChargePaymentDetails()
                        {
                            AdhocFlag=1,
                            AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            BuyerCharge=30.03m,
                            Description="Check LoanUpdate",
                            LEAmount=2.66m,
                            PBBuyerAtClosing=10.01m,
                            PBBuyerBeforeClosing=10.01m,
                            PBOthersForBuyer=10.01m,
                            PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.POC,
                            PBOthersForSeller=5.01m,
                            PBOthersForSellerPMTypeCdID=OtherPaymentMethods.POCL,
                            PBSellerAtClosing=5.01m,
                            PBSellerBeforeClosing=5.01m,
                            SellerCharge=15.03m,
                        },
                    },
                    CDOriginationCharges = new CDChargePaymentDetails[]
                    {
                        new CDChargePaymentDetails()
                        {
                            AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            BuyerCharge=16.04m,

                            LEAmount=5.02m,
                            PBBuyerAtClosing=8.02m,
                            PBBuyerBeforeClosing=4.01m,
                            PBOthersForBuyer=4.01m,
                            PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.POC,
                            PBOthersForSeller=3.01m,
                            PBOthersForSellerPMTypeCdID=OtherPaymentMethods.POC,
                            PBSellerAtClosing=2.01m,
                            PBSellerBeforeClosing=3.01m,
                            SellerCharge=8.03m,
                            SeqNum=1
                        },
                        new CDChargePaymentDetails()
                        {
                            AdhocFlag=1,
                            AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            BuyerCharge=22.05m,
                            Description="Adhoc OrgCharge",
                            LEAmount=2.66m,
                            PBBuyerAtClosing=7.02m,
                            PBBuyerBeforeClosing=8.02m,
                            PBOthersForBuyer=7.01m,
                            PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.POC,
                            PBOthersForSeller=4.02m,
                            PBOthersForSellerPMTypeCdID=OtherPaymentMethods.POC,
                            PBSellerAtClosing=1.01m,
                            PBSellerBeforeClosing=5.02m,
                            SellerCharge=10.05m
                        },
                    },
                    CDPrincipalBalanceCharges = new CDChargePaymentDetails()
                    {
                        AtClosingSellerPaymentMethodTypeID = AtClosingPaymentMethods.RBL,
                        Description = "UpdateBal",
                        LEAmount = 11.11m,
                        PBOthersForSeller = 1.01m,
                        PBOthersForSellerPMTypeCdID = OtherPaymentMethods.POCMB,
                        PBSellerAtClosing = 5.01m,
                        PBSellerBeforeClosing = 6.01m,
                        SellerCharge = 12.03m
                    },
                    CDPrincipalReductionOrConstructionHoldBack = new CDChargePaymentDetails[]
                    {
                        new CDChargePaymentDetails()
                        {
                            BuyerCharge = 22.01m,
                            SellerCharge = 12.01m,
                            SeqNum=1
                        },
                        new CDChargePaymentDetails()
                        {
                            AdhocFlag=1,
                            BuyerCharge = 10.03m,
                            Description ="Adhoc PriciRed",
                            LEAmount = 5.03m,
                            PBBuyerAtClosing=2.01m,
                            PBBuyerBeforeClosing=5.01m,
                            PBOthersForBuyer=3.01m,
                            PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.POC,
                            PBOthersForSeller=1.01m,
                            PBOthersForSellerPMTypeCdID=OtherPaymentMethods.POC,
                            PBSellerAtClosing=1.02m,
                            PBSellerBeforeClosing=2.03m,
                            SellerCharge = 4.06m,
                        },
                    },
                    #endregion
                },
                MortgageBroker = new MortgageBroker()
                {
                    #region CD
                    CDBrokerFee = new BrokerFee()
                    {
                        Description = "Check BrokerFeeNew",
                        FileCharge = 14.33m,
                        PaymentMethodTypeID = 2390
                    },
                    CDFutureRecordingFeescollectedbyMB = new CDChargePaymentDetails[]
                    {
                        new CDChargePaymentDetails()
                        {
                            AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            BuyerCharge=22.12m,
                            SeqNum=1
                        },
                    },
                    CDLenderCredits = new CDChargePaymentDetails[]
                    {
                        new CDChargePaymentDetails()
                        {
                            BuyerCredit=10.01m,
                            BuyerCreditPaymentMethodTypeCdID=CreditPaymentMethods.Lender,
                            SeqNum=1
                        },
                    },
                    CDMortgageBrokerCharges = new CDChargePaymentDetails[]
                    {
                        new CDChargePaymentDetails()
                        {
                            AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            BuyerCharge=22.05m,
                            Description="Check",
                            LEAmount = 5.03m,
                            PBBuyerAtClosing=10.01m,
                            PBOthersForBuyer=12.04m,
                            PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.POC,
                            PBOthersForSeller=3.01m,
                            PBOthersForSellerPMTypeCdID=OtherPaymentMethods.POCL,
                            PBSellerAtClosing=1.01m,
                            PBSellerBeforeClosing=5.01m,
                            SellerCharge = 9.03m,
                            SeqNum=1
                        },
                        new CDChargePaymentDetails()
                        {
                            AdhocFlag=1,
                            AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                            BuyerCharge=12.03m,
                            Description="Adhoc MortgageCharge",
                            LEAmount = 5.03m,
                            PBBuyerAtClosing=4.01m,
                            PBBuyerBeforeClosing=4.01m,
                            PBOthersForBuyer=4.01m,
                            PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.POC,
                            PBOthersForSeller=2.01m,
                            PBOthersForSellerPMTypeCdID=OtherPaymentMethods.POC,
                            PBSellerAtClosing=2.01m,
                            PBSellerBeforeClosing=2.01m,
                            SellerCharge = 6.03m,
                        },
                    },
                    #endregion
                    #region HUD
                    GFE3Charges = new GFELoanCharges[]
                    {
                        new GFELoanCharges
                        {
                            PaymentDetail = new PaymentDetailsWithGFEAndPOC
                            {
                                BuyerCharge = 22.22m,
                                BuyerPaymentMethodTypeID = 385,
                                SellerCharge = 21.12m,
                                SellerPaymentMethodTypeID = 385,
                                SeqNum = 40
                            }
                        }
                    },
                    MortgageBrokerCharges = new PaymentDetailsWithGFE[]
                    {
                        new PaymentDetailsWithGFE
                        {
                            BuyerCharge = 120.01m,
                        }
                    },
                    PayCharges = new PayCharge
                    {
                        DisbursementCharges = new DisbursementCharge[]
                        {
                            new DisbursementCharge
                            {
                                BuyerCharge = 100,
                                SeqNum = 40
                            }
                        }
                    },
                    YieldSpreadPremium = new YieldSpreadPremium
                    {
                        Description = "Test",
                        FileCharge = 5000.02m
                    },
                    #endregion
                    MorgageBrokerInformation = new FileBusinessParty()
                    {
                        AddrBookEntryID = 8835488
                    },
                },
                EmployeeID = 1,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        #region Subordination
        public static SubordinationRequest GetAddSubordinationRequest(int fileId)
        {
            return new SubordinationRequest
            {
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS",
                Subordination = new Subordination
                {
                    SeqNum = 1,
                    SubLender = new SubordinationLenderDetail
                    {
                        FileBusinessParty = new FileBusinessParty
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("BOA", Convert.ToInt32(AutoConfig.SelectedRegionBUID)),
                        },
                        Position = 1,
                        ResponsibleParty = "Nhat Nguyen",
                        LoanNumber = "1253.52",
                        LoanAmount = 1253.25m,
                        Page = "5",
                        SubOrdinationOrderDate = DateTime.Now,
                        SubRecordedDate = DateTime.Now,
                        AssignmentDate = DateTime.Now,
                        Instrument = "5",
                        Book = "Book"
                    }
                }
            };
        }

        public static SubordinationRequest GetUpdateSubordinationRequest(int fileId, SubordinationLenderDetail SubLender = null)
        {
            return new SubordinationRequest
            {
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS",
                Subordination = new Subordination
                {
                    SeqNum = 1,
                    SubLender = SubLender ?? new SubordinationLenderDetail
                    {
                        FileBusinessParty = new FileBusinessParty
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("BOA", Convert.ToInt32(AutoConfig.SelectedRegionBUID)),
                        },
                        Position = 1,
                        ResponsibleParty = "Carlos Parra",
                        LoanNumber = "1995.87",
                        LoanAmount = 1995.87m,
                        Page = "8",
                        SubOrdinationOrderDate = DateTime.Now.AddDays(2),
                        SubRecordedDate = DateTime.Now.AddDays(2),
                        AssignmentDate = DateTime.Now.AddDays(2),
                        Instrument = "2",
                        Book = "PDF Book"
                    }
                }
            };
        }

        public static DeleteSubordinationRequest GetDeleteSubordinationRequest(int fileId)
        {
            return new DeleteSubordinationRequest
            {
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS",
                SeqNum = 1
            };
        }

        public static SubordinationDetailsRequest GetSubordinationDetailsRequest(int fileId)
        {
            return new SubordinationDetailsRequest
            {
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS",
                SeqNum = 1
            };
        }

        public static SubordinationSummaryRequest GetSubordinationSummaryRequest(int fileId)
        {
            return new SubordinationSummaryRequest
            {
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }
        #endregion

        #region Deposit Outside Escrow

        public static DepositOutsideEscrowRequest GetDepositOERequest(int fileId)
        {
            return new DepositOutsideEscrowRequest
            {
                FileId = fileId,
                LoginName = AutoConfig.UserName,
                DepositOERequest = new DepositOutsideEscrowReq
                {
                    UserID = 1
                },
                Source = @"FAMOS"
            };
        }

        public static DepositOutsideEscrowSaveRequest GetCreateDepositOutSideEscrowRequest(int fileId)
        {
            return new DepositOutsideEscrowSaveRequest
            {
                FileId = fileId,
                LoginName = AutoConfig.UserName,
                CDDepositOESaveRequest = new CDDepositOutsideEscrow
                {
                    TotalAmount = 2500,
                    EarnestDeposits = new EarnestDeposit[]
                    {
                        new EarnestDeposit
                        {
                            EarnestAmount = 1200,
                            HolderEntityTypeCdID = 325,
                            HolderName = "test-name 1",
                            OutOfEscrowID = 1
                        },
                        new EarnestDeposit
                        {
                            EarnestAmount = 1300,
                            HolderEntityTypeCdID = 323,
                            HolderName = "test-name 2",
                            OutOfEscrowID = 1
                        }
                    },
                    UserID = 1
                },
                Source = @"FAMOS"
            };
        }

        public static DepositOutsideEscrowSaveRequest UpdateDepositOutSideEscrowRequest(int fileId)
        {
            return new DepositOutsideEscrowSaveRequest
            {
                FileId = fileId,
                LoginName = AutoConfig.UserName,
                CDDepositOESaveRequest = new CDDepositOutsideEscrow
                {
                    TotalAmount = 15432094625,
                    DistributionAmount = 15432094625,
                    DisbursedAsProceedsAmount = 500,
                    ExcessDepositAmount = 500,
                    UpdateFlag = true,
                    EarnestDeposits = new EarnestDeposit[]
                    {
                        new EarnestDeposit
                        {
                            EarnestAmount = 3086418725,
                            HolderEntityTypeCdID = 326,
                            HolderName = "TestName1",
                        },
                        new EarnestDeposit
                        {
                            EarnestAmount = 3086418725,
                            HolderEntityTypeCdID = 325,
                            HolderName = "TestName2",
                        },
                        new EarnestDeposit
                        {
                            EarnestAmount = 3086418725,
                            HolderEntityTypeCdID = 322,
                            HolderName = "TestName3",
                        },
                        new EarnestDeposit
                        {
                            EarnestAmount = 3086418725,
                            HolderEntityTypeCdID = 323,
                            HolderName = "TestName4",
                        },
                        new EarnestDeposit
                        {
                            EarnestAmount = 3086418725,
                            HolderEntityTypeCdID = 317,
                            HolderName = "TestName1",
                        }
                    },
                    UserID = 1
                },
                Source = @"FAMOS"
            };
        }

        #endregion

        #region Escrow Deposit
        public static AdjustEscrowDepositRequest GetAdjustEscrowDepositRequest(int fileId, int depositId)
        {
            return new AdjustEscrowDepositRequest
            {
                FileId = fileId,
                AdjustmentType = "edit",
                DepositAdjustment = new DepositAdjustment
                {
                    ReversalTransaction = new ReversalTransaction
                    {
                        AdjustmentDate = DateTime.Now,
                        AdjustmentReason = "653",
                        Description = "Change the amount of the deposit",
                        Comment = "All Good"
                    },
                    CorrectingTransaction = new CorrectingTransaction
                    {
                        Amount = 5558,
                        Description = "Change the amount of the deposit",
                        Comment = "None"
                    },
                    IssuedItem = new IssuedItem
                    {

                    }
                },
                Source = @"FAMOS",
                LoginName = AutoConfig.UserName,
                InEscrowID = depositId,
                UserId = 1
            };
        }

        public static DepositListDetailsRequest GetReadDepositListDetailsRequest(int DepositListID, string DepositBankAccID)
        {
            return new DepositListDetailsRequest
            {
                DepositListID = DepositListID,
                BankAcNumber = DepositBankAccID,
                BusinessUnitID = Convert.ToInt32(AutoConfig.SelectedRegionBUID),
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static DepositListSaveDetailsRequest GetSaveDepositListRequest()
        {
            return new DepositListSaveDetailsRequest
            {
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS",

            };
        }
        #endregion

        #region New Loan       
        public static AddLenderLoanInvestorRequest GetAddLenderLoanInvestorRequest(int fileID, int OrgLenderAddrBookID = 516787, int InvestorAddrBookID = 1256)
        {
            return new AddLenderLoanInvestorRequest
            {
                FileID = fileID,
                LoanNum = "0123456789",
                LenderLoanInvestor = new LenderLoanInvestor
                {
                    AddrBookEntryID = InvestorAddrBookID,
                    LenderLoanInvestorContacts = new LenderLoanInvestorContact[]
                    {
                        new LenderLoanInvestorContact
                        {
                            AddrBookEntryID = InvestorAddrBookID
                        }
                    }
                },
                OrgLoanInvestorAddrBookEntryID = OrgLenderAddrBookID,
                Source = "FAMOS",
                LoginName = AutoConfig.UserName
            };
        }

        public static LoanStatusRequest GetRestrictLenderUpdateStatusRequest(string fileNum, string LoanNum)
        {
            return new LoanStatusRequest
            {
                FileNum = fileNum,
                LoanNo = LoanNum,
                RegionID = Convert.ToInt32(AutoConfig.SelectedRegionBUID),
                Source = @"FAMOS",
                LoginName = AutoConfig.UserName,

            };
        }

        public static GFEDetailsRequest GetGFEDetailsRequest(int fileId)
        {
            return new GFEDetailsRequest
            {
                fileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static GFELoanRequest GetGFELoanRequest(int fileId)
        {
            return new GFELoanRequest
            {
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }
        #endregion

        public static HoldFundsSaveRequest GetCreateHoldFundsRequest(int fileId, int seqNum)
        {
            return new HoldFundsSaveRequest
            {
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS",
                SeqNum = seqNum,
                HoldFunds = new HoldFunds
                {
                    Reason = "Hold Test Reason",
                    Date = DateTime.Now.ToString(),
                    ReleaseIn = 10,
                    ReleaseDaysOn = DateTime.Now.AddDays(10).ToString(),
                    SellerCharge = 50000
                },
                HoldFundsDisbursement = new HoldFundsDisbursement[2]
                {
                    new HoldFundsDisbursement
                    {
                        HoldFundsDisbursementChargeList = new HoldFundsDisbursementChargeList[1]
                        {
                            new HoldFundsDisbursementChargeList
                            {
                                SellerCharge = 2500,
                                Description = "Test Entry 1"
                            }
                        },
                        HoldFundsFileBusinessParty = new HoldFundsFileBusinessParty
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("BOA", Convert.ToInt32(AutoConfig.SelectedRegionBUID))
                        },
                        SeqNum = 1
                    },
                    new HoldFundsDisbursement
                    {
                        HoldFundsDisbursementChargeList = new HoldFundsDisbursementChargeList[1]
                        {
                            new HoldFundsDisbursementChargeList
                            {
                                SellerCharge = 3500,
                                Description = "Test Entry 2"
                            }
                        },
                        HoldFundsFileBusinessParty = new HoldFundsFileBusinessParty
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("BOA", Convert.ToInt32(AutoConfig.SelectedRegionBUID))
                        },
                        SeqNum = 1
                    }
                }

            };
        }

        public static HoldFundsSaveRequest GetHoldFundsSaveRequest(int fileId, int seqNum, string gabCode = "BOA")
        {
            return new HoldFundsSaveRequest
            {
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS",
                SeqNum = seqNum,
                HoldFunds = new HoldFunds
                {
                    Reason = "Hold Test Reason",
                    Date = DateTime.Now.ToString(),
                    ReleaseIn = 10,
                    ReleaseDaysOn = DateTime.Now.AddDays(10).ToString(),
                    SellerCharge = 50000
                },
                HoldFundsDisbursement = new HoldFundsDisbursement[2]
                {
                    new HoldFundsDisbursement
                    {
                        HoldFundsDisbursementChargeList = new HoldFundsDisbursementChargeList[1]
                        {
                            new HoldFundsDisbursementChargeList
                            {
                                SellerCharge = 2500,
                                Description = "Test Entry 1"
                            }
                        },
                        HoldFundsFileBusinessParty = new HoldFundsFileBusinessParty
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId(gabCode, Convert.ToInt32(AutoConfig.SelectedRegionBUID))
                        },
                        SeqNum = 1
                    },
                    new HoldFundsDisbursement
                    {
                        HoldFundsDisbursementChargeList = new HoldFundsDisbursementChargeList[1]
                        {
                            new HoldFundsDisbursementChargeList
                            {
                                SellerCharge = 3500,
                                Description = "Test Entry 2"
                            }
                        },
                        HoldFundsFileBusinessParty = new HoldFundsFileBusinessParty
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId(gabCode, Convert.ToInt32(AutoConfig.SelectedRegionBUID))
                        },
                        SeqNum = 1
                    }
                }

            };
        }
        public static NewLoanPayChargeAssociationRequest GetNewLoanPayChargeAssociationRequest(int fileID, int seqNum, DisbursementCharge charge, PayChargeFileBusinessParty fileBusParty)
        {
            return new NewLoanPayChargeAssociationRequest()
            {
                EmployeeID = 1,
                FileID = fileID,
                SeqNum = seqNum,
                LoginName = AutoConfig.UserName,
                Source = "FAMOS",
                Target = "FAST",
                ChargeDetails = new NewLoanDisbursementCharge[]{
                   new NewLoanDisbursementCharge(){
                      ChargeId = charge != null ? charge.ChargeID : 0,
                      IsSelected = true,
                      AddressBookEntryId = fileBusParty != null ? fileBusParty.AddrBookEntryID : 0,
                   }
                },
                PayeeInformation = new NewLoanDisbursementPayeeInformation[]{
                    new NewLoanDisbursementPayeeInformation(){
                       eOperationType = OperationType.Update,
                       FileBusinessParty = new FileBusinessParty(){
                           FileBusinessPartyID = fileBusParty != null ? fileBusParty.FileBusinessPartyID : 0,
                       }
                    }
                },
            };
        }

        #region Insurance

        public static InsuranceRequest CreateInsuranceReq(int? fileID)
        {
            return new InsuranceRequest()
            {

                EmployeeID = 11345,
                InsuranceInformation = new InsuranceInformation()
                {
                    HazardInsuranceInformation = new FileBusinessParty()
                    {
                        BusOrgContact = new BusOrgContact()
                        {
                            ContactID = 8835368,
                        },
                    },

                    InsuranceAgentInformation = new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),
                    },

                    InsuranceCharges = new InsuCharges()
                    {

                        CDInsuranceChargesList = new CDChargePaymentDetails[]
                        {
                            new CDChargePaymentDetails()
                            {
                              BuyerCharge  =55555555555.15m,
                              SellerCharge=55555555555.15m,
                              SeqNum=1,

                            },
                        },

                    },

                    InsuranceDetails = new InsuranceDetails()
                    {
                        Premium = 1000.01m,
                        PremiumType = PremiumTypeCdID.Month,
                        Term = 5,
                    },

                    InsuranceType = InsuranceType.Others,
                    IssueCheckTo = CheckType.InsuranceAgent,
                    InsuranceTypeOthersSeqNum = 1,
                    Proration = new Proration()
                    {
                        Amount = 10000.01m,
                        AmountPeriod = DuePeriod.MONTH,
                        BasedOnDays = 365,
                        FromDateInclusive = true,
                        ProrationType = ProrationType.NONE,
                        ToDateInclusive = true,

                    },
                },


                LoginName = AutoConfig.UserName,
                Source = "FAMOS",
                FileID = fileID,

            };
        }

        public static ServiceFileRequest GetInsuranceDetailRequest(int? fileId)
        {
            return new ServiceFileRequest()
            {
                FileId = fileId,
                EmployeeObjectCD = "1",
                Target = "FAST",
                LoginName = AutoConfig.UserName,
                Source = "FAMOS"
            };
        }

        public static InsuranceRequest UpdateInsuranceReq(int? fileID)
        {
            return new InsuranceRequest()
            {

                EmployeeID = 11345,
                InsuranceInformation = new InsuranceInformation()
                {
                    HazardInsuranceInformation = new FileBusinessParty()
                    {
                        BusOrgContact = new BusOrgContact()
                        {
                            ContactID = 8835368,
                        },
                    },

                    InsuranceAgentInformation = new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                    },

                    InsuranceCharges = new InsuCharges()
                    {

                        CDInsuranceChargesList = new FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails[] {
                        EscrowRequestFactory.GetCDChargePaymentDetails(),
                    }

                    },

                    InsuranceDetails = new InsuranceDetails()
                    {
                        Premium = 1100.01m,
                        PremiumType = PremiumTypeCdID.Month,
                        Term = 5,
                    },


                    InsuranceType = InsuranceType.Others,
                    IssueCheckTo = CheckType.InsuranceAgent,
                    InsuranceTypeOthersSeqNum = 1,
                    Proration = new Proration()
                    {
                        Amount = 11000.01m,
                        AmountPeriod = DuePeriod.MONTH,
                        BasedOnDays = 360,
                        FromDateInclusive = true,
                        ProrationType = ProrationType.NONE,
                        ToDateInclusive = true,

                    },
                },


                LoginName = AutoConfig.UserName,
                Source = "FAMOS",
                FileID = fileID,

            };
        }

        #endregion

        #region Real Estate Agent Broker

        public static RealEstateBrokerRequest GetDefaultRequestForRealEstateBrokerAgentHUD(int? FileId, RealEstateBrokerType REBType)
        {
            return new RealEstateBrokerRequest()
            {
                EmployeeID = 1,
                FileID = FileId,
                LoginName = AutoConfig.UserName,
                Source = "FAMOS",
                Target = "FAST",

                RealEstateBrokerInformation = new RealEstateBrokerDetails()
                {
                    REBrokerInformation = new RealEstateBrokerInformation()
                    {
                        FBP = new FileBusinessParty()
                        {
                            AddrBookEntryID = 1234,
                            FileBusinessPartyID = 0,
                        },

                    },
                    REBrokerType = REBType,
                    CommissionChargeAmount = new ChargePaymentDetails()
                    {
                        BuyerCharge = 10,
                        BuyerCredit = 11,
                        SellerCharge = 12,
                        SellerCredit = 13,
                    },
                    REBrokerCharges = new ChargePaymentDetails[]{
                        new ChargePaymentDetails()
                    {
                        BuyerCharge = 14,
                        BuyerCredit = 15,
                        SellerCharge = 16,
                        SellerCredit = 17,
                    },

                    },
                    REBrokerCredits = new ChargePaymentDetails[]
                    {
                        new ChargePaymentDetails()
                    {
                        BuyerCharge = 18,
                        BuyerCredit = 19,
                        SellerCharge = 20,
                        SellerCredit = 21,
                    },
                    }

                },
            };
        }
        //
        public static RealEstateBrokerRequest GetDefaultRequestForRealEstateBrokerAgentCD(int? FileId, RealEstateBrokerType REBType)
        {
            return new RealEstateBrokerRequest()
            {
                EmployeeID = 1,
                FileID = FileId,
                LoginName = AutoConfig.UserName,
                Source = "FAMOS",
                Target = "FAST",
                RealEstateBrokerInformation = new RealEstateBrokerDetails()
                {
                    #region Charges
                    REBrokerInformation = new RealEstateBrokerInformation()
                    {
                        FBP = new FileBusinessParty()
                        {
                            AddrBookEntryID = GetFileBusinessParty("220").AddrBookEntryID
                        },

                    },
                    REBrokerType = REBType,
                    CDCommissionChargeAmount = new CDChargePaymentDetails()
                    {
                        AdhocFlag = 0,
                        Description = "Commission charge desc",
                        BuyerCharge = 10,
                        SellerCharge = 12,
                        SeqNum = 1,
                    },
                    CDREBrokerCharges = new CDChargePaymentDetails[]{
                        new CDChargePaymentDetails()
                    {
                        AdhocFlag=1,
                        Description="REBrokerCharge desc",
                        BuyerCharge = 14,
                        SellerCharge = 16,
                       SeqNum=1,
                    },
                    },
                    CommissionSummary = new CommissionSummary()
                    {
                        CommissionAmount = 2000,
                        CreditBuyerBrokerFlag = true,
                        CreditSellerBrokerFlag = true,
                        CreditBuyerBrokerAmt = 49,
                        CreditSellerBrokerAmt = 59,

                    },
                    #endregion
                    DisbSummaryFBP = new DisbursementSummaryFBP[]
                {
                new DisbursementSummaryFBP()
                {
                    CheckAmount=200,
                    FBP= new FileBusinessParty()
                    {
                        AddrBookEntryID= GetFileBusinessParty("230").AddrBookEntryID,
                    }
                },
            },
                },
            };
        }


        public static RealEstateBrokerRequest UpdateRequestForRealEstateBroker(int? FileId, RealEstateBrokerType REBType)
        {
            return new RealEstateBrokerRequest()
            {

                EmployeeID = 1,
                FileID = FileId,
                LoginName = AutoConfig.UserName,
                Source = "FAMOS",
                Target = "FAST",
                RealEstateBrokerInformation = new RealEstateBrokerDetails()
                {
                    SeqNum = 1,
                    #region Charges
                    REBrokerInformation = new RealEstateBrokerInformation()
                    {
                        FBP = new FileBusinessParty()
                        {
                            AddrBookEntryID = GetFileBusinessParty("220").AddrBookEntryID,
                        },

                    },
                    REBrokerType = REBType,
                    CDCommissionChargeAmount = new CDChargePaymentDetails()
                    {
                        AdhocFlag = 0,
                        Description = "Commission charge desc",
                        BuyerCharge = 11,
                        SellerCharge = 22,
                        SeqNum = 1,
                    },
                    CDREBrokerCharges = new CDChargePaymentDetails[]{
                        new CDChargePaymentDetails()
                    {
                        AdhocFlag=1,
                        Description="REBrokerCharge desc",
                        BuyerCharge = 33,
                        SellerCharge = 44,
                       SeqNum=1,
                    },
                    },
                    CommissionSummary = new CommissionSummary()
                    {
                        CommissionAmount = 2000,
                        CreditBuyerBrokerFlag = true,
                        CreditSellerBrokerFlag = true,
                        CreditBuyerBrokerAmt = 55,
                        CreditSellerBrokerAmt = 66,

                    },
                    #endregion
                    DisbSummaryFBP = new DisbursementSummaryFBP[]
                {
                new DisbursementSummaryFBP()
                {
                    CheckAmount=200,
                    FBP= new FileBusinessParty()
                    {
                        AddrBookEntryID= GetFileBusinessParty("230").AddrBookEntryID,
                    }
                },
            },
                },
            };
        }

        public static RealEstateBrokerRequest RemoveRequestForRealEstateBroker(int? FileId, RealEstateBrokerType REBType)
        {
            return new RealEstateBrokerRequest()
            {

                EmployeeID = 1,
                FileID = FileId,
                LoginName = AutoConfig.UserName,
                Source = "FAMOS",
                Target = "FAST",
                RealEstateBrokerInformation = new RealEstateBrokerDetails()
                {
                    SeqNum = 1,
                    REBrokerType = REBType,
                },
            };
        }
        #endregion

        public static SDNSearchRequest GetSDNSearchRequest(int fileId)
        {
            return new SDNSearchRequest
            {
                FileID = fileId,
                EmployeeObjectCD = "1",
                LoginName = AutoConfig.UserName,
                Source = "FAMOS"
            };
        }

        public static ExcludedReceiptLoadRequest GetExcludedReceiptLoadRequest(string buid = null, string fromDate = null, string toDate = null)
        {
            return new ExcludedReceiptLoadRequest
            {
                BusinessUnitID = buid ?? AutoConfig.SelectedRegionBUID,
                FromDate = fromDate ?? DateTime.Now.AddDays(-30).ToString("M-d-yyyy"),
                ToDate = toDate ?? DateTime.Now.ToString("M-d-yyyy"),
                EmployeeObjectCD = "1",
                LoginName = AutoConfig.UserName,
                Source = "FAMOS"
            };
        }

        public static DuplicateFileSearchRequest GetDuplicateFileSearchRequest()
        {
            return new DuplicateFileSearchRequest
            {
                BuyerInfo = new BuyerTypeInfo()
                {
                    Buyer1 = new PrincipalInfoWithBuyerType()
                    {
                        Type = BuyerType.Individual,
                        FirstName = "Bart",
                        LastName = "Simpson",
                        MiddleName = "",
                        SpouseFirstName = "",
                        SpouseMiddleName = "",
                        SpouseLastName = ""
                    },
                    Buyer2 = new PrincipalInfoWithBuyerType()
                    {
                        Type = BuyerType.HusbandWife,
                        FirstName = "Homer",
                        LastName = "Simpson",
                        MiddleName = "",
                        SpouseFirstName = "",
                        SpouseMiddleName = "",
                        SpouseLastName = ""
                    }
                },
                PropertyInfo = new PropertyInfo()
                {
                    PropertyAddressLine1 = "",
                    PropertyAddressLine2 = "",
                    PropertyAddressLine3 = "",
                    PropertyAddressLine4 = "",
                    PropertyCity = "Santa Ana",
                    PropertyCounty = "orange",
                    PropertyState = "CA",
                    PropertyZipCode = ""
                },
                RegionID = Convert.ToInt32(AutoConfig.SelectedRegionBUID),
                EmployeeObjectCD = "1",
                LoginName = AutoConfig.UserName,
                Source = "FAMOS",
                Target = "FAST"
            };
        }

        #region Work Queue
        public static WorkQueueUploadRequest GetUploadWorkQFileRequest(byte[] fileContent)
        {
            return new WorkQueueUploadRequest
            {
                File = new WorkQFileDetails
                {
                    Content = fileContent,
                    FileName = "test_document" + Support.RandomString("AzNZ"),
                    FileExtension = ".pdf"
                },
                QueueId = 1,
                EmployeeId = 1,
                EmployeeObjectCD = "1",
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static WorkQListRequest GetWorkQueueListRequest()
        {
            return new WorkQListRequest
            {
                DeleteOnlyFlag = false,
                QueueId = 1,
                EmployeeId = 1,
                EmployeeObjectCD = "1",
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static WorkQueueAttachRequest GetAttachMessageRequest(int fileId, int messageId)
        {
            return new WorkQueueAttachRequest
            {
                FileID = fileId,
                MessageID = messageId,
                WorkQueueTriggerID = 220,
                AdditionalInfo = "Additional Information",
                Comments = "Comments related",
                DocumentName = "Miscellaneous",
                DocumentType = 48,
                QueueID = 1,
                LoginName = AutoConfig.UserName,
                EmployeeID = 1,
                EmployeeObjectCD = "1",
                Source = @"FAMOS"
            };
        }

        public static WorkQueueUpdateRequest GetUpdateWorkQueueMessageRequest(int messageId, WorkQRequestType requestType)
        {
            return new WorkQueueUpdateRequest
            {
                LoginName = AutoConfig.UserName,
                EmployeeId = 1,
                EmployeeObjectCD = "1",
                RequestType = requestType,
                Source = @"FAMOS",
                UpdateDetails = new WorkQUpdateDetails[1]
                {
                    new WorkQUpdateDetails
                    {
                        Comment ="Updated Status Comment",
                        MessageId = messageId,
                        SourceQueueId = 1
                    }
                }
            };
        }

        public static WorkQMessageLogDetailsRequest GetWorkQueueMessageLogDetailsRequest(int messageId)
        {
            return new WorkQMessageLogDetailsRequest
            {
                EmployeeId = 1,
                EmployeeObjectCD = "1",
                LoginName = AutoConfig.UserName,
                MessageID = messageId,
                QueueId = 1,
                Source = @"FAMOS"
            };
        }

        public static DocumentTypeRequest GetWorkQueueTriggersRequest()
        {
            return new DocumentTypeRequest
            {
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS",
                EmployeeObjectCD = "1"
            };
        }

        public static DocumentTypeRequest GetDocumentTypeRequest()
        {
            return new DocumentTypeRequest
            {
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS",
                EmployeeObjectCD = "1"
            };
        }

        public static WorkQueueNameRequest GetWorkQueueNamesRequest()
        {
            return new WorkQueueNameRequest
            {
                EmployeeId = 1,
                EmployeeObjectCD = "1",
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static WorkQueueMessageRequest GetWorkQueueMessageDocumentRequest(int messageId)
        {
            return new WorkQueueMessageRequest
            {
                EmployeeId = 1,
                EmployeeObjectCD = "1",
                LoginName = AutoConfig.UserName,
                MessageId = messageId,
                QueueId = 1,
                Source = @"FAMOS"
            };
        }
        #endregion

        public static GetHUDEscrowChargeRequest GetHUDEscrowChargeRequest(int fileId, Filter filter)
        {
            return new GetHUDEscrowChargeRequest
            {
                FileId = fileId,
                Filter = filter,
                EmployeeObjectCD = "1",
                LoginName = AutoConfig.UserName,
                Source = "FAMOS"
            };
        }

        public static Hud1LineNumberRequest GetHud1LineNumberRequest(int fileId, Hud1Charges charges)
        {
            return new Hud1LineNumberRequest
            {
                FileID = fileId,
                Hud1LineNumbers = charges,
                EmployeeID = 1,
                EmployeeObjectCD = "1",
                LoginName = AutoConfig.UserName,
                Source = "FAMOS"
            };
        }

        public static ALTASettlementStatementRequest GetALTASettlementStatementRequest(int fileID)
        {
            return new ALTASettlementStatementRequest
            {
                FileID = fileID,
                EmployeeObjectCD = "1",
                LoginName = AutoConfig.UserName,
                Source = "FAMOS",
                Target = "FAST"
            };
        }

        public static OTCRequest GetDeleteOutsideTitleCompanyRequest(int fileID, int seqNum)
        {
            return new OTCRequest
            {
                FileID = fileID,
                OTCInformation = new OTCInformation
                {
                    SeqNum = seqNum
                },
                LoginName = AutoConfig.UserName,
                EmployeeObjectCD = "1",
                EmployeeID = 1,
                Source = "FAMOS",
            };
        }

        public static FileBalanceSummaryRequest GetFileBalanceSummaryRequest(int? fileId)
        {
            return new FileBalanceSummaryRequest
            {
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static DepositListSearchRequest SearchDepositListRequest()
        {
            return new DepositListSearchRequest
            {
                StartingDate = DateTime.Now.ToString("M/d/yyyy"),
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS",
                BankAccount = "2529",
                BuisnessUnitID = "1487"

            };
        }
    }
}
