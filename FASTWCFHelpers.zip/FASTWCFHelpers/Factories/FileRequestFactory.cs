﻿using FASTWCFHelpers.DataObjects;
using FASTWCFHelpers.FastFileService;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Diagnostics;

namespace FASTWCFHelpers.Factories
{
    public class FileRequestFactory : RequestFactory
    {
        public static File Create(FastFile fileTemplate)
        {
            var newFile = new File();

            newFile.TransactionTypeObjectCD = fileTemplate.TransactionTypeObjectCD;
            newFile.BusinessSegmentObjectCD = fileTemplate.BusinessSegmentObjectCD;
            newFile.ExternalFileNumber = fileTemplate.ExternalFileNumber;
            newFile.AutoNumberIndicator = fileTemplate.AutoNumberIndicator;
            newFile.BusinessParties = fileTemplate.BusinessParties;
            newFile.Services = fileTemplate.Services;
            newFile.Properties = fileTemplate.Properties;
            newFile.Buyers = fileTemplate.Buyers;
            newFile.Sellers = fileTemplate.Sellers;
            newFile.NewLoan = fileTemplate.NewLoan;

            Debug.Print("Created File from File Factory");
            return newFile;
        }

        #region MiscellaneousDisbutrsement

        public static NewMiscDisbusementRequest CreateNewMiscDisbusementRequest(int? fileId)
        {
            return new NewMiscDisbusementRequest()
            {

                FileID = fileId,
                Source = "FAMOS",
                EmployeeID = 11345,
                SeqNum = 1,
                FileBusinessParty = new FileBusinessParty()
                {

                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),

                    BusOrgContact = new BusOrgContact()
                    {
                        ContactName = "Tester",
                        EditContactName = true,
                        EditElectronicAddress = true,
                    },

                    ElectronicAddress = new ElectronicAddress()
                    {
                        Cellular = "1234512345",
                        Enddated = false,
                    },


                },

                MiscDisbCDPaymentDetails = new CDChargePaymentDetails[]
               {
                   new CDChargePaymentDetails()
                   {
                       AdhocFlag=0,
                      AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.CHK,
                      AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.CHK,
                      BuyerCharge=122.04m,
                      Description="TestCD",
                      LEAmount=14.02m,
                      PBBuyerAtClosing=100.02m,
                      PBBuyerBeforeClosing=22.02m,
                      PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.None,
                      PBOthersForSeller=10.01m,
                      PBOthersForSellerPMTypeCdID=OtherPaymentMethods.POC,
                      PBSellerAtClosing=10.01m,
                      PBSellerBeforeClosing=20.02m,
                      SellerCharge=40.04m,
                      SeqNum=1,

                   },

                   new CDChargePaymentDetails()
                   {
                        AdhocFlag=1,
                      AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.CHK,
                      AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.CHK,
                      BuyerCharge=60.06m,
                      Description="AdhocCD",
                      LEAmount=33.68m,
                      PBBuyerAtClosing=30.02m,
                      PBBuyerBeforeClosing=20.02m,
                      PBOthersForBuyer=10.02m,
                      PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.POC,

                      PBSellerAtClosing=22.01m,
                      PBSellerBeforeClosing=22.01m,
                      SellerCharge=44.02m,
                      SeqNum=2,
                   },


               },




            };
        }

        public static NewMiscDisbusementRequest CreateNewMiscDisbusementRequestCheckOnly(int? fileId)
        {
            return new NewMiscDisbusementRequest()
            {

                FileID = fileId,
                Source = "FAMOS",
                EmployeeID = 11345,
                SeqNum = 1,
                FileBusinessParty = new FileBusinessParty()
                {

                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId("248"),

                    BusOrgContact = new BusOrgContact()
                    {
                        ContactName = "Tester",
                        EditContactName = true,
                        EditElectronicAddress = true,
                    },

                    ElectronicAddress = new ElectronicAddress()
                    {
                        Cellular = "1234512345",
                        Enddated = false,
                    },

                },

                NonBuyerSellerCharge = new NonBuyerSellerCharge()
                {
                    Description = "Checkonly",
                    Amount = 100,
                }

            };
        }

        public static NewMiscDisbusementRequest UpdateMiscDisbusementRequest(int? fileId)
        {
            return new NewMiscDisbusementRequest()
            {

                FileID = fileId,
                Source = "FAMOS",
                EmployeeID = 11345,
                SeqNum = 1,
                FileBusinessParty = new FileBusinessParty()
                {

                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),

                    BusOrgContact = new BusOrgContact()
                    {
                        ContactName = "Tester",
                        EditContactName = true,
                        EditElectronicAddress = true,
                    },

                    ElectronicAddress = new ElectronicAddress()
                    {
                        Cellular = "1234512345",
                        Enddated = false,
                    },


                },

                MiscDisbCDPaymentDetails = new CDChargePaymentDetails[]
               {
                   new CDChargePaymentDetails()
                   {
                       AdhocFlag=0,
                      AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.CHK,
                      AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.CHK,
                      BuyerCharge=122.04m,
                      Description="Update_TestCD",
                      LEAmount=14.02m,
                      PBBuyerAtClosing=100.02m,
                      PBBuyerBeforeClosing=22.02m,
                      PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.None,
                      PBOthersForSeller=10.01m,
                      PBOthersForSellerPMTypeCdID=OtherPaymentMethods.POC,
                      PBSellerAtClosing=10.01m,
                      PBSellerBeforeClosing=20.02m,
                      SellerCharge=40.04m,
                      SeqNum=1,

                   },

                   new CDChargePaymentDetails()
                   {
                        AdhocFlag=1,
                      AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.CHK,
                      AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.CHK,
                      BuyerCharge=60.06m,
                      Description="Update_AdhocCD",
                      LEAmount=33.68m,
                      PBBuyerAtClosing=30.02m,
                      PBBuyerBeforeClosing=20.02m,
                      PBOthersForBuyer=10.02m,
                      PBOthersForBuyerPMTypeCdID=OtherPaymentMethods.POC,

                      PBSellerAtClosing=22.01m,
                      PBSellerBeforeClosing=22.01m,
                      SellerCharge=44.02m,
                      SeqNum=2,
                   },
               },
            };
        }

        public static NewMiscDisbusementRequest UpdateMiscDisbusementRequestCheckOnly(int? fileId)
        {
            return new NewMiscDisbusementRequest()
            {

                FileID = fileId,
                Source = "FAMOS",
                EmployeeID = 11345,
                SeqNum = 1,
                FileBusinessParty = new FileBusinessParty()
                {

                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId("242"),

                    BusOrgContact = new BusOrgContact()
                    {
                        ContactName = "Tester",
                        EditContactName = true,
                        EditElectronicAddress = true,
                    },

                    ElectronicAddress = new ElectronicAddress()
                    {
                        Cellular = "1234512345",
                        Enddated = false,
                    },

                },

                NonBuyerSellerCharge = new NonBuyerSellerCharge()
                {
                    Description = "Update_Checkonly",
                    Amount = 200,
                }

            };
        }

        public static DeleteMiscDisbRequest GetDeleteMiscDisbRequest(int? fileId)
        {

            return new DeleteMiscDisbRequest()
            {

                FileID = fileId,
                Source = @"FAMOS",
                SeqNum = 1,
                EmployeeID = 1,

            };
        }
        #endregion

        #region PayoffLoan
        public static PayoffLoanRequest GetDefaultPayoffLoanRequestWithCharge(String fileId)
        {
            #region CreatePayOffLoanRequestWithCharge

            return new PayoffLoanRequest()
            {
                FileID = int.Parse(fileId),
                PayOffLenderAddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                PayOffLenderOrigPrincipalBal = 400.01m,
                LoanTypeCdID = 667,

                CDInterestCalculationSummary = new CDPayOffLoanInterestChargeset[]
                {

                    new CDPayOffLoanInterestChargeset()
                    {
                        InterestType = 433,
                        PerDiemFlag = 1,
                        PerDiemAmount = 10.02m,
                        CalendarBaseDays = 365,
                        FromDate = DateTime.Now.ToUniversalTime(),
                        ToDate = DateTime.Now.ToUniversalTime().AddDays(10),
                        ToDateInclusive = 1,
                        FromDateInclusive = 0,
                        Description = "Interest on Payoff Loan",
                        SeqNum = 1,

                    CDChargePaymentDetails = new CDChargePaymentDetails()
                       {
                        AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        Description = "Interest on Payoff Loan",
                        BuyerCharge = 9.03m,
                        BuyerCredit = 5.01m,
                        PBBuyerAtClosing = 2.01m,
                        PBBuyerBeforeClosing = 3.01m,
                        PBOthersForBuyer = 4.01m,
                        PBOthersForSeller = 4.01m,
                        PBSellerAtClosing = 100.20m,
                        PBSellerBeforeClosing = 3.01m,
                        SellerCharge = 107.22m,
                        SellerCredit = 5.01m,
                        LEAmount = 10.01m,
                       }
                    }
                },

                CDLoanCharges = new CDChargePaymentDetails()
                {
                    AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                    AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                    PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                    PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                    Description = "Principal Balance",
                    BuyerCharge = 9.03m,
                    BuyerCredit = 4.12m,
                    PBBuyerAtClosing = 2.01m,
                    PBBuyerBeforeClosing = 3.01m,
                    PBOthersForBuyer = 4.01m,
                    PBOthersForSeller = 4.01m,
                    PBSellerAtClosing = 2.01m,
                    PBSellerBeforeClosing = 3.01m,
                    SellerCharge = 9.03m,
                    SellerCredit = 10.30m,
                    LEAmount = 10.01m,
                },

                CDPayoffLoanCharges = new CDChargePaymentDetails[]
                {
                    new CDChargePaymentDetails()
                    {
                        AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        Description = "Statement/Forwarding Fee",
                        BuyerCharge = 9.03m,
                        BuyerCredit = 5.01m,
                        PBBuyerAtClosing = 2.01m,
                        PBBuyerBeforeClosing = 3.01m,
                        PBOthersForBuyer = 4.01m,
                        PBOthersForSeller = 4.01m,
                        PBSellerAtClosing = 2.01m,
                        PBSellerBeforeClosing = 3.01m,
                        SellerCharge = 9.03m,
                        SellerCredit = 5.01m,
                        LEAmount = 10.01m,
                        SeqNum = 1,
                    },

                    new CDChargePaymentDetails()
                    {
                        AdhocFlag = 1,
                        AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        Description = "Adhoc",
                        BuyerCharge = 9.03m,
                        BuyerCredit = 5.01m,
                        PBBuyerAtClosing = 2.01m,
                        PBBuyerBeforeClosing = 3.01m,
                        PBOthersForBuyer = 4.01m,
                        PBOthersForSeller = 4.01m,
                        PBSellerAtClosing = 2.01m,
                        PBSellerBeforeClosing = 3.01m,
                        SellerCharge = 9.03m,
                        SellerCredit = 5.01m,
                        LEAmount = 10.01m,
                        SeqNum = 9,
                    }
                },
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
            #endregion
        }

        public static PayoffLoanRequest GetUpdatePayoffLoanRequestWithCharge(String fileId)
        {
            #region UpdatePayOffLoanRequestWithCharge

            return new PayoffLoanRequest()
            {
                FileID = int.Parse(fileId),
                PayOffLenderAddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"),

                PayOffLenderOrigPrincipalBal = 500.05m,
                LoanTypeCdID = 667,

                CDInterestCalculationSummary = new CDPayOffLoanInterestChargeset[]
                {
                    new CDPayOffLoanInterestChargeset()
                    {
                        InterestType = 433,
                        PerDiemFlag = 1,
                        PerDiemAmount = 15.02m,
                        CalendarBaseDays = 360,

                        FromDate =DateTime.Now.ToUniversalTime(),
                        ToDate = DateTime.Now.ToUniversalTime().AddDays(8),
                        ToDateInclusive = 1,
                        FromDateInclusive = 1,
                        Description = "Interest on Payoff Loan",
                        SeqNum = 1,

                    CDChargePaymentDetails = new CDChargePaymentDetails()
                       {
                        AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        Description = "Interest on Payoff Loan",
                        BuyerCharge = 10.06m,
                        BuyerCredit = 4.01m,
                        PBBuyerAtClosing = 3.02m,
                        PBBuyerBeforeClosing = 3.02m,
                        PBOthersForBuyer = 4.02m,
                        PBOthersForSeller = 7.02m,
                        PBSellerAtClosing = 8.02m,
                        PBSellerBeforeClosing = 5.02m,
                        SellerCharge = 20.06m,
                        SellerCredit = 4.01m,
                        LEAmount = 30.15m,
                       }
                    }
                },

                CDLoanCharges = new CDChargePaymentDetails()
                {
                    AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                    AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                    PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                    PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                    Description = "Principal Balance",
                    BuyerCharge = 20.06m,
                    BuyerCredit = 5.01m,
                    PBBuyerAtClosing = 5.02m,
                    PBBuyerBeforeClosing = 4.02m,
                    PBOthersForBuyer = 11.02m,
                    PBOthersForSeller = 4.02m,
                    PBSellerAtClosing = 6.02m,
                    PBSellerBeforeClosing = 10.02m,
                    SellerCharge = 20.06m,
                    SellerCredit = 8.01m,
                    LEAmount = 100.01m,
                },
                CDPayoffLoanCharges = new CDChargePaymentDetails[]
                {
                    new CDChargePaymentDetails()
                    {
                        AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        Description = "Statement/Forwarding Fee",
                        BuyerCharge = 19.06m,
                        BuyerCredit = 8.01m,
                        PBBuyerAtClosing = 4.02m,
                        PBBuyerBeforeClosing = 5.02m,
                        PBOthersForBuyer = 10.02m,
                        PBOthersForSeller = 4.02m,
                        PBSellerAtClosing = 5.02m,
                        PBSellerBeforeClosing = 10.02m,
                        SellerCharge = 19.06m,
                        SellerCredit = 5.01m,
                        LEAmount = 50.01m,
                        SeqNum = 1,
                    },

                    new CDChargePaymentDetails()
                    {
                        AdhocFlag = 1,
                        AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                        BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                        PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        Description = "Adhoc",
                        BuyerCharge = 25.12m,
                        BuyerCredit = 8.01m,
                        PBBuyerAtClosing = 8.04m,
                        PBBuyerBeforeClosing = 7.04m,
                        PBOthersForBuyer = 10.04m,
                        PBOthersForSeller = 8.04m,
                        PBSellerAtClosing = 10.04m,
                        PBSellerBeforeClosing = 7.04m,
                        SellerCharge = 25.12m,
                        SellerCredit = 7.01m,
                        LEAmount = 10.01m,
                        SeqNum = 9,
                    }
                },

                LoginName = AutoConfig.UserName,
                Source = @"FAMOS",
                SeqNum = 1
            };
            #endregion
        }

        public static PayoffLoanRequest GetPayOffLoanRequest(int? fileId, int? seqNum)
        {
            #region CreatePayOffLoanRequest
            return new PayoffLoanRequest()
            {
                CDInterestCalculationSummary = GetCDPayOffLoanInterestChargesetList(),
                CDLoanCharges = GetCDChargePaymentDetails(),
                CDPayoffLoanCharges = GetCDChargePaymentDetailsList(),
                FileID = fileId,
                GoodThroughDate = DateTime.Today.AddDays(28),
                InstrumentNumber = "1",
                LenderAttentionContacID = AdminService.GetGABByAddressBookEntryID(415).GABContactID,
                LoanTypeCdID = 668,
                LoginName = AutoConfig.UserName,
                PayOffLenderAddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"),
                PayOffLenderOrigPrincipalBal = 1500000,
                RecordedBook = "1",
                RecordedBookPageNumber = "1",
                RecordingDate = DateTime.Today,
                SeqNum = seqNum,
                Source = "FAMOS",
                TrustDeedDate = DateTime.Today,
                TrusteeAddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"),
                TrusteeAttentionContacID = AdminService.GetGABByAddressBookEntryID(415).GABContactID
            };
            #endregion
        }

        public static PayoffLoanRequest GetPayoffLoanRequest(int fileId, int lenderID)
        {
            return new PayoffLoanRequest()
            {
                FileID = fileId,
                GoodThroughDate = DateTime.Today.AddDays(28),
                LoanTypeCdID = 667,
                LoginName = AutoConfig.UserName,
                PayOffLenderAddrBookEntryID = AdminService.GetGABByAddressBookEntryID(lenderID).GABAddrBookEntryID,
                RecordedBook = "1",
                RecordedBookPageNumber = "1",
                RecordingDate = DateTime.Today.AddDays(7),
                RestrictDemandUpdates = 0,
                SeqNum = 1,
                Source = "FAMOS",
            };
        }

        public static CDPayOffLoanInterestChargeset[] GetCDPayOffLoanInterestChargesetList()
        {
            return new CDPayOffLoanInterestChargeset[]
                {
                    new CDPayOffLoanInterestChargeset(){
                        AnnualInterestRate = 2,
                        CDChargePaymentDetails = GetCDChargePaymentDetails(),
                        CalendarBaseDays = 365,
                        Description = "test-interest-charge",
                        FromDate = DateTime.Today,
                        FromDateInclusive = 1,
                        InterestType = 433,
                        PerDiemAmount = 0,
                        PerDiemFlag = 0,
                        SeqNum = 1,
                        ToDate = DateTime.Today.AddDays(28),
                        ToDateInclusive = 1,
                        TotalInterest = 0,
                    }
                };
        }

        public static CDChargePaymentDetails GetCDChargePaymentDetails()
        {
            return new CDChargePaymentDetails()
            {
                AdditionalDescription = "test-description",
                AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                BuyerCharge = (decimal)1000000,
                BuyerCredit = (decimal)1000000,
                BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                LEAmount = (decimal)999999.99,
                PBBuyerAtClosing = (decimal)900000.00,
                PBBuyerBeforeClosing = (decimal)99999.99,
                PBOthersForBuyer = (decimal)0.01,
                PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                SellerCharge = (decimal)1000000,
                SellerCredit = (decimal)1000000,
                SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                PBSellerAtClosing = (decimal)900000.00,
                PBSellerBeforeClosing = (decimal)99999.99,
                PBOthersForSeller = (decimal)0.01,
                PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                PartOf = false,
                SeqNum = 1,
                eSectionShop = FASTWCFHelpers.FastFileService.SectionsShoppedFor.None,
            };
        }

        public static CDChargePaymentDetails[] GetCDChargePaymentDetailsList()
        {
            return new CDChargePaymentDetails[] { GetCDChargePaymentDetails() };
        }
        public static PayoffLoanRequest RemovePaoffLoanRequest(string fileId)
        {
            return new PayoffLoanRequest()
            {
                FileID = int.Parse(fileId),
                Source = "famous",
                LoginName = AutoConfig.UserName,
                SeqNum = 1,

            };
        }

        public static PayoffLoanRequest GetInitiatePayoffRequest(int fileId, int seqNum)
        {
            return new PayoffLoanRequest
            {
                FileID = fileId,
                LoanTypeCdID = 669,
                PayOffLenderOrigPrincipalBal = 99579.99m,
                GoodThroughDate = DateTime.Now,
                PayOffLenderAddrBookEntryID = AdminService.GetGABAddressBookEntryId("1254", Convert.ToInt32(AutoConfig.SelectedRegionBUID)),
                PayOffLenderReference = "123456789",
                //CDLoanCharges = new CDChargePaymentDetails
                //{
                //    AdditionalDescription = "test-description",
                //    AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                //    AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                //    BuyerCharge = (decimal)1000000,
                //    BuyerCredit = (decimal)1000000,
                //    BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                //    LEAmount = (decimal)999999.99,
                //    PBBuyerAtClosing = (decimal)900000.00,
                //    PBBuyerBeforeClosing = (decimal)99999.99,
                //    PBOthersForBuyer = (decimal)0.01,
                //    PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                //    SellerCharge = (decimal)1000000,
                //    SellerCredit = (decimal)1000000,
                //    SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                //    PBSellerAtClosing = (decimal)900000.00,
                //    PBSellerBeforeClosing = (decimal)99999.99,
                //    PBOthersForSeller = (decimal)0.01,
                //    PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                //    PartOf = false,
                //    SeqNum = 1,
                //    eSectionShop = FASTWCFHelpers.FastFileService.SectionsShoppedFor.None,
                //},
                //CDInterestCalculationSummary = new CDPayOffLoanInterestChargeset[]
                //{
                //    new CDPayOffLoanInterestChargeset
                //    {
                //        AnnualInterestRate = 2,
                //        CDChargePaymentDetails = GetCDChargePaymentDetails(),
                //        CalendarBaseDays = 365,
                //        Description = "test-interest-charge",
                //        FromDate = DateTime.Today,
                //        FromDateInclusive = 1,
                //        InterestType = 433,
                //        PerDiemAmount = 0,
                //        PerDiemFlag = 0,
                //        SeqNum = 1,
                //        ToDate = DateTime.Today.AddDays(28),
                //        ToDateInclusive = 1,
                //        TotalInterest = 0,
                //    }
                //},
                //CDPayoffLoanCharges = new CDChargePaymentDetails[]
                //{
                //    new CDChargePaymentDetails
                //    {
                //        AdditionalDescription = "Additional Desc - test",
                //        AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                //        AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.CHK,
                //        BuyerCharge = (decimal)120.35,
                //        BuyerCredit = (decimal)120.25,
                //        BuyerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                //        LEAmount = (decimal)250.00,
                //        PBBuyerAtClosing = (decimal)500.00,
                //        PBBuyerBeforeClosing = (decimal)99999.99,
                //        PBOthersForBuyer = (decimal)0.01,
                //        PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                //        SellerCharge = (decimal)152.25,
                //        SellerCredit = (decimal)130.50,
                //        SellerCreditPaymentMethodTypeCdID = FASTWCFHelpers.FastFileService.CreditPaymentMethods.AtClosing,
                //        PBSellerAtClosing = (decimal)250.00,
                //        PBSellerBeforeClosing = (decimal)250.99,
                //        PBOthersForSeller = (decimal)0.01,
                //        PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                //        PartOf = false,
                //        SeqNum = 1,
                //        eSectionShop = FASTWCFHelpers.FastFileService.SectionsShoppedFor.None,
                //    }
                //},
                //BeneficiaryMortgagee = "Beneficiary-Mortgage test",
                //TrusteeAddrBookEntryID = AdminService.GetGABAddressBookEntryId("247", Convert.ToInt32(AutoConfig.SelectedRegionBUID)),
                //TrustDeedDate = DateTime.Now,
                //RecordingDate = DateTime.Now,
                LoginName = AutoConfig.UserName,
                EmployeeObjectCD = "1",
                SeqNum = seqNum,
                Source = @"FAMOS"
                
            };
        }

        #endregion

        #region Delivery
        public static EmailDeliveryRequest GetEmailDeliveryRequest(int fileId, DocumentList[] documentList, string senderEmail, FastFileService.DocumentFormat format, TOList[] toList)
        {
            return new EmailDeliveryRequest
            {
                FileID = fileId,
                Documents = documentList,
                SenderEmail = senderEmail,
                eFormat = format,
                TOs = toList,
                Source = "FAMOS"
            };
        }

        public static FaxDeliveryRequest GetFaxDeliveryRequest(int fileId, DocumentList[] documentList, string senderName, FaxRecipientList[] toList)
        {
            return new FaxDeliveryRequest
            {
                FileID = fileId,
                Documents = documentList,
                SenderName = senderName,
                FaxRecipients = toList,
                Source = "FAMOS"
            };
        }

        public static Hud1DeliveryRequest GetHud1StatementDeliveryRequest(int fileId, string senderEmail, FastFileService.DocumentFormat format, TOList[] toList, string subject = null)
        {
            return new Hud1DeliveryRequest
            {
                FileID = fileId,
                eDeliveryMethod = DeliveryMethod.Email,
                eHUDStatementType = HUDStatementType.HUD_1,
                EmailDeliveryRequest = new EmailDelivery
                {
                    BuyerSignatures = false,
                    Message = "Test",
                    MiscTextSignatures = false,
                    SellerSignatures = false,
                    SenderEmail = senderEmail,
                    Subject = subject ?? "Test email delivery for HUD1 Statement [WCF]",
                    eFormat = format,
                    TOs = toList
                },
                clientFormat = new ClientFormat
                {
                    Combined = true,
                },
                Source = "FAMOS"
            };
        }

        public static InvoiceFeesDeliveryRequest GetInvoiceFeesDeliveryRequest(int fileId, int invoiceId, string senderEmail, FastFileService.DocumentFormat format, TOList[] toList, string subject = null)
        {
            return new InvoiceFeesDeliveryRequest
            {
                FileID = fileId,
                InvoiceID = invoiceId,
                eDeliveryMethod = DeliveryMethod.Email,
                EmailDeliveryRequest = new EmailDelivery
                {
                    BuyerSignatures = false,
                    Message = "Test",
                    MiscTextSignatures = false,
                    SellerSignatures = false,
                    SenderEmail = senderEmail,
                    Subject = subject ?? "Test email delivery for HUD1 Statement [WCF]",
                    eFormat = format,
                    TOs = toList
                },
                EmployeeID = 1,
                Source = "FAMOS"
            };
        }

        public static WintrackDeliveryRequest GetWintrackDeliveryRequest(int? fileID, DocumentList[] documents)
        {
            return new WintrackDeliveryRequest()
            {
                Documents = documents,
                EmployeeID = 1,
                FileID = fileID,
                Source = @"FAMOS"
            };
        }

        public static FastWebDeliveryRequest GetFastWebDeliveryRequest(int? fileID, DocumentList[] documents)
        {
            return new FastWebDeliveryRequest()
            {
                Documents = documents,
                EmployeeID = 1,
                FileID = fileID,
                Source = @"FAMOS"
            };
        }
        #endregion

        #region Property / Tax Info
        public static RemovePropertyAddressRequest GetRemovePropertyAddressRequest(int fileId, int propertyAddrSeqNum, int propertyTaxSeqNum)
        {
            return new RemovePropertyAddressRequest
            {
                FileID = fileId,
                PropertyAddressSeqNum = propertyAddrSeqNum,
                PropertyTaxSeqNum = propertyTaxSeqNum,
                Source = "FAMOS",
                UpdatedEmployeeID = "1",
            };
        }

        public static RemovePropertyRequest GetRemovePropertyRequest(int fileId, int seqNum)
        {
            return new RemovePropertyRequest
            {
                FileID = fileId,
                SeqNum = seqNum,
                LoginName = AutoConfig.UserName,
                Source = "FAMOS"
            };
        }
        public static LACOMDeliveryRequest GetLACOMDeliveryRequest(int? fileID, DocumentList[] documents)
        {
            return new LACOMDeliveryRequest()
            {
                Documents = documents,
                EmployeeID = 1,
                FileID = fileID,
                Source = @"FAMOS"
            };
        }

        public static PropertyAddressRequest GetNewPropertyAddressRequest(int fileId, int propertySeqNum, string addressLine1)
        {
            return new PropertyAddressRequest()
            {
                FileID = fileId,
                PropertyTaxSeqNum = propertySeqNum,
                AddrLine1 = addressLine1,
                AddrLine2 = "Address2",
                AddrLine3 = "Address3",
                AddrLine4 = "Address4",
                State = "CA",
                City = "ALBANY",
                County = "ALAMEDA",
                UpdatedEmployeeID = "1",
                Source = "FAMOS",
            };
        }

        public static CopyPropertyAddressRequest GetCopyPropertyAddressRequest(int fileId, int fromSeqNum, int propertyTaxSeqNum)
        {
            return new CopyPropertyAddressRequest
            {
                FileID = fileId,
                CopyFromSequenceNo = fromSeqNum,
                PropertyTaxSeqNum = propertyTaxSeqNum,
                Source = "FAMOS",
                UpdatedEmployeeID = "1",
            };
        }

        #endregion

        #region ActiveDisbursementSummaryWS
        public static DisbursementEditDetailsRequest DisbursementEditDetailsRequest(int fileId, int disbursementId)
        {
            return new DisbursementEditDetailsRequest()
            {

                FileId = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS",
                DisbursementId = disbursementId,
            };
        }

        #endregion

        #region Signature Signing
        public static DeliverSigningPackageRequest GetDeliverSigningPackageRequest(int fileId, int signingID)
        {
            return new DeliverSigningPackageRequest()
            {
                FileID = fileId,
                SigningID = signingID,
                EmployeeID = 1,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static UpdateSignatureSigningRequest GetUpdateSignatureSigningRequest(int fileId, int signingID)
        {
            return new UpdateSignatureSigningRequest()
            {
                SignatureSigningDetail = new SigningDetail
                {
                    FileID = fileId,
                    SigningID = signingID
                },
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS",
            };
        }

        public static SigningDetailRequest GetSigningDetailRequest(int fileId, int signingID, SigningFASSNotary notaryService, string source = "FAMOS", SigningCancellationReason signingCancellationReason = SigningCancellationReason.None, SigningQuality signingQuality = SigningQuality.None)
        {
            return new SigningDetailRequest()
            {
                FileID = fileId,
                SigningID = signingID,
                eSigningFASSNotaryService = notaryService,
                eSigningCancellationReason = signingCancellationReason,
                eSigningQuality = signingQuality,
                //LoginName = AutoConfig.UserName,
                Source = source
            };
        }
        #endregion

        public static GFELoanRequest GetGFELoanRequest(int fileId)
        {
            return new GFELoanRequest
            {
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static HUDStatementRequest GetHUDStatementRequest(int fileId)
        {
            return new HUDStatementRequest
            {
                FileID = fileId,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }
        public static AddProductionOfficeRequest GetAddProductionOfficeRequest(int fileId, int productionOfficeID, int serviceTypeCdID)
        {
            return new AddProductionOfficeRequest
            {
                FileID = fileId,
                ProductionOfficeID = productionOfficeID,
                ServiceTypeCdID = serviceTypeCdID,
                LoginName = AutoConfig.UserName,
                EmployeeObjectCD = "1",
                Source = "FAMOS",
                Target = "FAST"
            };
        }

        public static RemoveProductionOfficeRequest GetRemoveProductionOfficeRequest(int fileId, int productionOfficeID, int serviceTypeCdID)
        {
            return new RemoveProductionOfficeRequest
            {
                FileID = fileId,
                ProductionOfficeID = productionOfficeID,
                ServiceTypeCdID = serviceTypeCdID,
                LoginName = AutoConfig.UserName,
                EmployeeObjectCD = "1",
                Source = "FAMOS",
                Target = "FAST"
            };
        }

        public static GABRequest GetModifyGABRequest(int fileID, int regionID, string name1, int addrBookEntryID, int employeeID, string source, int processTypeCdID, int seqNum)
        {
            return new GABRequest
            {
                /*FileID, AddrBookEntryID, EmployeeID, Source, BuyerSellerTypeCdID, EntityTypeID, Name1, PhysicalAddress (AddrLine1, City, State, Country) , RegionID, ProcessTypeCdID and SeqNum*/
                FileID = fileID,
                RegionID = regionID,
                AddrBookEntryID = addrBookEntryID,
                EmployeeID = employeeID,
                Source = source,
                ProcessTypeCDID = processTypeCdID,
                SeqNum = seqNum,
                GABentryRequest = new GABEntryRequest { Name1 = name1 }

            };
        }

        public static GABRequest GetCreateGABRequest(int fileID, int employeeID, string source, int buyerSellerTypeCdID, int entityTypeID, string name1, int physicalAddrTypeCdID, string addressLine1, string city, string state, string country, int regionID, int processTypeCdID, int seqNum)
        {
            return new GABRequest
            {
                /*: FileID, , Source , EmployeeID, BuyerSellerTypeCdID, EntityTypeID, Name1, PhysicalAddress (AddrLine1, City, State, Country), RegionID and ProcessTypeCdID*/
                FileID = fileID,
                EmployeeID = employeeID,
                Source = source,
                ProcessTypeCDID = processTypeCdID,
                RegionID = regionID,
                SeqNum = seqNum,
                GABentryRequest = new GABEntryRequest
                {
                    BuyerOrSellerTypeCdID = buyerSellerTypeCdID,
                    EntityTypeID = entityTypeID,
                    Name1 = name1

                },
                PhysicalAddresses = new PhysicalAddressWithID[]
                {
                    new PhysicalAddressWithID
                    {
                        PhyAddressTypeCdID = physicalAddrTypeCdID,
                        AddrLine1 = addressLine1,
                        City = city,
                        State = state,
                        Country = country
                    }
                }

            };
        }

        public static ExchangeCompanyRequest GetExchangeCompanyRequest(int fileId, int buyerOrSellerFileBusinessPartyID, FileBusinessParty businessParty)
        {
            return new ExchangeCompanyRequest
            {
                FileID = fileId,
                BuyerOrSellerFileBusinessPartyID = buyerOrSellerFileBusinessPartyID,
                FileBusinessParty = businessParty
            };
        }

        public static FileSearchRequest GetFileSearchRequest(DateTime dateFrom, DateTime dateTo, string employeeName = null, string fileNumber = null, string otherParties = null, int? otherPartyTypeID = null, string principalName = null, string propertyAPNTaxNo = null, string propertyCountry = null, string propertyCounty = null, string propertyLot = null, string propertyName = null, string propertyParcelNo = null, string propertyState = null, string propertStreetName = null, string propertySubdivision = null, string propertyTractNo = null, int? regionID = null, int? withinMonths = null, EmployeeType employeeType = EmployeeType.Any, FileActionDate fileActionDate = FileActionDate.OpenedDate, FileStatus fileStatus = FileStatus.Any, FileType fileType = FileType.FileNo, PrincipalSource principalSource = PrincipalSource.Any, PrincipalType principalType = PrincipalType.Any)
        {
            return new FileSearchRequest
            {
                DateFrom = dateFrom,
                DateTo = dateTo,
                EmployeeName = employeeName,
                FileNumber = fileNumber,
                OtherParties = otherParties,
                OtherPartyTypeID = otherPartyTypeID,
                PrincipalName = principalName,
                PropertyAPNTaxNo = propertyAPNTaxNo,
                PropertyCountry = propertyCountry,
                PropertyCounty = propertyCounty,
                PropertyLot = propertyLot,
                PropertyName = propertyName,
                PropertyParcelNo = propertyParcelNo,
                PropertyState = propertyState,
                PropertyStreetName = propertStreetName,
                PropertySubdivision = propertySubdivision,
                PropertyTractNo = propertyTractNo,
                RegionID = regionID,
                WithinMonths = withinMonths,
                eEmployeeType = employeeType,
                eFileActionDate = fileActionDate,
                eFileStatus = fileStatus,
                eFileType = fileType,
                ePrincipalSource = principalSource,
                ePrincipalType = principalType
            };
        }

        public static FileNotesRequest GetFileNotesRequest(int FileID)
        {
            return new FileNotesRequest()
            {
                FileID = FileID,
                Comments = "Test Comment",
                CreateEmployeeName = "FAST QA07",
                CreatedEmployeeID = 86208,
                Note = "Test Note",
                TypeCdID = 21,
                CreationDate = DateTime.Now
            };
        }

        public static AlertOrReminderRequest GetAlertOrReminderRequest(int fileID, int visibilityType, DateTime notifyDate)
        {
            return new AlertOrReminderRequest()
            {
                FileID = fileID,
                NotifyDate = notifyDate,
                Note = "Reminder Message",
                VisibilityTypeCDID = visibilityType,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        public static SearchFileRequest GetSearchFileRequest(DateTime fromDate, DateTime toDate, int regionID, bool localCloseOrderFlag = false, FileStatus fileStatus = FileStatus.Any, ServiceType serviceType = ServiceType.None)
        {
            return new SearchFileRequest()
            {
                FromDate = fromDate,
                ToDate = toDate,
                RegionID = regionID,
                LocalCloseOrderFlag = localCloseOrderFlag,
                eFileStatus = fileStatus,
                eServiceType = serviceType
            };
        }

        public static ReserveFileNumberRequest GetReserveFileNumberRequest(int userID, int officeID, int regionID, string comment = null)
        {
            return new ReserveFileNumberRequest()
            {
                UserID = userID,
                OfficeID = officeID,
                RegionID = regionID,
                Comments = comment
            };
        }

        public static SearchInstructionsRequest GetSearchInstructionsRequest(int businessUnitID)
        {
            return new SearchInstructionsRequest()
            {
                BusinessUnitID = businessUnitID
            };
        }

        public static FastSearchRequest GetFastSearchRequest(int fileID, int propertyTaxSeqNum = 1, string source = "famos", string updatedEmployeeID = "1")
        {
            return new FastSearchRequest()
            {
                FileID = fileID,
                PropertyTaxSeqNum = propertyTaxSeqNum,
                Source = source,
                UpdatedEmployeeID = updatedEmployeeID
            };
        }

        public static StarterRefRequest GetStarterRefCopyRequest(string starterFile, string targetFile)
        {
            return new StarterRefRequest
            {
                RegionID = Convert.ToInt32(AutoConfig.SelectedRegionBUID),
                SelectAllItemsFlag = true,
                StarterFileNum = starterFile,
                TargetFileNum = targetFile,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS",
                EmployeeObjectCD = "1"
            };
        }

        public static OrderSummaryRequest GetOrderSummaryRequest(int fileId)
        {
            return new OrderSummaryRequest
            {
                FileID = fileId
            };
        }

        public static SetProjectFileRequest GetSetProjectFileRequest(int projectFileID, int siteFileID, string source = "famos", string target = null, string employeeObjectCD = null)
        {
            return new SetProjectFileRequest
            {
                ProjectFileID = projectFileID,
                SiteFileID = siteFileID,
                Source = source, 
                Target = target, 
                EmployeeObjectCD = employeeObjectCD
            };
        }

        public static NotificationRequest GetNotificationRequest(int fileID, int? clientTypeCdID = null, string source = null, string target = null, string employeeObjectCD = null)
        {
            return new NotificationRequest
            {
                FileID = fileID,
                ClientTypeCdID = clientTypeCdID,
                Source = source,
                Target = target,
                EmployeeObjectCD = employeeObjectCD
            };
        }

        public static DeArchiveFileRequest GetDeArchiveFileRequestt(int fileID, string source = "famos", string loginName = null, string target = null, string employeeObjectCD = null)
        {
            return new DeArchiveFileRequest
            {
                FileID = fileID,
                Source = source,
                Target = target,
                EmployeeObjectCD = employeeObjectCD,
                LoginName = loginName
            };
        }

        public static TriggerATPReviewRequest GetTriggerATPReviewRequest(int fileID, string source = "famos", string loginName = null, string target = null, string employeeObjectCD = null)
        {
            return new TriggerATPReviewRequest
            {
                FileID = fileID,
                Source = source,
                Target = target,
                EmployeeObjectCD = employeeObjectCD,
                LoginName = loginName
            };
        }

        public static TriggerTaskEventRequest GetTriggerTaskEventRequest(int fileID, int taskEventID, int taskOfficeID, string source = "famos")
        {
            return new TriggerTaskEventRequest
            {
                FileID = fileID,
                Source = source,
                TaskEventID = taskEventID,
                TaskOfficeID = taskOfficeID,
            };
        }

        public static AddProcessRequest GetAddProcessRequest(int fileID, int officeID, int processEventID, int processTriggerEventID, string source = "famos")
        {
            return new AddProcessRequest
            {
                FileID = fileID,
                Source = source,
                OfficeID = officeID,
                ProcessEventID = processEventID,
                ProcessTriggerEventID = processTriggerEventID,
            };
        }

        public static GetHudRequest GetHudRequest(int fileID, FastFileService.DocumentFormat format, string source = "famos")
        {
            return new GetHudRequest
            {
                Hud1DeliveryRequest = new Hud1DeliveryRequest
                {
                    clientFormat = new ClientFormat
                    {
                        BuyerOrBorrowerNumOfCopies = 0,
                        BuyerOrBorrowerOnly = false,
                        BuyerOrBorrowerSignature = false,
                        Combined = false,
                        CombinedNumOfCopies = 0,
                        CombinedSignature = false,
                        SellerNumOfCopies = 0,
                        SellerOnly = false,
                        SellerSignature = false
                    },
                    EmailDeliveryRequest = new EmailDelivery
                    {
                        eFormat = format
                    },
                    FileID = fileID
                },
                Source = source
            };
        }

        public static InterfaceOrderRequest GetInterfaceOrderRequest(int fileID, int orderTypeCdID)
        {
            return new InterfaceOrderRequest
            {
                FileID = fileID,
                OrderTypeCdId = orderTypeCdID
            };
        }
    }
}
