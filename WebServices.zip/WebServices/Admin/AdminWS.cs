﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastAdminService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using WebServices.Helpers.Admin;

namespace WebServices.Admin
{
    [CodedUITest]
    public partial class AdminWS : MasterTestClass
    {
        [TestMethod]
        public void REG0001_GetStates()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify GetStates() service method";

                Reports.TestStep = "Log into FAST ADM application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

                Reports.TestStep = "Invoke GetStates service";
                var request = AdminService.GetStates();

                Reports.TestStep = "Navigate to Address Book Search";
                FastDriver.AddressBookSearch.Open();

                Reports.TestStep = "Validate the response from web service with the ui";
                Support.AreEqual(request.States.Count().ToString(), (FastDriver.AddressBookSearch.State.FAGetDropdownOptions().Count-1).ToString(), "Validate");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0002_GetLicenseTypes()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify GetLicenseTypes() service";

                Reports.TestStep = "Log into FAST ADM application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

                Reports.TestStep = "Invoke the GetLicenseTypes service method";
                int state = AdminHelpers.GetStateId("CA");
                var getLicenseRequest = AdminRequestFactory.GetLicenseTypesRequest(state);
                var getLicenseResponse = AdminService.GetLicenseTypes(getLicenseRequest);
                getLicenseResponse.Validate();

                Reports.TestStep = "Navigate to Address Book screen and click new button";
                FastDriver.AddressBookSearch.Open().ClickNew().WaitForScreenToLoad();

                Reports.TestStep = "Click on New button in the License Information section";
                FastDriver.BusinessPartyOrganizationSetUp.LicenseInformationNew.FAClick();
                FastDriver.LicenseInformationDlg.WaitForScreenToLoad();

                Reports.TestStep = "Select state: 'CA'";
                FastDriver.LicenseInformationDlg.State.FASelectItem("CA");

                Reports.TestStep = "Validate the response from web service with State License Type dropdown content";
                Support.AreEqual("NMLS", getLicenseResponse.States.First().LicenseTypeDescription.ToString(), "Validate NMLS license type exists");
                Support.AreEqual(getLicenseResponse.States.Count(m => m.LicenseTypeDescription != "NMLS").ToString(), (FastDriver.LicenseInformationDlg.StateLicenseType.FAGetDropdownOptions().Count - 1).ToString(), "Validate");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0003_GetOfficeAddresses()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                int busUnitID = 1487;
                #endregion

                Reports.TestDescription = "Verify GetOfficeAddresses() service method";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

                Reports.TestStep = "Invoke GetOfficeAddresses service";
                var getOfficeAddrRequest = AdminService.GetOfficeAddress(busUnitID);

                Reports.TestStep = "Navigate to Business Unit > Office Setup";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>"+getOfficeAddrRequest.BusUnits[0].ObjectCD);
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                Reports.TestStep = "Validate the data in the UI with the response from Web Service";
                Support.AreEqual(getOfficeAddrRequest.BusUnits[0].ObjectCD, FastDriver.OfficeSetupOffice.OfficeCode.FAGetText(), "Office Code");
                Support.AreEqual(getOfficeAddrRequest.BusUnits[0].Name, FastDriver.OfficeSetupOffice.OfficeName.FAGetValue(), "Office Name");
                Support.AreEqual(getOfficeAddrRequest.OfficeAddresses.Count().ToString(), FastDriver.OfficeSetupOffice.TableAddress.GetRowCount().ToString(), "Office Addresses");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0004_GetProducts()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var productsCount = 0;
                #endregion

                Reports.TestDescription = "Verify GetProducts() service method";

                Reports.TestStep = "Log into FAST ADM application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

                Reports.TestStep = "Invoke GetProducts service";
                var productsRequest = AdminService.GetAllProducts();

                Reports.TestStep = "Navigate to Products Setup screen";
                FastDriver.ProductSetup.Open();

                Reports.TestStep = "Get the count of all the products in the UI";
                productsCount += FastDriver.ProductSetup.OwnerTable.GetRowCount();

                FastDriver.ProductSetup.LenderPolicies.FAClick();
                FastDriver.ProductSetup.WaitForScreenToLoad(FastDriver.ProductSetup.LenderTable);
                productsCount += FastDriver.ProductSetup.LenderTable.GetRowCount();

                FastDriver.ProductSetup.OtherProducts.FAClick();
                FastDriver.ProductSetup.WaitForScreenToLoad(FastDriver.ProductSetup.OtherTable);
                productsCount += FastDriver.ProductSetup.OtherTable.GetRowCount();

                FastDriver.ProductSetup.Guarantees.FAClick();
                FastDriver.ProductSetup.WaitForScreenToLoad(FastDriver.ProductSetup.GuaranteesTable);
                productsCount += FastDriver.ProductSetup.GuaranteesTable.GetRowCount();

                Reports.TestStep = "Verify the product's count in the UI is the same as the web service response";
                Support.AreEqual(productsRequest.Products.Count().ToString(), productsCount.ToString(), "Validate");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0005_GetOffices()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify GetOffices() service method";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

                Reports.TestStep = "Invoke GetOffices service";
                var officesRequest = AdminService.GetOffices(Convert.ToInt32(AutoConfig.SelectedRegionBUID), eActiveOrHiddenOffice.Active);
                Support.IsTrue(officesRequest.BusUnits != null, "Validate response");

                Reports.TestStep = "Navigate to Business Unit > Offices";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices");
                FastDriver.OfficeSummary.WaitForScreenToLoad(FastDriver.OfficeSummary.OfficeSummaryTable);

                Reports.TestStep = "Verify the data in the UI with the response from web service";
                Support.AreEqual(officesRequest.BusUnits.Count().ToString(), (FastDriver.OfficeSummary.OfficeSummaryTable.GetRowCount() - 1).ToString(), "Validate the count of offices in the ui is same from web services");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0006_GetCountries()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify GetCountries() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

                Reports.TestStep = "Navigate to Address Book.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.New.FAClick();
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();

                Reports.TestStep = "Invoke GetCountries request.";
                var countriesList = AdminService.GetCountries();

                FastDriver.BusinessPartyOrganizationSetUp.AddressesNew.FAClick();
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();

                Reports.TestStep = "Validate GetCountries succeeded.";
                Support.AreEqual((FastDriver.BusinessPartyOrganizationSetUp.Country.FAGetDropdownOptions().Count - 1).ToString(), countriesList.Count.ToString(), "Validating event for GetCountries");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0007_GetCounties()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify GetCounties() service.";

                Reports.TestStep = "Invoke GetCounties request.";
                var countiesList = AdminService.GetCounties(6);

                Reports.TestStep = "Validate GetCounties succeeded.";
                Support.AreEqual("58", countiesList.Counties.Length.ToString(), "Validating event for GetCountries");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0008_GetCanadaProvinces()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify GetCountries() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

                Reports.TestStep = "Navigate to Address Book.";
                FastDriver.LeftNavigation.Navigate<AddressBookSearch>("Home>System Maintenance>Address Book").WaitForScreenToLoad();
                FastDriver.AddressBookSearch.New.FAClick();
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();

                Reports.TestStep = "Invoke GetCanadaProvinces request.";
                var canadaProvinces = AdminService.GetCanadaProvinces();

                Reports.TestStep = "Change Country to Canada in Address Book.";
                FastDriver.BusinessPartyOrganizationSetUp.AddressesNew.FAClick();
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();
                FastDriver.BusinessPartyOrganizationSetUp.Country.FASelectItem("CANADA");
                FastDriver.BusinessPartyOrganizationSetUp.WaitForScreenToLoad();

                var provincesDropDown = FastDriver.BusinessPartyOrganizationSetUp.State.FAGetDropdownOptions();
                Reports.TestStep = "Validate GetCanadaProvinces succeeded.";
                Support.AreEqual((provincesDropDown.Count - 1).ToString(), canadaProvinces.Provinces.Count.ToString(), "Validating event for GetCanadaProvinces");

                for (int i = 0; i < provincesDropDown.Count - 1; i++)
                {
                    Support.AreEqual(provincesDropDown[i + 1].Text.Clean(), canadaProvinces.Provinces[i].ObjectCD, "Validating Canada Provinces matches web service response");
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG_0009GetCities()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify GetCities() service.";

                Reports.TestStep = "Invoke GetCities request.";
                var citiesList = AdminService.GetCities(1);

                Reports.TestStep = "Validate GetCities succeeded.";
                Support.AreEqual("54", citiesList.Cities.Length.ToString(), "Validating event for GetCities");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0010_SearchGABorGABContact()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify SearchGABorGABContact() service.";

                Reports.TestStep = "Invoke SearchGABorGABContact request.";
                var gabSearchResponse = AdminService.GABSearch(AdminRequestFactory.GetGABSearchRequest(1486, "BOA"));

                Reports.TestStep = "Validate SearchGABorGABContact succeeded.";
                Support.AreEqual("8836375", gabSearchResponse.GABResults[0].GABAddrBookEntryID.ToString().Clean());
                Support.AreEqual("BOA", gabSearchResponse.GABResults[0].GABCode.Clean());
                Support.AreEqual("Bank of America", gabSearchResponse.GABResults[0].Name1.Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0011_GetGABDetails()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify GetGABDetails() service.";

                Reports.TestStep = "Invoke SearchGABorGABContact request.";
                var gabSearchResponse = AdminService.GABSearch(AdminRequestFactory.GetGABSearchRequest(1486, "BOA"));

                Reports.TestStep = "Invoke GetGABDetails request.";
                var gabDetailResponse = AdminService.GetGABDetails(gabSearchResponse.GABResults[0].GABAddrBookEntryID.GetValueOrDefault(), GABType.Parent);
                gabDetailResponse.Validate();

                Reports.TestStep = "Validate GetGABDetails succeeded.";
                Support.AreEqual("8836375", gabDetailResponse.GABDetails[0].AddressBookID.ToString().Clean());
                Support.AreEqual("BOA", gabDetailResponse.GABDetails[0].GABIDCode.Clean());
                Support.AreEqual("Bank of America", gabDetailResponse.GABDetails[0].EntityName.Name1.Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0012_GetRegions()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var corporateID = 1; //1 for FIRSTAM; 
                #endregion

                Reports.TestDescription = "Verify GetRegions() service method";

                Reports.TestStep = "Log into FAST ADM application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

                Reports.TestStep = "Invoke GetRegions service";
                var request = AdminService.GetRegions(corporateID);
                Support.IsTrue(request.BusUnits != null, "Validate response");

                Reports.TestStep = "Navigate to Business Unit > FIRSTAM > Proc. Regions";
                FastDriver.LeftNavigation.Navigate<ProcessingRegionSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions");
                FastDriver.ProcessingRegionSummary.WaitForScreenToLoad(FastDriver.ProcessingRegionSummary.RegionSummaryTable);

                Reports.TestStep = "Validate the data in the ui match with the response from web service";
                var tableText = FastDriver.ProcessingRegionSummary.RegionSummaryTable.FAGetText();
                foreach (var region in request.BusUnits)
                {
                    Support.IsTrue(tableText.Contains(region.BusinessUnitID.ToString()), string.Format("Validate the office with id: {0} is in the table results", region.BusinessUnitID));
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0013_GetRegionByOffice()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify GetRegionByOffice() service methd";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

                Reports.TestStep = "Invoke GetRegionByOffice service";
                Reports.StatusUpdate(AutoConfig.SelectedOfficeBUID, true);
                var request = AdminRequestFactory.GetRegionByOfficeRequest(Convert.ToInt32(AutoConfig.SelectedOfficeBUID));
                var response = AdminService.GetRegionByOffice(request);
                response.Validate();

                Reports.TestStep = "Validate the data from the web service";
                Support.AreEqual(response.RegionName, AutoConfig.SelectedRegionName, "Verify: the office name from the response match with selected office");
                Support.AreEqual(response.RegionID.ToString(), AutoConfig.SelectedRegionBUID, "Verify: the office id from the response match with selected office");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0014_GetSalesReps()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify GetSalesReps() service method";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

                Reports.TestStep = "Invoke GetSalesReps service";
                var request = AdminService.GetSalesReps(Convert.ToInt32(AutoConfig.SelectedRegionBUID));
                request.OperationResponse.Validate();

                Reports.TestStep = "Navigate to Employee Setup";
                FastDriver.EmployeeSearch.Open();

                Reports.TestStep = "Search for all employees inside region 1486";
                FastDriver.EmployeeSearch.SearchEmployee(
                    new EmployeeSearchParameters
                    {
                        FirstName = "*",
                        Region = "QA Automation Region - DO NOT TOUCH"
                    }
                );

                Reports.TestStep = "Validate the response from web service match with data in the ui";
                foreach (var employee in request.Employees)
                {
                    Support.AreEqual(true, FastDriver.EmployeeSearch.SearchResultsEmployees.FAGetText().Contains(employee.LoginName), "Each employee exists in the results table");
                }

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0015_GetProgramTypes()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify GetProgramTypes() service method";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

                Reports.TestStep = "Invoke GetProgramTypes service";
                var request = AdminService.GetProgramTypes(Convert.ToInt32(AutoConfig.SelectedRegionBUID));
                Support.IsTrue(request != null, "Validate response");

                Reports.TestStep = "Navigate to Program Type under Program Setup";
                FastDriver.ProgramTypeSetup.Open();

                Reports.TestStep = "Validate the response from web service match with the data in the ui";
                Support.AreEqual(request.ProgramTypes.Count().ToString(), (FastDriver.ProgramTypeSetup.Table.GetRowCount() - 1).ToString(), "Verify: the count of program types match with web service response");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0016_GetEmployeeByEmployeeID()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var employeeID = 0;
                var resultText = string.Empty;
                #endregion

                Reports.TestDescription = "Verify GetEmployeeByEmployeeID() service method";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

                Reports.TestStep = "Invoke GetEmployeeByLoginName service";
                var EmployeeByLoginRequest = AdminService.GetEmployeeByLoginName(AutoConfig.UserName);
                Support.IsTrue(EmployeeByLoginRequest != null, "Validate the response");
                employeeID = EmployeeByLoginRequest.EmployeeID.Value;

                Reports.TestStep = "Invoke GetEmployeeByEmployeeID service";
                var request = AdminService.GetEmployeeByEmployeeID(employeeID);
                Support.IsTrue(request != null, "Validate the response");

                Reports.TestStep = "Navigate to Employee Setup";
                FastDriver.EmployeeSearch.Open();

                Reports.TestStep = "Search for the employee selected";
                FastDriver.EmployeeSearch.SearchEmployee(
                    new EmployeeSearchParameters
                    {
                        FirstName = request.FirstName,
                        LastName = request.LastName,
                        Region = AutoConfig.SelectedRegionName,
                        LoginName = request.LoginName
                    }
                );

                Reports.TestStep = "Validate the data on the screen with the response from web service";
                resultText = FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(2, 1, TableAction.GetText).Message.Clean();
                Support.AreEqual(request.LoginName, resultText.Substring(1, resultText.Count() - 2), "Verify: Login Name match in the ui with the response from ws");
                Support.AreEqual(string.Format("{0} {1}", request.FirstName, request.LastName), FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(2, 2, TableAction.GetText).Message.Clean(), "Verify: User Name (First and Last Name) match in the ui with the response from ws");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0017_SearchEmployeeByType()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify SearchEmployeeByType() service method";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

                Reports.TestStep = "Invoke SearchEmployeeByType service";
                var employeeID = AdminService.GetEmployeeByLoginName(AutoConfig.UserName).EmployeeID.Value;

                var request = AdminRequestFactory.GetSearchEmployeeByTypeRequest(employeeID);
                var response = AdminService.SearchEmployeeByType(request);
                response.OperationResponse.Validate();

                Reports.TestStep = "Navigate to Employee Setup";
                FastDriver.EmployeeSearch.Open();

                Reports.TestStep = "Search for the employee selected";
                FastDriver.EmployeeSearch.SearchEmployee(
                    new EmployeeSearchParameters
                    {
                        Region = AutoConfig.SelectedRegionName,
                        LoginName = AutoConfig.UserName
                    }
                );

                Reports.TestStep = "Validate the data on the screen with the response from web service";
                Support.AreEqual(string.Format("{0} {1}", response.SearchEmployees[0].FirstName, response.SearchEmployees[0].LastName), FastDriver.EmployeeSearch.SearchResultsEmployees.PerformTableAction(2, 2, TableAction.GetText).Message.Clean(), "Verify: User Name (First and Last Name) match in the ui with the response from ws");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0018_GetOfficeBankAccountsByOfficeID()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var officeID = Convert.ToInt32(AutoConfig.SelectedOfficeBUID);
                #endregion

                Reports.TestDescription = "Verify GetOfficeBankAccountsByOfficeID() service method";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

                Reports.TestStep = "Invoke GetOfficeAddresses service";
                var getOfficeAddrRequest = AdminService.GetOfficeAddress(officeID);

                Reports.TestStep = "Invoke GetOfficeBankAccountsByOfficeID service";
                var request = AdminRequestFactory.GetOfficeBankAccountsByOfficeIDRequest(officeID);
                var response = AdminService.GetOfficeBankAccountsByOfficeID(request);
                response.Validate();

                Reports.TestStep = "Navigate to Business Unit > Office Setup";
                FastDriver.LeftNavigation.Navigate<OfficeSetupOffice>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>" + getOfficeAddrRequest.BusUnits[0].ObjectCD);
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                Reports.TestStep = "Click on Bank Accounts tab";
                FastDriver.OfficeSetupOffice.BankAccountsMenu.FAClick();
                FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad();

                Reports.TestStep = "Validate the data in the ui with the response from Web Service";
                Support.AreEqual(response.BankAccountDetailsColl.Count().ToString(), FastDriver.OfficeSetupBankAccounts.BanksTable.GetRowCount().ToString(), "Validate");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0019_GetTaskCategoriesByRegionID()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify GetTaskCategoriesByRegionID() service method";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

                Reports.TestStep = "Invoke GetTaskCategoriesByRegionID service";
                var request = AdminService.GetTaskCategoriesByRegionID(Convert.ToInt32(AutoConfig.SelectedRegionBUID));
                Support.IsTrue(request != null, "Validate response");

                Reports.TestStep = "Navigate to Task Templates screen";
                FastDriver.TaskTemplateSelection.Open();

                Reports.TestStep = "Validate the response from web service match with data in the ui (categories section)";
                Support.IsTrue(request.TaskCategories.Count() == FastDriver.TaskTemplateSelection.Categories.GetRowCount() - 1, "Response count categories match with ui categories");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0020_GetTaskTemplatesByCategoryID()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify GetTaskTemplatesByCategoryID() service method";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");

                Reports.TestStep = "Invoke GetTaskCategoriesByRegionID service";
                var category = AdminService.GetTaskCategoriesByRegionID(Convert.ToInt32(AutoConfig.SelectedRegionBUID)).TaskCategories[3];
                Support.IsTrue(category != null, "Validate response");

                Reports.TestStep = "Invoke GetTaskTemplatesByCategoryID service";
                var request = AdminService.GetTaskTemplatesByCategoryID(category.ID.Value);
                Support.IsTrue(request != null, "Validate response");

                Reports.TestStep = "Navigate to Task Templates screen";
                FastDriver.TaskTemplateSelection.Open();

                Reports.TestStep = "Select the category";
                FastDriver.TaskTemplateSelection.Categories.PerformTableAction(2, category.Name, 1, TableAction.Click);
                FastDriver.TaskTemplateSelection.WaitForScreenToLoad(FastDriver.TaskTemplateSelection.TasksForTable);

                Reports.TestStep = "Validate the response from web service match with data in the ui ('task for' section)";
                Support.AreEqual(category.Name, FastDriver.WebDriver.FAFindElement(ByLocator.Id, "lblCategoryTask").FAGetText(), "Task For sectin label");
                Support.AreEqual(request.TaskTemplates.Count().ToString(), FastDriver.TaskTemplateSelection.TasksForTable.GetRowCount().ToString(), "Validate the elements in the response match with elements in the ui");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0021_GetWorkFlowTemplates()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify GetWorkFlowTemplates() service method";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("189");

                Reports.TestStep = "Invoke GetWorkFlowTemplates service";
                var request = AdminService.GetWorkFlowTemplates(189, (int) AdminHelpers.webCustomerTypeCDID.FASTWEB);
                Support.IsTrue(request.WFTemplates != null, "Validate response");

                Reports.TestStep = "Navigate to Regional Process Summary";
                FastDriver.RegionalProcessSummary.Open();

                Reports.TestStep = "Validate the response from web service with data in the ui";
                foreach (var template in request.WFTemplates)   
                {
                    Support.AreEqual(template.Name, FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, template.Name, 1, TableAction.GetText).Message.Clean(), "Validate WFTemplate is in the table");
                }
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0022_GetTaskTemplates()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify GetTaskTemplates() service method";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("189");

                Reports.TestStep = "Invoke GetWorkFlowTemplates service";
                var WFTemplateID = AdminService.GetWorkFlowTemplates(189, (int)AdminHelpers.webCustomerTypeCDID.FASTWEB).WFTemplates[1].WorkFlowTemplateID;
                Support.IsTrue(WFTemplateID != null, "Validate response");

                Reports.TestStep = "Invoke GetTaskTemplates service";
                var taskTemplateRrequest = AdminService.GetTaskTemplates(WFTemplateID.Value);
                Support.IsTrue(taskTemplateRrequest != null, "Validate response");

                Reports.TestStep = "Navigate to Task Templates";
                FastDriver.TaskTemplateSelection.Open();

                Reports.TestStep = "Validate the response from web service with data in the ui";
                FastDriver.TaskTemplateSelection.Categories.PerformTableAction(2, "Escrow", 1, TableAction.Click);
                FastDriver.TaskTemplateSelection.WaitForTasksForTableToRefresh();
                var tableText = FastDriver.TaskTemplateSelection.TasksForTable.FAGetText();
                Support.AreEqual(true, tableText.Contains(taskTemplateRrequest.TaskTemplates[0].Name), "Validate the data in the screen match with the response from web service");
                Support.AreEqual(true, tableText.Contains(taskTemplateRrequest.TaskTemplates[1].Name), "Validate the data in the screen match with the response from web service");
                Support.AreEqual(true, tableText.Contains(taskTemplateRrequest.TaskTemplates[2].Name), "Validate the data in the screen match with the response from web service");
                Support.AreEqual(true, tableText.Contains(taskTemplateRrequest.TaskTemplates[4].Name), "Validate the data in the screen match with the response from web service");
                Support.AreEqual(true, tableText.Contains(taskTemplateRrequest.TaskTemplates[5].Name), "Validate the data in the screen match with the response from web service");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0023_GetVersionedGABInfo()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                int addrBookEntryID = AdminService.GetGABAddressBookEntryId("BOA", Convert.ToInt32(AutoConfig.SelectedRegionBUID)).Value;
                #endregion

                Reports.TestDescription = "Verify GetVersionedGABInfo() service method.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Invoke GetVersionedGABInfo service.";
                var request = AdminRequestFactory.GetVersionedGABInfoRequest(addrBookEntryID);
                var response = AdminService.GetVersionedGABInfo(request);
                Support.AreEqual(response.Status.ToString(), "1", "Status Code");
                Support.AreEqual(response.StatusDescription.ToString(), "Success", "Status Description");

                Reports.TestStep = "Navigate to Address Book Search screen.";
                FastDriver.AddressBookSearch.Open();

                Reports.TestStep = "Search for the GAB and click Edit button.";
                FastDriver.AddressBookSearch.EditGAB("BOA");

                Reports.TestStep = "Validate the data in the screen with the response from web service.";
                Support.AreEqual(response.LatestBusOrgAddrBookEntryID.ToString(), FastDriver.BusinessPartyOrganizationSetUp.AddressBookID.FAGetText(), "Verify: Lastest Address Book ID of the GAB");
                Support.AreEqual(response.OriginalBusOrgAddrBookEntryID.ToString(), FastDriver.BusinessPartyOrganizationSetUp.OriginalAddressBookID.FAGetText(), "Verify: Original Address Book ID of the GAB");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0024_GetGABorGABContactDetails()
        {
            try
            {
                Reports.TestDescription = "Verify GetGABorGABContactDetails() service.";

                Reports.TestStep = "Invoke SearchGABorGABContact request.";
                var gabSearchResponse = AdminService.GABSearch(AdminRequestFactory.GetGABSearchRequest(1486, "BOA"));

                Reports.TestStep = "Invoke GetGABorGABContactDetails request.";
                var gabDetailResponse = AdminService.GetGABorGABContactDetails(AdminRequestFactory.GetGABorGABContactDetailsRequest(gabSearchResponse.GABResults[0].GABAddrBookEntryID.GetValueOrDefault()));
                gabDetailResponse.Validate();

                Reports.TestStep = "Validate GetGABorGABContactDetails succeeded.";
                Support.AreEqual("8836375", gabDetailResponse.GABInfo.GABAddrBookEntryID.ToString().Clean());
                Support.AreEqual("BOA", gabDetailResponse.GABInfo.ObjectCd.Clean());
                Support.AreEqual("Bank of America", gabDetailResponse.GABInfo.Name1.Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0025_GetGABByAddressBookEntryID()
        {
            try
            {
                Reports.TestDescription = "Verify GetGABByAddressBookEntryID() service.";

                Reports.TestStep = "Invoke SearchGABorGABContact request.";
                var gabSearchResponse = AdminService.GABSearch(AdminRequestFactory.GetGABSearchRequest(1486, "BOA"));

                Reports.TestStep = "Invoke GetGABByAddressBookEntryID request.";
                var gabDetailResponse = AdminService.GetGABByAddressBookEntryID(gabSearchResponse.GABResults[0].GABAddrBookEntryID.GetValueOrDefault());

                Reports.TestStep = "Validate GetGABByAddressBookEntryID succeeded.";
                Support.AreEqual("8836375", gabDetailResponse.GABAddrBookEntryID.ToString().Clean());
                Support.AreEqual("BOA", gabDetailResponse.ObjectCd.Clean());
                Support.AreEqual("Bank of America", gabDetailResponse.Name1.Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0026_GetEmployeeByLoginName()
        {
            try
            {
                Reports.TestDescription = "Verify GetEmployeeByLoginName() service.";

                Reports.TestStep = "Invoke GetEmployeeByLoginName request.";
                var employeeInfo = AdminService.GetEmployeeByLoginName(AutoConfig.UserName);

                Reports.TestStep = "Validate GetEmployeeByLoginName succeeded.";
                Support.AreEqual("86208", employeeInfo.EmployeeID.ToString().Clean());
                Support.AreEqual("FAST", employeeInfo.FirstName.Clean());
                Support.AreEqual("QA07", employeeInfo.LastName.Clean());
                Support.AreEqual("1487", employeeInfo.HomeOfficeID.ToString().Clean());
                Support.AreEqual(@"FASTTS\FASTQA07", employeeInfo.LoginName.Clean());
                Support.AreEqual("FASTQA07A", employeeInfo.ObjectCd.Clean());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0027_GetGABorGABContactsByRegionID()
        {
            try
            {
                Reports.TestDescription = "Verify GetGABorGABContactsByRegionID() service.";

                Reports.TestStep = "Invoke GetGABorGABContactsByRegionID request.";
                var gabResponse = AdminService.GetGABorGABContactsByRegionID(AdminRequestFactory.GetGABAndGABContactsRequest(189));

                Reports.TestStep = "Validate GetGABorGABContactsByRegionID succeeded.";
                var x = gabResponse.GABResults.ToList().FirstOrDefault(p => p.GABAddrBookEntryID == 247);
                Support.AreEqual(true, !(x == null), "Validating response from GetGABorGABContactsByRegionID");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0028_GetBusinessSourceTypesByRegionID()
        {
            try
            {
                Reports.TestDescription = "Verify GetBusinessSourceTypesByRegionID() service.";

                Reports.TestStep = "Invoke GetBusinessSourceTypesByRegionID request.";
                var busSourceTypeReponse = AdminService.GetBusinessSourceTypesByRegionID(AdminRequestFactory.GetBusSourceTypeRequest(189));

                Reports.TestStep = "Validate GetBusinessSourceTypesByRegionID succeeded.";
                Support.AreEqual("2000", busSourceTypeReponse.BusSourceTypes[0].BusSourceTypeName.Clean(), "Validating response from GetBusinessSourceTypesByRegionID");
                Support.AreEqual("TEST BUS SRC TYPE", busSourceTypeReponse.BusSourceTypes[1].BusSourceTypeName.Clean(), "Validating response from GetBusinessSourceTypesByRegionID");
                Support.AreEqual("TEST INACTIVE", busSourceTypeReponse.BusSourceTypes[2].BusSourceTypeName.Clean(), "Validating response from GetBusinessSourceTypesByRegionID");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0029_GetContactsByBusOrgId()
        {
            try
            {
                Reports.TestDescription = "Verify GetContactsByBusOrgId() service.";

                Reports.TestStep = "Invoke GetContactsByBusOrgId request.";
                var mdmContactCollection = AdminService.GetContactsByBusOrgId(AdminRequestFactory.GetGABRequest(58906206));

                Reports.TestStep = "Validate GetContactsByBusOrgId succeeded.";
                Support.AreEqual("172402307", mdmContactCollection.BusOrgContactsList[0].AddressbookEntryId.ToString().Clean(), "Validating response from GetContactsByBusOrgId");
                Support.AreEqual("172403235", mdmContactCollection.BusOrgContactsList[1].AddressbookEntryId.ToString().Clean(), "Validating response from GetContactsByBusOrgId");
                Support.AreEqual("172403239", mdmContactCollection.BusOrgContactsList[2].AddressbookEntryId.ToString().Clean(), "Validating response from GetContactsByBusOrgId");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0030_GetCommentCodesByTaskTemplateID()
        {
            try
            {
                Reports.TestDescription = "[Bug 936859] Verify GetCommentCodesByTaskTemplateID() service.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID("189");

                Reports.TestStep = "Navigate to Task Tempaltes";
                FastDriver.LeftNavigation.Navigate<TaskTemplateSelection>("Home>System Maintenance>Process Setup>Task Templates").WaitForScreenToLoad();

                var taskTemplate = "TaskTestWS";
                if (!FastDriver.TaskTemplateSelection.TasksForTable.FAGetText().Contains(taskTemplate))
                {
                    Reports.TestStep = "Create a new task template";
                    FastDriver.TaskTemplateSelection.New.FAClick();
                    FastDriver.TaskTemplateSelection.WaitForScreenToLoad();
                    FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(FastDriver.TaskTemplateSelection.TasksForTable.GetRowCount(), 3, TableAction.SetText, taskTemplate);
                    FastDriver.BottomFrame.Save();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                    FastDriver.TaskTemplateSelection.WaitForScreenToLoad();

                    Reports.TestStep = "Add Comment Codes to the task template";
                    FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(3, taskTemplate, 9, TableAction.Click);
                    FastDriver.SelectCommentCodeDlg.WaitForScreenToLoad();
                    FastDriver.SelectCommentCodeDlg.CommentCodeTable.PerformTableAction(1, 1, TableAction.On);
                    FastDriver.SelectCommentCodeDlg.CommentCodeTable.PerformTableAction(2, 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.BottomFrame.Save();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                    FastDriver.TaskTemplateSelection.WaitForScreenToLoad();
                }

                FastDriver.TaskTemplateSelection.Categories.PerformTableAction(4, 2, TableAction.Click);
                Playback.Wait(20000);
                if (!FastDriver.TaskTemplateSelection.TasksForTable.FAGetText().Contains(taskTemplate))
                {
                    Reports.TestStep = "Create a new task template";
                    FastDriver.TaskTemplateSelection.New.FAClick();
                    FastDriver.TaskTemplateSelection.WaitForScreenToLoad();
                    FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(FastDriver.TaskTemplateSelection.TasksForTable.GetRowCount(), 3, TableAction.SetText, taskTemplate);
                    FastDriver.BottomFrame.Save();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                    FastDriver.TaskTemplateSelection.WaitForScreenToLoad();

                    Reports.TestStep = "Add Comment Codes to the task template";
                    FastDriver.TaskTemplateSelection.TasksForTable.PerformTableAction(3, taskTemplate, 9, TableAction.Click);
                    FastDriver.SelectCommentCodeDlg.WaitForScreenToLoad();
                    FastDriver.SelectCommentCodeDlg.CommentCodeTable.PerformTableAction(1, 1, TableAction.On);
                    FastDriver.SelectCommentCodeDlg.CommentCodeTable.PerformTableAction(2, 1, TableAction.On);
                    FastDriver.DialogBottomFrame.ClickDone();
                    FastDriver.BottomFrame.Save();
                    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                    FastDriver.TaskTemplateSelection.WaitForScreenToLoad();
                }

                Reports.TestStep = "Select the new template to activate it.";
                FastDriver.LeftNavigation.Navigate<RegionalProcessSummary>("Home>System Maintenance>Process Setup>Regional Process Summary").WaitForScreenToLoad();
                FastDriver.RegionalProcessSummary.New.FAClick();
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.ProcessType.FASelectItem("1099");
                var templateName = "WebServiceProcessTest - " + Support.RandomString("AAZNZNNA");
                FastDriver.RegionalProcessEdit.ProcessName.FASetText(templateName);
                FastDriver.RegionalProcessEdit.PriorityProcess.FASetCheckbox(true);
                FastDriver.RegionalProcessEdit.Description.FASetText("Selenium Web Service Regression Test.");
                string processName = FastDriver.RegionalProcessEdit.ProcessName.FAGetValue();
                FastDriver.RegionalProcessEdit.ProcessTemplateSelectionCriteriaSelect.FAClick();
                FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.SelectionCriteriaDlg.TranType.FASelectItem("Sale w/Mortgage");
                FastDriver.SelectionCriteriaDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();

                Reports.TestStep = "Add tasks to the process";
                FastDriver.RegionalProcessEdit.Add.FAClick();
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, taskTemplate, 2, TableAction.On);
                FastDriver.TaskTemplateSelectionDlg.SelectTasks.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();

                FastDriver.RegionalProcessEdit.Add.FAClick();
                FastDriver.TaskTemplateSelectionDlg.WaitForScreenToLoad();
                FastDriver.TaskTemplateSelectionDlg.TaskCategoryTable.PerformTableAction(4, 2, TableAction.Click);
                FastDriver.TaskTemplateSelectionDlg.TasksForTable.PerformTableAction(3, taskTemplate, 2, TableAction.On);
                FastDriver.TaskTemplateSelectionDlg.SelectTasks.FAClick();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();

                Reports.TestStep = "Add workgroups to all tasks";
                FastDriver.RegionalProcessEdit.TaskTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.RegionalProcessEdit.WorkGrpEllipse.FAClick();
                FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectDlg.ViewMore.FAClick();
                FastDriver.WorkgroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectionDlg.Table.PerformTableAction(1, 1, TableAction.SelectItem, "1099");
                FastDriver.WorkgroupSelectionDlg.Select.FAClick();
                FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectDlg.WorkgroupTable.PerformTableAction(2, "1099", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();

                Reports.TestStep = "Set External Customer to FASTWEB.";
                FastDriver.RegionalProcessEdit.ExternalCustomer.FAClick();
                FastDriver.ExternalCustomerDlg.WaitForScreenToLoad();
                FastDriver.ExternalCustomerDlg.ExternalCustomerTable.PerformTableAction(1, "FASTWEB", 2, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Activating Process";
                FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
                FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, processName, 2, TableAction.Click);
                FastDriver.RegionalProcessSummary.ViewChangeStatus.FAClick();
                FastDriver.StatusEdit.WaitForScreenToLoad();
                FastDriver.StatusEdit.Deactivate.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(false, true, 10);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 10);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Invoke GetWorkFlowTemplates service";
                var workflowResponse = AdminService.GetWorkFlowTemplates(189, (int)AdminHelpers.webCustomerTypeCDID.FASTWEB);
                Reports.StatusUpdate(workflowResponse.ToJSON(), true);
                Support.IsTrue(workflowResponse != null, "Validate response");
                var wfTemplateID = workflowResponse.WFTemplates.ToList().FirstOrDefault(p => p.Name.Clean() == processName.Clean());
                //Add WaitForACtionToComplete to wait for response to not be null

                int? taskTemplateID = null;
                TaskTemplateResponse taskTemplateResponse = null;
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    Reports.TestStep = "Invoke GetTaskTemplates service";
                    taskTemplateResponse = AdminService.GetTaskTemplates(wfTemplateID.WorkFlowTemplateID.GetValueOrDefault());
                    Reports.StatusUpdate(taskTemplateResponse.ToJSON(), true);
                    Support.IsTrue(taskTemplateResponse != null, "Validate response");

                    return !(taskTemplateResponse.TaskTemplates == null);
                }, timeout: 600, idleInterval: 5);

                taskTemplateID = taskTemplateResponse.TaskTemplates[0].TaskTemplateID;


                Reports.TestStep = "Invoke GetCommentCodesByTaskTemplateID request.";
                var mdmContactCollection = AdminService.GetCommentCodesByTaskTemplateID(AdminRequestFactory.GetTaskTemplateCommentCodesRequest(taskTemplateID.GetValueOrDefault()));

                Reports.TestStep = "Validate GetCommentCodesByTaskTemplateID succeeded.";
                //Support.AreEqual("172402307", mdmContactCollection.BusOrgContactsList[0].AddressbookEntryId.ToString().Clean(), "Validating response from GetCommentCodesByTaskTemplateID");
                //Support.AreEqual("172403235", mdmContactCollection.BusOrgContactsList[1].AddressbookEntryId.ToString().Clean(), "Validating response from GetCommentCodesByTaskTemplateID");
                //Support.AreEqual("172403239", mdmContactCollection.BusOrgContactsList[2].AddressbookEntryId.ToString().Clean(), "Validating response from GetCommentCodesByTaskTemplateID");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}