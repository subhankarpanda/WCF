﻿using System;
using System.Linq;
using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTWCFHelpers;
using FASTWCFHelpers.FastAdminService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;

namespace Web_Services_Regression.Regression.ADMService
{
    [CodedUITest]
    public class OfficeSetupWS : MasterTestClass
    {
        [TestMethod]
        [Description("Verify Getoffices service functionality.")]
        public void REG_GetOffices()
        {
            try
            {
                Reports.TestDescription = "US 819839:Getoffices() WCF method should display a flag in response xml for indicating an office is active or hidden [0/1].";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                int iRegionId = Convert.ToInt32(ClosingDisclosureSupport.IMDRegionBUID);
                string buid = Setup_HiddenOffice(false);

                //ActiveOrHiddenOffice = NULL
                var officeList = FASTWCFHelpers.AdminService.GetOffices(iRegionId, null);

                var hasHiddenOffices = officeList.BusUnits.Any(x => x.HiddenOfficeFlag == true);

                var hasActiveOffices = officeList.BusUnits.Any(x => x.HiddenOfficeFlag == false);

                Support.IsTrue(hasActiveOffices == hasHiddenOffices, string.Format("Both Active and Hidden offices under {0} region got displayed as HiddenOfficeFlag=True and HiddenOfficeFlag=False for NUll.", iRegionId));


                //ActiveOrHiddenOffice = Active
                officeList = FASTWCFHelpers.AdminService.GetOffices(iRegionId, eActiveOrHiddenOffice.Active);

                var isAnyHiddenOfficeFound = officeList.BusUnits.Any(x => x.HiddenOfficeFlag == true);

                var activeOfficeMatched = officeList.BusUnits.Any(x => x.BusinessUnitID == Convert.ToInt32(buid) && x.HiddenOfficeFlag == false);

                Support.IsTrue(!isAnyHiddenOfficeFound == activeOfficeMatched, string.Format("Active offices alone under {0} region got displayed as HiddenOfficeFlag=false.", iRegionId));

                //ActiveOrHiddenOffice = Hidden
                buid = Setup_HiddenOffice(true);

                officeList = FASTWCFHelpers.AdminService.GetOffices(iRegionId, eActiveOrHiddenOffice.Hidden);

                var isAnyActiveOfficeFound = officeList.BusUnits.Any(x => x.HiddenOfficeFlag == false);

                var hiddenOfficeMatched = officeList.BusUnits.Any(x => x.BusinessUnitID == Convert.ToInt32(buid) && x.HiddenOfficeFlag == true);

                Support.IsTrue(!isAnyActiveOfficeFound == hiddenOfficeMatched, string.Format("Hidden offices alone under {0} region got displayed as HiddenOfficeFlag=True.", iRegionId));


                //ActiveOrHiddenOffice = ActiveHidden
                officeList = FASTWCFHelpers.AdminService.GetOffices(iRegionId, eActiveOrHiddenOffice.ActiveAndHidden);

                hasHiddenOffices = officeList.BusUnits.Any(x => x.HiddenOfficeFlag == true);

                hasActiveOffices = officeList.BusUnits.Any(x => x.HiddenOfficeFlag == false);

                Support.IsTrue(hasActiveOffices == hasHiddenOffices, string.Format("Both Active and Hidden offices under {0} region got displayed as HiddenOfficeFlag=True and HiddenOfficeFlag=False for ActiveHidden.", iRegionId));
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        private void CreateNewOffice()
        {
            FastDriver.OfficeSummary.New.FAClick();

            Reports.TestStep = "Enter details to newly created office.";
            FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
            Random random = new Random();
            string OfficeCode1 = random.Next(999, 10000).ToString();
            FastDriver.OfficeSetupOffice.OfficeCode.FASetText(OfficeCode1);
            FastDriver.OfficeSetupOffice.FederalTaxID.FASetText("567891234");
            FastDriver.OfficeSetupOffice.OfficeName.FASetText("SRT Test Automation Office");
            FastDriver.OfficeSetupOffice.OfficeCompanyName1.FASetText("SRT DO Not Touch Automation Office");
            FastDriver.OfficeSetupOffice.OfficeComments.FASetText("Creating a new Office");
            FastDriver.OfficeSetupOffice.OfficeLogoFile1.FASetText("Test");
            FastDriver.OfficeSetupOffice.OfficeSystemLogoFile.FASetText("Automation Test");
            FastDriver.OfficeSetupOffice.BusinessSegment.FASelectItem("Commercial");
            FastDriver.OfficeSetupOffice.Can_be_Inter_Regional_Production_office.FASetCheckbox(true);
            FastDriver.OfficeSetupOffice.FeeTransmittalType.FASelectItem("Fee Transfer");
            FastDriver.OfficeSetupOffice.TimeZone.FASelectItem("Mountain Time");
            FastDriver.OfficeSetupOffice.DivisionProductionCenter.FASetCheckbox(true);
            FastDriver.OfficeSetupOffice.NPSProductionOffice.FASetCheckbox(true);
            FastDriver.OfficeSetupOffice.StatisticalReportingOffice.FASelectItem("Agency");
            FastDriver.OfficeSetupOffice.ProductionSystem.FASelectItem("FAST deployed");
            FastDriver.OfficeSetupOffice.FileNumberSchemaPrefix.FASetText("EWS");
            FastDriver.OfficeSetupOffice.FileNumberSchemaSeparator1.FASelectItem("-");
            FastDriver.OfficeSetupOffice.FileNumberSchemaSeparator2.FASelectItem("-");
            FastDriver.OfficeSetupOffice.FileNumberSchemaSuffix.FASetText("ADC");
            FastDriver.OfficeSetupOffice.DocumentNumberSchemaInvoicePrefix.FASetText("100");
            FastDriver.OfficeSetupOffice.FastStatCode.FASetText("12345");
            FastDriver.OfficeSetupOffice.CorporateParent.FASelectItemBySendingKeys("First American (FA)");
            FastDriver.OfficeSetupOffice.UnderwritersMenu.FAClick();
            FastDriver.OfficeSetupUnderwriters.UnderwritersNew.FAClick();
            FastDriver.OfficeSetupUnderwriters.UnderwriterName1.FASelectItem("New Underwriter");
            FastDriver.OfficeSetupUnderwriters.PremiumPercentage.FASetText("10");
            FastDriver.OfficeSetupUnderwriters.UseAsDefaultUnderwriter.FASetCheckbox(true);

            FastDriver.OfficeSetupOffice.BankAccountsMenu.FAClick();
            FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad();
            FastDriver.OfficeSetupBankAccounts.BankAccountSummaryNew.FAClick();
            FastDriver.OfficeSetupBankAccounts.BankAccountDetail_BankName.FASelectItemBySendingKeys("Automation Bank - Automation Testing");
            FastDriver.OfficeSetupBankAccounts.BankAccountDetailAccountNo1.FASetText("232345");
            FastDriver.OfficeSetupBankAccounts.BankAccountDetail_AccountDescription.FASetText("SRT AUTOMATION BANK");
            FastDriver.OfficeSetupBankAccounts.DisburseAcct.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.PrimaryDisburse.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.PrimaryDisburse.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.DepositAcct.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.PrimaryDeposit.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.BanksTable.PerformTableAction("Bank Name", "Automation Bank - Automation Testing", "Bank Name", TableAction.Click);

            FastDriver.BottomFrame.Done();


        }

        private string Setup_HiddenOffice(Boolean HiddenOfficeFlag)
        {
            string OfficeBuid = "0";

            try
            {
                Reports.TestStep = "Check if automation office exists";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                Playback.Wait(3000);
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");

                FastDriver.OfficeSummary.WaitForScreenToLoad();
                if (FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Automation Office"))
                {

                    Reports.TestStep = "Select an office and edit it.";
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();

                    FastDriver.OfficeSummary.Edit.FAClick();
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                    Reports.TestStep = "Set the Hidden flag status as true for office if it's not set";
                    if (!HiddenOfficeFlag)
                    {
                        if (FastDriver.OfficeSetupOffice.Hidden.Selected)
                        {
                            FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(false);

                        }
                    }
                    else if (!FastDriver.OfficeSetupOffice.Hidden.Selected)
                    {
                        FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);
                    }
                    FastDriver.BottomFrame.Done();
                    Playback.Wait(4000);

                }
                else
                {
                    Reports.TestStep = "Create a new office.";
                    this.CreateNewOffice();

                    FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                    FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    Playback.Wait(1000);
                    FastDriver.OfficeSummary.Edit.FAClick();
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                    Reports.TestStep = "Set the Hidden flag status as true for office if it's not set";
                    if (!HiddenOfficeFlag)
                    {
                        if (FastDriver.OfficeSetupOffice.Hidden.Selected)
                        {
                            FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(false);

                        }
                    }
                    else if (!FastDriver.OfficeSetupOffice.Hidden.Selected)
                    {
                        FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);
                    }
                    FastDriver.BottomFrame.Done();
                    Playback.Wait(4000);

                }

                return OfficeBuid;

                #endregion UI

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
                return "";
            }
        }
    }
}
