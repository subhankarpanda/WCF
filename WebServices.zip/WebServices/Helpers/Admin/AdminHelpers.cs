﻿using FASTWCFHelpers.FastAdminService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FASTWCFHelpers.Factories;
using SeleniumInternalHelpersSupportLibrary;
using FASTWCFHelpers;

namespace WebServices.Helpers.Admin
{
    public class AdminHelpers
    {
        public static int GetStateId(string state)
        {
            var request = AdminService.GetStates();

            try
            {
                return request.States.First(m => m.ObjectCD == state).ID.Value;
            }
            catch (Exception)
            {
                throw new Exception("State name was incorrect or it doesn't exists");
            }
        }

        public enum webCustomerTypeCDID
        {
            AGENTFIRST = 1239,
            AgentNet = 2064,
            CustomerFacingTechnology = 1715,
            EagleStatus = 2023,
            FAMOS = 1800,
            FASTWEB = 1238,
            LACOM = 2402,
            MYFAMS = 3200,
            myFASTNCS = 1826,
            SIU = 2072,
            WebSigning = 2667
        }
    }
}