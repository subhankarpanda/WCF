﻿using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebServices.Helpers.Escrow
{
    class EscrowTransactionsHelpers
    {
        public static DepositImagesResponse GetDepositImages(DepositImagesRequest request)
        {
            DepositImagesResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.GetDepositImages(request);

                Reports.StatusUpdate("GetDepositImages", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetDepositImages", false, ex.Message);
            }

            return response;

        }

        public static EditDisbursementResponse SaveEditDisbursementDetails(EditDisbursementRequest request)
        {
            EditDisbursementResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.SaveEditDisbursementDetails(request);

                Reports.StatusUpdate("SaveEditDisbursementDetails", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("SaveEditDisbursementDetails", false, ex.Message);
            }

            return response;

        }

        public static UpdateSplitDisbResponse UpdateSplitDisbursement(UpdateSplitDisbRequest request)
        {
            UpdateSplitDisbResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.UpdateSplitDisbursement(request);

                Reports.StatusUpdate("UpdateSplitDisbursement", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("UpdateSplitDisbursement", false, ex.Message);
            }

            return response;

        }
        public static OperationResponse SetCalculationFees(UpdateFeesCalculationRequest request)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.SetCalculationFees(request);

                Reports.StatusUpdate("SetCalculationFees", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("SetCalculationFees", false, ex.Message);
            }

            return response;

        }

        public static ExcludedReceiptLoadResponse GetExcludedReceipts(ExcludedReceiptLoadRequest request)
        {
            ExcludedReceiptLoadResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.GetExcludedReceipts(request);

                Reports.StatusUpdate("GetExcludedReceipts", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetExcludedReceipts", false, ex.Message);
            }

            return response;

        }

        public static DepositHistoryResponse GetDepositHistorySummary(ServiceFileRequest request)
        {
            DepositHistoryResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.GetDepositHistorySummary(request);

                Reports.StatusUpdate("GetDepositHistorySummary", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetDepositHistorySummary", false, ex.Message);
            }

            return response;

        }

        public static DepositViewdetailsResponse GetDepositHistoryViewDetails(DepositImagesRequest request)
        {
            DepositViewdetailsResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.GetDepositHistoryViewDetails(request);

                Reports.StatusUpdate("GetDepositHistoryViewDetails", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetDepositHistoryViewDetails", false, ex.Message);
            }

            return response;

        }

        public static DepositListDetailsResponse GetDepositList(DepositListDetailsRequest request)
        {
            DepositListDetailsResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.GetDepositList(request);

                Reports.StatusUpdate("GetDepositList", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetDepositList", false, ex.Message);
            }

            return response;

        }

        public static SplitDisbDetailResponse GetSplitDisbursementDetail(SplitDisbDetailRequest request)
        {
            SplitDisbDetailResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.GetSplitDisbursementDetail(request);

                Reports.StatusUpdate("GetSplitDisbursementDetail", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetSplitDisbursementDetail", false, ex.Message);
            }

            return response;

        }

        public static DisbTrackResponse GetDisbursementTrackDetails(DisbTrackRequest request)
        {
            DisbTrackResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.GetDisbursementTrackDetails(request);

                Reports.StatusUpdate("GetDisbursementTrackDetails", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetDisbursementTrackDetails", false, ex.Message);
            }

            return response;

        }

        public static UpdateDisbTrackResponse UpdateDisbursementTrackDetails(UpdateDisbTrackRequest request)
        {
            UpdateDisbTrackResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.UpdateDisbursementTrackDetails(request);

                Reports.StatusUpdate("UpdateDisbursementTrackDetails", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("UpdateDisbursementTrackDetails", false, ex.Message);
            }

            return response;

        }

        public static DocumentTypesResponse GetDocTypeAndDocNames(DocumentTypeRequest request)
        {
            DocumentTypesResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.GetDocTypeAndDocNames(request);

                Reports.StatusUpdate("GetDocTypeAndDocNames", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetDocTypeAndDocNames", false, ex.Message);
            }

            return response;

        }

        public static AssumptionLoanDisbursementDetailsResponse GetAssumptionLoanDisbursementDetails(int?fileID,int seqNum)
        {
            var response = new AssumptionLoanDisbursementDetailsResponse();
            bool result = false;
            try
            {
                response = FASTWCFHelpers.EscrowService.GetAssumptionLoanDisbursementDetails(EscrowRequestFactory.GetAssumptionLoanDisbursementDetailsRequest(fileID, seqNum));
                result = (response.Status == 1) ? true : false;
                Reports.StatusUpdate(response.StatusDescription, result);
            }
            catch
            {
                Reports.StatusUpdate(response.StatusDescription, result);
            }
            return response;
        }

        public static AssumptionLoanDisbSaveResponse UpdateAssumptionLoanDisbDetails(AssumptionLoanDisbSaveRequest request)
        {
            var response = new AssumptionLoanDisbSaveResponse();
            bool result = false;
            try
            {
                response = FASTWCFHelpers.EscrowService.UpdateAssumptionLoanDisbDetails(request);
                result = (response.Status == 1) ? true : false;
                Reports.StatusUpdate(response.StatusDescription, result);
            }
            catch
            {
                Reports.StatusUpdate(response.StatusDescription, result);
            }
            return response;
        }
    }
}
