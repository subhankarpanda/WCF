﻿using FASTWCFHelpers.FastEscrowService;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebServices.Helpers.Escrow
{
    class FileManagementHelpers
    {
        public static DuplicateFileSearchResponse GetDuplicateFileSearchResult(DuplicateFileSearchRequest request)
        {
            var response = new DuplicateFileSearchResponse();
            try
            {
                response = FASTWCFHelpers.EscrowService.GetDuplicateFileSearchResults(request);
                if(response.Status==1)
                {
                    Reports.StatusUpdate("DuplicateFileSearch invoked successfully.", true);
                }
                else
                {
                    Reports.StatusUpdate("DuplicateFileSearch is not invoked successfully.", false);
                }
            }
            catch
            {
                Reports.StatusUpdate("DuplicateFileSearch is not invoked successfully.", false);
            }
            return response;
        }

        public static GFELoanResponse GetGFEDetails(GFEDetailsRequest request)
        {
            GFELoanResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.GetGFEDetails(request);

                Reports.StatusUpdate("GetGFEDetails", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetGFEDetails", false, ex.Message);
            }

            return response;

        }

        public static OperationResponse UpdateGFEDetails(GFELoanRequest request)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.UpdateGFEDetails(request);

                Reports.StatusUpdate("UpdateGFEDetails", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("UpdateGFEDetails", false, ex.Message);
            }

            return response;

        }

        public static UpdateExternalServiceNumResponse UpdateExternalServiceNumber(UpdateExternalServiceNumRequest request)
        {
            UpdateExternalServiceNumResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.UpdateExternalServiceNumber(request);

                Reports.StatusUpdate("UpdateExternalServiceNumber", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("UpdateExternalServiceNumber", false, ex.Message);
            }

            return response;

        }
        public static OperationResponse UpdateSiteFileStatus(UpdateSFStatus request)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.UpdateSiteFileStatus(request);

                Reports.StatusUpdate("UpdateSiteFileStatus", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("UpdateSiteFileStatus", false, ex.Message);
            }

            return response;

        }

        public static OperationResponse SplitImageDocument(SplitImageDocument request)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.SplitImageDocument(request);

                Reports.StatusUpdate("SplitImageDocument", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("SplitImageDocument", false, ex.Message);
            }

            return response;

        }

        public static UpdateSecondOrderSourceResponse UnlinkSecondOrderSource(UpdateSecondOrderSourceRequest request)
        {
            UpdateSecondOrderSourceResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.UnlinkSecondOrderSource(request);

                Reports.StatusUpdate("UnlinkSecondOrderSource", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("UnlinkSecondOrderSource", false, ex.Message);
            }

            return response;

        }

        public static SDNTrackingSummary GetSDNTrackingSummaryDetails(SDNSearchRequest request)
        {
            SDNTrackingSummary response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.GetSDNTrackingSummaryDetails(request);

                Reports.StatusUpdate("GetSDNTrackingSummaryDetails", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetSDNTrackingSummaryDetails", false, ex.Message);
            }

            return response;

        }
    }
}
