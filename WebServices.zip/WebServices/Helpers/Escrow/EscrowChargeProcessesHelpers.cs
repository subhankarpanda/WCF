﻿using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebServices.Helpers.Escrow
{
    class EscrowChargeProcessesHelpers
    {

        public static OperationResponse CreateOutsideEscrowCompany(OECRequest request)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.CreateOutsideEscrowCompany(request);

                Reports.StatusUpdate("CreateOutsideEscrowCompany", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("CreateOutsideEscrowCompany", false, ex.Message);
            }

            return response;

        }
        public static OperationResponse DeleteOutsideEscrowCompany(OECRequest request)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.DeleteOutsideEscrowCompany(request);

                Reports.StatusUpdate("DeleteOutsideEscrowCompany", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("DeleteOutsideEscrowCompany", false, ex.Message);
            }

            return response;

        }

        public static InspectionRepairSepticSummaryResponse GetInspectionRepairSepticSummary(InspectionRepairSepticSummaryRequest request)
        {
            InspectionRepairSepticSummaryResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.GetInspectionRepairSepticSummary(request);

                Reports.StatusUpdate("GetInspectionRepairSepticSummary", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetInspectionRepairSepticSummary", false, ex.Message);
            }

            return response;

        }

        public static InspectionRepairSepticSaveResponse CreateInspectionRepairSeptic(InspectionRepairSepticSaveRequest request)
        {
            InspectionRepairSepticSaveResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.CreateInspectionRepairSeptic(request);

                Reports.StatusUpdate("CreateInspectionRepairSeptic", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("CreateInspectionRepairSeptic", false, ex.Message);
            }

            return response;

        }

        public static InspectionRepairPestResponse CreateInspectionRepairPest(InspectionRepairPestRequest request)
        {
            InspectionRepairPestResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.CreateInspectionRepairPest(request);

                Reports.StatusUpdate("CreateInspectionRepairPest", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("CreateInspectionRepairPest", false, ex.Message);
            }

            return response;

        }

        public static InspectionRepairPestResponse UpdateInspectionRepairPest(InspectionRepairPestRequest request)
        {
            InspectionRepairPestResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.UpdateInspectionRepairPest(request);

                Reports.StatusUpdate("UpdateInspectionRepairPest", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("UpdateInspectionRepairPest", false, ex.Message);
            }

            return response;

        }

        public static InspectionRepairPestResponse RemoveInspectionRepairPest(InspectionRepairPestRequest request)
        {
            InspectionRepairPestResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.RemoveInspectionRepairPest(request);

                Reports.StatusUpdate("RemoveInspectionRepairPest", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("RemoveInspectionRepairPest", false, ex.Message);
            }

            return response;

        }

        public static InspectionRepairSepticSaveResponse UpdateInspectionRepairSeptic(InspectionRepairSepticSaveRequest request)
        {
            InspectionRepairSepticSaveResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.UpdateInspectionRepairSeptic(request);

                Reports.StatusUpdate("UpdateInspectionRepairSeptic", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("UpdateInspectionRepairSeptic", false, ex.Message);
            }

            return response;

        }
        public static InspectionRepairSepticRemoveResponse RemoveInspectionRepairSeptic(InspectionRepairSepticRemoveRequest request)
        {
            InspectionRepairSepticRemoveResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.RemoveInspectionRepairSeptic(request);

                Reports.StatusUpdate("RemoveInspectionRepairSeptic", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("RemoveInspectionRepairSeptic", false, ex.Message);
            }

            return response;

        }

        public static OperationResponse RemoveLenderThirdPartyPayee(RemoveThirdPartyPayee request)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.RemoveLenderThirdPartyPayee(request);

                Reports.StatusUpdate("RemoveLenderThirdPartyPayee", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("RemoveLenderThirdPartyPayee", false, ex.Message);
            }

            return response;

        }

        public static OperationResponse RemoveMortgageBrokerInformation(RemoveNewLoanRequest request)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.RemoveMortgageBrokerInformation(request);

                Reports.StatusUpdate("RemoveMortgageBrokerInformation", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("RemoveMortgageBrokerInformation", false, ex.Message);
            }

            return response;

        }

        public static OperationResponse RemoveMortgageBrokerThirdPartyPayee(RemoveThirdPartyPayee request)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.RemoveMortgageBrokerThirdPartyPayee(request);

                Reports.StatusUpdate("RemoveMortgageBrokerThirdPartyPayee", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("RemoveMortgageBrokerThirdPartyPayee", false, ex.Message);
            }

            return response;

        }

        public static OperationResponse UpdatePropertyTaxCheck(PropertyTaxCheckRequest request)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.UpdatePropertyTaxCheck(request);

                Reports.StatusUpdate("UpdatePropertyTaxCheck", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("UpdatePropertyTaxCheck", false, ex.Message);
            }

            return response;

        }
        public static OperationResponse RemovePropertyTaxCheck(PropertyTaxCheckRequest request)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.RemovePropertyTaxCheck(request);

                Reports.StatusUpdate("RemovePropertyTaxCheck", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("RemovePropertyTaxCheck", false, ex.Message);
            }

            return response;

        }

        public static NewLoanResponse GetNewLoanDetails(NewLoanDetailsRequest request)
        {
            NewLoanResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.GetNewLoanDetails(request);

                Reports.StatusUpdate("GetNewLoanDetails", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetNewLoanDetails", false, ex.Message);
            }

            return response;

        }

        public static OperationResponse CreatePropertyTaxCheck(PropertyTaxCheckRequest request)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.CreatePropertyTaxCheck(request);

                Reports.StatusUpdate("CreatePropertyTaxCheck", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("CreatePropertyTaxCheck", false, ex.Message);
            }

            return response;

        }

        public static PropertyTaxCheckResponse GetPropertyTaxCheckDetails(int fileId)
        {
            PropertyTaxCheckResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.GetPropertyTaxCheckDetails(fileId);

                Reports.StatusUpdate("GetPropertyTaxCheckDetails", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetPropertyTaxCheckDetails", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse CreateSurvey(SurveyRequest request)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.CreateSurvey(request);

                Reports.StatusUpdate("CreateSurvey", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("CreateSurvey", false, ex.Message);
            }

            return response;
        }

        public static SurveyResponse GetSurveyDetails(ServiceFileRequest request)
        {
            SurveyResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.GetSurveyDetails(request);

                Reports.StatusUpdate("GetSurveyDetails", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetSurveyDetails", false, ex.Message);
            }

            return response;

        }

        public static OperationResponse RemoveSurvey(SurveyRequest request)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.RemoveSurvey(request);

                Reports.StatusUpdate("RemoveSurvey", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("RemoveSurvey", false, ex.Message);
            }

            return response;

        }

        public static OperationResponse UpdateSurvey(SurveyRequest request)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.UpdateSurvey(request);

                Reports.StatusUpdate("UpdateSurvey", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("UpdateSurvey", false, ex.Message);
            }

            return response;

        }

        public static HoldFundsSaveResponse CreateHoldFunds(HoldFundsSaveRequest request)
        {
            HoldFundsSaveResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.CreateHoldFunds(request);

                Reports.StatusUpdate("CreateHoldFunds", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("CreateHoldFunds", false, ex.Message);
            }

            return response;

        }

        public static HoldFundsSummaryResponse GetHoldFundsSummary(HoldFundsSummaryRequest request)
        {
            HoldFundsSummaryResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.GetHoldFundsSummary(request);

                Reports.StatusUpdate("GetHoldFundsSummary", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetHoldFundsSummary", false, ex.Message);
            }

            return response;

        }

        public static GetHoldFundsResponse GetHoldFundsDetails(GetHoldFundsRequest request)
        {
            GetHoldFundsResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.GetHoldFundsDetails(request);

                Reports.StatusUpdate("GetHoldFundsDetails", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetHoldFundsDetails", false, ex.Message);
            }

            return response;

        }
        public static HoldFundsSaveResponse UpdateHoldFunds(HoldFundsSaveRequest request)
        {
            HoldFundsSaveResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.UpdateHoldFunds(request);

                Reports.StatusUpdate("UpdateHoldFunds", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("UpdateHoldFunds", false, ex.Message);
            }

            return response;

        }

        public static HoldFundsRemoveResponse RemoveHoldFunds(HoldFundsRemoveRequest request)
        {
            HoldFundsRemoveResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.RemoveHoldFunds(request);

                Reports.StatusUpdate("RemoveHoldFunds", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("RemoveHoldFunds", false, ex.Message);
            }

            return response;

        }

        public static DepositListDetailsResponse ReadDepositListDetails(DepositListDetailsRequest request)
        {
            DepositListDetailsResponse response = null;

            try
            {
                response =  FASTWCFHelpers.EscrowService.ReadDepositListDetails(request);

                Reports.StatusUpdate("ReadDepositListDetails", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("ReadDepositListDetails", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse GetHomeOwnerInstanceCreated(int fileID, int seqNum = 1)
        {
            OperationResponse respnc = null;
            try
            {
                HomeownerAssociationRequest request = EscrowRequestFactory.GetHomeOwnerAssociationRequestWithCharge(fileID, seqNum);
                respnc = FASTWCFHelpers.EscrowService.CreateHomeownerAssociation(request);
                if(respnc.Status==1)
                {
                    Reports.StatusUpdate("CreateHomeOwnerAssociation web services invoked successfully.", true);
                }
                else
                {
                    Reports.StatusUpdate("CreateHomeOwnerAssociation web services was not invoked successfully.", false);
                }
            }
            catch
            {
                Reports.StatusUpdate("CreateHomeOwnerAssociation web services was not invoked successfully.", false);
            }
            return respnc;
        }

        public static HomeownerAssociationResponse GetHomeOwnerAssociationDetails(int fileID)
        {
            var response = new HomeownerAssociationResponse();
            try
            {
                ServiceFileRequest request=EscrowRequestFactory.GetServiceFileRequest(fileID);
                response = FASTWCFHelpers.EscrowService.GetHomeownerAssociation(request);
                if (response.Status == 1)
                {
                    Reports.StatusUpdate("GetHomeOwnerAssociationDetails web service invoked successfully.", true);
                }
                else
                {
                    Reports.StatusUpdate("GetHomeOwnerAssociationDetails web services was not invoked successfully.", false);
                }
            }
            catch
            {
                Reports.StatusUpdate("GetHomeOwnerAssociationDetails web services was not invoked successfully.", false);
            }
            return response;
        }

        public static OperationResponse UpdateHomeOwnerAssociationDetails(HomeownerAssociationRequest request)
        {
            var response = new OperationResponse();
            try
            {
                response = FASTWCFHelpers.EscrowService.UpdateHomeownerAssociation(request);
                if (response.Status == 1)
                {
                    Reports.StatusUpdate("UpdateHomeOwnerAssociationDetails web service invoked successfully.", true);
                }
                else
                {
                    Reports.StatusUpdate("UpdateHomeOwnerAssociationDetails web services was not invoked successfully.", false);
                }
            }
            catch
            {
                Reports.StatusUpdate("UpdateHomeOwnerAssociationDetails web services was not invoked successfully.", false);
            }
            return response;
        }

        public static OperationResponse RemoveHomeOwnerAssociation(int fileId, int seqNum)
        {
            var response = new OperationResponse();
            try
            {
                HomeownerAssociationRequest request = EscrowRequestFactory.GetHomeownerAssociationRequest(fileId, seqNum);
                response = FASTWCFHelpers.EscrowService.RemoveHomeownerAssociation(request);
                if (response.Status == 1)
                {
                    Reports.StatusUpdate("RemoveHomeOwnerAssociationDetails web service invoked successfully.", true);
                }
                else
                {
                    Reports.StatusUpdate("RemoveHomeOwnerAssociationDetails web services was not invoked successfully.", false);
                }
            }
            catch
            {
                Reports.StatusUpdate("RemoveHomeOwnerAssociationDetails web services was not invoked successfully.", false);
            }
            return response;
        }

        public static OperationResponse GetInspectionRepairOthersCreated(int fileId,int seqNum)
        {
            var response = new OperationResponse();
            try
            {
                InspectionRepairRequest request = EscrowRequestFactory.GetIRORequest(fileId, seqNum);
                response = FASTWCFHelpers.EscrowService.CreateInspectionRepairOther(request);
                if (response.Status == 1)
                {
                    Reports.StatusUpdate("CreateInspectionRepairOthers web service invoked successfully.", true);
                }
                else
                {
                    Reports.StatusUpdate("CreateInspectionRepairOthers web services was not invoked successfully.", false);
                }
            }
            catch
            {
                Reports.StatusUpdate("CreateInspectionRepairOthers web services was not invoked successfully.", false);
            }
            return response;
        }

        public static InspectionRepairResponse GetInspectionRepairOthersDetails(int fileID)
        {
            var response = new InspectionRepairResponse();
            try
            {
                ServiceFileRequest request = EscrowRequestFactory.GetServiceFileRequest(fileID);
                response = FASTWCFHelpers.EscrowService.GetInspectionRepairOtherDetails(request);
                if (response.Status == 1)
                {
                    Reports.StatusUpdate("GetInspectionRepairOthersDetails web service invoked successfully.", true);
                }
                else
                {
                    Reports.StatusUpdate("GetInspectionRepairOthersDetails web services was not invoked successfully.", false);
                }
            }
            catch
            {
                Reports.StatusUpdate("GetInspectionRepairOthersDetails web services was not invoked successfully.", false);
            }
            return response;
        }

        public static OperationResponse UpdateInspectionRepairOthers(InspectionRepairRequest request)
        {
            var response = new OperationResponse();
            try
            {
                response = FASTWCFHelpers.EscrowService.UpdateInspectionRepairOther(request);
                if (response.Status == 1)
                {
                    Reports.StatusUpdate("UpdateInspectionRepairOther web service invoked successfully.", true);
                }
                else
                {
                    Reports.StatusUpdate("UpdateInspectionRepairOther  web services was not invoked successfully.", false);
                }
            }
            catch
            {
                Reports.StatusUpdate("UpdateInspectionRepairOther  web services was not invoked successfully.", false);
            }
            return response;
        }

        public static OperationResponse RemoveInspectionRepairOther(int fileId, int seqNum)
        {
            var response = new OperationResponse();
            try
            {
                InspectionRepairRequest request = EscrowRequestFactory.GetIRORequest(fileId,seqNum);
                response = FASTWCFHelpers.EscrowService.RemoveInspectionRepairOther(request);
                if (response.Status == 1)
                {
                    Reports.StatusUpdate("RemoveInspectionRepairOthers web service invoked successfully.", true);
                }
                else
                {
                    Reports.StatusUpdate("RemoveInspectionRepairOthers web services was not invoked successfully.", false);
                }
            }
            catch
            {
                Reports.StatusUpdate("RemoveInspectionRepairOthers web services was not invoked successfully.", false);
            }
            return response;
        }
    }
}
