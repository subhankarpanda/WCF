﻿using FASTSelenium.Common;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Text;
using System.Text.RegularExpressions;
using FASTWCFHelpers.FastFileService;


namespace WebServices
{
    public class ServiceHelper
    {
        public static void CompareUIDate(string sActualVal, string sExpectedVal)
        {
            object PropValue = "";
            bool iResult = true;
            string eErrorMsg = "";
            try
            {
                DateTime uiDate = Convert.ToDateTime(sActualVal).Date;
                DateTime serviceDate = Convert.ToDateTime(sExpectedVal).Date;
                int i = DateTime.Compare(uiDate, serviceDate);
                Assert.IsTrue(i == 0, "Value is: " + i);
            }
            catch (Exception e)
            {
                iResult = false;
                Reports.TestResult = false;
                eErrorMsg = e.Message;
            }
            Reports.UpdateDebugLog("Verify", Reports.obj_class, "CompareUIDate", "", sExpectedVal, sActualVal, Reports.Result(iResult), eErrorMsg);
        }

        public static void CompareUIDate(IWebElement element, string sproperty, string sExpectedVal)
        {
            object PropValue = "";
            bool iResult = true;
            string eErrorMsg = Support.GeneralMessage;
            if (element.IsVisible(60000))
            {
                try
                {
                    PropValue = GetProperty(element, sproperty);
                    DateTime uiDate = Convert.ToDateTime(PropValue).Date;
                    DateTime serviceDate = Convert.ToDateTime(sExpectedVal).Date;
                    int i = DateTime.Compare(uiDate, serviceDate);
                    Support.IsTrue(i == 0, "Value is: " + i);
                }
                catch (Exception e)
                {
                    iResult = false;
                    eErrorMsg = e.Message;
                    Reports.TestResult = false;
                }
                Reports.UpdateDebugLog(Support.controlname, Reports.obj_class, "CompareUIDate", sproperty, sExpectedVal, PropValue.ToString(), Reports.Result(iResult), eErrorMsg);
            }
            else
            {
                Reports.UpdateDebugLog(Support.controlname, "", "CompareUIDate", sproperty, sExpectedVal, PropValue.ToString(), Reports.Result(false), eErrorMsg);
            }
        }

        /// <summary>
        /// This method gets the Date based on PST and compare with current Date and return true if same
        /// </summary>
        /// <returns></returns>
        public static bool IsCurrentDateSameInPSTAndIST()
        {
            DateTime dt = DateTime.Now;
            DateTime newDateTime = TimeZoneInfo.ConvertTime(dt, TimeZoneInfo.FindSystemTimeZoneById("Pacific Standard Time"));

            bool result = newDateTime < dt.Date;
            bool finalResult = !(result);
            return finalResult;
        }

        /// <summary>
        /// Method to verify whetether the  controls value for the specified property contains given value 
        /// </summary>
        /// <param name="_fahtmlcontrol">FAHtmlInterface object</param>
        /// <param name="sproperty">Control property to check</param>
        /// <param name="sExpectedVal">Expected value</param>
        /// <param name="isRemoveSpecialCharacter">Boolean : To remove special charachters in the retreived value</param>
        /// <param name="removeComma">Boolean : If to remove only commas</param>
        public static void ContainsUIVal(IWebElement element, string sproperty, string sExpectedVal, bool isRemoveSpecialCharacter = false, bool removeComma = false)
        {
            object PropValue = "";
            bool iResult = true;
            string eErrorMsg = Support.GeneralMessage;
            if (element.IsVisible(60000))
            {
                try
                {
                    //FAHtmlControl _fahtmlcontrol1 = (FAHtmlControl)_fahtmlcontrol;
                    //_fahtmlcontrol.WaitForControlReady(General.syncTimeout);

                    PropValue = GetProperty(element, sproperty);
                    if (isRemoveSpecialCharacter)
                    {
                        PropValue = RemoveSpecialCharacters(PropValue.ToString(), removeComma);
                        sExpectedVal = RemoveSpecialCharacters(sExpectedVal, removeComma);
                    }
                    Support.IsTrue(PropValue.ToString().ToLower().Contains(sExpectedVal.ToLower()) || sExpectedVal.ToString().ToLower().Contains(PropValue.ToString().ToLower()), "Has the comparison returned true ?");
                }
                catch (Exception e)
                {
                    //Reports.CaptureImage();
                    iResult = false;
                    eErrorMsg = e.Message + ":" + eErrorMsg;
                    Reports.TestResult = false;
                }
                Reports.UpdateDebugLog(Support.controlname, Reports.obj_class, "ContainsUIVal", sproperty, sExpectedVal, PropValue.ToString(), Reports.Result(iResult), eErrorMsg);
            }
            else
            {
                Reports.UpdateDebugLog(Support.controlname, "", "ContainsUIVal", sproperty, sExpectedVal, PropValue.ToString(), Reports.Result(false), eErrorMsg);
            }
        }

        public static void ContainsUIVal(string actualVal, string expectedVal, bool isRemoveSpecialCharacter = false, bool removeComma = false)
        {
            bool areEqual = false;
            string eErrorMsg = "";
            try
            {
                if (isRemoveSpecialCharacter)
                {
                    actualVal = RemoveSpecialCharacters(actualVal.ToString(), removeComma).Replace(" ", "");
                    expectedVal = RemoveSpecialCharacters(expectedVal, removeComma).Replace(" ", "");
                }
                Assert.IsTrue(actualVal.ToString().ToLower().Contains(expectedVal.ToLower()) || expectedVal.ToString().ToLower().Contains(actualVal.ToString().ToLower()));
                areEqual = true;
            }
            catch (Exception e)
            {

                Reports.TestResult = false;
                eErrorMsg = e.Message;
            }
            Reports.UpdateDebugLog("Verify", Reports.obj_class, "AreEqual", "", expectedVal, actualVal, Reports.Result(areEqual), eErrorMsg);

        }

        /// <summary>
        /// Method to verify whether the  controls value for the specified property equals given value 
        /// </summary>
        /// <param name="element">FAHtmlInterface object</param>
        /// <param name="sproperty">Control property to check</param>
        /// <param name="sExpectedVal">Expected value</param>
        /// <param name="isRemoveSpecialCharacter">Boolean : To remove special charachters in the retreived value</param>
        /// <param name="removeComma">Boolean : If to remove only commas</param>
        public static void CompareWithUI(IWebElement element, string sproperty, string sExpectedVal, bool isRemoveSpecialCharacter = false, bool removeComma = false)
        {
            object PropValue = "";
            bool iResult = true;
            string eErrorMsg = Support.GeneralMessage;
            if (element.IsVisible(60000))
            {
                try
                {
                    //FAHtmlControl _fahtmlcontrol1 = (FAHtmlControl)_fahtmlcontrol;
                    //element.WaitForControlReady(General.syncTimeout);

                    PropValue = GetProperty(element, sproperty);
                    if (isRemoveSpecialCharacter)
                    {
                        PropValue = RemoveSpecialCharacters(PropValue.ToString(), removeComma).Replace(" ", "");
                        sExpectedVal = RemoveSpecialCharacters(sExpectedVal, removeComma).Replace(" ", "");
                    }
                    Support.AreEqual(sExpectedVal.ToLower().Trim(), PropValue.ToString().ToLower().Trim());
                }
                catch(NullReferenceException)
                {
                    Support.AreEqual("", PropValue.ToString().ToLower().Trim());
                }
                catch (Exception e)
                {
                    //Reports.CaptureImage();
                    iResult = false;
                    eErrorMsg = e.Message;
                    Reports.TestResult = false;
                }
                Reports.UpdateDebugLog(Support.controlname, Reports.obj_class, "CompareWithUI", sproperty, sExpectedVal, PropValue.ToString(), Reports.Result(iResult), eErrorMsg);
            }
            else
            {
                Reports.UpdateDebugLog(Support.controlname, "", "CompareWithUI", sproperty, sExpectedVal, PropValue.ToString(), Reports.Result(false), eErrorMsg);
            }
        }

        public static void CompareWithUI(string actualVal, string expectedVal, bool isRemoveSpecialCharacter = false, bool removeComma = false)
        {
            bool areEqual = false;
            string eErrorMsg = "";
            try
            {
                if (isRemoveSpecialCharacter)
                {
                    actualVal = RemoveSpecialCharacters(actualVal.ToString(), removeComma).Replace(" ", "");
                    expectedVal = RemoveSpecialCharacters(expectedVal, removeComma).Replace(" ", "");
                }
                Assert.AreEqual(expectedVal.ToLower().Trim(), actualVal.ToString().ToLower().Trim());
                areEqual = true;
            }
            catch (Exception e)
            {

                Reports.TestResult = false;
                eErrorMsg = e.Message;
            }
            Reports.UpdateDebugLog("Verify", Reports.obj_class, "AreEqual", "", expectedVal, actualVal, Reports.Result(areEqual), eErrorMsg);

        }

        /// <summary>
        /// Removes the special characters from the string 
        /// </summary>
        /// <param name="str"></param>
        /// <param name="removeComma"></param>
        /// <returns></returns>
        public static string RemoveSpecialCharacters(string str, bool removeComma = false)
        {
            StringBuilder sb = new StringBuilder();
            if (removeComma)
            {
                return str.Replace(",", "");
            }

            else
            {
                str = Regex.Replace(str, @"[^0-9a-zA-Z]+", "");
                return str.ToString();
            }
        }

        private static string GetProperty(IWebElement element, string property)
        {
            string value = "";
            if (property.ToLower().Equals("selecteditem"))
            {
                value = element.FAGetSelectedItem();
            }
            if (property.ToLower().Equals("value") || property.ToLower().Equals("text"))
            {
                value = element.FAGetValue();
                if (value == null)
                {
                    value = element.FAGetText();
                    if (value == null)
                    {
                        value = element.FAGetAttribute(property);
                    }
                }
            }
            if(property.ToLower().Equals("checked")||property.ToLower().Equals("selected"))
            {
                value = element.IsSelected().ToString();
                if(value==null)
                {
                    value = element.FAGetAttribute(property);
                }
            }
            return value;
        }

        /// <summary>
        /// Author : Roopa
        /// Verify details inside PaymentDetails page matches the given values
        /// </summary>
        /// <param name="payDetails">PaymentData object</param>
        public static void Validate_PaymentMethod_CD(CDPaymentData payDetails)
        {
            try
            {
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();

                if (payDetails.Description != "")
                    CompareWithUI(FastDriver.PaymentDetailsDlg.Description.FAGetValue().ToString(), payDetails.Description, true, true);

                if (payDetails.PayTo != "")
                    CompareWithUI(FastDriver.PaymentDetailsDlg.PayTo.FAGetValue().ToString(), payDetails.PayTo);

                if (payDetails.LoanEstimateUnrounded != "")
                    CompareWithUI(FastDriver.PaymentDetailsDlg.LoanEstimateUnrounded.FAGetValue().ToString(), payDetails.LoanEstimateUnrounded, true);
                if (payDetails.LoanEstimateRounded != "")
                    CompareWithUI(FastDriver.PaymentDetailsDlg.LoanEstimateRounded.FAGetValue().ToString(), payDetails.LoanEstimateRounded + ".00", true);

                if (payDetails.BuyerCharge != "")
                    CompareWithUI(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().ToString(), payDetails.BuyerCharge, true);
                if (payDetails.PaymentMethodBorrowerAtClosing != "" && payDetails.PaymentMethodBorrowerAtClosing.ToLower() != "none")
                {
                    if (payDetails.PaymentMethodBorrowerAtClosing.ToString().ToLower() == "chk")
                        CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().ToString(), "check", true);
                    else
                        CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().ToString(), payDetails.PaymentMethodBorrowerAtClosing, true);
                }
                if (payDetails.PBBorrowerAtClosing != "" && payDetails.PBBorrowerAtClosing.ToLower() != "none")
                    CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().ToString(), payDetails.PBBorrowerAtClosing, true);
                if (payDetails.PBBorrowerBeforeClosing != "" && payDetails.PBBorrowerBeforeClosing.ToLower() != "none")
                    CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().ToString(), payDetails.PBBorrowerBeforeClosing, true);
                if (payDetails.PBOtherForBorrower != "" && payDetails.PBOtherForBorrower.ToLower() != "none")
                    CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue().ToString(), payDetails.PBOtherForBorrower, true);
                if (payDetails.PBOthersForBuyerPMTypeCdID != "" && payDetails.PBOthersForBuyerPMTypeCdID.ToLower() != "none")
                    CompareWithUI(FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString(), payDetails.PBOthersForBuyerPMTypeCdID, true);

                if (payDetails.SellerCharge != "")
                    CompareWithUI(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().ToString(), payDetails.SellerCharge, true);
                if (payDetails.PaymentMethodSellerAtClosing != "" && payDetails.PaymentMethodSellerAtClosing.ToLower() != "none")
                {
                    if (payDetails.PaymentMethodSellerAtClosing.ToString().ToLower() == "chk")
                        CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().ToString(), "check", true);
                    else
                        CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().ToString(), payDetails.PaymentMethodSellerAtClosing, true);
                }
                if (payDetails.PBSellerAtClosing != "" && payDetails.PBSellerAtClosing.ToLower() != "none")
                    CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().ToString(), payDetails.PBSellerAtClosing, true);
                if (payDetails.PBSellerBeforeClosing != "" && payDetails.PBSellerBeforeClosing.ToLower() != "none")
                    CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().ToString(), payDetails.PBSellerBeforeClosing, true);
                if (payDetails.PBOtherForSeller != "" && payDetails.PBOtherForSeller.ToLower() != "none")
                    CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue().ToString(), payDetails.PBOtherForSeller, true);
                if (payDetails.PBOthersForSellerPMTypeCdID != "" && payDetails.PBOthersForSellerPMTypeCdID.ToLower() != "none")
                    CompareWithUI(FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString(), payDetails.PBOthersForSellerPMTypeCdID, true);

                //Commented by Jorge - Reason: cannot use framework's TestResult status variable to report result of this scope; if there's a previous failure that is not related to this method, it will report this method failed.
                //if (Reports.TestResult == false)
                //{
                //    Reports.StatusUpdate("Validation of Payment Details Failed!", false);
                //}

                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(3000);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(3000);
            }
        }

        public static void ValidatePaymentAndGetCheckAMount(FASTWCFHelpers.FastFileService.CDChargePaymentDetails payeeData)
        {
            CDPaymentData borrowerPayDataCD = SetPayDataCD(payeeData);
            Validate_PaymentMethod_CD(borrowerPayDataCD);
            Playback.Wait(2000);
        }

        public static void ValidatePaymentAndGetCheckAMount(FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails payeeData)
        {
            CDPaymentData borrowerPayDataCD = SetPayDataCD(payeeData);
            Validate_PaymentMethod_CD(borrowerPayDataCD);
            Playback.Wait(2000);
        }

        public static CDPaymentData SetPayDataCD(FASTWCFHelpers.FastFileService.CDChargePaymentDetails payeeData)
        {
            CDPaymentData payData = new CDPaymentData();
            double checkAmount = 0.00;
            if (payeeData.LEAmount != null)
            {
                if (payeeData.LEAmount == 0)
                    payData.LoanEstimateUnrounded = "0.00";
                else
                    payData.LoanEstimateUnrounded = payeeData.LEAmount.ToString();
            }

            if (payeeData.LEAmount != null)
            {
                payData.LoanEstimateRounded = Math.Round(Convert.ToDouble(payeeData.LEAmount)).ToString();
            }

            if (payeeData.BuyerCharge != null)
            {
                if (payeeData.BuyerCharge == 0)
                    payData.BuyerCharge = "0.00";
                else
                    payData.BuyerCharge = payeeData.BuyerCharge.ToString();
            }
            if (payeeData.SellerCharge != null)
            {
                if (payeeData.SellerCharge == 0)
                    payData.SellerCharge = "0.00";
                else
                    payData.SellerCharge = payeeData.SellerCharge.ToString();
            }
            if (payeeData.AtClosingBuyerPaymentMethodTypeID != null)
            {
                payData.PaymentMethodBorrowerAtClosing = payeeData.AtClosingBuyerPaymentMethodTypeID.ToString();
                if (payData.PaymentMethodBorrowerAtClosing.ToLower().Equals("chk") || payData.PaymentMethodBorrowerAtClosing.ToLower().Equals("none"))
                {
                    if (payeeData.BuyerCharge != null)
                        checkAmount = checkAmount + Convert.ToDouble(payeeData.BuyerCharge.ToString());
                }
            }
            if (payeeData.AtClosingSellerPaymentMethodTypeID != null)
            {
                payData.PaymentMethodSellerAtClosing = payeeData.AtClosingSellerPaymentMethodTypeID.ToString();
                if (payData.PaymentMethodSellerAtClosing.ToLower().Equals("chk") || payData.PaymentMethodSellerAtClosing.ToLower().Equals("none"))
                {
                    if (payeeData.SellerCharge != null)
                        checkAmount = checkAmount + Convert.ToDouble(payeeData.SellerCharge.ToString());
                }
            }

            if (payeeData.PBSellerAtClosing != null)
            {
                if (payeeData.PBSellerAtClosing == 0)
                    payData.PBSellerAtClosing = "0.00";
                else payData.PBSellerAtClosing = payeeData.PBSellerAtClosing.ToString();
            }
            if (payeeData.PBSellerBeforeClosing != null)
            {
                if (payeeData.PBSellerBeforeClosing == 0)
                    payData.PBSellerBeforeClosing = "0.00";
                else
                    payData.PBSellerBeforeClosing = payeeData.PBSellerBeforeClosing.ToString();
            }
            if (payeeData.PBOthersForSeller != null)
            {
                if (payeeData.PBOthersForSeller == 0)
                    payData.PBOtherForSeller = "0.00";
                else
                    payData.PBOtherForSeller = payeeData.PBOthersForSeller.ToString();
            }

            if (payeeData.PBOthersForSellerPMTypeCdID != null || !(payData.PBOthersForSellerPMTypeCdID.ToLower().Equals("none")))
            {
                payData.PBOthersForSellerPMTypeCdID = payeeData.PBOthersForSellerPMTypeCdID.ToString();
            }

            if (payeeData.PBBuyerAtClosing != null)
            {
                if (payeeData.PBBuyerAtClosing == 0)
                    payData.PBBorrowerAtClosing = "0.00";
                else
                    payData.PBBorrowerAtClosing = payeeData.PBBuyerAtClosing.ToString();
            }
            if (payeeData.PBBuyerBeforeClosing != null)
            {
                if (payeeData.PBBuyerBeforeClosing == 0)
                    payData.PBBorrowerBeforeClosing = "0.00";
                else
                    payData.PBBorrowerBeforeClosing = payeeData.PBBuyerBeforeClosing.ToString();
            }
            if (payeeData.PBOthersForBuyer != null)
            {
                if (payeeData.PBOthersForBuyer == 0)
                    payData.PBOtherForBorrower = "0.00";
                else
                    payData.PBOtherForBorrower = payeeData.PBOthersForBuyer.ToString();
            }

            if (payeeData.PBOthersForBuyerPMTypeCdID != null || !(payData.PaymentMethodSellerAtClosing.ToLower().Equals("none")))
            {
                payData.PBOthersForBuyerPMTypeCdID = payeeData.PBOthersForBuyerPMTypeCdID.ToString();
            }
            payData.CheckAmount = checkAmount;
            return payData;
        }

        public static CDPaymentData SetPayDataCD(FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails payeeData)
        {
            CDPaymentData payData = new CDPaymentData();
            double checkAmount = 0.00;
            if (payeeData.LEAmount != null)
            {
                if (payeeData.LEAmount == 0)
                    payData.LoanEstimateUnrounded = "0.00";
                else
                    payData.LoanEstimateUnrounded = payeeData.LEAmount.ToString();
            }

            if (payeeData.LEAmount != null)
            {
                payData.LoanEstimateRounded = Math.Round(Convert.ToDouble(payeeData.LEAmount)).ToString();
            }

            if (payeeData.BuyerCharge != null)
            {
                if (payeeData.BuyerCharge == 0)
                    payData.BuyerCharge = "0.00";
                else
                    payData.BuyerCharge = payeeData.BuyerCharge.ToString();
            }
            if (payeeData.SellerCharge != null)
            {
                if (payeeData.SellerCharge == 0)
                    payData.SellerCharge = "0.00";
                else
                    payData.SellerCharge = payeeData.SellerCharge.ToString();
            }
            if (payeeData.AtClosingBuyerPaymentMethodTypeID != null)
            {
                payData.PaymentMethodBorrowerAtClosing = payeeData.AtClosingBuyerPaymentMethodTypeID.ToString();
                if (payData.PaymentMethodBorrowerAtClosing.ToLower().Equals("chk") || payData.PaymentMethodBorrowerAtClosing.ToLower().Equals("none"))
                {
                    if (payeeData.BuyerCharge != null)
                        checkAmount = checkAmount + Convert.ToDouble(payeeData.BuyerCharge.ToString());
                }
            }
            if (payeeData.AtClosingSellerPaymentMethodTypeID != null)
            {
                payData.PaymentMethodSellerAtClosing = payeeData.AtClosingSellerPaymentMethodTypeID.ToString();
                if (payData.PaymentMethodSellerAtClosing.ToLower().Equals("chk") || payData.PaymentMethodSellerAtClosing.ToLower().Equals("none"))
                {
                    if (payeeData.SellerCharge != null)
                        checkAmount = checkAmount + Convert.ToDouble(payeeData.SellerCharge.ToString());
                }
            }

            if (payeeData.PBSellerAtClosing != null)
            {
                if (payeeData.PBSellerAtClosing == 0)
                    payData.PBSellerAtClosing = "0.00";
                else payData.PBSellerAtClosing = payeeData.PBSellerAtClosing.ToString();
            }
            if (payeeData.PBSellerBeforeClosing != null)
            {
                if (payeeData.PBSellerBeforeClosing == 0)
                    payData.PBSellerBeforeClosing = "0.00";
                else
                    payData.PBSellerBeforeClosing = payeeData.PBSellerBeforeClosing.ToString();
            }
            if (payeeData.PBOthersForSeller != null)
            {
                if (payeeData.PBOthersForSeller == 0)
                    payData.PBOtherForSeller = "0.00";
                else
                    payData.PBOtherForSeller = payeeData.PBOthersForSeller.ToString();
            }

            if (payeeData.PBOthersForSellerPMTypeCdID != null || !(payData.PBOthersForSellerPMTypeCdID.ToLower().Equals("none")))
            {
                payData.PBOthersForSellerPMTypeCdID = payeeData.PBOthersForSellerPMTypeCdID.ToString();
            }

            if (payeeData.PBBuyerAtClosing != null)
            {
                if (payeeData.PBBuyerAtClosing == 0)
                    payData.PBBorrowerAtClosing = "0.00";
                else
                    payData.PBBorrowerAtClosing = payeeData.PBBuyerAtClosing.ToString();
            }
            if (payeeData.PBBuyerBeforeClosing != null)
            {
                if (payeeData.PBBuyerBeforeClosing == 0)
                    payData.PBBorrowerBeforeClosing = "0.00";
                else
                    payData.PBBorrowerBeforeClosing = payeeData.PBBuyerBeforeClosing.ToString();
            }
            if (payeeData.PBOthersForBuyer != null)
            {
                if (payeeData.PBOthersForBuyer == 0)
                    payData.PBOtherForBorrower = "0.00";
                else
                    payData.PBOtherForBorrower = payeeData.PBOthersForBuyer.ToString();
            }

            if (payeeData.PBOthersForBuyerPMTypeCdID != null || !(payData.PaymentMethodSellerAtClosing.ToLower().Equals("none")))
            {
                payData.PBOthersForBuyerPMTypeCdID = payeeData.PBOthersForBuyerPMTypeCdID.ToString();
            }
            payData.CheckAmount = checkAmount;
            return payData;
        }

        public static string GetText(IWebElement element)
        {
            return (element.FAGetValue() ?? element.FAGetText() ?? element.FAGetAttribute("text"));
        }
    }

    public class CDPaymentData
    {
        private string description = "";
        private string buyerCharge = "";
        private string sellerCharge = "";
        private string loanEstimateUnrounded = "";
        private string loanEstimateRounded = "";
        private string paymentMethodBorrowerAtClosing = "";
        private string paymentMethodSellerAtClosing = "";
        private string pBBorrowerAtClosing = "";
        private string pBBorrowerBeforeClosing = "";
        private string pBOtherForBorrower = "";
        private string payTo = "";
        private string pBSellerAtClosing = "";
        private string pBSellerBeforeClosing = "";
        private string pBOtherForSeller = "";
        private string pBOthersForBuyerPMTypeCdID = "";
        private string pBOthersForSellerPMTypeCdID = "";
        private double checkAmount = 0;

        public string Description
        {
            get
            {
                return description;
            }
            set
            {
                description = value;
            }
        }
        public string BuyerCharge
        {
            get
            {
                return buyerCharge;
            }
            set
            {
                buyerCharge = value;
            }
        }
        public string SellerCharge
        {
            get
            {
                return sellerCharge;
            }
            set
            {
                sellerCharge = value;
            }
        }
        public string LoanEstimateUnrounded
        {
            get
            {
                return loanEstimateUnrounded;
            }
            set
            {
                loanEstimateUnrounded = value;
            }
        }
        public string LoanEstimateRounded
        {
            get
            {
                return loanEstimateRounded;
            }
            set
            {
                loanEstimateRounded = value;
            }
        }
        public string PaymentMethodBorrowerAtClosing
        {
            get
            {
                return paymentMethodBorrowerAtClosing;
            }
            set
            {
                paymentMethodBorrowerAtClosing = value;
            }
        }
        public string PaymentMethodSellerAtClosing
        {
            get
            {
                return paymentMethodSellerAtClosing;
            }
            set
            {
                paymentMethodSellerAtClosing = value;
            }
        }
        public string PBBorrowerAtClosing
        {
            get
            {
                return pBBorrowerAtClosing;
            }
            set
            {
                pBBorrowerAtClosing = value;
            }
        }

        public string PBBorrowerBeforeClosing
        {
            get
            {
                return pBBorrowerBeforeClosing;
            }
            set
            {
                pBBorrowerBeforeClosing = value;
            }
        }
        public string PBOtherForBorrower
        {
            get
            {
                return pBOtherForBorrower;
            }
            set
            {
                pBOtherForBorrower = value;
            }
        }
        public string PBSellerAtClosing
        {
            get
            {
                return pBSellerAtClosing;
            }
            set
            {
                pBSellerAtClosing = value;
            }
        }
        public string PBSellerBeforeClosing
        {
            get
            {
                return pBSellerBeforeClosing;
            }
            set
            {
                pBSellerBeforeClosing = value;
            }
        }
        public string PBOtherForSeller
        {
            get
            {
                return pBOtherForSeller;
            }
            set
            {
                pBOtherForSeller = value;
            }
        }
        public string PBOthersForBuyerPMTypeCdID
        {
            get
            {
                return pBOthersForBuyerPMTypeCdID;
            }
            set
            {
                pBOthersForBuyerPMTypeCdID = value;
            }
        }
        public string PBOthersForSellerPMTypeCdID
        {
            get
            {
                return pBOthersForSellerPMTypeCdID;
            }
            set
            {
                pBOthersForSellerPMTypeCdID = value;
            }
        }

        public string PayTo
        {
            get
            {
                return payTo;
            }
            set
            {
                payTo = value;
            }
        }
        public double CheckAmount
        {
            get
            {
                return checkAmount;
            }
            set
            {
                checkAmount = value;
            }
        }

    }

    public static class OperationResponseExtensions
    {
        public static void Validate(this OperationResponse response)
        {
            Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
        }

        public static void Validate(this FASTWCFHelpers.FastEscrowService.OperationResponse response)
        {
            Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
        }

        public static void Validate(this FASTWCFHelpers.FastClosingDisclosureService.OperationResponse response)
        {
            Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
        }

        public static void Validate(this FASTWCFHelpers.FastAdminService.OperationResponse response)
        {
            Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
        }

        public static void Validate(this FASTWCFHelpers.FastDocumentService.OperationResponse response)
        {
            Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
        }
        
    }
}