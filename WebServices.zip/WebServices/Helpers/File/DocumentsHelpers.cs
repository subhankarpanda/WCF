﻿using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebServices.Helpers.File
{
    class DocumentsHelpers
    {

        public static DocTemplateResponse GetDefaultDocTemplates()
        {
            DocTemplateResponse response = null;

            try
            {
                var GetDocTempReq = RequestFactory.GetDocTemplatesDefaultRequest();
                response = FASTWCFHelpers.FileService.GetDocTemplates(GetDocTempReq);

                Reports.StatusUpdate("GetDefaultDocTemplates", true, "Count: " + response.Templates.Count().ToString());

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetDefaultDocTemplates" , false, ex.Message);
            }

            return response;

        }

        public static DocumentResponse CreateDocument(int fileID, int templateID)
        {
            DocumentResponse response = null;

            try
            {
                var CreateDocReq = RequestFactory.GetCreateDocumentDefaultRequest(fileID, templateID);
                CreateDocReq.FileID = fileID;
                CreateDocReq.TemplateID = templateID;
                response = FASTWCFHelpers.FileService.CreateDocument(CreateDocReq);

                Reports.StatusUpdate("CreateDocument" , true, "DocID: " + response.DocumentID.ToString());
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("CreateDocument" , false, ex.Message);
            }

            return response;
        }

        public static CopyDocumentsResponse CopyDocuments(string sourceFile, string targetFile, int[] docIDs = null, int[] imageIDs = null)
        {
            CopyDocumentsResponse response = null;

            try
            {
                var GetDocTempReq = RequestFactory.GetCopyDocumentDefaultRequest(sourceFile, targetFile, Convert.ToInt32(AutoConfig.SelectedRegionBUID), docIDs, imageIDs);
                response = FASTWCFHelpers.FileService.CopyDocuments(GetDocTempReq);

                Reports.StatusUpdate("CopyDocuments", true, "From: " + sourceFile + " To: " + targetFile);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("CopyDocuments", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse AddPhrasesToDocument(int fileID, int docID, string phraseCode = @"XRL/15", int region = 1486, int position = 1)
        {
            OperationResponse response = null;

            try
            {
                var request = RequestFactory.GetAddPhraseDefaultRequest();
                request.DocumentID = docID;
                request.FileID = fileID;
                request.Phrases[0].PhraseCode = phraseCode;
                request.Phrases[0].PhraseRegionID = region;
                request.PositionToInsert = position;
                request.LoginName = @"fastts\fastqa07";
                request.Source = @"FAMOS";
                response = FASTWCFHelpers.FileService.AddPhrasesToDocument(request);

                Reports.StatusUpdate("AddPhrasesToDocument", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("AddPhrasesToDocument", false,  ex.Message);
            }

            return response;
        }

        public static int SubmitDocRequest(int fileID, int docID)
        {
            int response = 0;

            try
            {
                response = FASTWCFHelpers.FileService.SubmitDocRequest(fileID, docID);

                Reports.StatusUpdate("SubmitDocRequest", true,  "docRequestID: " + response.ToString());
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("SubmitDocRequest" , false,  ex.Message);
            }

            return response;
        }

        public static DocPrepDocumentResponse GetDocPrepDocument(int docRequestID)
        {
            DocPrepDocumentResponse response = null;

            try
            {
                response = FASTWCFHelpers.FileService.GetDocPrepDocument(docRequestID);

                Reports.StatusUpdate("GetDocPrepDocument", true, response.StatusMessage);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetDocPrepDocument", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse CreateImageDocument(int fileID, int docID)
        {
            OperationResponse response = null;

            try
            {
                var request = RequestFactory.GetCreateImageDocumentDefaultRequest();
                request.DocumentID = docID;
                request.FileID = fileID;

                response = FASTWCFHelpers.FileService.CreateImageDocument(request);

                Reports.StatusUpdate("CreateImageDocument", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("CreateImageDocument", false, ex.Message);
            }

            return response;
        }

        public static DocumentDetailsResponse GetDocumentDetails(int fileID, int docID)
        {
            DocumentDetailsResponse response = null;

            try
            {
                response = FASTWCFHelpers.FileService.GetDocumentDetails(fileID, docID);

                Reports.StatusUpdate("GetDocumentDetails", true, response.StatusMessage);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetDocumentDetails", false, ex.Message);
            }

            return response;
        }

        public static DocumentListResponse GetDocuments(int fileID)
        {
            DocumentListResponse response = null;

            try
            {
                response = FASTWCFHelpers.FileService.GetDocuments(fileID);

                Reports.StatusUpdate("GetDocuments", true, "Document count: " + response.Documents.Count().ToString() + "; Image count: " + response.Images.Count().ToString());
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetDocuments", false, ex.Message);
            }

            return response;
        }

        public static ImageDocumentDetailsResponse GetImageDocumentDetails(int fileID, int docID)
        {
            ImageDocumentDetailsResponse response = null;

            try
            {
                response = FASTWCFHelpers.FileService.GetImageDocumentDetails(fileID, docID);

                Reports.StatusUpdate("GetImageDocumentDetails", true, response.ImageName);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetImageDocumentDetails", false, ex.Message);
            }

            return response;
        }

        public static GetImageDocument2Response GetImageDocument2(int docID)
        {
            GetImageDocument2Response response = null;

            try
            {
                var request = RequestFactory.GetImageDocument2DefaultRequest(docID);
                response = FASTWCFHelpers.FileService.GetImageDocument2(request);

                Reports.StatusUpdate("GetImageDocument2", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetImageDocument2", false, ex.Message);
            }

            return response;
        }

        public static StateListForDocTemplateResponse GetStateListForDocTemplate(int templateID)
        {
            StateListForDocTemplateResponse response = null;

            try
            {
                var request = RequestFactory.GetStateListForDocTemplateDefaultRequest(templateID);
                response = FASTWCFHelpers.FileService.GetStateListForDocTemplate(request);

                Reports.StatusUpdate("GetStateListForDocTemplate", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetStateListForDocTemplate", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse RemoveDocument(int fileID, int docID)
        {
            OperationResponse response = null;

            try
            {
                var request = RequestFactory.GetRemoveDocumentDefaultRequest(fileID);
                request.DocumentID = docID;
                response = FASTWCFHelpers.FileService.RemoveDocument(request);

                Reports.StatusUpdate("RemoveDocument", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("RemoveDocument", false, ex.Message);
            }

            return response;
        }

        public static StarterRefDocumentResponse GetDocumentsForStarterRef(int fileID)
        {
            StarterRefDocumentResponse response = null;

            try
            {
                var request = RequestFactory.GetStarterRefDocumentDefaultRequest(fileID);
                response = FASTWCFHelpers.FileService.GetDocumentsForStarterRef(request);

                Reports.StatusUpdate("GetDocumentsForStarterRef", true, "Document Count: " + response.Documents.Count().ToString());
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetDocumentsForStarterRef", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse GetImageDocument(int docID, int docVersion = 0)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.FileService.GetImageDocument(docID, docVersion);

                Reports.StatusUpdate("GetImageDocument", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetImageDocument", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse EditDocument(int fileID, int docID, string editDocName)
        {
            OperationResponse response = null;

            try
            {
                var request = RequestFactory.GetEditDocumentDefaultRequest(fileID, docID, editDocName);
                response = FASTWCFHelpers.FileService.EditDocument(request);

                Reports.StatusUpdate("EditDocument", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("EditDocument", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse FinalizeDocument(int fileID, int docID)
        {
            OperationResponse response = null;

            try
            {
                var request = RequestFactory.GetFinalizeDocumentRequest(fileID, docID);
                response = FASTWCFHelpers.FileService.FinalizeDocument(request);

                Reports.StatusUpdate("FinalizeDocument", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("FinalizeDocument", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse UnfinalizeDocument(int fileID, int docID)
        {
            OperationResponse response = null;

            try
            {
                var request = RequestFactory.GetUnfinalizeDocumentRequest(fileID, docID);
                response = FASTWCFHelpers.FileService.UnfinalizeDocument(request);

                Reports.StatusUpdate("UnfinalizeDocument", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("UnfinalizeDocument", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse UpdateDocument(int fileID, int docID)
        {
            OperationResponse response = null;

            try
            {
                var request = RequestFactory.GetUpdateDocumentDefaultRequest(docID, fileID);
                response = FASTWCFHelpers.FileService.UpdateDocument(request);

                Reports.StatusUpdate("UpdateDocument", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("UpdateDocument", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse DeletePhraseFromDocument(int fileID, int docID, long phraseID)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.FileService.DeletePhrases(RequestFactory.GetDeletePhraseRequest(fileID,docID,phraseID));
                Reports.StatusUpdate("DeletePhrasesFromDocument", true, "PhraseID: "+phraseID.ToString()+ "is Deleted.");
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("DeletePhrasesFromDocument", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse UpdatePhraseOfDocument(int fileID, int docID, long phraseID)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.FileService.UpdatePhrase(RequestFactory.GetDefaultUpdatePhraseRequest(fileID,docID,phraseID));
                if (response.Status == 1)
                {
                    Reports.StatusUpdate("UpdatePhraseOfDocument", true, "Document ID: " + docID.ToString() + "is updated.");
                }
                else
                {
                    Reports.StatusUpdate("UpdatePhraseOfDocument", false, "Document is not updated.");
                }
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("UpdatePhraseOfDocument", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse MovePhraseOfDocument(DocumentDetailsResponse docresponse)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.FileService.MovePhrase(RequestFactory.GetMovePhraseRequest(docresponse));
                if (response.Status == 1)
                {
                    Reports.StatusUpdate("Phrase has been moved successfuly:", true);
                }
                else
                {
                    Reports.StatusUpdate("Phrase has not been moved successfuly", false);
                }
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("MovePhraseOfDocument", false, ex.Message);
            }

            return response;
        }

        public static ViewPhraseResponse ViewPhraseText(string phraseCode, int phraseRegionID)
        {
            ViewPhraseResponse response = null;
            try
            {
                response = FASTWCFHelpers.FileService.ViewPhraseText(RequestFactory.GetViewPhraseTextRequest(phraseCode, phraseRegionID));
                if (response.Status == 1)
                {
                    Reports.StatusUpdate("ViewPhraseText for the phrase " + phraseCode + " has been invoked successfuly:", true);
                }
                else
                {
                    Reports.StatusUpdate("ViewPhraseText for the phrase " + phraseCode + " has not been invoked successfuly", false);
                }
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("ViewPhraseText", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse UploadImage(int fileID, string docName, string docType, int docTypeID, string imageFileName)
        {
            OperationResponse response = null;

            byte[] bytes = System.IO.File.ReadAllBytes(imageFileName);

            try
            {
                var request = RequestFactory.GetUploadImageDefaultRequest(fileID, docName, docType, docTypeID, bytes);
                response = FASTWCFHelpers.FileService.UploadImage(request);

                Reports.StatusUpdate("UploadImage", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("UploadImage", false, ex.Message);
            }

            return response;
        }

        public static UploadImage2Response UploadImage2(int fileID, string docName, string docType, int docTypeID, string imageFileName)
        {
            UploadImage2Response response = null;

            byte[] bytes = System.IO.File.ReadAllBytes(imageFileName);

            try
            {
                var request = RequestFactory.GetUploadImage2DefaultRequest(fileID, docName, docType, docTypeID, bytes);
                response = FASTWCFHelpers.FileService.UploadImage2(request);

                Reports.StatusUpdate("UploadImage2", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("UploadImage2", false, ex.Message);
            }

            return response;
        }

        public static DocumentResponse CreateAssociateDocPackage(int fileID, Document[] docs, string packageName)
        {
            DocumentResponse response = null;

            try
            {
                var request = RequestFactory.GetCreateAssociateDocPackageDefaultRequest(fileID, docs, packageName);
                response = FASTWCFHelpers.FileService.CreateAssociateDocPackage(request);

                Reports.StatusUpdate("CreateAssociateDocPackage", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("CreateAssociateDocPackage", false, ex.Message);
            }

            return response;
        }

        public static AssociateDocPackageResponse GetAssociateDocPackages(int fileID)
        {
            AssociateDocPackageResponse response = null;

            try
            {
                response = FASTWCFHelpers.FileService.GetAssociateDocPackages(fileID);

                Reports.StatusUpdate("GetAssociateDocPackages", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetAssociateDocPackages", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse AddDocumentsToAssociateDocPackage(int fileID, Document[] docs, long packageID)
        {
            OperationResponse response = null;

            try
            {
                var request = RequestFactory.GetAddDocumentToAssociateDocPackageDefaultRequest(fileID, docs);
                request.PackageID = (int) packageID;
                response = FASTWCFHelpers.FileService.AddDocumentsToAssociateDocPackage(request);

                Reports.StatusUpdate("AddDocumentsToAssociateDocPackage", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("AddDocumentsToAssociateDocPackage", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse RemoveDocumentsToAssociateDocPackage(int fileID, Document[] docs, long packageID)
        {
            OperationResponse response = null;

            try
            {
                var request = RequestFactory.GetRemoveDocumentsFromAssociateDocPackageDefaultRequest(fileID, docs);
                request.PackageID = (int)packageID;
                response = FASTWCFHelpers.FileService.RemoveDocumentsFromAssociateDocPackage(request);

                Reports.StatusUpdate("RemoveDocumentsToAssociateDocPackage", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("RemoveDocumentsToAssociateDocPackage", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse ModifyAssociateDocPackage(int fileID, Document[] docs, long packageID, string packageName = null, bool changeSequence = false)
        {
            OperationResponse response = null;

            try
            {
                var request = RequestFactory.GetModifyAssociateDocPackageDefaultRequest(fileID, docs);
                request.PackageID = (int) packageID;
                request.PackageName = packageName;
                if (changeSequence)
                {
                    request.DocumentList[0].SeqNum = 3;
                    request.DocumentList[1].SeqNum = 1;
                    request.DocumentList[2].SeqNum = 2;
                }
                response = FASTWCFHelpers.FileService.ModifyAssociateDocPackage(request);

                Reports.StatusUpdate("ModifyAssociateDocPackage", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("ModifyAssociateDocPackage", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse RemoveAssociateDocPackage(int fileID, Document[] docs, long packageID)
        {
            OperationResponse response = null;

            try
            {
                var request = RequestFactory.GetRemoveAssociateDocPackageDefaultRequest(fileID, docs);
                request.PackageID = (int)packageID;
                response = FASTWCFHelpers.FileService.RemoveAssociateDocPackage(request);

                Reports.StatusUpdate("RemoveAssociateDocPackage", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("RemoveAssociateDocPackage", false, ex.Message);
            }

            return response;
        }
        
        public static OperationResponse AddPhraseMarker(int fileID, int docID)
        {
            var respnc = new OperationResponse();
            try
            {
                respnc = FASTWCFHelpers.FileService.AddPhraseMarker(RequestFactory.GetAddPhraseMarkerDefaultRequest(fileID, docID));
                if(respnc.Status==1)
                {
                    Reports.StatusUpdate("AddPhraseMarker service has been invoked successfully.", true);
                }
                else
                {
                    Reports.StatusUpdate("AddPhraseMarker service is not invoked successfully.",false);
                }
            }
            catch
            {
                Reports.StatusUpdate("AddPhraseMarker service is not invoked successfully.", false);
            }
            return respnc;
        }

        public static DocPhraseResponse WaiveorUnWaivePhrase(int fileID,int docID,long  docPhraseID,bool beWaiveFlag=false)
        {
            DocPhraseResponse respnc = null;
            try
            {
                respnc = FASTWCFHelpers.FileService.GetPhraseWaivedorUnwaived(FileRequestFactory.GetWaiveOrUnWaivePhraseRequest(fileID, docID, docPhraseID, beWaiveFlag));
                Reports.StatusUpdate(respnc.StatusDescription, (respnc.Status == 1) ? true : false);
            }
            catch
            {
                Reports.StatusUpdate("WaiveorUnwaivephrase webservice is not invoked successfully.", false);
            }
            return respnc;
        }
    }
}
