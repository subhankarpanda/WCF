﻿using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebServices.Helpers.File
{
    class DeliveryHelpers
    {
        public static DeliveryResponse WintrackDelivery(WintrackDeliveryRequest request)
        {
            DeliveryResponse response = null;

            try
            {
                response = FASTWCFHelpers.FileService.WintrackDelivery(request);

                Reports.StatusUpdate("WintrackDelivery", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("WintrackDelivery", false, ex.Message);
            }

            return response;

        }

        public static DeliveryResponse FastWebDelivery(FastWebDeliveryRequest request)
        {
            DeliveryResponse response = null;

            try
            {
                response = FASTWCFHelpers.FileService.FastWebDelivery(request);

                Reports.StatusUpdate("FastWebDelivery", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("FastWebDelivery", false, ex.Message);
            }

            return response;

        }

        public static DeliveryResponse LACOMDelivery(LACOMDeliveryRequest request)
        {
            DeliveryResponse response = null;

            try
            {
                response = FASTWCFHelpers.FileService.LACOMDelivery(request);

                Reports.StatusUpdate("LACOMDelivery", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("LACOMDelivery", false, ex.Message);
            }

            return response;

        }

        public static DeliveryResponse InvoiceDelivery(InvoiceFeesDeliveryRequest request)
        {
            DeliveryResponse response = null;

            try
            {
                response = FASTWCFHelpers.FileService.InvoiceDelivery(request);

                Reports.StatusUpdate("InvoiceDelivery", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("InvoiceDelivery", false, ex.Message);
            }

            return response;

        }


    }
}
