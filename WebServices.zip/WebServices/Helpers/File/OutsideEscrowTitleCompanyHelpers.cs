﻿using FASTWCFHelpers.FastFileService;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebServices.Helpers.File
{
    class OutsideEscrowTitleCompanyHelpers
    {
        public static OperationResponse CreateOutsideEscrowCompany(OECRequest request)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.FileService.CreateOutsideEscrowCompany(request);

                Reports.StatusUpdate("CreateOutsideEscrowCompany", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("CreateOutsideEscrowCompany", false, ex.Message);
            }

            return response;
        }

        public static CreateOutsideTitleCompanyResponse CreateOutsideTitleCompany(CreateOutsideTitleCompanyRequest request)
        {
            CreateOutsideTitleCompanyResponse response = null;

            try
            {
                response = FASTWCFHelpers.FileService.CreateOutsideTitleCompany(request);

                Reports.StatusUpdate("CreateOutsideTitleCompany", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("CreateOutsideTitleCompany", false, ex.Message);
            }

            return response;
        }

    }
}
