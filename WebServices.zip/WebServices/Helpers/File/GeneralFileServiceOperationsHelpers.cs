﻿using FASTWCFHelpers.FastFileService;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebServices.Helpers.File
{
    class GeneralFileServiceOperationsHelpers
    {

        public static int CreateFile(CreateFileRequest request = null)
        {
            string fileNum = "";
            int fileID = 0;

            try
            {
                fileID = (int)FASTWCFHelpers.FileService.CreateFile(request).FileID;
                fileNum = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.StatusUpdate("CreateFile", true, fileNum);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("CreateFile", false, ex.Message);
            }

            return fileID;
        }

        public static OperationResponse UpdateHUD1StatementDetails(HUDStatementRequest request)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.FileService.UpdateHUD1StatementDetails(request);

                Reports.StatusUpdate("UpdateHUD1StatementDetails", true);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("UpdateHUD1StatementDetails", false, ex.Message);
            }

            return response;
        }

    }
}
