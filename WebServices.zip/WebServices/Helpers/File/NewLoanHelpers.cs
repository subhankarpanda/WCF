﻿using FASTWCFHelpers.FastFileService;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebServices.Helpers.File
{
    class NewLoanHelpers
    {
        public static OperationResponse RemoveNewLoanRelatedParty(RemoveRelatedPartyRequest request)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.FileService.RemoveNewLoanRelatedParty(request);

                Reports.StatusUpdate("RemoveNewLoanRelatedParty", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("RemoveNewLoanRelatedParty", false, ex.Message);
            }

            return response;

        }

        public static AddLenderLoanInvestorResponse AddLenderLoanInvestor(AddLenderLoanInvestorRequest request)
        {
            AddLenderLoanInvestorResponse response = null;

            try
            {
                response = FASTWCFHelpers.FileService.AddLenderLoanInvestor(request);

                Reports.StatusUpdate("AddLenderLoanInvestor", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("AddLenderLoanInvestor", false, ex.Message);
            }

            return response;

        }

        
    }
}
