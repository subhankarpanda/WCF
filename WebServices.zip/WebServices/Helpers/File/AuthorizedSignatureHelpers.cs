﻿using FASTWCFHelpers.FastFileService;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebServices.Helpers.File
{
    public class AuthorizedSignatureHelpers
    {
        public static void VerifyIndividualSignatureTypes(IndividualSignatureType[] expectedTypes, IndividualSignatureType[] receivedTypes)
        {
            Support.AreEqual(expectedTypes.Count().ToString(), receivedTypes.Count().ToString(), "expected IndividualSignatureTypes size");
            for (int i = 0; i < expectedTypes.Count(); i++)
            {
                Support.AreEqual(expectedTypes[i].Description, receivedTypes[i].Description, "Description");
                Support.AreEqual(expectedTypes[i].ObjectCD, receivedTypes[i].ObjectCD, "ObjectCD");
                Support.AreEqual(expectedTypes[i].TypeCdID.ToString(), receivedTypes[i].TypeCdID.ToString(), "TypeCdID");
            }
        }

        public static void VerifyHusbandWifeSignatureTypes(HusbandWifeSignatureType[] expectedTypes, HusbandWifeSignatureType[] receivedTypes)
        {
            Support.AreEqual(expectedTypes.Count().ToString(), receivedTypes.Count().ToString(), "expected HusbandWifeSignatureTypes size");
            for (int i = 0; i < expectedTypes.Count(); i++)
            {
                Support.AreEqual(expectedTypes[i].Description, receivedTypes[i].Description, "Description");
                Support.AreEqual(expectedTypes[i].ObjectCD, receivedTypes[i].ObjectCD, "ObjectCD");
                Support.AreEqual(expectedTypes[i].TypeCdID.ToString(), receivedTypes[i].TypeCdID.ToString(), "TypeCdID");
            }
        }

        public static void VerifyTrustEstateSignatureTypes(TrustEstateSignatureType[] expectedTypes, TrustEstateSignatureType[] receivedTypes)
        {
            Support.AreEqual(expectedTypes.Count().ToString(), receivedTypes.Count().ToString(), "expected TrustEstateSignatureTypes size");
            for (int i = 0; i < expectedTypes.Count(); i++)
            {
                Support.AreEqual(expectedTypes[i].Description, receivedTypes[i].Description, "Description");
                Support.AreEqual(expectedTypes[i].ObjectCD, receivedTypes[i].ObjectCD, "ObjectCD");
                Support.AreEqual(expectedTypes[i].TypeCdID.ToString(), receivedTypes[i].TypeCdID.ToString(), "TypeCdID");
            }
        }
    }
}
