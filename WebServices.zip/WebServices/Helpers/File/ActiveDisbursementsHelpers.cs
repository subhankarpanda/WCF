﻿using FASTWCFHelpers.FastFileService;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebServices.Helpers.File
{
    class ActiveDisbursementsHelpers
    {
        public static DisbursementHistoryResponse GetDisbursementHistorySummary(int fileID,string loginName)
        {
            DisbursementHistoryResponse response = null;
            try
            {
                response = FASTWCFHelpers.FileService.GetDisbursementHistorySummary(fileID, loginName);
                Reports.StatusUpdate("GetDisbursementHistorySummary webservice is invoked successfuly.", true);
            }
            catch
            {
                Reports.StatusUpdate("GetDisbursementHistorySummary webservice is not invoked successfuly.", false);
            }
            return response;
        }
    }
}
