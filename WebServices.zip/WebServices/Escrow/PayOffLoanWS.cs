﻿using FASTSelenium.Common;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Globalization;

namespace WebServices.Escrow
{
    [CodedUITest]
  public  class PayOffLoanWS : MasterTestClass
    {
        //
        [TestMethod]
        [Description("Verify PayoffLoanPayChargesAssociation() service functionality")]
        public void REG_PayoffLoanPayChargesAssociation()
        {
            try
            {
                Reports.TestStep = "Verify PayoffLoanPayChargesAssociation() service";
                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTHelpers.FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke CreatePayOffLoan service";
                var CreatePayoffLoanReq = FileRequestFactory.GetDefaultPayoffLoanRequestWithCharge(FASTHelpers.File.FileID.ToString());
                var CreatePayoffLoanRes = FASTWCFHelpers.FileService.CreatePayoffLoan(CreatePayoffLoanReq);
                Support.AreEqual("1", CreatePayoffLoanRes.Status.ToString(), CreatePayoffLoanRes.StatusDescription);
               
                #region Variables
                var cdPrincipalBalanceAmt = CreatePayoffLoanReq.PayOffLenderOrigPrincipalBal;
                var cdPyoffLnpayoffloancharges = CreatePayoffLoanReq.CDPayoffLoanCharges;
                #endregion
                #region Invoke GetPayoffLoanDetails service
                Reports.TestStep = "Invoke GetPayoffLoanDetails service to get the details of Payoff Loan instance";
                var Request = EscrowRequestFactory.GetServiceFileRequest(FASTHelpers.File.FileID);
                var PayOffResDetails = FASTWCFHelpers.EscrowService.GetPayoffLoanDetails(Request);
                #endregion
                //
                Reports.TestStep = "Associate PayoffLoan charges using to payee web service";
                int? AddrBookEntryID = PayOffResDetails.PayOffLoanSummary[0].FileBusinessParty.AddrBookEntryID;
                int? ChargeID = PayOffResDetails.PayOffLoanSummary[0].CDPayCharges.DisbursementCharges[0].ChargeID;
                FASTWCFHelpers.FastEscrowService.PayOffLoanPayChargeAssociationRequest PayChargeAssociationRequest = EscrowRequestFactory.PayOffLoanPayChargesAssociationReq(FASTHelpers.File.FileID, AddrBookEntryID, ChargeID);
                //
                Reports.TestStep = "Verify PayoffLoan details in FAST";
                FastDriver.PayoffLoanDetails.Open();
                FastDriver.PayoffLoanDetails.ChargesTab.FAClick();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                System.Threading.Thread.Sleep(2000);
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                FastDriver.PayoffLoanCharges.WaitCreation(FastDriver.PayoffLoanCharges.PayChargesBtn);
                FastDriver.PayoffLoanCharges.PayChargesBtn.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                int Row = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction("Description", @"Statement/Forwarding Fee", "Description", TableAction.GetCell).CurrentRow;
                Support.AreEqual(cdPyoffLnpayoffloancharges[0].PBBuyerAtClosing.ToString(), FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(++Row, 4, TableAction.GetText).Message.ToString());
                Support.AreEqual(cdPyoffLnpayoffloancharges[0].BuyerCredit.ToString(), FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(Row, 5, TableAction.GetText).Message.ToString());
                Support.AreEqual(cdPyoffLnpayoffloancharges[0].PBSellerAtClosing.ToString(), FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(Row, 6, TableAction.GetText).Message.ToString());
                Support.AreEqual(cdPyoffLnpayoffloancharges[0].SellerCredit.ToString(), FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(Row, 7, TableAction.GetText).Message.ToString());
                Support.AreEqual("True", FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction(Row, 1, TableAction.GetAttribute, "selected").Message.ToString(), true);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        [Description("Verify CreatePayOffLoan() service functionality")]
        public void REG_GetPayOffLoanDetails()
        {
            try
            {
                Reports.TestStep = "Verify CreatePayOffLoan() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTSelenium.Common.FASTHelpers.FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
               FASTSelenium.Common.FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke CreatePayOffLoan service";
                var CreatePayoffLoanReq = EscrowRequestFactory.GetDefaultPayoffLoanRequestWithCharge(FASTHelpers.File.FileID.ToString());
                var CreatePayoffLoanRes = FASTWCFHelpers.EscrowService.CreatePayoffLoan(CreatePayoffLoanReq);
                Support.AreEqual("1", CreatePayoffLoanRes.Status.ToString(), CreatePayoffLoanRes.StatusDescription);

                var GetPayoffloanRequest = EscrowRequestFactory.GetGetPayoffLoanRequest(FASTSelenium.Common.FASTHelpers.File.FileID);
                var GetPayoffLoanRes = FASTWCFHelpers.EscrowService.GetPayoffLoanDetails(GetPayoffloanRequest);

                #region Variables

                var cdPyoffLnLoancharges = GetPayoffLoanRes.PayOffLoanSummary[0].CDLoanCharges;
                var cdPyoffLnpayoffloancharges = GetPayoffLoanRes.PayOffLoanSummary[0].CDPayoffLoanCharges;
                var cdPyoffLnInterestCalSum = GetPayoffLoanRes.PayOffLoanSummary[0].CDInterestCalculationSummary[0].CDChargePaymentDetails;

                #endregion

                #region Navigate to PayOffLoan and verify PayOffLoan request
                Reports.TestStep = "Navigate to PayOff Loan and verify the Loan Details";

                FastDriver.PayoffLoanDetails.Open();
                #region Validate Payoff Loan Details page
                String loantype = "";

                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FAGetValue().ToString(), GetPayoffLoanRes.PayOffLoanSummary[0].OriginalPrincipalBalance.ToString(), true, true);

                if (GetPayoffLoanRes.PayOffLoanSummary[0].LoanType.ToString().Equals("667"))
                {
                    loantype = "Institutional";
                }
                if (GetPayoffLoanRes.PayOffLoanSummary[0].LoanType.ToString().Equals("668"))
                {
                    loantype = "Private Party";
                }
                else
                    if (GetPayoffLoanRes.PayOffLoanSummary[0].LoanType.ToString().Equals("669"))
                    {
                        loantype = "Collection Payoff lender";
                    }

                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanDetails.LenderLoanType.FAGetSelectedItem().ToString(), loantype, true);
                #endregion

                #region Validate Loan Charges

                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                if (cdPyoffLnLoancharges.Description != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesDescription.FAGetValue(), cdPyoffLnLoancharges.Description, true, true);
                if (cdPyoffLnLoancharges.BuyerCharge != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FAGetValue().ToString(), cdPyoffLnLoancharges.BuyerCharge.ToString(), true, true);
                if (cdPyoffLnLoancharges.SellerCharge != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FAGetValue().ToString(), cdPyoffLnLoancharges.SellerCharge.ToString(), true, true);
               if (cdPyoffLnLoancharges.LEAmount != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesEstimatedUnRounded.FAGetValue().ToString(), cdPyoffLnLoancharges.LEAmount.ToString(), true, true);

                if (FastDriver.PayoffLoanCharges.LoanChargesDescription.FAGetValue().ToString().Equals(cdPyoffLnLoancharges.Description.ToString()))
                {
                    FastDriver.PayoffLoanCharges.PaymentDetails.FAClick();
                    FastDriver.PayoffLoanCharges.LoanChargesDescription.FAClick();

                    Playback.Wait(4000);

                }
                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdPyoffLnLoancharges);

                #endregion


                #region Validate Interest Calculation Summary
                String FromDateInclusive = "";
                String ToDateInclusive = "";

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                FastDriver.PayoffLoanCharges.SwitchToContentFrame();

                Reports.TestStep = "Verify Interest Calculation Summary";

                ServiceHelper.ContainsUIVal(FastDriver.PayoffLoanCharges.InterestCalculationProrPerDiem.FAGetValue().ToString(), CreatePayoffLoanReq.CDInterestCalculationSummary[0].PerDiemAmount.ToString());
                Assert.AreEqual(((DateTime)CreatePayoffLoanReq.CDInterestCalculationSummary[0].FromDate).ToDateString(), FastDriver.PayoffLoanCharges.InterestCalculationProrFromDate.FAGetValue());
                Assert.AreEqual(((DateTime)CreatePayoffLoanReq.CDInterestCalculationSummary[0].ToDate).ToDateString(), FastDriver.PayoffLoanCharges.InterestCalculationProrToDate.FAGetValue());
                if (CreatePayoffLoanReq.CDInterestCalculationSummary[0].FromDateInclusive.ToString().Equals("1"))
                {
                    FromDateInclusive = "on";
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.InterestCalculationInclusiveFrom.FAGetValue().ToString(), FromDateInclusive);
                }
                if (CreatePayoffLoanReq.CDInterestCalculationSummary[0].ToDateInclusive.ToString().Equals("1"))
                {
                    ToDateInclusive = "on";
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.InterestCalculationInclusiveTo.FAGetValue().ToString(), ToDateInclusive);
                } ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.InterestCalculationBasedonDays.FAGetSelectedItem().ToString(), CreatePayoffLoanReq.CDInterestCalculationSummary[0].CalendarBaseDays.ToString());

                #endregion

                #region Validate Payoff Loan Charges



                FastDriver.PayoffLoanCharges.ChargesTab.Click();

                if (cdPyoffLnpayoffloancharges[0].Description != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[0].Description.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[0].BuyerCharge != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCharge.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[0].BuyerCharge.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[0].BuyerCredit != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCredit.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[0].BuyerCredit.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[0].SellerCharge != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCharge.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[0].SellerCharge.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[0].SellerCredit != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCredit.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[0].SellerCredit.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[0].LEAmount != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeLoanEstimate.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[0].LEAmount.ToString(), true, true);


                if (cdPyoffLnpayoffloancharges[1].Description != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription8.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[1].Description.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[1].BuyerCharge != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCharge8.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[1].BuyerCharge.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[1].BuyerCredit != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCredit8.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[1].BuyerCredit.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[1].SellerCharge != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCharge8.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[1].SellerCharge.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[1].SellerCredit != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCredit8.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[1].SellerCredit.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[1].LEAmount != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeLoanEstimate8.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[1].LEAmount.ToString(), true, true);


                if (FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription.FAGetValue().ToString().Equals(cdPyoffLnpayoffloancharges[0].Description.ToString()))
                {
                    FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription.FAClick();
                    FastDriver.PayoffLoanCharges.PaymentDetails.FAClick();
                }

                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdPyoffLnpayoffloancharges[0]);

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();

               
                #endregion
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


    //

        [TestMethod]
        [Description("Verify CreatePayOffLoan() service functionality")]
        public void REG_CreatePayOffLoan()
        {
            try
            {
                Reports.TestStep = "Verify CreatePayOffLoan() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTSelenium.Common.FASTHelpers.FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FASTSelenium.Common.FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke CreatePayOffLoan service";
                var CreatePayoffLoanReq = EscrowRequestFactory.GetDefaultPayoffLoanRequestWithCharge(FASTHelpers.File.FileID.ToString());

                var CreatePayoffLoanRes = FASTWCFHelpers.EscrowService.CreatePayoffLoan(CreatePayoffLoanReq);

                Support.AreEqual("1", CreatePayoffLoanRes.Status.ToString(), CreatePayoffLoanRes.StatusDescription);

                #region Variables

                var cdPyoffLnLoancharges = CreatePayoffLoanReq.CDLoanCharges;
                var cdPyoffLnpayoffloancharges = CreatePayoffLoanReq.CDPayoffLoanCharges;
                var cdPyoffLnInterestCalSum = CreatePayoffLoanReq.CDInterestCalculationSummary[0].CDChargePaymentDetails;

                #endregion

                #region Navigate to PayOffLoan and verify PayOffLoan request
                Reports.TestStep = "Navigate to PayOff Loan and verify the Loan Details";

                FastDriver.PayoffLoanDetails.Open();
                #region Validate Payoff Loan Details page
                String loantype = "";

                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FAGetValue().ToString(), CreatePayoffLoanReq.PayOffLenderOrigPrincipalBal.ToString(), true, true);

                if (CreatePayoffLoanReq.LoanTypeCdID.ToString().Equals("667"))
                {
                    loantype = "Institutional";
                }
                if (CreatePayoffLoanReq.LoanTypeCdID.ToString().Equals("668"))
                {
                    loantype = "Private Party";
                }
                else
                    if (CreatePayoffLoanReq.LoanTypeCdID.ToString().Equals("669"))
                    {
                        loantype = "Collection Payoff lender";
                    }

                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanDetails.LenderLoanType.FAGetSelectedItem().ToString(), loantype, true);
                #endregion

                #region Validate Loan Charges

                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                if (cdPyoffLnLoancharges.Description != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesDescription.FAGetValue(), cdPyoffLnLoancharges.Description, true, true);
                if (cdPyoffLnLoancharges.BuyerCharge != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FAGetValue().ToString(), cdPyoffLnLoancharges.BuyerCharge.ToString(), true, true);
                if (cdPyoffLnLoancharges.SellerCharge != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FAGetValue().ToString(), cdPyoffLnLoancharges.SellerCharge.ToString(), true, true);
                if (cdPyoffLnLoancharges.LEAmount != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesEstimatedUnRounded.FAGetValue().ToString(), cdPyoffLnLoancharges.LEAmount.ToString(), true, true);

                if (FastDriver.PayoffLoanCharges.LoanChargesDescription.FAGetValue().ToString().Equals(cdPyoffLnLoancharges.Description.ToString()))
                {
                    FastDriver.PayoffLoanCharges.PaymentDetails.FAClick();
                    FastDriver.PayoffLoanCharges.LoanChargesDescription.FAClick();

                    Playback.Wait(4000);

                }
                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdPyoffLnLoancharges);

                #endregion


                #region Validate Interest Calculation Summary
                String FromDateInclusive = "";
                String ToDateInclusive = "";

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                FastDriver.PayoffLoanCharges.SwitchToContentFrame();

                Reports.TestStep = "Verify Interest Calculation Summary";
                string fromdate = FastDriver.PayoffLoanCharges.InterestCalculationProrFromDate.FAGetValue().ToString();
                fromdate = fromdate.Replace("-", "/").ToString();
                if (fromdate.StartsWith("0"))
                {
                    fromdate = fromdate.Substring(1);
                }

                string todate = FastDriver.PayoffLoanCharges.InterestCalculationProrToDate.FAGetValue().ToString();
                todate = todate.Replace("-", "/").ToString();
                if (todate.StartsWith("0"))
                {
                    todate = todate.Substring(1);
                }

                ServiceHelper.ContainsUIVal(FastDriver.PayoffLoanCharges.InterestCalculationProrPerDiem.FAGetValue().ToString(), CreatePayoffLoanReq.CDInterestCalculationSummary[0].PerDiemAmount.ToString());
                Assert.AreEqual("True", CreatePayoffLoanReq.CDInterestCalculationSummary[0].FromDate.ToString().Contains(fromdate).ToString());
                Assert.AreEqual("True", CreatePayoffLoanReq.CDInterestCalculationSummary[0].ToDate.ToString().Contains(todate).ToString());
                if (CreatePayoffLoanReq.CDInterestCalculationSummary[0].FromDateInclusive.ToString().Equals("1"))
                {
                    FromDateInclusive = "on";
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.InterestCalculationInclusiveFrom.FAGetValue().ToString(), FromDateInclusive);
                }
                if (CreatePayoffLoanReq.CDInterestCalculationSummary[0].ToDateInclusive.ToString().Equals("1"))
                {
                    ToDateInclusive = "on";
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.InterestCalculationInclusiveTo.FAGetValue().ToString(), ToDateInclusive);
                }
                //Helper.CompareWithUI(FastDriver.PayoffLoanCharges.InterestCalculationInclusiveFrom.FAGetValue().ToString(), CreatePayoffLoanReq.CDInterestCalculationSummary[0].FromDateInclusive.ToString());
                //Helper.CompareWithUI(FastDriver.PayoffLoanCharges.InterestCalculationInclusiveTo.FAGetValue().ToString(), CreatePayoffLoanReq.CDInterestCalculationSummary[0].ToDateInclusive.ToString());
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.InterestCalculationBasedonDays.FAGetSelectedItem().ToString(), CreatePayoffLoanReq.CDInterestCalculationSummary[0].CalendarBaseDays.ToString());

                #endregion

                #region Validate Payoff Loan Charges



                FastDriver.PayoffLoanCharges.ChargesTab.Click();

                if (cdPyoffLnpayoffloancharges[0].Description != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[0].Description.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[0].BuyerCharge != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCharge.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[0].BuyerCharge.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[0].BuyerCredit != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCredit.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[0].BuyerCredit.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[0].SellerCharge != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCharge.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[0].SellerCharge.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[0].SellerCredit != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCredit.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[0].SellerCredit.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[0].LEAmount != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeLoanEstimate.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[0].LEAmount.ToString(), true, true);


                if (cdPyoffLnpayoffloancharges[1].Description != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription8.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[1].Description.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[1].BuyerCharge != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCharge8.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[1].BuyerCharge.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[1].BuyerCredit != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCredit8.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[1].BuyerCredit.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[1].SellerCharge != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCharge8.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[1].SellerCharge.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[1].SellerCredit != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCredit8.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[1].SellerCredit.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[1].LEAmount != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeLoanEstimate8.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[1].LEAmount.ToString(), true, true);


                if (FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription.FAGetValue().ToString().Equals(cdPyoffLnpayoffloancharges[0].Description.ToString()))
                {
                    FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription.FAClick();
                    FastDriver.PayoffLoanCharges.PaymentDetails.FAClick();
                }

                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdPyoffLnpayoffloancharges[0]);

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();

                if (FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription8.FAGetValue().ToString().Equals(cdPyoffLnpayoffloancharges[1].Description.ToString()))
                {
                    FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription8.FAClick();
                    FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                }

                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdPyoffLnpayoffloancharges[1]);

                #endregion
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        [Description("Verify UpdatePayOffLoan() service functionality")]
        public void REG_UpdateOffLoan()
        {
            TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("Pacific SA Standard Time");

            DateTime newDateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);

            try
            {
                Reports.TestStep = "Verify UpdatePayOffLoan() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTSelenium.Common.FASTHelpers.FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FASTSelenium.Common.FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                #region Creating PayoffLoan Instance

                Reports.TestStep = "Invoke CreatePayOffLoan service";
                var CreatePayoffLoanReq = FileRequestFactory.GetDefaultPayoffLoanRequestWithCharge(FASTSelenium.Common.FASTHelpers.File.FileID.ToString());

                var CreatePayoffLoanRes = FASTWCFHelpers.FileService.CreatePayoffLoan(CreatePayoffLoanReq);

                Support.AreEqual("1", CreatePayoffLoanRes.Status.ToString(), CreatePayoffLoanRes.StatusDescription);
                #endregion

                Reports.TestStep = "Invoke UpdatePayOffLoan service";
                //var getresponse = EscrowService.GetPayOffLoanDetails(File.FileID.ToString());

                var UpdatePayoffLoanReq = EscrowRequestFactory.GetUpdatePayoffLoanRequestWithCharge(FASTHelpers.File.FileID.ToString());

                var UpdatePayoffLoanRes = FASTWCFHelpers.EscrowService.UpdatePayoffLoan(UpdatePayoffLoanReq);

                Support.AreEqual("1", UpdatePayoffLoanRes.Status.ToString(), UpdatePayoffLoanRes.StatusDescription);
                #region Variables

                var cdPyoffLnLoancharges = UpdatePayoffLoanReq.CDLoanCharges;
                var cdPyoffLnpayoffloancharges = UpdatePayoffLoanReq.CDPayoffLoanCharges;
                var cdPyoffLnInterestCalSum = UpdatePayoffLoanReq.CDInterestCalculationSummary[0].CDChargePaymentDetails;

                #endregion

                #region Navigate to PayOffLoan and verify PayOffLoan request
                Reports.TestStep = "Navigate to PayOff Loan and verify the Loan Details";

                FastDriver.PayoffLoanDetails.Open();
                #region Validate Payoff Loan Details
                String loantype = "";

                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FAGetValue().ToString(), UpdatePayoffLoanReq.PayOffLenderOrigPrincipalBal.ToString(), true, true);

                if (CreatePayoffLoanReq.LoanTypeCdID.ToString().Equals("667"))
                {
                    loantype = "Institutional";
                }
                if (CreatePayoffLoanReq.LoanTypeCdID.ToString().Equals("668"))
                {
                    loantype = "Private Party";
                }
                else
                    if (CreatePayoffLoanReq.LoanTypeCdID.ToString().Equals("669"))
                    {
                        loantype = "Collection Payoff lender";
                    }

                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanDetails.LenderLoanType.FAGetSelectedItem().ToString(), loantype, true);
                #endregion
                #endregion

                #region Validate Loan Charges

                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

                if (cdPyoffLnLoancharges.Description != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesDescription.FAGetValue(), cdPyoffLnLoancharges.Description, true, true);
                if (cdPyoffLnLoancharges.BuyerCharge != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FAGetValue().ToString(), cdPyoffLnLoancharges.BuyerCharge.ToString(), true, true);
                if (cdPyoffLnLoancharges.SellerCharge != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FAGetValue().ToString(), cdPyoffLnLoancharges.SellerCharge.ToString(), true, true);
                if (cdPyoffLnLoancharges.LEAmount != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesEstimatedUnRounded.FAGetValue().ToString(), cdPyoffLnLoancharges.LEAmount.ToString(), true, true);

                if (FastDriver.PayoffLoanCharges.LoanChargesDescription.FAGetValue().ToString().Equals(cdPyoffLnLoancharges.Description.ToString()))
                {
                    FastDriver.PayoffLoanCharges.PaymentDetails.FAClick();
                    FastDriver.PayoffLoanCharges.LoanChargesDescription.FAClick();

                    // FastDriver.PayoffLoanCharges.LoanChargesDescription.FADoubleClick();
                    Playback.Wait(4000);

                }
                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdPyoffLnLoancharges);

                #endregion


                #region Validate Interest Calculation Summary
                String FromDateInclusive = "";
                String ToDateInclusive = "";

                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                FastDriver.PayoffLoanCharges.SwitchToContentFrame();

                Reports.TestStep = "Verify Interest Calculation Summary";
                string fromdate = FastDriver.PayoffLoanCharges.InterestCalculationProrFromDate.FAGetValue().ToString();
                fromdate = fromdate.Replace("-", "/").ToString();
                if (fromdate.StartsWith("0"))
                {
                    fromdate = fromdate.Substring(1);
                }

                string todate = FastDriver.PayoffLoanCharges.InterestCalculationProrToDate.FAGetValue().ToString();
                todate = todate.Replace("-", "/").ToString();
                if (todate.StartsWith("0"))
                {
                    todate = todate.Substring(1);
                }
                ServiceHelper.ContainsUIVal(FastDriver.PayoffLoanCharges.InterestCalculationProrPerDiem.FAGetValue().ToString(), UpdatePayoffLoanReq.CDInterestCalculationSummary[0].PerDiemAmount.ToString());
                Support.AreEqual("True", UpdatePayoffLoanReq.CDInterestCalculationSummary[0].FromDate.ToString().Contains(fromdate).ToString());
                Support.AreEqual("True", UpdatePayoffLoanReq.CDInterestCalculationSummary[0].ToDate.ToString().Contains(todate).ToString());
                if (UpdatePayoffLoanReq.CDInterestCalculationSummary[0].FromDateInclusive.ToString().Equals("1"))
                {
                    FromDateInclusive = "on";
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.InterestCalculationInclusiveFrom.FAGetValue().ToString(), FromDateInclusive, true);
                }
                if (UpdatePayoffLoanReq.CDInterestCalculationSummary[0].ToDateInclusive.ToString().Equals("1"))
                {
                    ToDateInclusive = "on";
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.InterestCalculationInclusiveTo.FAGetValue().ToString(), ToDateInclusive, true);
                }
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.InterestCalculationBasedonDays.FAGetSelectedItem().ToString(), UpdatePayoffLoanReq.CDInterestCalculationSummary[0].CalendarBaseDays.ToString());

                #endregion

                #region Validate Payoff Loan Charges

                FastDriver.PayoffLoanCharges.ChargesTab.Click();
                FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
                if (cdPyoffLnpayoffloancharges[0].Description != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[0].Description.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[0].BuyerCharge != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCharge.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[0].BuyerCharge.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[0].BuyerCredit != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCredit.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[0].BuyerCredit.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[0].SellerCharge != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCharge.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[0].SellerCharge.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[0].SellerCredit != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCredit.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[0].SellerCredit.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[0].LEAmount != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeLoanEstimate.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[0].LEAmount.ToString(), true, true);

                if (cdPyoffLnpayoffloancharges[1].Description != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription8.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[1].Description.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[1].BuyerCharge != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCharge8.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[1].BuyerCharge.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[1].BuyerCredit != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCredit8.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[1].BuyerCredit.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[1].SellerCharge != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCharge8.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[1].SellerCharge.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[1].SellerCredit != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCredit8.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[1].SellerCredit.ToString(), true, true);
                if (cdPyoffLnpayoffloancharges[1].LEAmount != null)
                    ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeLoanEstimate8.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[1].LEAmount.ToString(), true, true);


                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        //
        [TestMethod]
        [Description("Verify InitiatePayOffRequest() service functionality")]
        public void REG_InitiatePayOffLoan()
        {
            TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("Pacific SA Standard Time");

            DateTime newDateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);

            try
            {
                Reports.TestStep = "Verify InitiatePayOffLoan() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTSelenium.Common.FASTHelpers.FAST_Login_IIS();
                #endregion
                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                var pAddr = new FASTWCFHelpers.FastFileService.PhysicalAddress();
                pAddr.AddressType = "Business";
                pAddr.AddrLine1 = "Street 1";
                pAddr.City = "Virginia";
                pAddr.County = "Richmond";
                pAddr.State = "NY";
                pAddr.Zip = "92700";
                FASTSelenium.Common.FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000, pAddr: pAddr);
                #endregion
                #region Add Seller
                FASTSelenium.Common.FASTHelpers.FAST_WCF_AddBuyerSeller("Seller");
                #endregion
                #region Creating PayoffLoan Instance
                Reports.TestStep = "Invoke CreatePayOffLoan service";
                var CreatePayoffLoanReq = EscrowRequestFactory.GetDefaultPayoffLoanRequestWithCharge(FASTSelenium.Common.FASTHelpers.File.FileID.ToString());
                CreatePayoffLoanReq.PayOffLenderReference = "1234354321";
                CreatePayoffLoanReq.GoodThroughDate = DateTime.UtcNow.Date.AddDays(2);
                CreatePayoffLoanReq.SeqNum = 1;
                var CreatePayoffLoanRes = FASTWCFHelpers.EscrowService.CreatePayoffLoan(CreatePayoffLoanReq);
                Support.AreEqual("1", CreatePayoffLoanRes.Status.ToString(), CreatePayoffLoanRes.StatusDescription);
                #endregion
                //
                Reports.TestStep = "Invoke InitiatePayOffRequest service";
                var InitiatePayoffRes = FASTWCFHelpers.EscrowService.InitiatePayoffRequest(CreatePayoffLoanReq);
                Support.AreEqual("1", InitiatePayoffRes.Status.ToString(), InitiatePayoffRes.StatusDescription);
                //
                Reports.TestStep = "Validate event tracking log";
                Reports.TestStep = @"Navigate to Event/Tracking Log, validate Payoff Demand Request Initiated/Submitted events";
                string Event = "[Payoff Demand Request Initiated]";
                WaitForEventToGetRecorded(Event);
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateEvent(Event).ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateSourceForEvent(Event, "FAMOS Application").ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateUserNameForEvent(Event, @"FAMOS").ToString());
                string Comment = FastDriver.EventTrackingLog.GetCommentForEvent(Event);
                Support.AreEqualTrim("True", Comment.Contains("Payoff Demand Request Initiated").ToString());
                //
                Event = "[Payoff Demand Request Submitted]";
                WaitForEventToGetRecorded(Event);
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateEvent(Event).ToString());
                Support.AreEqualTrim("True", FastDriver.EventTrackingLog.ValidateSourceForEvent(Event, "FAST Application").ToString());
                Comment = FastDriver.EventTrackingLog.GetCommentForEvent(Event);
                Support.AreEqualTrim("True", Comment.Contains("Payoff Demand Request Submitted").ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }
        #region PrivateMethods
        //
        private void WaitForEventToGetRecorded(string Event)
        {
            for (int i = 0; i < 10; i++)
            {
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("File Process");
                System.Threading.Thread.Sleep(5000);
                FastDriver.EventTrackingLog.WaitForScreenToLoad(FastDriver.EventTrackingLog.EventTable);
                FastDriver.EventTrackingLog.WaitCreation(FastDriver.EventTrackingLog.EventTable);
                if (!FastDriver.EventTrackingLog.EventTable.FAGetText().Contains(Event))
                    System.Threading.Thread.Sleep(5000);
                else break;
            }
        }
        #endregion

    }
}
