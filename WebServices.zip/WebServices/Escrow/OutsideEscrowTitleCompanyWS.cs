﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using WebServices.Helpers.Escrow;

namespace WebServices.Escrow
{
    [CodedUITest]
    public class OutsideEscrowTitleCompanyWS : MasterTestClass
    {
        [TestMethod]
        public void REG0001_CreateOutsideEscrowCompany()
        {
            try
            {
                Reports.TestDescription = "Verify CreateOutsideEscrowCompany service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Invoke CreateOutsideEscrowCompany method, validate response (WS)";
                var request = EscrowRequestFactory.GetOECRequest(fileId, 1, "BOA");
                var response = OutsideEscrowTitleCompanyHelpers.CreateOutsideEscrowCompany(request);
                Support.AreEqual("1", response.Status.ToString(), "Operation Status");
                Support.AreEqual("Create Outside Escrow Company details Successful.", response.StatusDescription, "Operation Status Description");

                Reports.TestStep = "Navigate to Outside Escrow Company screen, validate GAB Code";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                Support.AreEqual("BOA", FastDriver.OutsideEscrowCompanyDetail.GABcodeLabel.FAGetText().Clean(), "GAB Name");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0002_CreateOutsideTitleCompany()
        {
            try
            {
                Reports.TestDescription = "Verify CreateOutsideTitleCompany service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Invoke CreateOutsideTitleCompany method, validate response (WS)";
                var request = EscrowRequestFactory.GetOutsideTitleCompanyRequest(fileId, 1, "BOA");
                var response = OutsideEscrowTitleCompanyHelpers.CreateOutsideTitleCompany(request);
                Support.AreEqual("1", response.OperationResponse.Status.ToString(), "Operation Status");
                Support.AreEqual("CreateOutsideTitleCompany is successfull", response.OperationResponse.StatusDescription, "Operation Status Description");

                Reports.TestStep = "Navigate to Outside Title Company screen, validate GAB Code";
                FastDriver.OutsideTitleCompanyDetail.Open();
                Support.AreEqual("BOA", FastDriver.OutsideTitleCompanyDetail.IDCode.FAGetText().Clean(), "GAB Name");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0003_GetOutsideEscrowCompanyDetails()
        {
            try
            {
                Reports.TestDescription = "Verify GetOutsideEscrowCompanyDetails service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Create an Outside Escrow company (WS)";
                var createOECrequest = EscrowRequestFactory.GetOECRequest(fileId, 1, "BOA");
                OutsideEscrowTitleCompanyHelpers.CreateOutsideEscrowCompany(createOECrequest);

                Reports.TestStep = "Navigate to Outside Escrow Company, enter buyer & seller charges";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(2, 1, TableAction.SetText, "REG0003_GetOutsideEscrowCompany" + FAKeys.Tab);
                Thread.Sleep(2000);
                FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(2, 3, TableAction.SetText, "10.00" + FAKeys.Tab);
                Thread.Sleep(2000);
                FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(2, 4, TableAction.SetText, "20.00" + FAKeys.Tab);
                Thread.Sleep(2000);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Invoke GetOutsideEscrowCompany method, validate response (WS)";
                var request = EscrowRequestFactory.GetServiceFileRequest(fileId);
                var response = OutsideEscrowTitleCompanyHelpers.GetOutsideEscrowCompanyDetails(request);
                Support.AreEqual("1", response.Status.ToString(), "Operation Status");
                Support.AreEqual("Successful.", response.StatusDescription, "Operation Status Description");

                Reports.TestStep = "Validate GAB Name, buyer & seller charges";
                Support.AreEqual("BOA", response.OECInformations[0].OECFileBusinessParty.IDCode, "GAB Name");
                Support.AreEqual("10", response.OECInformations[0].OECCharges.CDPaymentDetails[0].BuyerCharge.ToString(), "Buyer Charge");
                Support.AreEqual("20", response.OECInformations[0].OECCharges.CDPaymentDetails[0].SellerCharge.ToString(), "Seller Charge");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0004_GetOutsideTitleCompanyDetails()
        {
            try
            {
                Reports.TestDescription = "Verify GetOutsideTitleCompanyDetails service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Create an Outside Title company (WS)";
                var OTCRequest = EscrowRequestFactory.GetOutsideTitleCompanyRequest(fileId, 1, "BOA");
                OTCRequest.OTCDetails = new OTCDetails()
                {
                    ChargesRetained = (decimal)1000,
                    eOTCType = OTCType.Attorney,
                };
                OutsideEscrowTitleCompanyHelpers.CreateOutsideTitleCompany(OTCRequest);

                Reports.TestStep = "Invoke GetOutsideTitleCompanyDetails method, validate response (WS)";
                var request = EscrowRequestFactory.GetServiceFileRequest(fileId);
                var response = OutsideEscrowTitleCompanyHelpers.GetOutsideTitleCompanyDetails(request);
                Support.AreEqual("1", response.Status.ToString(), "Operation Status");
                Support.AreEqual("Successful.", response.StatusDescription, "Operation Status Description");

                Reports.TestStep = "Navigate to Outside Title Company, Validate Funds Deposited and Outside Title Company Type";
                FastDriver.OutsideTitleCompanyDetail.Open();
                Support.AreEqual("1000", response.OTCInformations[0].OTCDetails.ChargesRetained.ToString(), "Funds Deposited");
                Support.AreEqual("Attorney", response.OTCInformations[0].OTCDetails.eOTCType.ToString(), "Outside Title Company Type");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0005_UpdateOutsideTitleCompanyDetails()
        {
            try
            {
                Reports.TestDescription = "Verify UpdateOutsideTitleCompanyDetails service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Create an Outside Title company (WS)";
                var OTCRequest = EscrowRequestFactory.GetOutsideTitleCompanyRequest(fileId, 1, "BOA");
                OTCRequest.OTCDetails = new OTCDetails()
                {
                    ChargesRetained = (decimal)1000,
                    eOTCType = OTCType.Attorney
                };
                OutsideEscrowTitleCompanyHelpers.CreateOutsideTitleCompany(OTCRequest);

                Reports.TestStep = "Invoke UpdateOutsideTitleCompanyDetails method, validate response (WS)";
                var updateOCTrequest = EscrowRequestFactory.GetOTCRequest(fileId, 1);
                updateOCTrequest.OTCInformation.OTCDetails = new OTCDetails()
                {
                    ChargesRetained = (decimal)2000,
                    eOTCType = OTCType.OutsideTitleCompany
                };

                var response = OutsideEscrowTitleCompanyHelpers.UpdateOutsideTitleCompanyDetails(updateOCTrequest);
                Support.AreEqual("1", response.Status.ToString(), "Operation Status");
                Support.AreEqual("Update Outside Title Company details Successful.", response.StatusDescription, "Operation Status Description");

                Reports.TestStep = "Navigate to Outside Title Company, Validate Funds Deposited and Outside Title Company Type";
                FastDriver.OutsideTitleCompanyDetail.Open();
                Support.AreEqual("2,000.00", FastDriver.OutsideTitleCompanyDetail.FundsDeposited.FAGetText().Replace("$", "").Clean(), "Funds Deposited");
                Support.AreEqual("Outside Title Company", FastDriver.OutsideTitleCompanyDetail.TypeSelect.FAGetSelectedItem(), "Outside Title Company Type");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0006_UpdateOutsideEscrowCompanyDetails()
        {
            try
            {
                Reports.TestDescription = "Verify UpdateOutsideEscrowCompanyDetails service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Create an Outside Escrow company (WS)";
                var OECRequest = EscrowRequestFactory.GetOECRequest(fileId, 1, "BOA");
                OutsideEscrowTitleCompanyHelpers.CreateOutsideEscrowCompany(OECRequest);

                Reports.TestStep = "Invoke UpdateOutsideEscrowCompanyDetails method, validate response (WS)";
                var updateOECrequest = EscrowRequestFactory.GetOECRequest(fileId, 1, "1256");

                var response = OutsideEscrowTitleCompanyHelpers.UpdateOutsideEscrowCompanyDetails(updateOECrequest);
                Support.AreEqual("1", response.Status.ToString(), "Operation Status");
                Support.AreEqual("Update Outside Escrow Company details Successful.", response.StatusDescription, "Operation Status Description");

                Reports.TestStep = "Navigate to Outside Escrow Company screen, validate ID Code has changed";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                Support.AreEqual("1256", FastDriver.OutsideTitleCompanyDetail.IDCode.FAGetText(), "ID Code");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

    }
}
