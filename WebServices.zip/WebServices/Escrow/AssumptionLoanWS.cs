﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using WebServices.Helpers.Escrow;

namespace WebServices.Escrow
{
    [CodedUITest]
    public class AssumptionLoanWS : FASTHelpers
    {
        [TestMethod]
        [Description("Verify REG_CreateAssumptionLoan() service functionality")]
        public void REG_CreateAssumptionLoan()
        {

            try
            {
                Reports.TestStep = "Verify CreateAssumptionLoan() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke CreateAssumptionLoan service";
                var CreateAssumptionLoanReq = EscrowRequestFactory.GetDefaultAssumptionLoanRequestWithCharge(File.FileID);

                var CreateAssumptionLoanRes = FASTWCFHelpers.EscrowService.CreateAssumptionLoan(CreateAssumptionLoanReq);


                #region UI Validation
                Reports.TestStep = "Validate the UI";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                Support.AreEqual("248", FastDriver.AssumptionLoanDetails.GABcodeLabel.FAGetText());

                Reports.TestStep = "Enter Charges in Charges Tab.";
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                Support.AreEqual("Create Instance", FastDriver.AssumptionLoanCharges.AssumpLoanChargesDescription.FAGetValue());
                Support.AreEqual("11,111,111,111.11", FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCharge.FAGetValue());
                Support.AreEqual("22,222,222,222.22", FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCredit0.FAGetValue());
                Support.AreEqual("44,444,444,444.44", FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FAGetValue());
                Support.AreEqual("33,333,333,333.33", FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCredit1.FAGetValue());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG_GetAssumptionLoanDetails()
        {
            Reports.TestDescription = "Get the values of the Assumption Loan by invoking WCF Service.";
            Reports.TestStep = "Checking for fileId.";
            try
            {
                Reports.TestStep = "Verify CreatePayOffLoan() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);


                Reports.TestStep = "Invoke CreatePayOffLoan service";
                var CreateAssumptionLoanReq = EscrowRequestFactory.GetDefaultAssumptionLoanRequestWithCharge(File.FileID);

                var CreateAssumptionLoanRes = FASTWCFHelpers.EscrowService.CreateAssumptionLoan(CreateAssumptionLoanReq);
                #endregion

                #region Get Assumption Loan details and verify againest UI

                var GetAssumptioLoanReq = EscrowRequestFactory.GetAssumptionLoanDetailsRequest(File.FileID);
                var GetAssumptionLoanRes = FASTWCFHelpers.EscrowService.GetAssumptionLoanDetails(GetAssumptioLoanReq);

                Reports.TestStep = "Validate the UI";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                string sample = GetAssumptionLoanRes.AssumptionLoanDetails.NoteDetails.LateChargeAfterDays.ToString();
                Support.AreEqual(FastDriver.AssumptionLoanDetails.LateChargeAfterDays.FAGetValue(), GetAssumptionLoanRes.AssumptionLoanDetails.NoteDetails.LateChargeAfterDays.ToString());
                Support.AreEqual(FastDriver.AssumptionLoanDetails.PaymentAmount.FAGetValue(), GetAssumptionLoanRes.AssumptionLoanDetails.NoteDetails.PaymentAmount.ToString());
                Support.AreEqual(FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FAGetValue(), GetAssumptionLoanRes.AssumptionLoanDetails.NoteDetails.OriginalNoteAmount.ToString());

                Reports.TestStep = "Enter Charges in Charges Tab.";
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.AssumptionLoanCharges.AssumpLoanChargesDescription.FAGetValue(), GetAssumptionLoanRes.AssumptionLoanCharges.CDAssumptionLoanCharge[0].Description.ToString());
                Support.AreEqual(FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCharge.FAGetValue().Replace(",", "").ToString(), GetAssumptionLoanRes.AssumptionLoanCharges.CDAssumptionLoanCharge[0].BuyerCharge.ToString());
                Support.AreEqual(FastDriver.AssumptionLoanCharges.AssumpLoanChargesBuyerCredit0.FAGetValue().Replace(",", "").ToString(), GetAssumptionLoanRes.AssumptionLoanCharges.CDAssumptionLoanCharge[0].BuyerCredit.ToString());
                Support.AreEqual(FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCharge.FAGetValue().Replace(",", "").ToString(), GetAssumptionLoanRes.AssumptionLoanCharges.CDAssumptionLoanCharge[0].SellerCharge.ToString());
                Support.AreEqual(FastDriver.AssumptionLoanCharges.AssumpLoanChargesSellerCredit1.FAGetValue().Replace(",", "").ToString(), GetAssumptionLoanRes.AssumptionLoanCharges.CDAssumptionLoanCharge[0].SellerCredit.ToString());

                Support.AreEqual(FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.FAGetValue().Replace(",", "").ToString(), GetAssumptionLoanRes.AssumptionLoanCharges.CDUnPaidPrincipalLoanCharges[0].BuyerCredit.ToString());
                Support.AreEqual(FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.FAGetValue().Replace(",", "").ToString(), GetAssumptionLoanRes.AssumptionLoanCharges.CDUnPaidPrincipalLoanCharges[0].SellerCharge.ToString());

                Reports.TestStep = "Verify the Unpaid Principal Balance payment methos";
                FastDriver.AssumptionLoanCharges.UnpaidPrincipalLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                string paidbuyer = GetAssumptionLoanRes.AssumptionLoanCharges.CDUnPaidPrincipalLoanCharges[0].AtClosingBuyerPaymentMethodTypeID.ToString();
                if (paidbuyer == "CHK")
                {
                    paidbuyer = "Check";
                }
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem(), paidbuyer);

                string paidseller = GetAssumptionLoanRes.AssumptionLoanCharges.CDUnPaidPrincipalLoanCharges[0].AtClosingSellerPaymentMethodTypeID.ToString();
                if (paidseller == "CHK")
                {
                    paidseller = "Check";
                }
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem(), paidseller);
                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FAGetSelectedItem(), GetAssumptionLoanRes.AssumptionLoanCharges.CDUnPaidPrincipalLoanCharges[0].BuyerCreditPaymentMethodTypeCdID.ToString());
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the Assumption Loan Charges Payment Method Dialog";
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                FastDriver.AssumptionLoanCharges.AssumpLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                string Assum_paidbuyer = GetAssumptionLoanRes.AssumptionLoanCharges.CDAssumptionLoanCharge[0].AtClosingBuyerPaymentMethodTypeID.ToString();
                if (Assum_paidbuyer == "CHK")
                {
                    Assum_paidbuyer = "Check";
                }
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem(), Assum_paidbuyer);

                string Assum_paidseller = GetAssumptionLoanRes.AssumptionLoanCharges.CDAssumptionLoanCharge[0].AtClosingSellerPaymentMethodTypeID.ToString();
                if (Assum_paidseller == "CHK")
                {
                    Assum_paidseller = "Check";
                }
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem(), Assum_paidseller);
                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FAGetSelectedItem(), GetAssumptionLoanRes.AssumptionLoanCharges.CDAssumptionLoanCharge[0].BuyerCreditPaymentMethodTypeCdID.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCreditPaymentMethod.FAGetSelectedItem(), GetAssumptionLoanRes.AssumptionLoanCharges.CDAssumptionLoanCharge[0].SellerCreditPaymentMethodTypeCdID.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG_UpdateAssumptionLoan_ChargesAndDetailsTab()
        {
            try
            {
                #region Pre requisite
                Reports.TestStep = "Verify CreatePayOffLoan() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke CreatePayOffLoan service";
                var CreateAssumptionLoanReq = EscrowRequestFactory.GetDefaultAssumptionLoanRequestWithCharge(File.FileID);

                var CreateAssumptionLoanRes = FASTWCFHelpers.EscrowService.CreateAssumptionLoan(CreateAssumptionLoanReq);

                #endregion


                #region Update Assumption Loan
                var UpdateAssumptionLoanReq = EscrowRequestFactory.GetDefaultUpdateAssmptionLoanDetails(File.FileID);

                var UpdateAssumptionLoanRes = FASTWCFHelpers.EscrowService.UpdateAssumptionLoanDetails(UpdateAssumptionLoanReq);
                Support.AreEqual("1", UpdateAssumptionLoanRes.Status.ToString(), UpdateAssumptionLoanRes.StatusDescription);

                #endregion

                #region Verify updated Lender Information
                Reports.TestStep = "Validate the UI";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                Support.AreEqual("247", FastDriver.AssumptionLoanDetails.GABcodeLabel.FAGetText());
                #endregion
                #region Verify the Updated Loan Details
                Support.AreEqual(FastDriver.AssumptionLoanDetails.DetailsLoanType.FAGetSelectedItem().Replace(" ", ""), UpdateAssumptionLoanReq.AssumtionLoanDetails.LoanDetail.LoanType.ToString());
                Support.AreEqual(FastDriver.AssumptionLoanDetails.UnpaidPricincipalBalance.FAGetValue(), UpdateAssumptionLoanReq.AssumtionLoanDetails.LoanDetail.UnpaidPrincipalBalance.ToString());


                #endregion

                #region Verify the Updated Note Details
                Support.AreEqual(FastDriver.AssumptionLoanDetails.OriginalNoteAmount.FAGetValue(), UpdateAssumptionLoanReq.AssumtionLoanDetails.NoteDetails.OriginalNoteAmount.ToString());
                Support.AreEqual(FastDriver.AssumptionLoanDetails.PaymentAmount.FAGetValue(), UpdateAssumptionLoanReq.AssumtionLoanDetails.NoteDetails.PaymentAmount.ToString());
                Support.AreEqual(FastDriver.AssumptionLoanDetails.PaymentType.FAGetSelectedItem().Replace("&", "").Trim(), UpdateAssumptionLoanReq.AssumtionLoanDetails.NoteDetails.PaymentType.ToString());
                Support.AreEqual(FastDriver.AssumptionLoanDetails.PaymentPer.FAGetSelectedItem().ToLower(), UpdateAssumptionLoanReq.AssumtionLoanDetails.NoteDetails.payablePer.ToString().ToLower());
                Support.AreEqual(FastDriver.AssumptionLoanDetails.LateCharge.IsSelected().ToString(), UpdateAssumptionLoanReq.AssumtionLoanDetails.NoteDetails.LateChargeFlag.ToString());
                Support.AreEqual(FastDriver.AssumptionLoanDetails.LateChargePercentage.FAGetValue(), UpdateAssumptionLoanReq.AssumtionLoanDetails.NoteDetails.LateChargePercentage.ToString());
                Support.AreEqual(FastDriver.AssumptionLoanDetails.LateChargeAfterDays.FAGetValue(), UpdateAssumptionLoanReq.AssumtionLoanDetails.NoteDetails.LateChargeAfterDays.ToString());

                #endregion

                Reports.TestStep = "Validate the Charge Details";
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();

                #region verify Updated unpaid Principal Loan Charges
                Support.AreEqual(FastDriver.AssumptionLoanCharges.UnpaidPrincLoanBuyerCredit.FAGetValue(), UpdateAssumptionLoanReq.Charges.CDUnPaidPrincipalLoanCharges[0].BuyerCredit.ToString());
                Support.AreEqual(FastDriver.AssumptionLoanCharges.UnpaidPrincLoanSellerCharge.FAGetValue(), UpdateAssumptionLoanReq.Charges.CDUnPaidPrincipalLoanCharges[0].SellerCharge.ToString());
                FastDriver.AssumptionLoanCharges.UnpaidPrincipalLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                string paidbuyer = UpdateAssumptionLoanReq.Charges.CDUnPaidPrincipalLoanCharges[0].AtClosingBuyerPaymentMethodTypeID.ToString();
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().Replace(" ", "").ToString(), paidbuyer.Trim());

                string paidseller = UpdateAssumptionLoanReq.Charges.CDUnPaidPrincipalLoanCharges[0].AtClosingSellerPaymentMethodTypeID.ToString();
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().Replace(" ", ""), paidseller);
                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCreditPaymentMethod.FAGetSelectedItem().Replace(" ", ""), UpdateAssumptionLoanReq.Charges.CDUnPaidPrincipalLoanCharges[0].BuyerCreditPaymentMethodTypeCdID.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region verify Updated Assumption Loan Charges
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                string c = FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction(7, 1, TableAction.GetText).Element.FAFindElement(ByLocator.TagName, "input").GetAttribute("value");
                Support.AreEqual(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction(7, 1, TableAction.GetText).Element.FAFindElement(ByLocator.TagName, "input").GetAttribute("value").ToString(), UpdateAssumptionLoanReq.Charges.CDAssumptionLoanCharge[0].Description.ToString());
                Support.AreEqual(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction(7, 3, TableAction.GetText).Element.FAFindElement(ByLocator.TagName, "input").GetAttribute("value").ToString(), UpdateAssumptionLoanReq.Charges.CDAssumptionLoanCharge[0].BuyerCharge.ToString());
                Support.AreEqual(FastDriver.AssumptionLoanCharges.AssumptionLoanChargesTable.PerformTableAction(7, 5, TableAction.GetText).Element.FAFindElement(ByLocator.TagName, "input").GetAttribute("value").ToString(), UpdateAssumptionLoanReq.Charges.CDAssumptionLoanCharge[0].SellerCharge.ToString());


                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void REG_GetAssumptionLoanSummary()
        {
            Reports.TestDescription = "Get the values of the Assumption Loan by invoking WCF Service.";


            try
            {
               
               
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke assumption service";
                var CreateAssumptionLoanReq = EscrowRequestFactory.GetDefaultAssumptionLoanRequestWithCharge(File.FileID);

                var CreateAssumptionLoanRes = FASTWCFHelpers.EscrowService.CreateAssumptionLoan(CreateAssumptionLoanReq);
                CreateAssumptionLoanReq = EscrowRequestFactory.GetDefaultAssumptionLoanRequestWithCharge(File.FileID);

                CreateAssumptionLoanRes = FASTWCFHelpers.EscrowService.CreateAssumptionLoan(CreateAssumptionLoanReq);

                var GetAssumptionLoanSummaryReq = EscrowRequestFactory.GetDefaultAssumptionLoanSummaryRequest(File.FileID);
                
                var GetAssumptionLoanSummaryRes = FASTWCFHelpers.EscrowService.AssumptionLoanSummaryResponse(GetAssumptionLoanSummaryReq);

                #region Vailidate the Assumption Loan Summary details
                Reports.TestStep = "Validate the Assumption Loan Summary";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan");
                FastDriver.AssumptionLoanSummary.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.AssumptionLoanSummary.TotalNoOfRecords.FAGetText().Contains(GetAssumptionLoanSummaryRes.TotalNumberofRecords.ToString()).ToString());
               Support.AreEqual(FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(2, 2, TableAction.GetText).Message.ToString(), GetAssumptionLoanSummaryRes.AssumptionLoanSummary[0].Name.ToString());
               Support.AreEqual(FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(3, 2, TableAction.GetText).Message.ToString(), GetAssumptionLoanSummaryRes.AssumptionLoanSummary[1].Name.ToString());

               Support.AreEqual(FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(2, 5, TableAction.GetText).Message.ToString(), GetAssumptionLoanSummaryRes.AssumptionLoanSummary[0].BusinessPhone.ToString());
               Support.AreEqual(FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(3, 5, TableAction.GetText).Message.ToString(), GetAssumptionLoanSummaryRes.AssumptionLoanSummary[1].BusinessPhone.ToString());

               Support.AreEqual(FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(2, 6, TableAction.GetText).Message.ToString(), GetAssumptionLoanSummaryRes.AssumptionLoanSummary[0].BusinessFax.ToString());
               Support.AreEqual(FastDriver.AssumptionLoanSummary.SummaryTable.PerformTableAction(3, 6, TableAction.GetText).Message.ToString(), GetAssumptionLoanSummaryRes.AssumptionLoanSummary[1].BusinessFax.ToString());
               
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG_RemoveAssumptionLoanDetails()
        {
            Reports.TestDescription = "Remove Assumption Loan Charge Details";
           

            try
            {


                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke assumption service";
                var CreateAssumptionLoanReq = EscrowRequestFactory.GetDefaultAssumptionLoanRequestWithCharge(File.FileID);

                var CreateAssumptionLoanRes = FASTWCFHelpers.EscrowService.CreateAssumptionLoan(CreateAssumptionLoanReq);
                var RemoveAssumptionLoanChargeReq = EscrowRequestFactory.GetDefaultRemoveAssumptionLoanRequest(File.FileID);
                var RemoveAssumptionLoanChargeRes = FASTWCFHelpers.EscrowService.RemoveAssumptionLoanResponse(RemoveAssumptionLoanChargeReq);

                #region validate the Assumptin Loan Charges are removed
                Reports.TestStep = "validate the Assumptin Loan Charges are removed";
                FastDriver.LeftNavigation.Navigate<AssumptionLoanDetails>("Home>Order Entry>Assumption Loan").WaitForScreenToLoad();
                FastDriver.AssumptionLoanDetails.ChargesTab.FAClick();
                FastDriver.AssumptionLoanCharges.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.AssumptionLoanCharges.UnPrincBalPane.FAGetText(),"$ 0.00");
                Support.AreEqual(FastDriver.AssumptionLoanCharges.TotChgPane.FAGetText(), "$0.00");
                Support.AreEqual(FastDriver.AssumptionLoanCharges.TotPocPane.FAGetText(), "$0.00");
                Support.AreEqual(FastDriver.AssumptionLoanCharges.UnPrincBalPane.FAGetText(), "$ 0.00");
                Support.AreEqual(FastDriver.AssumptionLoanCharges.CheqAmt.FAGetText(), "$0.00");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG_GetAssumptionLoanDisbursementDetails()
        {
            Reports.TestDescription = "Verify the GetAssumptionLoanDisbursementDetails webservice.";
            try
            {
                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke CreateAssumptionLoan service";
                var CreateAssumptionLoanReq = EscrowRequestFactory.GetDefaultAssumptionLoanRequestWithCharge(File.FileID);
                var CreateAssumptionLoanRes = FASTWCFHelpers.EscrowService.CreateAssumptionLoan(CreateAssumptionLoanReq);

                #region Open the Active disbursement summary page and disburse the charges related to the assumption loan.
                Reports.TestStep = "Open active disbursement summary page.";
                FastDriver.ActiveDisbursementSummary.Open();

                Reports.TestStep = "Select the check related with the assumption loan and disburse it manually.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 2, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                Random rn=new Random();
                FastDriver.IssueManualCheck.CheckNo.FASetText((10000 + rn.Next(1111, 9999)).ToString());
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 20);
                try
                {
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                }
                catch (Exception)
                {
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }

                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("RElease the amount.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to the active disbursement summary page and validate the issue check related with split fee.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Check", 1, TableAction.GetText).Message.Trim(), "Status of the of the charge should be issued.");
                #endregion

                #region invoke the GetAssumptionLoanDisbursementDetails service and validate the response.
                Reports.TestStep = "Invoke the GetAssumptionLoanDisbursementDetails webservice.";
                var response = EscrowTransactionsHelpers.GetAssumptionLoanDisbursementDetails(File.FileID, 1);

                Reports.TestStep = "Verify the response in the FAST Application.";
                FastDriver.ActiveDisbursementSummary.Open();
                ServiceHelper.CompareWithUI(FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, 8, TableAction.GetText).Message, response.ChargeDetails[0].PayeeName);
                ServiceHelper.CompareWithUI(FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, 7, TableAction.GetText).Message, string.Format("{0:0,000.00}", response.ChargeDetails[0].DisburedAmount));
                ServiceHelper.CompareWithUI(FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1,1,TableAction.GetText).Message.Contains("Issued").ToString(),response.ChargeDetails[0].IsDisbursed.ToString());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG_UpdateAssumptionLoanDisbursementDetails()
        {
            Reports.TestDescription = "Verify the UpdateAssumptionLoanDisbursementDetails webservice.";
            try
            {
                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke CreateAssumptionLoan service";
                var CreateAssumptionLoanReq = EscrowRequestFactory.GetDefaultAssumptionLoanRequestWithCharge(File.FileID);
                var CreateAssumptionLoanRes = FASTWCFHelpers.EscrowService.CreateAssumptionLoan(CreateAssumptionLoanReq);

                #region Open the Active disbursement summary page and disburse the charges related to the assumption loan.
                Reports.TestStep = "Open active disbursement summary page.";
                FastDriver.ActiveDisbursementSummary.Open();

                Reports.TestStep = "Select the check related with the assumption loan and disburse it manually.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Pending", 2, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                Random rn = new Random();
                FastDriver.IssueManualCheck.CheckNo.FASetText((10000 + rn.Next(1111, 9999)).ToString());
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 20);
                try
                {
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                }
                catch (Exception)
                {
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }

                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("RElease the amount.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to the active disbursement summary page and validate the issue check related with split fee.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Check", 1, TableAction.GetText).Message.Trim(), "Status of the of the charge should be issued.");
                #endregion

                #region invoke the GetAssumptionLoanDisbursementDetails service.
                Reports.TestStep = "Invoke the GetAssumptionLoanDisbursementDetails webservice.";
                var response = EscrowTransactionsHelpers.GetAssumptionLoanDisbursementDetails(File.FileID, 1);
                #endregion

                #region Invoke the updateassumptionloandisbursementdetails and update the details.
                Reports.TestStep = "Invoke the UpdateAssumptionLoanDisbDetails webservice.";
                var assumptionLoanRequest = EscrowRequestFactory.GetAssumptionLoanDisbSaveRequest(Convert.ToInt32(File.FileID), 1);
                
                assumptionLoanRequest.PayeeInformation = new FASTWCFHelpers.FastEscrowService.AssumptionLoanDisbursementPayeeInformation[]
                {
                    new FASTWCFHelpers.FastEscrowService.AssumptionLoanDisbursementPayeeInformation()
                    {
                        eOperationType = FASTWCFHelpers.FastEscrowService.OperationType.Update,
                        FBPOverrideFlag = true,
                        FileBusinessParty = new FASTWCFHelpers.FastEscrowService.FileBusinessParty()
                        {
                            FileBusinessPartyID = response.PayeeInformation[0].FileBusinessParty.FileBusinessPartyID,
                            IDCode = "508"
                        }
                    }
                };
                
                var updateasmptLoandisbRspn = EscrowTransactionsHelpers.UpdateAssumptionLoanDisbDetails(assumptionLoanRequest);
                #endregion

                Reports.TestStep = "Verify the response in the FAST Application.";
                FastDriver.ActiveDisbursementSummary.Open();
                ServiceHelper.CompareWithUI(FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, 8, TableAction.GetText).Message, response.ChargeDetails[0].PayeeName);
                ServiceHelper.CompareWithUI(FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, 7, TableAction.GetText).Message, string.Format("{0:0,000.00}", response.ChargeDetails[0].DisburedAmount));
                ServiceHelper.CompareWithUI(FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, 1, TableAction.GetText).Message.Contains("Issued").ToString(), response.ChargeDetails[0].IsDisbursed.ToString());
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
    }

}
