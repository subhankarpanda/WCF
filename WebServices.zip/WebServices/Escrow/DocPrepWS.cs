﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebServices.Helpers.Escrow;
using WebServices.Helpers.File;

namespace WebServices.Escrow
{
    [CodedUITest]
    public class DocPrepWS: MasterTestClass
    {
        [TestMethod]
        public void REG0001_GetALTASettlementStatement()
        {
            Reports.TestDescription = "Verify the web service GetALTASettlementStatement (Escrow Service).";
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                DepositParameters depositDetails = new DepositParameters()
                {
                    Amount = 8000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Testing Payor",
                    CreditToSeller = true,
                    Comments = "It is a Manual Cash deposit.",
                };
                #endregion

                #region Login to the FAST Application and create one file using web service.
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;

                Reports.TestStep = "Open the newly created file in FAST application.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);
                #endregion

                #region Navigate to the deposit in escrow and perform one deposit.
                Reports.TestStep = "Navigate to the deposit in escrow and perform one deposit.";
                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(depositDetails);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                #endregion

                #region Navigate to the Payoff page and add one pay off Loan.
                Reports.TestStep = "Navigate to the Payoff Loan page and add details, charges.";
                FastDriver.PayoffLoanDetails.Open();
                FastDriver.PayoffLoanDetails.SearchGAB("501");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.AddCharge(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable, chargeDescription: "Reconveyance Fee", buyerCharge: 100.00, sellerCharge: 101.01);
                FastDriver.BottomFrame.Done();
                FastDriver.PayoffLoanDetails.WaitForScreenToLoad();
                #endregion

                #region Invoke the GetALTASettlementStatement webservice.
                Reports.TestStep = "Invoke the GetALTASettlementStatement webservice.";
                var response = DocPrepHelpers.GetALTASettlementStatementDetails(fileId);
                #endregion

                #region Navigate to the view Settlement statement page and verify the details recieved by web service in FAST.
                Reports.TestStep = "Navigate to the View Settlement Statement page.";
                FastDriver.ViewSettlementStatement.Open();

                Reports.TestStep = "Verify the details in FAST application for view settlement statement.";
                ServiceHelper.CompareWithUI(actualVal: (!FastDriver.ViewSettlementStatement.isNotALTA()).ToString(), expectedVal: response.ALTASettlementSatementDetails.IsALTAStatement.ToString());

                ServiceHelper.CompareWithUI(FastDriver.ViewSettlementStatement.FinancialTable.PerformTableAction(3, 1, TableAction.GetCell).Element, "text", response.ALTASettlementSatementDetails.Financial[1].SellerChargeAmt.ToString());
                ServiceHelper.CompareWithUI(FastDriver.ViewSettlementStatement.FinancialTable.PerformTableAction(3, 2, TableAction.GetCell).Element, "text", response.ALTASettlementSatementDetails.Financial[1].SellerCreditAmt.ToString());
                ServiceHelper.CompareWithUI(FastDriver.ViewSettlementStatement.FinancialTable.PerformTableAction(3,3, TableAction.GetCell).Element, "text", response.ALTASettlementSatementDetails.Financial[1].ChargeDescription.ToString());
                ServiceHelper.CompareWithUI(FastDriver.ViewSettlementStatement.FinancialTable.PerformTableAction(3, 4, TableAction.GetCell).Element, "text", response.ALTASettlementSatementDetails.Financial[1].BuyerChargeAmt.ToString());
                ServiceHelper.CompareWithUI(FastDriver.ViewSettlementStatement.FinancialTable.PerformTableAction(3, 5, TableAction.GetCell).Element, "text", response.ALTASettlementSatementDetails.Financial[1].BuyerCreditAmt.ToString());

                ServiceHelper.CompareWithUI(FastDriver.ViewSettlementStatement.PayOffTable.PerformTableAction(4, 1, TableAction.GetCell).Element, "text", response.ALTASettlementSatementDetails.PayOffs[2].SellerChargeAmt.ToString());
                ServiceHelper.CompareWithUI(FastDriver.ViewSettlementStatement.PayOffTable.PerformTableAction(4, 2, TableAction.GetCell).Element, "text", response.ALTASettlementSatementDetails.PayOffs[2].SellerCreditAmt.ToString());
                ServiceHelper.CompareWithUI(FastDriver.ViewSettlementStatement.PayOffTable.PerformTableAction(4, 3, TableAction.GetCell).Element, "text", response.ALTASettlementSatementDetails.PayOffs[2].ChargeDescription.ToString());
                ServiceHelper.CompareWithUI(FastDriver.ViewSettlementStatement.PayOffTable.PerformTableAction(4, 4, TableAction.GetCell).Element, "text", response.ALTASettlementSatementDetails.PayOffs[2].BuyerChargeAmt.ToString());
                ServiceHelper.CompareWithUI(FastDriver.ViewSettlementStatement.PayOffTable.PerformTableAction(4, 5, TableAction.GetCell).Element, "text", response.ALTASettlementSatementDetails.PayOffs[2].BuyerCreditAmt.ToString());

                Reports.TestStep = "Verifying the subtotal section.";
                for(int i=1;i<4;i++)
                {
                    ServiceHelper.CompareWithUI(FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(i, 1, TableAction.GetCell).Element, "text", response.ALTASettlementSatementDetails.Subtotals[i].SellerChargeAmt.ToString());
                    ServiceHelper.CompareWithUI(FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(i, 2, TableAction.GetCell).Element, "text", response.ALTASettlementSatementDetails.Subtotals[i].SellerCreditAmt.ToString());
                    ServiceHelper.CompareWithUI(FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(i, 3, TableAction.GetCell).Element, "text", response.ALTASettlementSatementDetails.Subtotals[i].ChargeDescription.ToString());
                    ServiceHelper.CompareWithUI(FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(i, 4, TableAction.GetCell).Element, "text", response.ALTASettlementSatementDetails.Subtotals[i].BuyerChargeAmt.ToString());
                    ServiceHelper.CompareWithUI(FastDriver.ViewSettlementStatement.SubTotalsTable.PerformTableAction(i, 5, TableAction.GetCell).Element, "text", response.ALTASettlementSatementDetails.Subtotals[i].BuyerCreditAmt.ToString());
                }
                FastDriver.ViewSettlementStatement.PrintDeliver.FAClick();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
    
        [TestMethod]
        [DeploymentItem(@"Common\Support\CECONTRACT_4438673_LEG.pdf")]
        public void REG0002_UploadWorkQFile()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify UploadWorkQFile() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId).FileNumber;

                Reports.TestStep = "Convert file to byte array";
                var filePath = @"CECONTRACT_4438673_LEG.pdf";
                byte[] fileContent = IOHelper.ConvertFileToByteArray(filePath);

                Reports.TestStep = "Invoke UploadWorkQFile Service";
                var request = EscrowRequestFactory.GetUploadWorkQFileRequest(fileContent);
                request.File.FileName = filePath.Split('.')[0];
                var response = EscrowService.UploadWorkQFile(request);
                response.Validate();

                Reports.TestStep = "Navigate to Work Queue Messages Browser and select a Queue with ID: 1";
                FastDriver.TopFrame.ClickQListTab();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                FastDriver.WorkQueueMessagesBrowser.ForQueue.FASelectItemBySendingKeys("TestQueue");
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                Reports.TestStep = "Verify the data in the UI has been filled with the web service data";
                Support.AreEqual(true, FastDriver.WorkQueueMessagesBrowser.MessageTable.FAGetText().Contains(request.File.FileName), "File Name exists");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\CECONTRACT_4438673_LEG.pdf")]
        public void REG0003_UpdateWorkQueueMessage()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify UpdateWorkQueueMessage() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Convert file to byte array";
                var filePath = @"CECONTRACT_4438673_LEG.pdf";
                byte[] fileContent = IOHelper.ConvertFileToByteArray(filePath);

                Reports.TestStep = "Invoke UploadWorkQFile Service";
                var UploadWQFRequest = EscrowRequestFactory.GetUploadWorkQFileRequest(fileContent);
                UploadWQFRequest.File.FileName = filePath.Split('.')[0];

                var UploadWQFResponse = EscrowService.UploadWorkQFile(UploadWQFRequest);
                UploadWQFResponse.Validate();

                Reports.TestStep = "Invoke GetWorkQueueList service";
                var GetWorkQListRequest = EscrowRequestFactory.GetWorkQueueListRequest();
                var GetWorkQListResponse = EscrowService.GetWorkQueueList(GetWorkQListRequest);
                GetWorkQListResponse.Validate();

                int messageId = 0;

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    messageId = (int)GetWorkQListResponse.Messages.Where(d => d.FileName.Contains(UploadWQFRequest.File.FileName)).FirstOrDefault().MessageId;
                    return (messageId != 0);
                }, timeout: 10000);

                Reports.TestStep = "Invoke UpdateWorkQueueMessage service";
                var UpdateWorkQMessageRequest = EscrowRequestFactory.GetUpdateWorkQueueMessageRequest(messageId: messageId, requestType: WorkQRequestType.MoveToTop);
                var UpdateWorkQMessageResponse = EscrowService.UpdateWorkQueueMessage(UpdateWorkQMessageRequest);
                UpdateWorkQMessageResponse.Validate();

                Reports.TestStep = "Navigate to the UI, select a queue with ID: 1, and validate the response from the web service";
                FastDriver.TopFrame.ClickQListTab();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                FastDriver.WorkQueueMessagesBrowser.ForQueue.FASelectItem("TestQueue");
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                Support.AreEqual(true, FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(2, 3, TableAction.GetText).Message.Contains(UploadWQFRequest.File.FileName), "Message should be the first on the Queue");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0004_GetWorkQueueList()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.formType = FASTWCFHelpers.FastFileService.FormType.HUD;
                #endregion

                Reports.TestDescription = "Verify GetWorkQueueList() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId).FileNumber;

                Reports.TestStep = "Invoke GetWorkQueueList service";
                var request = EscrowRequestFactory.GetWorkQueueListRequest();
                request.DeleteOnlyFlag = true;
                var response = EscrowService.GetWorkQueueList(request);
                response.Validate();

                Reports.TestStep = "Navigate to the UI and validate with the data from the web service";
                FastDriver.TopFrame.ClickQListTab();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                FastDriver.WorkQueueMessagesBrowser.DeletedOnly.FASetCheckbox(request.DeleteOnlyFlag);
                FastDriver.WorkQueueMessagesBrowser.ForQueue.FASelectItem("TestQueue");
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                Support.AreEqual(response.Messages.Length.ToString(), (FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount() - 1).ToString(), "Messages");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\Hello.pdf")]
        public void REG0005_GetWorkQueueMessageLogDetails()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify GetWorkQueueMessageLogDetails() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Convert file to byte array";
                var filePath = @"Hello.pdf";
                byte[] fileContent = IOHelper.ConvertFileToByteArray(filePath);

                Reports.TestStep = "Invoke UploadWorkQFile Service";
                var UploadWQFRequest = EscrowRequestFactory.GetUploadWorkQFileRequest(fileContent);
                UploadWQFRequest.File.FileName = filePath.Split('.')[0];

                var UploadWQFResponse = EscrowService.UploadWorkQFile(UploadWQFRequest);
                UploadWQFResponse.Validate();

                Reports.TestStep = "Invoke GetWorkQueueList service";
                var GetWorkQListRequest = EscrowRequestFactory.GetWorkQueueListRequest();
                var GetWorkQListResponse = EscrowService.GetWorkQueueList(GetWorkQListRequest);
                GetWorkQListResponse.Validate();

                int messageId = 0;

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    messageId = (int)GetWorkQListResponse.Messages.Where(d => d.FileName.Contains(UploadWQFRequest.File.FileName)).FirstOrDefault().MessageId;
                    return (messageId != 0);
                }, timeout: 10000);

                Reports.TestStep = "Invoke GetWorkQueueMessageLogDetails service";
                var GetWorkQMLogDetailsRequest = EscrowRequestFactory.GetWorkQueueMessageLogDetailsRequest(messageId: messageId);
                var GetWorkQMLogDetailsResponse = EscrowService.GetWorkQueueMessageLogDetails(GetWorkQMLogDetailsRequest);
                GetWorkQMLogDetailsResponse.Validate();

                Reports.TestStep = "Navigate to the UI, select a queue with ID: 1, and validate the response from the web service";
                FastDriver.TopFrame.ClickQListTab();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                FastDriver.WorkQueueMessagesBrowser.ForQueue.FASelectItem("TestQueue");
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                var rows = FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount();
                FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(rows, 1, TableAction.Click);
                FastDriver.WorkQueueMessagesBrowser.MessageHistory.FAClick();
                FastDriver.WorkQueueMessageLogDlg.WaitForScreenToLoad();

                Support.AreEqual(GetWorkQMLogDetailsResponse.Logs.Length.ToString(), FastDriver.WorkQueueMessageLogDlg.MsgQueueTable.GetRowCount().ToString(), "Logs entry count");
                Support.AreEqual(GetWorkQMLogDetailsResponse.Logs[0].Status, FastDriver.WorkQueueMessageLogDlg.MsgQueueTable.PerformTableAction(1, 2, TableAction.GetText).Message, "First Log entry Status");
                Support.AreEqual(GetWorkQMLogDetailsResponse.Logs[1].Status, FastDriver.WorkQueueMessageLogDlg.MsgQueueTable.PerformTableAction(2, 2, TableAction.GetText).Message, "Second Log entry Status");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0006_GetWorkQueueTriggers()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify GetWorkQueueTriggers() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke GetWorkQueueTriggers service";
                var request = EscrowRequestFactory.GetWorkQueueTriggersRequest();
                var response = EscrowService.GetWorkQueueTriggers(request);

                Reports.TestStep = "Click on WorkQ link.";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.ClickWorkQTab();
                Support.CloseAllProcessStartingWith("AcroRd");
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Get the Queue selected by default.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();

                var defaultWorkQueue = FastDriver.WorkQueueTop.SelectQueue.FAGetSelectedItem();

                Reports.TestStep = "Select TestQueue from the dropdown.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                FastDriver.WorkQueueTop.SelectQueue.FASelectItem(@"TestQueue");
                
                Reports.TestStep = "Handle 'Retain In Queue/Delete' Dlg, if appeared.";
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                Reports.TestStep = "Handle any pop-ups, if appeared.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.HandleDialogMessage();
                Support.CloseAllProcessStartingWith("AcroRd");
                FastDriver.WorkQueueTop.WaitForScreenToLoad();

                Reports.TestStep = "Click on Attach link";
                FastDriver.WorkQueueTop.Attach.FAClick();
                FastDriver.AttachMessageDlg.WaitForScreenToLoad(FastDriver.AttachMessageDlg.WQTriggerNames);

                Reports.TestStep = "Verify data from web service with WorkQueue Trigger names";
                Support.AreEqual(response.WorkQueueTriggers.Length.ToString(), (FastDriver.AttachMessageDlg.WQTriggerNames.FAGetDropdownOptions().Count - 1).ToString(), "Work Queue Triggers Count");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\Hello.pdf")]
        public void REG0007_GetWorkQueueMessageDocument()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify GetWorkQueueMessageDocument() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Convert file to byte array";
                var filePath = @"Hello.pdf";
                byte[] fileContent = IOHelper.ConvertFileToByteArray(filePath);

                Reports.TestStep = "Invoke UploadWorkQFile Service";
                var UploadWQFRequest = EscrowRequestFactory.GetUploadWorkQFileRequest(fileContent);
                UploadWQFRequest.File.FileName = filePath.Split('.')[0];

                var UploadWQFResponse = EscrowService.UploadWorkQFile(UploadWQFRequest);
                UploadWQFResponse.Validate();

                Reports.TestStep = "Invoke GetWorkQueueList service";
                var GetWorkQListRequest = EscrowRequestFactory.GetWorkQueueListRequest();
                var GetWorkQListResponse = EscrowService.GetWorkQueueList(GetWorkQListRequest);
                GetWorkQListResponse.Validate();

                int messageId = 0;

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    messageId = (int)GetWorkQListResponse.Messages.Where(d => d.FileName.Contains(UploadWQFRequest.File.FileName)).FirstOrDefault().MessageId;
                    return (messageId != 0);
                }, timeout: 10000);

                Reports.TestStep = "Invoke GetWorkQueueMessageDocument service";
                var GetWorkQMDocumentRequest = EscrowRequestFactory.GetWorkQueueMessageDocumentRequest(messageId: messageId);
                var GetWorkQMDocumentResponse = EscrowService.GetWorkQueueMessageDocument(GetWorkQMDocumentRequest);
                GetWorkQMDocumentResponse.Validate();

                Reports.TestStep = "Navigate to the UI, select a queue with ID: 1, and validate the response from the web service";
                FastDriver.TopFrame.ClickQListTab();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                FastDriver.WorkQueueMessagesBrowser.ForQueue.FASelectItem("TestQueue");
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                var row = FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount();
                Support.AreEqual(true, FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(3, GetWorkQMDocumentResponse.MessageDocument.FileName, 3, TableAction.GetText).Message.Contains(UploadWQFRequest.File.FileName), "File Name");
                Support.AreEqual(UploadWQFRequest.File.FileExtension, GetWorkQMDocumentResponse.MessageDocument.FileExtension, "File Extension");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0008_GetWorkQueueNames()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify GetWorkQueueNames() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke GetWorkQueueNames service";
                var request = EscrowRequestFactory.GetWorkQueueNamesRequest();
                var response = EscrowService.GetWorkQueueNames(request);
                response.Validate();

                Reports.TestStep = "Click on WorkQ link.";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.ClickWorkQTab();
                Support.CloseAllProcessStartingWith("AcroRd");
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Get the Queue selected by default.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();

                var defaultWorkQueue = FastDriver.WorkQueueTop.SelectQueue.FAGetSelectedItem();

                Reports.TestStep = "Select TestQueue from the dropdown.";
                var queueOptions = FastDriver.WorkQueueTop.SelectQueue.FAGetDropdownOptions();

                Reports.TestStep = "Verify the data in the UI with the web service response";

                List<string> elements = (from q in response.QueueDetails select q.QueueName).ToList();

                foreach (var option in queueOptions)
                {
                    int index = (elements.BinarySearch(option.Text) == -4) ? elements.IndexOf(option.Text) : elements.BinarySearch(option.Text);
                    Support.AreEqual(elements.ElementAt(index), option.Text, "Queue element found at index: " + index.ToString());
                }

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\CECONTRACT_4438673_LEG.pdf")]
        public void REG0009_UpdateWorkQueueMessage_2()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestDescription = "Verify UpdateWorkQueueMessage() service [US690118 and US695211]";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Convert file to byte array";
                var filePath = @"CECONTRACT_4438673_LEG.pdf";
                byte[] fileContent = IOHelper.ConvertFileToByteArray(filePath);

                Reports.TestStep = "Invoke UploadWorkQFile Service";
                var UploadWQFRequest = EscrowRequestFactory.GetUploadWorkQFileRequest(fileContent);
                UploadWQFRequest.File.FileName = filePath.Split('.')[0] + Support.RandomString("ANZa");
                UploadWQFRequest.QueueId = 1;

                var UploadWQFResponse = EscrowService.UploadWorkQFile(UploadWQFRequest);
                UploadWQFResponse.Validate();

                Reports.TestStep = "Invoke GetWorkQueueList service";
                var GetWorkQListRequest = EscrowRequestFactory.GetWorkQueueListRequest();
                GetWorkQListRequest.QueueId = 1;

                var GetWorkQListResponse = EscrowService.GetWorkQueueList(GetWorkQListRequest);
                GetWorkQListResponse.Validate();

                Reports.TestStep = "Navigate to Work Queue Messages Browser screen and get the messageID of the added message";
                FastDriver.TopFrame.ClickQListTab();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                FastDriver.WorkQueueMessagesBrowser.ForQueue.FASelectItem("TestQueue");
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                var mFileName = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(2, 3, TableAction.GetText).Message;
                int messageId = Convert.ToInt32(FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(2, 3, TableAction.GetText).Message.Split('\\')[1].Split('_')[0]);

                #region Locking the message
                Reports.TestStep = "Click on WorkQ link.";
                FastDriver.TopFrame.SwitchToTopFrame();
                FastDriver.TopFrame.ClickWorkQTab();
                Support.CloseAllProcessStartingWith("AcroRd");
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                FastDriver.WebDriver.HandleDialogMessage();

                Reports.TestStep = "Get the Queue selected by default.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();

                var defaultWorkQueue = FastDriver.WorkQueueTop.SelectQueue.FAGetSelectedItem();

                Reports.TestStep = "Select ForAttachMQueue from the dropdown.";
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                FastDriver.WorkQueueTop.SelectQueue.FASelectItem(@"TestQueue");

                Reports.TestStep = "Handle 'Retain In Queue/Delete' Dlg, if appeared.";
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }
                Reports.TestStep = "Handle any pop-ups, if appeared.";
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.HandleDialogMessage();
                Support.CloseAllProcessStartingWith("AcroRd");
                FastDriver.WorkQueueTop.WaitForScreenToLoad();
                #endregion

                Reports.TestStep = "Navigate to the UI, select a queue with ID: 6190, and verify the message is locked";
                FastDriver.TopFrame.ClickQListTab();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                FastDriver.WorkQueueMessagesBrowser.ForQueue.FASelectItem("TestQueue");
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                Support.AreEqual(true, FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(2, 7, TableAction.GetText).Message.Contains("Locked"), "Message should have status: Locked");

                Reports.TestStep = "Invoke UpdateWorkQueueMessage service";
                var UpdateWorkQMessageRequest = EscrowRequestFactory.GetUpdateWorkQueueMessageRequest(messageId: messageId, requestType: WorkQRequestType.UnlockMessage);
                UpdateWorkQMessageRequest.UpdateDetails[0].SourceQueueId = 1;

                var UpdateWorkQMessageResponse = EscrowService.UpdateWorkQueueMessage(UpdateWorkQMessageRequest);
                UpdateWorkQMessageResponse.Validate();

                Reports.TestStep = "Click on QList tab again, select a queue with ID: 6190, and validate the response from the web service";
                FastDriver.TopFrame.ClickQListTab();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                FastDriver.WorkQueueMessagesBrowser.ForQueue.FASelectItem("TestQueue");
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                Support.AreEqual(true, FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(3, mFileName, 7, TableAction.GetText).Message.Contains("Waiting"), "Message should have status: Waiting");

                Reports.TestStep = "Click on WorkNTab to close the panel from the right";
                FastDriver.TopFrame.ClickWorkNTab();
                Reports.TestStep = "Handle 'Retain In Queue/Delete' Dlg, if appeared.";
                if (FastDriver.RetaininQDeleteDlg.RetainInQueueExists())
                {
                    FastDriver.RetaininQDeleteDlg.WorkQMessageHandler(true);
                }

                Reports.TestStep = "Invoke UpdateWorkQueueMessage service again, for cleaning the queue";
                var request = EscrowRequestFactory.GetUpdateWorkQueueMessageRequest(messageId: messageId, requestType: WorkQRequestType.Delete);
                request.UpdateDetails[0].SourceQueueId = 1;
                var response = EscrowService.UpdateWorkQueueMessage(request);
                response.Validate();

                Reports.TestStep = "Invoke GetWorkQueueList service with DeleteOnly flag as true";
                var onlyDeletedRequest = EscrowRequestFactory.GetWorkQueueListRequest();
                onlyDeletedRequest.QueueId = 1;
                onlyDeletedRequest.DeleteOnlyFlag = true;

                var onlyDeletedResponse = EscrowService.GetWorkQueueList(onlyDeletedRequest);
                GetWorkQListResponse.Validate();

                Reports.TestStep = "Check Delete Only checkbox on Work Queue Messages Browser screen";
                FastDriver.TopFrame.ClickQListTab();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                FastDriver.WorkQueueMessagesBrowser.ForQueue.FASelectItem("TestQueue");
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                FastDriver.WorkQueueMessagesBrowser.DeletedOnly.FASetCheckbox(onlyDeletedRequest.DeleteOnlyFlag);
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(2, 3, TableAction.GetText).Message.Contains(mFileName), "Verify the message is in deleted queue");

                Reports.TestStep = "Invoke the UpdateWorkQueueMessage service with Request Type: BringMessageIntoQueue [US695211]";
                var updateRequest = EscrowRequestFactory.GetUpdateWorkQueueMessageRequest(messageId: messageId, requestType: WorkQRequestType.BringMessageIntoQueue);
                updateRequest.UpdateDetails[0].SourceQueueId = 1;
                var updateResponse = EscrowService.UpdateWorkQueueMessage(updateRequest);
                updateResponse.Validate();

                Reports.TestStep = "Validate the message has been bringed back into the queue [US695211]";
                FastDriver.TopFrame.ClickQListTab();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                FastDriver.WorkQueueMessagesBrowser.ForQueue.FASelectItem("TestQueue");
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(2, 3, TableAction.GetText).Message.Contains(mFileName), "Verify the message is in queue");

                Reports.TestStep = "Clean the queue";
                var request2 = EscrowRequestFactory.GetUpdateWorkQueueMessageRequest(messageId: messageId, requestType: WorkQRequestType.Delete);
                request.UpdateDetails[0].SourceQueueId = 1;
                var response2 = EscrowService.UpdateWorkQueueMessage(request);
                response.Validate();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}