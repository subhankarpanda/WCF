﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace WebServices.Escrow
{
    [CodedUITest]
    public class InsuranceWS : MasterTestClass
    {
        [TestMethod]
        [Description("Verify CreateInsurance() service functionality")]
        public void Reg_CreateInsurance_Others()
        {

            try
            {
                Reports.TestStep = "Verify CreateInsurance() service";

                #region FAST Login IIS side
                Reports.TestStep = "Verify CreateInsurance() service";
                FASTSelenium.Common.FASTHelpers.FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
              FASTSelenium.Common.FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke CreateInsurance service";
                var CreateInsuranceReq = EscrowRequestFactory.CreateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                var CreateInsuranceRes = FASTWCFHelpers.EscrowService.CreateInsuranceResponse(CreateInsuranceReq);

                #region UI Validation
                Reports.TestStep = "Validate the UI";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual("248", FastDriver.InsuranceOther.OtherGABLabel.FAGetText());
                string premimum=null;
                if (CreateInsuranceReq.InsuranceInformation.InsuranceDetails.Premium.Value.ToString()=="1000.01")
                {
                    premimum = "1,000.01";
                }

                Support.AreEqual(premimum, FastDriver.InsuranceOther.OthertextPremium.FAGetValue());
                string OtheroptMonths=null;
                if (FastDriver.InsuranceOther.OtheroptMonths.Selected.ToString() == "True")
                {
                    OtheroptMonths="Month";
                }
                Support.AreEqual(CreateInsuranceReq.InsuranceInformation.InsuranceDetails.Term.Value.ToString(), FastDriver.InsuranceOther.OthertextTerm.FAGetValue());
                Support.AreEqual(CreateInsuranceReq.InsuranceInformation.InsuranceDetails.PremiumType.ToString(), OtheroptMonths);
                string BuyerCharge = FastDriver.InsuranceOther.OtherBuyerCharge.FAGetValue();
                if (BuyerCharge == "55,555,555,555.15")
                {
                    BuyerCharge = "55555555555.15";
                }
                Support.AreEqual(CreateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].BuyerCharge.Value.ToString(), BuyerCharge);
                string SellerCharge = FastDriver.InsuranceOther.OtherSellerCharge.FAGetValue();
                if (SellerCharge == "55,555,555,555.15")
                {
                    SellerCharge = "55555555555.15";
                }
                Support.AreEqual(CreateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].SellerCharge.Value.ToString(), SellerCharge);
                string prorationamt = null;
                if (CreateInsuranceReq.InsuranceInformation.Proration.Amount.Value.ToString()=="10000.01")
                {
                    prorationamt = "10,000.01";
                }
                Support.AreEqual(prorationamt, FastDriver.InsuranceOther.OtherAmount.FAGetValue());
                Support.AreEqual(CreateInsuranceReq.InsuranceInformation.Proration.FromDateInclusive.Value.ToString(), FastDriver.InsuranceOther.OtherfromInclusive.Selected.ToString());
                Support.AreEqual(CreateInsuranceReq.InsuranceInformation.Proration.ToDateInclusive.Value.ToString(), FastDriver.InsuranceOther.OthertoInclusive.Selected.ToString());
                Support.AreEqual(CreateInsuranceReq.InsuranceInformation.Proration.BasedOnDays.Value.ToString(), FastDriver.InsuranceOther.OtherBasedOn.FAGetSelectedItem().ToString());
                Support.AreEqual(CreateInsuranceReq.InsuranceInformation.Proration.AmountPeriod.ToString(), FastDriver.InsuranceOther.OtherPer.FAGetSelectedItem().ToString());
               


                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verif GetInsuranceDetails() service functionality")]
        public void Reg_GetInsuranceDetails_Others()
        {

            try
            {
                Reports.TestStep = "Verify GetInsuranceDetails() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTSelenium.Common.FASTHelpers.FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FASTSelenium.Common.FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke Create Insurance Details service";
                var CreateInsuranceReq = EscrowRequestFactory.CreateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                var CreateInsuranceRes = FASTWCFHelpers.EscrowService.CreateInsuranceResponse(CreateInsuranceReq);
                var GetInsuranceReq = EscrowRequestFactory.GetInsuranceDetailRequest(FASTSelenium.Common.FASTHelpers.File.FileID);
                var GetInsuranceRes = FASTWCFHelpers.EscrowService.GetInsuranceDetilsResponse(GetInsuranceReq);
                
                #region UI Validation
                Reports.TestStep = "Validate the UI";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual("248", FastDriver.InsuranceOther.OtherGABLabel.FAGetText());
                string premimum = null;
                if (GetInsuranceRes.Others[0].InsuranceDetails.Premium.Value.ToString() == "1000.01")
                {
                    premimum = "1,000.01";
                }

                Support.AreEqual(premimum, FastDriver.InsuranceOther.OthertextPremium.FAGetValue());
                string OtheroptMonths = null;
                if (FastDriver.InsuranceOther.OtheroptMonths.Selected.ToString() == "True")
                {
                    OtheroptMonths = "Month";
                }
                Support.AreEqual(GetInsuranceRes.Others[0].InsuranceDetails.Term.Value.ToString(), FastDriver.InsuranceOther.OthertextTerm.FAGetValue());
                Support.AreEqual(GetInsuranceRes.Others[0].InsuranceDetails.PremiumType.ToString(), OtheroptMonths);
                string BuyerCharge = FastDriver.InsuranceOther.OtherBuyerCharge.FAGetValue();
                if (BuyerCharge == "55,555,555,555.15")
                {
                    BuyerCharge = "55555555555.15";
                }
                Support.AreEqual(GetInsuranceRes.Others[0].InsuranceCharges.CDInsuranceChargesList[0].BuyerCharge.Value.ToString(), BuyerCharge);
                string SellerCharge = FastDriver.InsuranceOther.OtherSellerCharge.FAGetValue();
                if (SellerCharge == "55,555,555,555.15")
                {
                    SellerCharge = "55555555555.15";
                }
                Support.AreEqual(GetInsuranceRes.Others[0].InsuranceCharges.CDInsuranceChargesList[0].SellerCharge.Value.ToString(), SellerCharge);
                string prorationamt = null;
                if (GetInsuranceRes.Others[0].Proration.Amount.Value.ToString() == "10000.01")
                {
                    prorationamt = "10,000.01";
                }
                Support.AreEqual(prorationamt, FastDriver.InsuranceOther.OtherAmount.FAGetValue());
                Support.AreEqual(GetInsuranceRes.Others[0].Proration.FromDateInclusive.Value.ToString(), FastDriver.InsuranceOther.OtherfromInclusive.Selected.ToString());
                Support.AreEqual(GetInsuranceRes.Others[0].Proration.ToDateInclusive.Value.ToString(), FastDriver.InsuranceOther.OthertoInclusive.Selected.ToString());
                Support.AreEqual(GetInsuranceRes.Others[0].Proration.BasedOnDays.Value.ToString(), FastDriver.InsuranceOther.OtherBasedOn.FAGetSelectedItem().ToString());
                Support.AreEqual(GetInsuranceRes.Others[0].Proration.AmountPeriod.ToString(), FastDriver.InsuranceOther.OtherPer.FAGetSelectedItem().ToString());



                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verif UpdateInsurance() service functionality")]
        public void Reg_UpdateInsuranceDetails_Others()
        {

            try
            {
                Reports.TestStep = "Verify GetInsuranceDetails() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTSelenium.Common.FASTHelpers.FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FASTSelenium.Common.FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke Create Insurance Details service";
                var CreateInsuranceReq = EscrowRequestFactory.CreateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                var CreateInsuranceRes = FASTWCFHelpers.EscrowService.CreateInsuranceResponse(CreateInsuranceReq);
                var UpdateInsuranceReq = EscrowRequestFactory.UpdateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                var UpdateInsuranceRes = FASTWCFHelpers.EscrowService.UpdateInsurance(UpdateInsuranceReq);

                #region UI Validation
                Reports.TestStep = "Validate the UI";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual("247", FastDriver.InsuranceOther.OtherGABLabel.FAGetText());
                string premimum = null;
                if (UpdateInsuranceReq.InsuranceInformation.InsuranceDetails.Premium.Value.ToString() == "1100.01")
                {
                    premimum = "1,100.01";
                }

                Support.AreEqual(premimum, FastDriver.InsuranceOther.OthertextPremium.FAGetValue());
                string OtheroptMonths = null;
                if (FastDriver.InsuranceOther.OtheroptMonths.Selected.ToString() == "True")
                {
                    OtheroptMonths = "Month";
                }
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceDetails.Term.Value.ToString(), FastDriver.InsuranceOther.OthertextTerm.FAGetValue());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceDetails.PremiumType.ToString(), OtheroptMonths);
                string BuyerCharge = FastDriver.InsuranceOther.OtherBuyerCharge.FAGetValue();
                if (BuyerCharge == "1,000,000.00")
                {
                    BuyerCharge = "1000000";
                }
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].BuyerCharge.Value.ToString(), BuyerCharge);
                string SellerCharge = FastDriver.InsuranceOther.OtherSellerCharge.FAGetValue();
                if (SellerCharge == "1,000,000.00")
                {
                    SellerCharge = "1000000";
                }
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].SellerCharge.Value.ToString(), SellerCharge);
                string prorationamt = null;
                if (UpdateInsuranceReq.InsuranceInformation.Proration.Amount.Value.ToString() == "11000.01")
                {
                    prorationamt = "11,000.01";
                }
                Support.AreEqual(prorationamt, FastDriver.InsuranceOther.OtherAmount.FAGetValue());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.Proration.FromDateInclusive.Value.ToString(), FastDriver.InsuranceOther.OtherfromInclusive.Selected.ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.Proration.ToDateInclusive.Value.ToString(), FastDriver.InsuranceOther.OthertoInclusive.Selected.ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.Proration.BasedOnDays.Value.ToString(), FastDriver.InsuranceOther.OtherBasedOn.FAGetSelectedItem().ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.Proration.AmountPeriod.ToString(), FastDriver.InsuranceOther.OtherPer.FAGetSelectedItem().ToString());

                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                string paymentmethod_buyer = null;
                if (UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].AtClosingBuyerPaymentMethodTypeID.ToString() == "CHK")
                {
                    paymentmethod_buyer = "Check";
                }
                string paymentmethod_seller = null;
                if (UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].AtClosingSellerPaymentMethodTypeID.ToString() == "CHK")
                {
                    paymentmethod_seller = "Check";
                }
                Support.AreEqual(paymentmethod_buyer, FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                Support.AreEqual(paymentmethod_seller, FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].PBOthersForBuyerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].PBOthersForSellerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verify RemoveInsurance_Others() service functionality")]
        public void Reg_RemoveInsurance_Others()
        {

            try
            {
                Reports.TestStep = "Verify CreateInsurance() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTSelenium.Common.FASTHelpers.FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FASTSelenium.Common.FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke Create and remove Insurance services";
                var CreateInsuranceReq = EscrowRequestFactory.CreateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                var CreateInsuranceRes = FASTWCFHelpers.EscrowService.CreateInsuranceResponse(CreateInsuranceReq);
               
                #region UI Validation
                Reports.TestStep = "Validate the UI";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual("248", FastDriver.InsuranceOther.OtherGABLabel.FAGetText());
#endregion

                #region
                Reports.TestStep = "Invoke remove insurance service";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes");
                var RemoveInsuranceRes = FASTWCFHelpers.EscrowService.RemoveInsurance(CreateInsuranceReq);
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.OtherInsuranceSummary.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.InsuranceSummary.SummaryEditOther.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                Support.AreEqual("Check Amount: $ 0.00", FastDriver.InsuranceOther.CheckAmount.FAGetText());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verif UpdateInsuranceDetails_Fire() service functionality")]
        public void Reg_UpdateInsuranceDetails_Fire()
        {

            try
            {
                Reports.TestStep = "Verify UpdateInsuranceDetails_Fire() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTSelenium.Common.FASTHelpers.FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FASTSelenium.Common.FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke Create Insurance Details service";
                var CreateInsuranceReq = EscrowRequestFactory.CreateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                var CreateInsuranceRes = FASTWCFHelpers.EscrowService.CreateInsuranceResponse(CreateInsuranceReq);
                var UpdateInsuranceReq = EscrowRequestFactory.UpdateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                UpdateInsuranceReq.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Fire;
                var UpdateInsuranceRes = FASTWCFHelpers.EscrowService.UpdateInsurance(UpdateInsuranceReq);

                #region UI Validation
                Reports.TestStep = "Validate the UI";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                Support.AreEqual("247", FastDriver.InsuranceFire.FireGABLabel.FAGetText());
                string premimum = null;
                if (UpdateInsuranceReq.InsuranceInformation.InsuranceDetails.Premium.Value.ToString() == "1100.01")
                {
                    premimum = "1,100.01";
                }

                Support.AreEqual(premimum, FastDriver.InsuranceFire.FirePremium.FAGetValue());
                string OtheroptMonths = null;
                if (FastDriver.InsuranceFire.FireoptMonths.Selected.ToString() == "True")
                {
                    OtheroptMonths = "Month";
                }
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceDetails.Term.Value.ToString(), FastDriver.InsuranceFire.FiretextTerm.FAGetValue());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceDetails.PremiumType.ToString(), OtheroptMonths);
                string BuyerCharge = FastDriver.InsuranceFire.FireBuyerCharge.FAGetValue();
                if (BuyerCharge == "1,000,000.00")
                {
                    BuyerCharge = "1000000";
                }
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].BuyerCharge.Value.ToString(), BuyerCharge);
                string SellerCharge = FastDriver.InsuranceFire.FireSellerCharge.FAGetValue();
                if (SellerCharge == "1,000,000.00")
                {
                    SellerCharge = "1000000";
                }
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].SellerCharge.Value.ToString(), SellerCharge);
                string prorationamt = null;
                if (UpdateInsuranceReq.InsuranceInformation.Proration.Amount.Value.ToString() == "11000.01")
                {
                    prorationamt = "11,000.01";
                }
                Support.AreEqual(prorationamt, FastDriver.InsuranceOther.OtherAmount.FAGetValue());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.Proration.FromDateInclusive.Value.ToString(), FastDriver.InsuranceOther.OtherfromInclusive.Selected.ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.Proration.ToDateInclusive.Value.ToString(), FastDriver.InsuranceOther.OthertoInclusive.Selected.ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.Proration.BasedOnDays.Value.ToString(), FastDriver.InsuranceOther.OtherBasedOn.FAGetSelectedItem().ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.Proration.AmountPeriod.ToString(), FastDriver.InsuranceOther.OtherPer.FAGetSelectedItem().ToString());

                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                string paymentmethod_buyer = null;
                if (UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].AtClosingBuyerPaymentMethodTypeID.ToString() == "CHK")
                {
                    paymentmethod_buyer = "Check";
                }
                string paymentmethod_seller = null;
                if (UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].AtClosingSellerPaymentMethodTypeID.ToString() == "CHK")
                {
                    paymentmethod_seller = "Check";
                }
                Support.AreEqual(paymentmethod_buyer, FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                Support.AreEqual(paymentmethod_seller, FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].PBOthersForBuyerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].PBOthersForSellerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verif UpdateInsuranceDetails_Flood() service functionality")]
        public void Reg_UpdateInsuranceDetails_Flood()
        {

            try
            {
                Reports.TestStep = "Verify UpdateInsuranceDetails_Fire() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTSelenium.Common.FASTHelpers.FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FASTSelenium.Common.FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke Create Insurance Details service";
                var CreateInsuranceReq = EscrowRequestFactory.CreateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                var CreateInsuranceRes = FASTWCFHelpers.EscrowService.CreateInsuranceResponse(CreateInsuranceReq);
                var UpdateInsuranceReq = EscrowRequestFactory.UpdateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                UpdateInsuranceReq.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Flood;
                var UpdateInsuranceRes = FASTWCFHelpers.EscrowService.UpdateInsurance(UpdateInsuranceReq);

                #region UI Validation
                Reports.TestStep = "Validate the UI";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Flood.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.Insuranceflood.WaitForScreenToLoad();
                Support.AreEqual("247", FastDriver.Insuranceflood.FloodGABLabel.FAGetText());
                string premimum = null;
                if (UpdateInsuranceReq.InsuranceInformation.InsuranceDetails.Premium.Value.ToString() == "1100.01")
                {
                    premimum = "1,100.01";
                }

                Support.AreEqual(premimum, FastDriver.Insuranceflood.FloodPremium.FAGetValue());
                string OtheroptMonths = null;
                if (FastDriver.Insuranceflood.FloodoptMonths.Selected.ToString() == "True")
                {
                    OtheroptMonths = "Month";
                }
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceDetails.Term.Value.ToString(), FastDriver.Insuranceflood.FloodtextTerm.FAGetValue());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceDetails.PremiumType.ToString(), OtheroptMonths);
                string BuyerCharge = FastDriver.Insuranceflood.FloodBuyercharge.FAGetValue();
                if (BuyerCharge == "1,000,000.00")
                {
                    BuyerCharge = "1000000";
                }
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].BuyerCharge.Value.ToString(), BuyerCharge);
                string SellerCharge = FastDriver.Insuranceflood.FloodSellerCharge.FAGetValue();
                if (SellerCharge == "1,000,000.00")
                {
                    SellerCharge = "1000000";
                }
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].SellerCharge.Value.ToString(), SellerCharge);
                string prorationamt = null;
                if (UpdateInsuranceReq.InsuranceInformation.Proration.Amount.Value.ToString() == "11000.01")
                {
                    prorationamt = "11,000.01";
                }
                Support.AreEqual(prorationamt, FastDriver.InsuranceOther.OtherAmount.FAGetValue());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.Proration.FromDateInclusive.Value.ToString(), FastDriver.InsuranceOther.OtherfromInclusive.Selected.ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.Proration.ToDateInclusive.Value.ToString(), FastDriver.InsuranceOther.OthertoInclusive.Selected.ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.Proration.BasedOnDays.Value.ToString(), FastDriver.InsuranceOther.OtherBasedOn.FAGetSelectedItem().ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.Proration.AmountPeriod.ToString(), FastDriver.InsuranceOther.OtherPer.FAGetSelectedItem().ToString());
                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                string paymentmethod_buyer = null;
                if (UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].AtClosingBuyerPaymentMethodTypeID.ToString() == "CHK")
                {
                    paymentmethod_buyer = "Check";
                }
                string paymentmethod_seller = null;
                if (UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].AtClosingSellerPaymentMethodTypeID.ToString() == "CHK")
                {
                    paymentmethod_seller = "Check";
                }
                Support.AreEqual(paymentmethod_buyer, FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                Support.AreEqual(paymentmethod_seller, FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].PBOthersForBuyerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].PBOthersForSellerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verif UpdateInsuranceDetails_Wind() service functionality")]
        public void Reg_UpdateInsuranceDetails_Wind()
        {

            try
            {
                Reports.TestStep = "Verify UpdateInsuranceDetails_Wind() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTSelenium.Common.FASTHelpers.FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FASTSelenium.Common.FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke Create Insurance Details service";
                var CreateInsuranceReq = EscrowRequestFactory.CreateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                var CreateInsuranceRes = FASTWCFHelpers.EscrowService.CreateInsuranceResponse(CreateInsuranceReq);
                var UpdateInsuranceReq = EscrowRequestFactory.UpdateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                UpdateInsuranceReq.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Wind;
                var UpdateInsuranceRes = FASTWCFHelpers.EscrowService.UpdateInsurance(UpdateInsuranceReq);

                #region UI Validation
                Reports.TestStep = "Validate the UI";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Wind.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceWind.WaitForScreenToLoad();
                Support.AreEqual("247", FastDriver.InsuranceWind.WindGABLabel.FAGetText());
                string premimum = null;
                if (UpdateInsuranceReq.InsuranceInformation.InsuranceDetails.Premium.Value.ToString() == "1100.01")
                {
                    premimum = "1,100.01";
                }

                Support.AreEqual(premimum, FastDriver.InsuranceWind.WindtextPremium.FAGetValue());
                string OtheroptMonths = null;
                if (FastDriver.InsuranceWind.WindoptMonths.Selected.ToString() == "True")
                {
                    OtheroptMonths = "Month";
                }
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceDetails.Term.Value.ToString(), FastDriver.InsuranceWind.WindtextTerm.FAGetValue());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceDetails.PremiumType.ToString(), OtheroptMonths);
                string BuyerCharge = FastDriver.InsuranceWind.WindBuyerCharge.FAGetValue();
                if (BuyerCharge == "1,000,000.00")
                {
                    BuyerCharge = "1000000";
                }
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].BuyerCharge.Value.ToString(), BuyerCharge);
                string SellerCharge = FastDriver.InsuranceWind.WindSellerCharge.FAGetValue();
                if (SellerCharge == "1,000,000.00")
                {
                    SellerCharge = "1000000";
                }
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].SellerCharge.Value.ToString(), SellerCharge);
                string prorationamt = null;
                if (UpdateInsuranceReq.InsuranceInformation.Proration.Amount.Value.ToString() == "11000.01")
                {
                    prorationamt = "11,000.01";
                }
                Support.AreEqual(prorationamt, FastDriver.InsuranceOther.OtherAmount.FAGetValue());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.Proration.FromDateInclusive.Value.ToString(), FastDriver.InsuranceOther.OtherfromInclusive.Selected.ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.Proration.ToDateInclusive.Value.ToString(), FastDriver.InsuranceOther.OthertoInclusive.Selected.ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.Proration.BasedOnDays.Value.ToString(), FastDriver.InsuranceOther.OtherBasedOn.FAGetSelectedItem().ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.Proration.AmountPeriod.ToString(), FastDriver.InsuranceOther.OtherPer.FAGetSelectedItem().ToString());

                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].AtClosingBuyerPaymentMethodTypeID.ToString(), FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].AtClosingSellerPaymentMethodTypeID.ToString(), FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].PBOthersForBuyerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].PBOthersForSellerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verif UpdateInsuranceDetails_Earthquake() service functionality")]
        public void Reg_UpdateInsuranceDetails_Earthquake()
        {

            try
            {
                Reports.TestStep = "Verify UpdateInsuranceDetails_Wind() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTSelenium.Common.FASTHelpers.FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FASTSelenium.Common.FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke Create Insurance Details service";
                var CreateInsuranceReq = EscrowRequestFactory.CreateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                var CreateInsuranceRes = FASTWCFHelpers.EscrowService.CreateInsuranceResponse(CreateInsuranceReq);
                var UpdateInsuranceReq = EscrowRequestFactory.UpdateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                UpdateInsuranceReq.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Earthquake;
                var UpdateInsuranceRes = FASTWCFHelpers.EscrowService.UpdateInsurance(UpdateInsuranceReq);

                #region UI Validation
                Reports.TestStep = "Validate the UI";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceEarth.WaitForScreenToLoad();
                Support.AreEqual("247", FastDriver.InsuranceEarth.EarthGABLabel.FAGetText());
                string premimum = null;
                if (UpdateInsuranceReq.InsuranceInformation.InsuranceDetails.Premium.Value.ToString() == "1100.01")
                {
                    premimum = "1,100.01";
                }

                Support.AreEqual(premimum, FastDriver.InsuranceEarth.EarthtextPremium.FAGetValue());
                string OtheroptMonths = null;
                if (FastDriver.InsuranceEarth.EarthMonths.Selected.ToString() == "True")
                {
                    OtheroptMonths = "Month";
                }
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceDetails.Term.Value.ToString(), FastDriver.InsuranceEarth.EarthtextTerm.FAGetValue());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceDetails.PremiumType.ToString(), OtheroptMonths);
                string BuyerCharge = FastDriver.InsuranceEarth.EarthBuyerCharge.FAGetValue();
                if (BuyerCharge == "1,000,000.00")
                {
                    BuyerCharge = "1000000";
                }
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].BuyerCharge.Value.ToString(), BuyerCharge);
                string SellerCharge = FastDriver.InsuranceEarth.EarthSellerCharge.FAGetValue();
                if (SellerCharge == "1,000,000.00")
                {
                    SellerCharge = "1000000";
                }
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].SellerCharge.Value.ToString(), SellerCharge);
                string prorationamt = null;
                if (UpdateInsuranceReq.InsuranceInformation.Proration.Amount.Value.ToString() == "11000.01")
                {
                    prorationamt = "11,000.01";
                }
                Support.AreEqual(prorationamt, FastDriver.InsuranceOther.OtherAmount.FAGetValue());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.Proration.FromDateInclusive.Value.ToString(), FastDriver.InsuranceOther.OtherfromInclusive.Selected.ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.Proration.ToDateInclusive.Value.ToString(), FastDriver.InsuranceOther.OthertoInclusive.Selected.ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.Proration.BasedOnDays.Value.ToString(), FastDriver.InsuranceOther.OtherBasedOn.FAGetSelectedItem().ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.Proration.AmountPeriod.ToString(), FastDriver.InsuranceOther.OtherPer.FAGetSelectedItem().ToString());

                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].AtClosingBuyerPaymentMethodTypeID.ToString(), FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].AtClosingSellerPaymentMethodTypeID.ToString(), FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].PBOthersForBuyerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].PBOthersForSellerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verify RemoveInsurance_Fire() service functionality")]
        public void Reg_RemoveInsurance_Fire()
        {

            try
            {
                Reports.TestStep = "Verify RemoveInsurance_Fire() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTSelenium.Common.FASTHelpers.FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FASTSelenium.Common.FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke Create and remove Insurance services";
                var CreateInsuranceReq = EscrowRequestFactory.CreateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                var CreateInsuranceRes = FASTWCFHelpers.EscrowService.CreateInsuranceResponse(CreateInsuranceReq);
                var UpdateInsuranceReq = EscrowRequestFactory.UpdateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                UpdateInsuranceReq.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Fire;
                var UpdateInsuranceRes = FASTWCFHelpers.EscrowService.UpdateInsurance(UpdateInsuranceReq);

                #region UI Validation
                Reports.TestStep = "Validate the UI";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                Support.AreEqual("248", FastDriver.InsuranceFire.FireGABLabel.FAGetText());
                #endregion

                #region
                Reports.TestStep = "Invoke remove insurance service";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes");
                var RemoveInsuranceRes = FASTWCFHelpers.EscrowService.RemoveInsurance(UpdateInsuranceReq);
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                Support.AreEqual("Check Amount: $ 0.00", FastDriver.InsuranceFire.CheckAmount.FAGetText());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verify RemoveInsurance_Flood() service functionality")]
        public void Reg_RemoveInsurance_Flood()
        {

            try
            {
                Reports.TestStep = "Verify RemoveInsurance_Flood() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTSelenium.Common.FASTHelpers.FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FASTSelenium.Common.FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke Create and remove Insurance services";
                var CreateInsuranceReq = EscrowRequestFactory.CreateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                var CreateInsuranceRes = FASTWCFHelpers.EscrowService.CreateInsuranceResponse(CreateInsuranceReq);
                var UpdateInsuranceReq = EscrowRequestFactory.UpdateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                UpdateInsuranceReq.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Flood;
                var UpdateInsuranceRes = FASTWCFHelpers.EscrowService.UpdateInsurance(UpdateInsuranceReq);

                #region UI Validation
                Reports.TestStep = "Validate the UI";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Flood.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.Insuranceflood.WaitForScreenToLoad();
                Support.AreEqual("248", FastDriver.Insuranceflood.FloodGABLabel.FAGetText());
                #endregion

                #region Invoke remove insurance service
                Reports.TestStep = "Invoke remove insurance service";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes");
                var RemoveInsuranceRes = FASTWCFHelpers.EscrowService.RemoveInsurance(UpdateInsuranceReq);
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Flood.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.Insuranceflood.WaitForScreenToLoad();
                Support.AreEqual("Check Amount: $ 0.00", FastDriver.Insuranceflood.FloodAmount.FAGetText());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verify RemoveInsurance_Wind() service functionality")]
        public void Reg_RemoveInsurance_Wind()
        {

            try
            {
                Reports.TestStep = "Verify RemoveInsurance_Wind() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTSelenium.Common.FASTHelpers.FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FASTSelenium.Common.FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke Create and remove Insurance services";
                var CreateInsuranceReq = EscrowRequestFactory.CreateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                var CreateInsuranceRes = FASTWCFHelpers.EscrowService.CreateInsuranceResponse(CreateInsuranceReq);
                var UpdateInsuranceReq = EscrowRequestFactory.UpdateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                UpdateInsuranceReq.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Wind;
                var UpdateInsuranceRes = FASTWCFHelpers.EscrowService.UpdateInsurance(UpdateInsuranceReq);

                #region UI Validation
                Reports.TestStep = "Validate the UI";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Wind.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceWind.WaitForScreenToLoad();
                Support.AreEqual("247", FastDriver.InsuranceWind.WindGABLabel.FAGetText());
                #endregion

                #region Invoke remove insurance service
                Reports.TestStep = "Invoke remove insurance service";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes");
                var RemoveInsuranceRes = FASTWCFHelpers.EscrowService.RemoveInsurance(UpdateInsuranceReq);
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Wind.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceWind.WaitForScreenToLoad();
                Support.AreEqual("0", FastDriver.InsuranceWind.WindtextTerm.FAGetValue());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verify RemoveInsurance_Earthquake() service functionality")]
        public void Reg_RemoveInsurance_Earthquake()
        {

            try
            {
                Reports.TestStep = "Verify RemoveInsurance_Earthquake() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTSelenium.Common.FASTHelpers.FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FASTSelenium.Common.FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke Create and remove Insurance services";
                var CreateInsuranceReq = EscrowRequestFactory.CreateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                var CreateInsuranceRes = FASTWCFHelpers.EscrowService.CreateInsuranceResponse(CreateInsuranceReq);
                var UpdateInsuranceReq = EscrowRequestFactory.UpdateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                UpdateInsuranceReq.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Earthquake;
                var UpdateInsuranceRes = FASTWCFHelpers.EscrowService.UpdateInsurance(UpdateInsuranceReq);

                #region UI Validation
                Reports.TestStep = "Validate the UI";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceEarth.WaitForScreenToLoad();
                Support.AreEqual("247", FastDriver.InsuranceEarth.EarthGABLabel.FAGetText());
                #endregion

                #region Invoke remove insurance service
                Reports.TestStep = "Invoke remove insurance service";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes");
                var RemoveInsuranceRes = FASTWCFHelpers.EscrowService.RemoveInsurance(UpdateInsuranceReq);
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceEarth.WaitForScreenToLoad();
                Support.AreEqual("0", FastDriver.InsuranceEarth.EarthtextTerm.FAGetValue());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verif GetInsuranceDetails_Fire() service functionality")]
        public void Reg_GetInsuranceDetails_Fire()
        {

            try
            {
                Reports.TestStep = "Verify UpdateInsuranceDetails_Fire() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTSelenium.Common.FASTHelpers.FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FASTSelenium.Common.FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke Create Insurance Details service";
                var CreateInsuranceReq = EscrowRequestFactory.CreateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                var CreateInsuranceRes = FASTWCFHelpers.EscrowService.CreateInsuranceResponse(CreateInsuranceReq);
                var UpdateInsuranceReq = EscrowRequestFactory.UpdateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                UpdateInsuranceReq.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Fire;
                var UpdateInsuranceRes = FASTWCFHelpers.EscrowService.UpdateInsurance(UpdateInsuranceReq);
                var GetInsuranceReq = EscrowRequestFactory.GetInsuranceDetailRequest(FASTSelenium.Common.FASTHelpers.File.FileID);
                var GetInsuranceRes = FASTWCFHelpers.EscrowService.GetInsuranceDetilsResponse(GetInsuranceReq);
                

                #region UI Validation
                Reports.TestStep = "Validate the UI";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Fire.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceFire.WaitForScreenToLoad();
                Support.AreEqual("247", FastDriver.InsuranceFire.FireGABLabel.FAGetText());
                string premimum = null;
                if (GetInsuranceRes.Fire.InsuranceDetails.Premium.Value.ToString() == "1100.01")
                {
                    premimum = "1,100.01";
                }

                Support.AreEqual(premimum, FastDriver.InsuranceFire.FirePremium.FAGetValue());
                string OtheroptMonths = null;
                if (FastDriver.InsuranceFire.FireoptMonths.Selected.ToString() == "True")
                {
                    OtheroptMonths = "Month";
                }
                Support.AreEqual(GetInsuranceRes.Fire.InsuranceDetails.Term.Value.ToString(), FastDriver.InsuranceFire.FiretextTerm.FAGetValue());
                Support.AreEqual(GetInsuranceRes.Fire.InsuranceDetails.PremiumType.ToString(), OtheroptMonths);
                string BuyerCharge = FastDriver.InsuranceFire.FireBuyerCharge.FAGetValue();
                if (BuyerCharge == "1,000,000.00")
                {
                    BuyerCharge = "1000000";
                }
                Support.AreEqual(GetInsuranceRes.Fire.InsuranceCharges.CDInsuranceChargesList[0].BuyerCharge.Value.ToString(), BuyerCharge);
                string SellerCharge = FastDriver.InsuranceFire.FireSellerCharge.FAGetValue();
                if (SellerCharge == "1,000,000.00")
                {
                    SellerCharge = "1000000";
                }
                Support.AreEqual(GetInsuranceRes.Fire.InsuranceCharges.CDInsuranceChargesList[0].SellerCharge.Value.ToString(), SellerCharge);
                string prorationamt = null;
                if (GetInsuranceRes.Fire.Proration.Amount.Value.ToString() == "11000.01")
                {
                    prorationamt = "11,000.01";
                }
                Support.AreEqual(prorationamt, FastDriver.InsuranceOther.OtherAmount.FAGetValue());
                Support.AreEqual(GetInsuranceRes.Fire.Proration.FromDateInclusive.Value.ToString(), FastDriver.InsuranceOther.OtherfromInclusive.Selected.ToString());
                Support.AreEqual(GetInsuranceRes.Fire.Proration.ToDateInclusive.Value.ToString(), FastDriver.InsuranceOther.OthertoInclusive.Selected.ToString());
                Support.AreEqual(GetInsuranceRes.Fire.Proration.BasedOnDays.Value.ToString(), FastDriver.InsuranceOther.OtherBasedOn.FAGetSelectedItem().ToString());
                Support.AreEqual(GetInsuranceRes.Fire.Proration.AmountPeriod.ToString(), FastDriver.InsuranceOther.OtherPer.FAGetSelectedItem().ToString());

                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                string paymentmethod_buyer = null;
                if (UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].AtClosingBuyerPaymentMethodTypeID.ToString() == "CHK")
                {
                    paymentmethod_buyer = "Check";
                }
                string paymentmethod_seller = null;
                if (UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].AtClosingSellerPaymentMethodTypeID.ToString() == "CHK")
                {
                    paymentmethod_seller = "Check";
                }
                Support.AreEqual(paymentmethod_buyer, FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                Support.AreEqual(paymentmethod_seller, FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].PBOthersForBuyerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].PBOthersForSellerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verif GetInsuranceDetails_Flood() service functionality")]
        public void Reg_GetInsuranceDetails_Flood()
        {

            try
            {
                Reports.TestStep = "Verify UpdateInsuranceDetails_Fire() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTSelenium.Common.FASTHelpers.FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FASTSelenium.Common.FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke Create Insurance Details service";
                var CreateInsuranceReq = EscrowRequestFactory.CreateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                var CreateInsuranceRes = FASTWCFHelpers.EscrowService.CreateInsuranceResponse(CreateInsuranceReq);
                var UpdateInsuranceReq = EscrowRequestFactory.UpdateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                UpdateInsuranceReq.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Flood;
                var UpdateInsuranceRes = FASTWCFHelpers.EscrowService.UpdateInsurance(UpdateInsuranceReq);
                var GetInsuranceReq = EscrowRequestFactory.GetInsuranceDetailRequest(FASTSelenium.Common.FASTHelpers.File.FileID);
                var GetInsuranceRes = FASTWCFHelpers.EscrowService.GetInsuranceDetilsResponse(GetInsuranceReq);
                

                #region UI Validation
                Reports.TestStep = "Validate the UI";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Flood.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.Insuranceflood.WaitForScreenToLoad();
                Support.AreEqual("247", FastDriver.Insuranceflood.FloodGABLabel.FAGetText());
                string premimum = null;
                if (GetInsuranceRes.Flood.InsuranceDetails.Premium.Value.ToString() == "1100.01")
                {
                    premimum = "1,100.01";
                }

                Support.AreEqual(premimum, FastDriver.Insuranceflood.FloodPremium.FAGetValue());
                string OtheroptMonths = null;
                if (FastDriver.Insuranceflood.FloodoptMonths.Selected.ToString() == "True")
                {
                    OtheroptMonths = "Month";
                }
                Support.AreEqual(GetInsuranceRes.Flood.InsuranceDetails.Term.Value.ToString(), FastDriver.Insuranceflood.FloodtextTerm.FAGetValue());
                Support.AreEqual(GetInsuranceRes.Flood.InsuranceDetails.PremiumType.ToString(), OtheroptMonths);
                string BuyerCharge = FastDriver.Insuranceflood.FloodBuyercharge.FAGetValue();
                if (BuyerCharge == "1,000,000.00")
                {
                    BuyerCharge = "1000000";
                }
                Support.AreEqual(GetInsuranceRes.Flood.InsuranceCharges.CDInsuranceChargesList[0].BuyerCharge.Value.ToString(), BuyerCharge);
                string SellerCharge = FastDriver.Insuranceflood.FloodSellerCharge.FAGetValue();
                if (SellerCharge == "1,000,000.00")
                {
                    SellerCharge = "1000000";
                }
                Support.AreEqual(GetInsuranceRes.Flood.InsuranceCharges.CDInsuranceChargesList[0].SellerCharge.Value.ToString(), SellerCharge);
                string prorationamt = null;
                if (GetInsuranceRes.Flood.Proration.Amount.Value.ToString() == "11000.01")
                {
                    prorationamt = "11,000.01";
                }
                Support.AreEqual(prorationamt, FastDriver.InsuranceOther.OtherAmount.FAGetValue());
                Support.AreEqual(GetInsuranceRes.Flood.Proration.FromDateInclusive.Value.ToString(), FastDriver.InsuranceOther.OtherfromInclusive.Selected.ToString());
                Support.AreEqual(GetInsuranceRes.Flood.Proration.ToDateInclusive.Value.ToString(), FastDriver.InsuranceOther.OthertoInclusive.Selected.ToString());
                Support.AreEqual(GetInsuranceRes.Flood.Proration.BasedOnDays.Value.ToString(), FastDriver.InsuranceOther.OtherBasedOn.FAGetSelectedItem().ToString());
                Support.AreEqual(GetInsuranceRes.Flood.Proration.AmountPeriod.ToString(), FastDriver.InsuranceOther.OtherPer.FAGetSelectedItem().ToString());

                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                string paymentmethod_buyer = null;
                if (UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].AtClosingBuyerPaymentMethodTypeID.ToString() == "CHK")
                {
                    paymentmethod_buyer = "Check";
                }
                string paymentmethod_seller = null;
                if (UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].AtClosingSellerPaymentMethodTypeID.ToString() == "CHK")
                {
                    paymentmethod_seller = "Check";
                }
                Support.AreEqual(paymentmethod_buyer, FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                Support.AreEqual(paymentmethod_seller, FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].PBOthersForBuyerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].PBOthersForSellerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verif GetInsuranceDetails_Wind() service functionality")]
        public void Reg_GetInsuranceDetails_Wind()
        {

            try
            {
                Reports.TestStep = "Verify UpdateInsuranceDetails_Wind() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTSelenium.Common.FASTHelpers.FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FASTSelenium.Common.FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke Create Insurance Details service";
                var CreateInsuranceReq = EscrowRequestFactory.CreateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                var CreateInsuranceRes = FASTWCFHelpers.EscrowService.CreateInsuranceResponse(CreateInsuranceReq);
                var UpdateInsuranceReq = EscrowRequestFactory.UpdateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                UpdateInsuranceReq.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Wind;
                var UpdateInsuranceRes = FASTWCFHelpers.EscrowService.UpdateInsurance(UpdateInsuranceReq);
                var GetInsuranceReq = EscrowRequestFactory.GetInsuranceDetailRequest(FASTSelenium.Common.FASTHelpers.File.FileID);
                var GetInsuranceRes = FASTWCFHelpers.EscrowService.GetInsuranceDetilsResponse(GetInsuranceReq);
                
                #region UI Validation
                Reports.TestStep = "Validate the UI";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.Wind.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceWind.WaitForScreenToLoad();
                Support.AreEqual("247", FastDriver.InsuranceWind.WindGABLabel.FAGetText());
                string premimum = null;
                if (GetInsuranceRes.Wind.InsuranceDetails.Premium.Value.ToString() == "1100.01")
                {
                    premimum = "1,100.01";
                }

                Support.AreEqual(premimum, FastDriver.InsuranceWind.WindtextPremium.FAGetValue());
                string OtheroptMonths = null;
                if (FastDriver.InsuranceWind.WindoptMonths.Selected.ToString() == "True")
                {
                    OtheroptMonths = "Month";
                }
                Support.AreEqual(GetInsuranceRes.Wind.InsuranceDetails.Term.Value.ToString(), FastDriver.InsuranceWind.WindtextTerm.FAGetValue());
                Support.AreEqual(GetInsuranceRes.Wind.InsuranceDetails.PremiumType.ToString(), OtheroptMonths);
                string BuyerCharge = FastDriver.InsuranceWind.WindBuyerCharge.FAGetValue();
                if (BuyerCharge == "1,000,000.00")
                {
                    BuyerCharge = "1000000";
                }
                Support.AreEqual(GetInsuranceRes.Wind.InsuranceCharges.CDInsuranceChargesList[0].BuyerCharge.Value.ToString(), BuyerCharge);
                string SellerCharge = FastDriver.InsuranceWind.WindSellerCharge.FAGetValue();
                if (SellerCharge == "1,000,000.00")
                {
                    SellerCharge = "1000000";
                }
                Support.AreEqual(GetInsuranceRes.Wind.InsuranceCharges.CDInsuranceChargesList[0].SellerCharge.Value.ToString(), SellerCharge);
                string prorationamt = null;
                if (GetInsuranceRes.Wind.Proration.Amount.Value.ToString() == "11000.01")
                {
                    prorationamt = "11,000.01";
                }
                Support.AreEqual(prorationamt, FastDriver.InsuranceOther.OtherAmount.FAGetValue());
                Support.AreEqual(GetInsuranceRes.Wind.Proration.FromDateInclusive.Value.ToString(), FastDriver.InsuranceOther.OtherfromInclusive.Selected.ToString());
                Support.AreEqual(GetInsuranceRes.Wind.Proration.ToDateInclusive.Value.ToString(), FastDriver.InsuranceOther.OthertoInclusive.Selected.ToString());
                Support.AreEqual(GetInsuranceRes.Wind.Proration.BasedOnDays.Value.ToString(), FastDriver.InsuranceOther.OtherBasedOn.FAGetSelectedItem().ToString());
                Support.AreEqual(GetInsuranceRes.Wind.Proration.AmountPeriod.ToString(), FastDriver.InsuranceOther.OtherPer.FAGetSelectedItem().ToString());

                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                string paymentmethod_buyer = null;
                if (UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].AtClosingBuyerPaymentMethodTypeID.ToString() == "CHK")
                {
                    paymentmethod_buyer = "Check";
                }
                string paymentmethod_seller = null;
                if (UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].AtClosingSellerPaymentMethodTypeID.ToString() == "CHK")
                {
                    paymentmethod_seller = "Check";
                }
                Support.AreEqual(paymentmethod_buyer, FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                Support.AreEqual(paymentmethod_seller, FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].PBOthersForBuyerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].PBOthersForSellerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verif GetInsuranceDetails_Earthquake() service functionality")]
        public void Reg_GetInsuranceDetails_Earthquake()
        {

            try
            {
                Reports.TestStep = "Verify UpdateInsuranceDetails_Wind() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTSelenium.Common.FASTHelpers.FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FASTSelenium.Common.FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke Create Insurance Details service";
                var CreateInsuranceReq = EscrowRequestFactory.CreateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                var CreateInsuranceRes = FASTWCFHelpers.EscrowService.CreateInsuranceResponse(CreateInsuranceReq);
                var UpdateInsuranceReq = EscrowRequestFactory.UpdateInsuranceReq(FASTSelenium.Common.FASTHelpers.File.FileID);
                UpdateInsuranceReq.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Earthquake;
                var UpdateInsuranceRes = FASTWCFHelpers.EscrowService.UpdateInsurance(UpdateInsuranceReq);
                var GetInsuranceReq = EscrowRequestFactory.GetInsuranceDetailRequest(FASTSelenium.Common.FASTHelpers.File.FileID);
                var GetInsuranceRes = FASTWCFHelpers.EscrowService.GetInsuranceDetilsResponse(GetInsuranceReq);
                
                #region UI Validation
                Reports.TestStep = "Validate the UI";
                FastDriver.LeftNavigation.Navigate<InsuranceSummary>("Home>Order Entry>Escrow Charge Processes>Insurance").WaitForScreenToLoad();
                FastDriver.InsuranceSummary.EarthQuake.FAClick();
                FastDriver.InsuranceSummary.SummaryEdit.FAClick();
                FastDriver.InsuranceEarth.WaitForScreenToLoad();
                Support.AreEqual("247", FastDriver.InsuranceEarth.EarthGABLabel.FAGetText());
                string premimum = null;
                if (GetInsuranceRes.EarthQuake.InsuranceDetails.Premium.Value.ToString() == "1100.01")
                {
                    premimum = "1,100.01";
                }

                Support.AreEqual(premimum, FastDriver.InsuranceEarth.EarthtextPremium.FAGetValue());
                string OtheroptMonths = null;
                if (FastDriver.InsuranceEarth.EarthMonths.Selected.ToString() == "True")
                {
                    OtheroptMonths = "Month";
                }
                Support.AreEqual(GetInsuranceRes.EarthQuake.InsuranceDetails.Term.Value.ToString(), FastDriver.InsuranceEarth.EarthtextTerm.FAGetValue());
                Support.AreEqual(GetInsuranceRes.EarthQuake.InsuranceDetails.PremiumType.ToString(), OtheroptMonths);
                string BuyerCharge = FastDriver.InsuranceEarth.EarthBuyerCharge.FAGetValue();
                if (BuyerCharge == "1,000,000.00")
                {
                    BuyerCharge = "1000000";
                }
                Support.AreEqual(GetInsuranceRes.EarthQuake.InsuranceCharges.CDInsuranceChargesList[0].BuyerCharge.Value.ToString(), BuyerCharge);
                string SellerCharge = FastDriver.InsuranceEarth.EarthSellerCharge.FAGetValue();
                if (SellerCharge == "1,000,000.00")
                {
                    SellerCharge = "1000000";
                }
                Support.AreEqual(GetInsuranceRes.EarthQuake.InsuranceCharges.CDInsuranceChargesList[0].SellerCharge.Value.ToString(), SellerCharge);
                string prorationamt = null;
                if (GetInsuranceRes.EarthQuake.Proration.Amount.Value.ToString() == "11000.01")
                {
                    prorationamt = "11,000.01";
                }
                Support.AreEqual(prorationamt, FastDriver.InsuranceOther.OtherAmount.FAGetValue());
                Support.AreEqual(GetInsuranceRes.EarthQuake.Proration.FromDateInclusive.Value.ToString(), FastDriver.InsuranceOther.OtherfromInclusive.Selected.ToString());
                Support.AreEqual(GetInsuranceRes.EarthQuake.Proration.ToDateInclusive.Value.ToString(), FastDriver.InsuranceOther.OthertoInclusive.Selected.ToString());
                Support.AreEqual(GetInsuranceRes.EarthQuake.Proration.BasedOnDays.Value.ToString(), FastDriver.InsuranceOther.OtherBasedOn.FAGetSelectedItem().ToString());
                Support.AreEqual(GetInsuranceRes.EarthQuake.Proration.AmountPeriod.ToString(), FastDriver.InsuranceOther.OtherPer.FAGetSelectedItem().ToString());

                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                string paymentmethod_buyer = null;
                if (UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].AtClosingBuyerPaymentMethodTypeID.ToString() == "CHK")
                {
                    paymentmethod_buyer = "Check";
                }
                string paymentmethod_seller = null;
                if (UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].AtClosingSellerPaymentMethodTypeID.ToString() == "CHK")
                {
                    paymentmethod_seller = "Check";
                }
                Support.AreEqual(paymentmethod_buyer, FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                Support.AreEqual(paymentmethod_seller, FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].PBOthersForBuyerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                Support.AreEqual(UpdateInsuranceReq.InsuranceInformation.InsuranceCharges.CDInsuranceChargesList[0].PBOthersForSellerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


      }
}
