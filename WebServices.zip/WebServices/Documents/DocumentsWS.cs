﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastDocumentService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using WebServices.Helpers.Documents;


namespace WebServices.Documents
{
    [CodedUITest]
    public class DocumentsWS : MasterTestClass
    {

        [TestMethod]
        public void REG0001_AddDocumentsToAssociateDocPackage()
        {
            try
            {
                Reports.TestDescription = "Validate AddDocumentsToAssociateDocPackage web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add four documents to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID_1 = Convert.ToInt32(response.Templates[0].TemplateID);
                int templateID_2 = Convert.ToInt32(response.Templates[1].TemplateID);
                int templateID_3 = Convert.ToInt32(response.Templates[2].TemplateID);
                int templateID_4 = Convert.ToInt32(response.Templates[3].TemplateID);

                int docID_1 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_1).DocumentID;
                int docID_2 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_2).DocumentID;
                int docID_3 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_3).DocumentID;
                int docID_4 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_4).DocumentID;
                string docName_4 = response.Templates[3].Descr;

                Document[] docs = new Document[]
                {
                    new Document()
                    {
                        DocumentID = docID_1
                    },
                    new Document()
                    {
                        DocumentID = docID_2
                    },
                    new Document()
                    {
                        DocumentID = docID_3
                    }
                };

                Reports.TestStep = "Create Associate Doc Package with the first three documents(WS)";
                var CreateAssociateDocPackageResponse = DocumentsHelpers.CreateAssociateDocPackage(fileID, docs, "TestAssociateDocPackage");
                long packageID = CreateAssociateDocPackageResponse.AssociateDocPackageID;

                Reports.TestStep = "Invoke AddDocumentsToAssociateDocPackage and validate response (WS)";
                FASTWCFHelpers.FastDocumentService.Document[] docs2 = new FASTWCFHelpers.FastDocumentService.Document[]
                {
                    new FASTWCFHelpers.FastDocumentService.Document()
                    {
                        DocumentID = docID_4
                    }
                };
                var addDocResponse = WebServices.Helpers.Documents.DocumentsHelpers.AddDocumentsToAssociateDocPackage(fileID, docs2, packageID);
                Support.AreEqual("1", addDocResponse.Status.ToString(), "Operation Status");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate the new document is added to the package";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.AssociateDocsTab.FAClick();
                FastDriver.DocumentRepository.WaitForAssociateDocTabToLoad();
                Support.AreEqual(docName_4, FastDriver.DocumentRepository.PackageDocumentsTable.PerformTableAction(4, 1, TableAction.GetText).Message, "Document Name");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }

        }

        [TestMethod]
        public void REG0002_AddPhrasesToDocument()
        {
            try
            {
                Reports.TestDescription = "Validate AddPhrasesToDocument web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Add a phrase to the document (WS), validate response";
                var response = DocumentsHelpers.AddPhrasesToDocument(fileID: fileID, docID: docID, phraseCode: @"XRL/15");
                Support.AreEqual("1", response.Status.ToString(), "Validate status operation");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to event tracking log, validate [Update Document] event";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqual("Phrase(s) added successfully.DocumentID: " + docID.ToString() + " Document Name: " + templateName, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Update Document]", 5, TableAction.GetText).Message, "[Update Document]");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0003_CreateAssociateDocPackage()
        {
            try
            {
                Reports.TestDescription = "Validate CreateAssociateDocPackage web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add three documents to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID_1 = Convert.ToInt32(response.Templates[0].TemplateID);
                int templateID_2 = Convert.ToInt32(response.Templates[1].TemplateID);
                int templateID_3 = Convert.ToInt32(response.Templates[2].TemplateID);

                int docID_1 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_1).DocumentID;
                int docID_2 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_2).DocumentID;
                int docID_3 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_3).DocumentID;

                FASTWCFHelpers.FastDocumentService.Document[] docs = new FASTWCFHelpers.FastDocumentService.Document[]
                {
                    new FASTWCFHelpers.FastDocumentService.Document()
                    {
                        DocumentID = docID_1
                    },
                    new FASTWCFHelpers.FastDocumentService.Document()
                    {
                        DocumentID = docID_2
                    },
                    new FASTWCFHelpers.FastDocumentService.Document()
                    {
                        DocumentID = docID_3
                    }
                };

                Reports.TestStep = "Create Associate Doc Package and validate response (WS)";
                var CreateAssociateDocPackageResponse = WebServices.Helpers.Documents.DocumentsHelpers.CreateAssociateDocPackage(fileID, docs, "TestAssociateDocPackage");
                Support.AreEqual("1", CreateAssociateDocPackageResponse.Status.ToString(), "Status Operation");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate the associate package is present";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.AssociateDocsTab.FAClick();
                FastDriver.DocumentRepository.WaitForAssociateDocTabToLoad();
                Support.AreEqual("TestAssociateDocPackage", FastDriver.DocumentRepository.AssPackageTable.PerformTableAction(1, 1, TableAction.GetText).Message, "Package Name");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0004_CreateDocument()
        {
            try
            {
                Reports.TestDescription = "Validate CreateDocument web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID = Convert.ToInt32(response.Templates[0].TemplateID);
                string templateName = response.Templates[0].Descr;
                int docID = (int)WebServices.Helpers.Documents.DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to target file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate document " + templateName + " is present";
                FastDriver.DocumentRepository.Open();
                Support.AreEqual(templateName, FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(9, "Created", 4, TableAction.GetText).Message, templateName);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0005_EditDocument()
        {
            try
            {
                Reports.TestDescription = "Validate EditDocument web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID = Convert.ToInt32(response.Templates[0].TemplateID);
                string templateName = response.Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Edit document name and validate response (WS)";
                var editDocResponse = WebServices.Helpers.Documents.DocumentsHelpers.EditDocument(fileID, docID, "Edit Document Name");
                Support.AreEqual("1", editDocResponse.Status.ToString(), "Operation Status");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate document name has changed";
                FastDriver.DocumentRepository.Open();
                Support.AreEqual("Edit Document Name", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(9, "Created", 4, TableAction.GetText).Message, "Edit Document Name");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0006_FinalizeDocument()
        {
            try
            {
                Reports.TestDescription = "Validate FinalizeDocument web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID = Convert.ToInt32(response.Templates[0].TemplateID);
                string templateName = response.Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Finalize the document and validate response(WS)";
                var finalizeDocResponse = WebServices.Helpers.Documents.DocumentsHelpers.FinalizeDocument(fileID, docID);
                Support.AreEqual("1", finalizeDocResponse.Status.ToString(), "Status Operation");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate document is finalized";
                FastDriver.DocumentRepository.Open();
                Support.AreEqual("Finalized", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, templateName, 9, TableAction.GetText).Message, templateName);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0007_GetAssociateDocPackages()
        {
            try
            {
                Reports.TestDescription = "Validate GetAssociateDocPackages web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add three documents to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID_1 = Convert.ToInt32(response.Templates[0].TemplateID);
                int templateID_2 = Convert.ToInt32(response.Templates[1].TemplateID);
                int templateID_3 = Convert.ToInt32(response.Templates[2].TemplateID);

                int docID_1 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_1).DocumentID;
                int docID_2 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_2).DocumentID;
                int docID_3 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_3).DocumentID;

                FASTWCFHelpers.FastDocumentService.Document[] docs = new FASTWCFHelpers.FastDocumentService.Document[]
                {
                    new FASTWCFHelpers.FastDocumentService.Document()
                    {
                        DocumentID = docID_1
                    },
                    new FASTWCFHelpers.FastDocumentService.Document()
                    {
                        DocumentID = docID_2
                    },
                    new FASTWCFHelpers.FastDocumentService.Document()
                    {
                        DocumentID = docID_3
                    }
                };

                Reports.TestStep = "Create Associate Doc Package (WS)";
                WebServices.Helpers.Documents.DocumentsHelpers.CreateAssociateDocPackage(fileID, docs, "TestAssociateDocPackage");

                Reports.TestStep = "Invoke GetAssociateDocPackage and validate response (WS)";
                var GetAssociateDocPackagesRequest = DocumentRequestFactory.GetServiceFileRequest(fileID);
                var GetAssociateDocPackagesResponse = WebServices.Helpers.Documents.DocumentsHelpers.GetAssociateDocPackages(GetAssociateDocPackagesRequest);
                Support.AreEqual("TestAssociateDocPackage", GetAssociateDocPackagesResponse.PackageList[0].PackageName, "Package Name");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { }
        }

        [TestMethod]
        public void REG0008_AddPhraseMarkerDocService()
        {
            try
            {
                Reports.TestDescription = "Validate AddPhraseMarker web method";
                #region DataSetup
                var response = new OperationResponse();
                #endregion

                #region Create a file using WS.
                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Add a document to the file using webservice and verify it in UI.
                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Get the document details for the added document using webservice.";
                var docDtlRespnc = DocumentsHelpers.GetDocumentDetails(fileID, docID);

                Reports.TestStep = "Login to FAST and Verify in UI.";
                Login();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to the Event log and verify that document has been added.";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqual("Document:" + docDtlRespnc.DocName + "Status:Successful", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Create Document]", 5, TableAction.GetText).Message.Replace("\r\n", string.Empty), "Verifying the document is added at UI as well.");
                #endregion

                #region Invoke AddPhraseMarker web service for each phrase and verify it in UI side.
                Reports.TestStep = "Invoking the AddPhraseMarker webservice.";
                DocumentsHelpers.AddPhraseMarker(fileID, docID);

                Reports.TestStep = "Navigate to the document repository page and open the added document.";
                FastDriver.DocumentRepository.Open();
                List<string> documentsToselet = new List<string> { docDtlRespnc.DocName };
                FastDriver.DocumentRepository.SelectDocumentsByName(documentsToselet);
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Verify that phrase marker is added in given sequence.";
                Support.AreEqual(true, FastDriver.DocumentPreparation.PhraseTable.FAGetText().Contains("Phrase Marker"), "Verifying that Phrase Marker is added at UI");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0009_CreateImageDocumentDocService()
        {
            try
            {
                Reports.TestDescription = "Validate CreateImageDocument web method";

                #region Create a basic file using the WS.
                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Add a document to the file (WS).
                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;
                #endregion

                #region Finalize the document using the WS.
                Reports.TestStep = "Finalize the document and validate response(WS)";
                var finalizeDocResponse = DocumentsHelpers.FinalizeDocument(fileID, docID);
                Support.AreEqual("1", finalizeDocResponse.Status.ToString(), "Status Operation");
                #endregion

                #region Invoke CreateImageDocument web method and validate response (WS).
                Reports.TestStep = "Invoke CreateImageDocument web method and validate response (WS)";
                var response = DocumentsHelpers.CreateImageDocument(fileID: fileID, docID: docID);
                #endregion

                #region Validate the details in FAST application.
                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate image document " + templateName + " is created";
                FastDriver.DocumentRepository.Open();
                Support.AreEqual(templateName, FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(9, "Imaged", 4, TableAction.GetText).Message, templateName);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0010_DeletePhrasesDocService()
        {
            try
            {
                Reports.TestDescription = "Validate DeletePhrases web method";

                #region Create a file using WS.
                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Add a document to the file using WS
                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;
                #endregion

                #region Add a phrase to the document using WS and validate response.
                Reports.TestStep = "Add a phrase to the document (WS), validate response";
                var response = DocumentsHelpers.AddPhrasesToDocument(fileID: fileID, docID: docID, phraseCode: @"XRL/15");
                Support.AreEqual("1", response.Status.ToString(), "Validate status operation");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to event tracking log, validate [Update Document] event";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqual("Phrase(s) added successfully.DocumentID: " + docID.ToString() + " Document Name: " + templateName, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Update Document]", 5, TableAction.GetText).Message, "[Update Document]");
                #endregion

                #region Delete the added phrase using web method.
                Reports.TestStep = "Get the added document details for getting the phrase id.";
                var docDtlRespnc = DocumentsHelpers.GetDocumentDetails(fileID, docID);

                Reports.TestStep = "Remove the added phrase from the document using the WS.";
                string phraseName = docDtlRespnc.Phrases[1].PhraseGrpCode + "/" + docDtlRespnc.Phrases[1].Code;
                DocumentsHelpers.DeletePhraseFromDocument(fileID, docID, Convert.ToInt64(docDtlRespnc.Phrases[1].DocPhraseID));
                #endregion

                #region Verfiy the deletion of the phrase in file side.
                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                Reports.TestStep = "Navigate to Document repository page and select the document.";
                FastDriver.DocumentRepository.Open();
                List<string> documentsToselet = new List<string> { docDtlRespnc.DocName };
                FastDriver.DocumentRepository.SelectDocumentsByName(documentsToselet);
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Verify whether the phrase has been deleted.";
                FastDriver.DocumentPreparation.WaitForScreenToLoad();
                string tableContent = FastDriver.DocumentPreparation.PhraseTable.FAGetText();
                Support.AreEqual(true, !tableContent.Contains(phraseName), "Verification of deletion of Phrase from the list.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0011_MovePhrasesDocService()
        {
            try
            {
                Reports.TestDescription = "Validate MovePhrases web method";
                #region Create a file using WS.
                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Add a document to the file using WS
                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;
                #endregion

                #region Add a phrase to the document using WS and validate response.
                Reports.TestStep = "Add a phrase to the document (WS), validate response";
                var response = DocumentsHelpers.AddPhrasesToDocument(fileID: fileID, docID: docID, phraseCode: @"XRL/15");
                Support.AreEqual("1", response.Status.ToString(), "Validate status operation");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to event tracking log, validate [Update Document] event";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqual("Phrase(s) added successfully.DocumentID: " + docID.ToString() + " Document Name: " + templateName, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Update Document]", 5, TableAction.GetText).Message, "[Update Document]");
                #endregion

                #region Get the added phrase details and sequence using web method.
                Reports.TestStep = "Get the added document details for getting the phrase id.";
                var docDtlRespnc = DocumentsHelpers.GetDocumentDetails(fileID, docID);

                Reports.TestStep = "Get the sequence of the Phrases under the document.";
                Dictionary<string, int> phraseSeqWS = this.GetPhraseSequence(docDtlRespnc);

                Reports.TestStep = "Get the phrase id for which you want to move the sequence.";
                long phraseID = Convert.ToInt64(docDtlRespnc.Phrases[1].DocPhraseID);
                #endregion

                #region Move to the File side and verify the existing sequence of phrases.
                Reports.TestStep = "Navigate to the Document Repository page and verify the sequence of the phrases.";
                FastDriver.DocumentRepository.Open();
                List<string> documentsToselet = new List<string> { docDtlRespnc.DocName };
                FastDriver.DocumentRepository.SelectDocumentsByName(documentsToselet);
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Click on Move Phrases Option and get the existing sequence of phrases in UI.";
                Support.SendKeys("%P");
                Support.SendKeys("%o");
                FastDriver.PhraseResequenceDlg.WaitForScreenToLoad();
                Dictionary<string, int> phraseSeqUI = FastDriver.PhraseResequenceDlg.GetPhraseSequence();
                FastDriver.DialogBottomFrame.ClickDone();
                bool result = phraseSeqUI.SequenceEqual(phraseSeqWS);
                Reports.StatusUpdate("Verifying the sequence of phrases in UI and webservice: " + result.ToString(), result, expectedValue: "True", actualValue: result.ToString());
                #endregion

                #region Invoke the Move Phrase webservice and verify.
                Reports.TestStep = "Invoke the move phrase document web service.";
                response = DocumentsHelpers.MovePhraseOfDocument(docDtlRespnc);

                Reports.TestStep = "Get the document details and phrase details and verify whether the sequence of the phrase has been changed.";
                Dictionary<string, int> phraseSeqWSNew = this.GetPhraseSequence(DocumentsHelpers.GetDocumentDetails(fileID, docID));
                result = phraseSeqWSNew.SequenceEqual(phraseSeqWS);
                Reports.StatusUpdate("Verifying the sequence of phrases is changed: " + (!result).ToString(), !result);
                #endregion

                #region Verify changed sequence of phrases in UI.
                Reports.TestStep = "Navigate to the Document Repository page and verify the sequence of the phrases.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.SelectDocumentsByName(documentsToselet);
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Click on Move Phrases Option and get the existing sequence of phrases in UI.";
                Support.SendKeys("%P");
                Support.SendKeys("%o");
                FastDriver.PhraseResequenceDlg.WaitForScreenToLoad();
                Dictionary<string, int> phraseSeqUINew = FastDriver.PhraseResequenceDlg.GetPhraseSequence();
                FastDriver.DialogBottomFrame.ClickDone();
                result = phraseSeqUINew.SequenceEqual(phraseSeqWSNew);
                Reports.StatusUpdate("Verifying the sequence of phrases is changed in UI: " + (result).ToString(), result, expectedValue: "True", actualValue: result.ToString());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0012_UpdatePhraseDocService()
        {
            try
            {
                Reports.TestDescription = "Validate UpdatePhrases web method";
                #region Create a file using WS.
                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Add a document to the file using WS
                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;
                #endregion

                #region Add a phrase to the document using WS and validate response.
                Reports.TestStep = "Add a phrase to the document (WS), validate response";
                var response = DocumentsHelpers.AddPhrasesToDocument(fileID: fileID, docID: docID, phraseCode: @"XRL/15");
                Support.AreEqual("1", response.Status.ToString(), "Validate status operation");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to event tracking log, validate [Update Document] event";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqual("Phrase(s) added successfully.DocumentID: " + docID.ToString() + " Document Name: " + templateName, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Update Document]", 5, TableAction.GetText).Message, "[Update Document]");
                #endregion

                #region Update the added phrase using web method.
                Reports.TestStep = "Get the added document details for getting the phrase id.";
                var docDtlRespnc = DocumentsHelpers.GetDocumentDetails(fileID, docID);

                Reports.TestStep = "Update the added phrase from the document using the WS.";
                string phraseName = docDtlRespnc.Phrases[1].PhraseGrpCode + "/" + docDtlRespnc.Phrases[1].Code;
                string phraseProp = docDtlRespnc.Phrases[1].Name;
                var response1 = DocumentsHelpers.UpdatePhraseOfDocument(fileID, docID, Convert.ToInt64(docDtlRespnc.Phrases[1].DocPhraseID));
                bool status = response1.Status == 1 ? true : false;
                Reports.StatusUpdate(response1.StatusDescription + status.ToString(), status, expectedValue: "True", actualValue: status.ToString());
                #endregion

                #region Verfiy the update of the phrase in file side.
                Reports.TestStep = "Navigate to the event log page and verify that phrase has been updated.";
                FastDriver.EventTrackingLog.Open();
                string commentStrng = FastDriver.EventTrackingLog.GetCommentForEvent("[Update Document]").Replace("\r\n", string.Empty);
                Support.AreEqual("DocPhrase:" + phraseProp + "Status:Successful", commentStrng, "Phrase is updated successfuly.");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0013_WaiveorUnwaivePhraseDocService()
        {
            try
            {
                Reports.TestDescription = "Validate WaiveorUnwaivePhrase web method";

                #region Create a file using WS.
                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Add a document to the file using webservice and verify it in UI.
                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;
                #endregion

                #region Add a phrase to the document using WS and validate response.
                Reports.TestStep = "Add a phrase to the document (WS), validate response";
                var response = DocumentsHelpers.AddPhrasesToDocument(fileID: fileID, docID: docID, phraseCode: @"JV1/JV1");
                Support.AreEqual("1", response.Status.ToString(), "Validate status operation");

                Reports.TestStep = "Get the document details for the added document using webservice.";
                var docDtlRespnc = DocumentsHelpers.GetDocumentDetails(fileID, docID);
                #endregion

                #region Verify the document and phrases are added succuessfully in UI side as well.
                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to event tracking log, validate [Update Document] event";
                FastDriver.EventTrackingLog.Open();

                Support.AreEqual("Phrase(s) added successfully.DocumentID: " + docID.ToString() + " Document Name: " + templateName, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Update Document]", 5, TableAction.GetText).Message, "[Update Document]");
                #endregion

                #region Invoke the WaiveorUnwaivePhrase web method to waive the newly added phrase. Verify it in UI side as well.
                Reports.TestStep = "Invoke the WaiveorUnwaivePhrase web method to waive the newly added phrase.";
                response = DocumentsHelpers.WaiveorUnWaivePhrase(Convert.ToInt32(docDtlRespnc.FileID), Convert.ToInt32(docDtlRespnc.DocumentID), Convert.ToInt64(docDtlRespnc.Phrases[1].DocPhraseID), true);

                Reports.TestStep = "Navigate to the document repository page and edit the added document.";
                FastDriver.DocumentRepository.Open();
                List<string> documentsToselet = new List<string> { docDtlRespnc.DocName };
                FastDriver.DocumentRepository.SelectDocumentsByName(documentsToselet);
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Select the waived the phrase and verify for the waive checkbox for the waived phrase.";
                FastDriver.DocumentPreparation.WaitForScreenToLoad();
                string phraseName = docDtlRespnc.Phrases[1].PhraseGrpCode + "/" + docDtlRespnc.Phrases[1].Code;
                Reports.StatusUpdate("Phrase is waived successfully in UI as well", FastDriver.DocumentPreparation.VerifyPhraseWaivedorUnWaived(phraseName));
                #endregion

                #region Invoke the WaiveorUnwaivePhrase web method to Unwaive the newly added phrase. Verify it in UI side as well.
                Reports.TestStep = "Invoke the WaiveorUnwaivePhrase web method to unwaive the newly added phrase.";
                response = DocumentsHelpers.WaiveorUnWaivePhrase(Convert.ToInt32(docDtlRespnc.FileID), Convert.ToInt32(docDtlRespnc.DocumentID), Convert.ToInt64(docDtlRespnc.Phrases[1].DocPhraseID), false);

                Reports.TestStep = "Navigate to the document repository page and edit the added document.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.SelectDocumentsByName(documentsToselet);
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Select the unwaived the phrase and verify checkbox should not be available.";
                FastDriver.DocumentPreparation.WaitForScreenToLoad();
                Reports.StatusUpdate("Phrase is unwaived successfully in UI as well", !FastDriver.DocumentPreparation.VerifyPhraseWaivedorUnWaived(phraseName));
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0014_DocumentRefreshDocService()
        {
            try
            {
                #region Create a file using WS.
                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                int fileNumber = Convert.ToInt32(FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber);
                #endregion

                #region Add a document to the file using webservice and verify it in UI.
                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;
                #endregion

                #region Add a phrase to the document using WS and validate response.
                Reports.TestStep = "Add a phrase to the document (WS), validate response";
                var response = DocumentsHelpers.AddPhrasesToDocument(fileID: fileID, docID: docID, phraseCode: @"JV1/JV1");
                Support.AreEqual("1", response.Status.ToString(), "Validate status operation");

                Reports.TestStep = "Get the document details for the added document using webservice.";
                var docDtlRespnc = DocumentsHelpers.GetDocumentDetails(fileID, docID);
                #endregion

                #region Verify the document and phrases are added succuessfully in UI side as well.
                Reports.TestStep = "Log into FAST application and Navigate to the file number.";
                FASTHelpers.FAST_Login_IIS(fileNo: fileNumber);

                Reports.TestStep = "Navigate to event tracking log, validate [Update Document] event";
                FastDriver.EventTrackingLog.Open();

                Support.AreEqual("Phrase(s) added successfully.DocumentID: " + docID.ToString() + " Document Name: " + templateName, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Update Document]", 5, TableAction.GetText).Message, "[Update Document]");
                #endregion

                #region Navigate to the Document Repository page and update the phrase details.
                Reports.TestStep = "Navigate to the Document Repository page and click on edit button after selecting the added document.";
                FastDriver.DocumentRepository.Open();
                List<string> documentsToselet = new List<string> { docDtlRespnc.DocName };
                FastDriver.DocumentRepository.SelectDocumentsByName(documentsToselet);
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Select the second phrase and edit the phrase name on the screen.";
                FastDriver.DocumentPreparation.WaitForScreenToLoad();
                string phraseName = docDtlRespnc.Phrases[1].PhraseGrpCode + "/" + docDtlRespnc.Phrases[1].Code;
                string phraseText = FastDriver.DocumentPreparation.GetPhraseText(phraseName);
                FastDriver.DocumentPreparation.EditPhraseText(phraseName);
                FastDriver.BottomFrame.Done();
                FastDriver.DocumentRepository.WaitForScreenToLoad();
                #endregion

                #region Invoke the Documentrefresh webservice and verify the response.
                Reports.TestStep = "Invoke the Document Refresh webservice and verify the response.";
                var docRefreshRespns = DocumentsHelpers.DocumentRefresh(docDtlRespnc, 2);
                OperationResponseExtensions.Validate(docRefreshRespns);
                #endregion

                #region Verify the output in FAST application.
                Reports.TestStep = "Navigate to the Document Repository and open the document on clicking the edit button.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.SelectDocumentsByName(documentsToselet);
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparation.WaitForScreenToLoad();
                Support.AreEqual(phraseText, FastDriver.DocumentPreparation.GetPhraseText(phraseName), "Document Refresh invoked successfully in FAST applciation.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        #region REG0015_PurgeDocument
        [TestMethod]
        public void REG0015_PurgeDocument()
        {
            try
            {
                #region Data
                string DocumentsTable = string.Empty;

                #endregion
                Reports.TestDescription = "Validate REG0034_PurgeDocument web service.";

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Navigate to target file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add a document to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID = Convert.ToInt32(response.Templates[0].TemplateID);
                string templateName = response.Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Validate the presence of document in doc rep, all items list.";
                FastDriver.DocumentRepository.Open();
                DocumentsTable = FastDriver.DocumentRepository.DocumentsTable.FAGetText().ToString();
                Support.AreEqual("True", DocumentsTable.Contains(templateName).ToString(), true);

                Reports.TestStep = "Invoke RemoveDocument method and validate response (WS)";
                var RemoveDocumentResponse = DocumentsHelpers.RemoveDocument(fileID, docID);
                Support.AreEqual("1", RemoveDocumentResponse.Status.ToString(), "Operation Status");
                Support.AreEqual(true, RemoveDocumentResponse.StatusDescription.ToString().Contains("Status: Successful"), "Operation Status Description");

                Reports.TestStep = "Validate the presence of document in doc rep, removed items list.";
                FastDriver.DocumentRepository.Open();
                DocumentsTable = FastDriver.DocumentRepository.DocumentsTable.FAGetText().ToString();
                Support.AreEqual("False", DocumentsTable.Contains(templateName).ToString(), true);

                FastDriver.DocumentRepository.SearchType.FASelectItem("Removed Items");
                FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.Restore);
                DocumentsTable = FastDriver.DocumentRepository.DocumentsTable.FAGetText().ToString();
                Support.AreEqual("True", DocumentsTable.Contains(templateName).ToString(), true);

                Reports.TestStep = "Invoke PurgeDocument method and validate response (WS)";
                var PurgeDocumentRequest = FASTWCFHelpers.Factories.DocumentRequestFactory.PurgeDocumentReqt(fileID, docID);
                var PurgeDocumentResponse = FASTWCFHelpers.DocumentService.PurgeDocument(PurgeDocumentRequest);
                Support.AreEqual("1", RemoveDocumentResponse.Status.ToString(), "Operation Status");

                Reports.TestStep = "Validate the absence of document in doc rep, removed items list.";
                FastDriver.DocumentRepository.Open();
                DocumentsTable = FastDriver.DocumentRepository.DocumentsTable.FAGetText().ToString();
                Support.AreEqual("False", DocumentsTable.Contains(templateName).ToString(), true);

                FastDriver.DocumentRepository.SearchType.FASelectItem("Removed Items");
                FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.Restore);
                DocumentsTable = FastDriver.DocumentRepository.DocumentsTable.FAGetText().ToString();
                Support.AreEqual("False", DocumentsTable.Contains(templateName).ToString(), true);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region REG0016_RemoveDocument
        [TestMethod]
        public void REG0016_RemoveDocument()
        {
            try
            {
                #region Data
                string DocumentsTable = string.Empty;

                #endregion
                Reports.TestDescription = "Validate RemoveDocument web service.";

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Navigate to target file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add a document to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID = Convert.ToInt32(response.Templates[0].TemplateID);
                string templateName = response.Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Validate the presence of document in doc rep, all items list.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.SearchType.FASelectItem("All Items");
                DocumentsTable = FastDriver.DocumentRepository.DocumentsTable.FAGetText().ToString();
                Support.AreEqual("True", DocumentsTable.Contains(templateName).ToString(), true);

                Reports.TestStep = "Invoke RemoveDocument method and validate response (WS)";
                var RemoveDocumentResponse = DocumentsHelpers.RemoveDocument(fileID, docID);
                Support.AreEqual("1", RemoveDocumentResponse.Status.ToString(), "Operation Status");
                Support.AreEqual(true, RemoveDocumentResponse.StatusDescription.ToString().Contains("Status: Successful"), "Operation Status Description");

                Reports.TestStep = "Validate the absence of document in doc rep, all items list.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.SearchType.FASelectItem("All Items");
                DocumentsTable = FastDriver.DocumentRepository.DocumentsTable.FAGetText().ToString();
                Support.AreEqual("False", DocumentsTable.Contains(templateName).ToString(), true);

                Reports.TestStep = "Validate the presence of document in doc rep, removed items list.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.SearchType.FASelectItem("Removed Items");
                FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.Restore);
                DocumentsTable = FastDriver.DocumentRepository.DocumentsTable.FAGetText().ToString();
                Support.AreEqual("True", DocumentsTable.Contains(templateName).ToString(), true);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region REG0017_GetDocPackageDetails
        [TestMethod]
        public void REG0017_GetDocPackageDetails()
        {
            try
            {
                Reports.TestDescription = "Validate GetDocPackageDetails web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add three documents to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID_1 = Convert.ToInt32(response.Templates[0].TemplateID);
                int templateID_2 = Convert.ToInt32(response.Templates[1].TemplateID);
                int templateID_3 = Convert.ToInt32(response.Templates[2].TemplateID);

                int docID_1 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_1).DocumentID;
                int docID_2 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_2).DocumentID;
                int docID_3 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_3).DocumentID;

                FASTWCFHelpers.FastDocumentService.Document[] docs = new FASTWCFHelpers.FastDocumentService.Document[]
                {
                    new FASTWCFHelpers.FastDocumentService.Document()
                    {
                        DocumentID = docID_1
                    },
                    new FASTWCFHelpers.FastDocumentService.Document()
                    {
                        DocumentID = docID_2
                    },
                    new FASTWCFHelpers.FastDocumentService.Document()
                    {
                        DocumentID = docID_3
                    }
                };

                Reports.TestStep = "Create Associate Doc Package (WS)";
                WebServices.Helpers.Documents.DocumentsHelpers.CreateAssociateDocPackage(fileID, docs, "TestAssociateDocPackage");

                Reports.TestStep = "Invoke GetAssociateDocPackage and validate response (WS)";
                var GetAssociateDocPackagesRequest = DocumentRequestFactory.GetServiceFileRequest(fileID);
                var GetAssociateDocPackagesResponse = WebServices.Helpers.Documents.DocumentsHelpers.GetAssociateDocPackages(GetAssociateDocPackagesRequest);
                Support.AreEqual("TestAssociateDocPackage", GetAssociateDocPackagesResponse.PackageList[0].PackageName, "Package Name");

                int PackageID = Convert.ToInt32(GetAssociateDocPackagesResponse.PackageList[0].PackageID.ToString());

                Playback.Wait(10000);

                Reports.TestStep = "Invoke GeDocPackageDetails and validate response (WS)";
                var GetDocPckgDetailsReq = DocumentRequestFactory.GetDocPackageRequest(fileID, PackageID);
                var GetDocPckgDetailsRes = DocumentService.GetDocPackageDeatails(GetDocPckgDetailsReq);

                Support.AreEqual("1", GetDocPckgDetailsRes.Status.ToString(), "Operation Status");
                Support.AreEqual("Success", GetDocPckgDetailsRes.StatusDescription.ToString(), "Operation Status Description");


            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { }
        }

        #endregion

        #region REG0018_DeArchiveFileService
        [TestMethod]
        public void REG0018_DeArchiveFileService()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify DeArchiveFileService() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Archive file.";
                FASqlHelpers.ArchiveFile(fileid);

                Reports.TestStep = "Invoke DeArchiveFileService request.";
                var DearchiveFileReq = DocumentRequestFactory.GetDeArchiveFileRequest(fileid, "famos", "fastts\fastqa07");
                var DearchiveFileRes = FASTWCFHelpers.DocumentService.DeArchiveFileService(DearchiveFileReq);
                DearchiveFileRes.Validate();

                Reports.TestStep = "Validate DeArchiveFileService succeeded in Event/Tracking Log.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("File Process");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[File De-Archive]"), "Validating event for DeArchiveFileService");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("Documents De-Archived Successfully."), "Validating event for DeArchiveFileService");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        #endregion

        #region REG0019_GetDocTemplates
        [TestMethod]
        public void REG0019_GetDocTemplates()
        {
            try
            {
                Reports.TestDescription = "Validate GetDocTemplates web method";

                Reports.TestStep = "Invoke GetDocTemplates and validate the response (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                Support.AreEqual("", response.Status.ToString(), "Response Status");
                Support.AreNotEqual("0", response.Templates.Count().ToString(), "Template count is not zero");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { }
        }
        #endregion

        #region REG0020_ModifyAssociateDocPackage
        [TestMethod]
        public void REG0020_ModifyAssociateDocPackage()
        {
            try
            {
                Reports.TestDescription = "Validate ModifyAssociateDocPackage web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add three documents to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID_1 = Convert.ToInt32(response.Templates[0].TemplateID);
                int templateID_2 = Convert.ToInt32(response.Templates[1].TemplateID);
                int templateID_3 = Convert.ToInt32(response.Templates[2].TemplateID);

                int docID_1 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_1).DocumentID;
                int docID_2 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_2).DocumentID;
                int docID_3 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_3).DocumentID;

                FASTWCFHelpers.FastDocumentService.Document[] docs = new FASTWCFHelpers.FastDocumentService.Document[]
                {
                    new FASTWCFHelpers.FastDocumentService.Document()
                    {
                        DocumentID = docID_1
                    },
                    new FASTWCFHelpers.FastDocumentService.Document()
                    {
                        DocumentID = docID_2
                    },
                    new FASTWCFHelpers.FastDocumentService.Document()
                    {
                        DocumentID = docID_3
                    }
                };

                Reports.TestStep = "Create Associate Doc Package with the first three documents(WS)";
                var CreateAssociateDocPackageResponse = DocumentsHelpers.CreateAssociateDocPackage(fileID, docs, "TestAssociateDocPackage");
                long packageID = CreateAssociateDocPackageResponse.AssociateDocPackageID;

                Reports.TestStep = "Invoke ModifyAssociateDocPackage and validate response (WS)";
                var modifiedDocResponse = DocumentsHelpers.ModifyAssociateDocPackage(fileID, docs, packageID, "TestAssociateDocPackage_Modified", true);
                Support.AreEqual("1", modifiedDocResponse.Status.ToString(), "Operation Status");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate package name has changed";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.AssociateDocsTab.FAClick();
                FastDriver.DocumentRepository.WaitForAssociateDocTabToLoad();
                Support.AreEqual("TestAssociateDocPackage_Modified", FastDriver.DocumentRepository.AssPackageTable.PerformTableAction(1, 1, TableAction.GetText).Message, "Package Name Changed");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }


        }
        #endregion

        [TestMethod]
        public void REG0021_GetImageDocumentDocService()
        {
            try
            {
                Reports.TestDescription = "Validate GetImageDocument web method";

                #region Create a basic file (WS).
                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Add a document to the file using WS.
                Reports.TestStep = "Add a document to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID = Convert.ToInt32(response.Templates[0].TemplateID);
                string templateName = response.Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;
                #endregion 

                #region Finalize the document using the WS.
                Reports.TestStep = "Finalize the document and validate response(WS)";
                var finalizeDocResponse = WebServices.Helpers.Documents.DocumentsHelpers.FinalizeDocument(fileID, docID);
                Support.AreEqual("1", finalizeDocResponse.Status.ToString(), "Status Operation");
                #endregion

                #region Login to FAST and validate the response in UI as well.
                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate document is finalized";
                FastDriver.DocumentRepository.Open();
                Support.AreEqual("Finalized", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, templateName, 9, TableAction.GetText).Message, templateName);
                #endregion

                #region Invoke CreateImageDocument web method and validate response (WS).
                Reports.TestStep = "Invoke CreateImageDocument web method and validate response (WS)";
                var crtImgDoc= DocumentsHelpers.CreateImageDocument(fileID: fileID, docID: docID);
                OperationResponseExtensions.Validate(crtImgDoc);

                Reports.TestStep = "Navigate to Document Repository, validate image document " + templateName + " is created";
                FastDriver.DocumentRepository.Open();
                Support.AreEqual(templateName, FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(9, "Imaged", 4, TableAction.GetText).Message, templateName);
                #endregion

                #region Invoke the GetDocuments web method and get the imagedocument id.
                Reports.TestStep = "Invoke the GetDocuments web method and get the imagedocument id.";
                var docDetails = FASTWCFHelpers.DocumentService.GetDocuments(DocumentRequestFactory.GetServiceFileRequest(fileID));
                #endregion

                #region Invoke the GetImageDocument Web service.
                Reports.TestStep = "Get the request to be processed with GetImageDocument service.";
                ImageDocumentResponse imgDocRespns = DocumentsHelpers.GetImageDocument(fileID,docID,Convert.ToInt32(docDetails.Images[0].ImageDocumentID));
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0022_GetImageDocumentDetailsDocService()
        {
            try
            {
                Reports.TestDescription = "Validate GetImageDocumentDetails (Document Service) web method";

                #region Create a basic file (WS).
                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Add a document to file using the webservice.
                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;
                #endregion

                #region Finalize the document using the WS.
                Reports.TestStep = "Finalize the document and validate response(WS)";
                var finalizeDocResponse = WebServices.Helpers.Documents.DocumentsHelpers.FinalizeDocument(fileID, docID);
                Support.AreEqual("1", finalizeDocResponse.Status.ToString(), "Status Operation");
                #endregion

                #region Invoke CreateImageDocument web method and validate the response (WS).
                Reports.TestStep = "Invoke CreateImageDocument web method and validate response (WS)";
                var crtImgDoc = DocumentsHelpers.CreateImageDocument(fileID: fileID, docID: docID);
                OperationResponseExtensions.Validate(crtImgDoc);

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate document is finalized and Imaged";
                FastDriver.DocumentRepository.Open();
                Support.AreEqual("Finalized", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, templateName, 9, TableAction.GetText).Message, templateName);
                Support.AreEqual(templateName, FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(9, "Imaged", 4, TableAction.GetText).Message, templateName);
                #endregion

                #region Invoke the GetDocuments web method and get the imagedocument id.
                Reports.TestStep = "Invoke the GetDocuments web method and get the imagedocument id.";
                var docDetails = FASTWCFHelpers.DocumentService.GetDocuments(DocumentRequestFactory.GetServiceFileRequest(fileID));
                #endregion

                #region Invoke GetImageDocumentDetails web method and validate response (WS)
                Reports.TestStep = "Invoke GetImageDocumentDetails web method and validate response (WS)";
                var response = DocumentsHelpers.GetImageDocumentDetails(fileID,docID, Convert.ToInt32(docDetails.Images[0].ImageDocumentID));
                if(response!=null)
                {
                    Reports.StatusUpdate("GetImageDocumentdetails invoked successfully.",true);
                }
                else
                {
                    Reports.StatusUpdate("GetImageDocumentdetails is not invoked successfully.",false);
                }

                Reports.TestStep = "Validate the response in FAST application.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(9, "Imaged", 4, TableAction.Click);
                FastDriver.DocumentRepository.Details.FAClick();
                FastDriver.ImageDetailsScreen.WaitForScreenToLoad();
                ServiceHelper.CompareWithUI(FastDriver.ImageDetailsScreen.ImageDetailsTable.PerformTableAction(2, 3, TableAction.GetText).Message, response.ImageName);
                ServiceHelper.CompareWithUI(FastDriver.ImageDetailsScreen.ImageDetailsTable.PerformTableAction(3, 3, TableAction.GetText).Message, response.Status);
                ServiceHelper.CompareWithUI(FastDriver.ImageDetailsScreen.ImageDetailsTable.PerformTableAction(4, 3, TableAction.GetText).Message, response.Comments);
                ServiceHelper.CompareWithUI(FastDriver.ImageDetailsScreen.ImageDetailsTable.PerformTableAction(5, 3, TableAction.GetText).Message, response.DateCreated.ToString());
                ServiceHelper.CompareWithUI(FastDriver.ImageDetailsScreen.ImageDetailsTable.PerformTableAction(6, 3, TableAction.GetText).Message, response.Pages.ToString());
                ServiceHelper.CompareWithUI(FastDriver.ImageDetailsScreen.ImageDetailsTable.PerformTableAction(7, 3, TableAction.GetText).Message, response.StatusChangeDate.ToString());
                ServiceHelper.CompareWithUI(FastDriver.ImageDetailsScreen.ImageDetailsTable.PerformTableAction(9, 3, TableAction.GetText).Message, response.ModifiedDate.ToString());
                ServiceHelper.CompareWithUI(FastDriver.ImageDetailsScreen.ImageDetailsTable.PerformTableAction(12, 3, TableAction.GetText).Message, response.ElectronicFileID.ToString());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { }
        }

        [TestMethod]
        public void REG0023_PublishDocumentDetailsDocService()
        {
            try
            {
                Reports.TestDescription = "Validate PublishDocument (Document Service) web method";

                #region Create a basic file (WS).
                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Add a document to file using the webservice.
                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;
                #endregion

                #region Finalize the document using the WS.
                Reports.TestStep = "Finalize the document and validate response(WS)";
                var finalizeDocResponse = WebServices.Helpers.Documents.DocumentsHelpers.FinalizeDocument(fileID, docID);
                Support.AreEqual("1", finalizeDocResponse.Status.ToString(), "Status Operation");
                #endregion

                #region Invoke CreateImageDocument web method and validate the response (WS).
                Reports.TestStep = "Invoke CreateImageDocument web method and validate response (WS)";
                var crtImgDoc = DocumentsHelpers.CreateImageDocument(fileID: fileID, docID: docID);
                OperationResponseExtensions.Validate(crtImgDoc);

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate document is finalized and Imaged";
                FastDriver.DocumentRepository.Open();
                Support.AreEqual("Finalized", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, templateName, 9, TableAction.GetText).Message, templateName);
                Support.AreEqual(templateName, FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(9, "Imaged", 4, TableAction.GetText).Message, templateName);
                #endregion

                #region Invoke the GetDocuments web method and get the imagedocument id.
                Reports.TestStep = "Invoke the GetDocuments web method and get the imagedocument id.";
                var docDetails = FASTWCFHelpers.DocumentService.GetDocuments(DocumentRequestFactory.GetServiceFileRequest(fileID));
                #endregion

                #region Invoke PublishDocument web method and validate response (WS)
                Reports.TestStep = "Invoke the Publish Document webservice.";
                var pubDocRspnc = DocumentsHelpers.PublishDocument(fileID, docDetails.Images[0].ImageDocumentID, FileRoleType.Buyer);

                Reports.TestStep = "Validate the response in the FAST Application.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(9, "Imaged", 7, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "INPUT").FAClick();
                FastDriver.PublishDocumentsDlg.WaitForScreenToLoad();
                Support.AreEqual(true.ToString(),FastDriver.PublishDocumentsDlg.Table.PerformTableAction(2, FileRoleType.Buyer.ToString(), 1, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName,"INPUt").IsSelected().ToString(),bIgnoreCase:true);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { }
        }

        [TestMethod]
        public void REG0024_SubmitDocumentRequestDocService()
        {
            try
            {
                Reports.TestDescription = "Validate SubmitDocumentRequest (Document Service) web method";

                #region Create a basic file (WS).
                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Add a document to file using the webservice.
                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;
                #endregion

                #region Navigate to the FAST file side and validate that document is added. (WS).
                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Validate that document is added.";
 
                #endregion

                #region Invoke the GetDocuments web method and get the imagedocument id.
                Reports.TestStep = "Invoke the GetDocuments web method and get the imagedocument id.";
                var docDetails = FASTWCFHelpers.DocumentService.GetDocuments(DocumentRequestFactory.GetServiceFileRequest(fileID));
                #endregion

                #region Invoke PublishDocument web method and validate response (WS)
                Reports.TestStep = "Invoke the Publish Document webservice.";
                var pubDocRspnc = DocumentsHelpers.PublishDocument(fileID, docDetails.Images[0].ImageDocumentID, FileRoleType.Buyer);

                Reports.TestStep = "Validate the response in the FAST Application.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(9, "Imaged", 7, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "INPUT").FAClick();
                FastDriver.PublishDocumentsDlg.WaitForScreenToLoad();
                Support.AreEqual(true.ToString(), FastDriver.PublishDocumentsDlg.Table.PerformTableAction(2, FileRoleType.Buyer.ToString(), 1, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "INPUt").IsSelected().ToString(), bIgnoreCase: true);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { }
        }

        #region Private class methods

        private void Login(string url = null)
        {
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            FASTLogin.Login(url ?? AutoConfig.FASTHomeURL, credentials, true);
        }

        private Dictionary<string, int> GetPhraseSequence(FASTWCFHelpers.FastDocumentService.DocumentDetailsResponse documentRspnc)
        {
            string phraseCode = null;
            Dictionary<string, int> phraseSeq = new Dictionary<string, int>();
            for (int i = 0; i < documentRspnc.Phrases.Length; i++)
            {
                phraseCode = documentRspnc.Phrases[i].PhraseGrpCode + "/" + documentRspnc.Phrases[i].Code;
                phraseSeq.Add(phraseCode, Convert.ToInt16(documentRspnc.Phrases[i].SeqNum));
            }
            return phraseSeq;
        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
