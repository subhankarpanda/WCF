﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using WebServices.Helpers.File;

namespace WebServices.Documents
{
    [CodedUITest]
    public class RTMpackageWS : MasterTestClass
    {
        #region REG0001_CreateRTMPackage
        [TestMethod]
        public void REG0001_CreateRTMPackage()
        {
            try
            {
                #region Data
                string DocumentsTable = string.Empty;

                #endregion
                Reports.TestDescription = "Validate GetRTMPackageDetails web service.";

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Navigate to target file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add a document to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID = Convert.ToInt32(response.Templates[0].TemplateID);
                string templateName = response.Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Validate the presence of document in doc rep, all items list.";
                FastDriver.DocumentRepository.Open();
                DocumentsTable = FastDriver.DocumentRepository.DocumentsTable.FAGetText().ToString();
                Support.AreEqual("True", DocumentsTable.Contains(templateName).ToString(), true);

                Reports.TestStep = "Invoke CreateRTMPackageRequest method and validate response (WS)";
                var CreateRTMpackageReq = FASTWCFHelpers.Factories.DocumentRequestFactory.CreateRTMPackageReq(fileID, docID);
                var CreateRTMpackageRes = FASTWCFHelpers.DocumentService.CreateRTMPackage(CreateRTMpackageReq);
                Support.AreEqual("1", CreateRTMpackageRes.Status.ToString(), "Operation Status");
                Support.AreEqual(true, CreateRTMpackageRes.StatusDescription.ToString().Contains("RTM Package created successfully"), "Operation Status Description");

                Reports.TestStep = "Validate in UI, that RTM package is cretaed.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Name", templateName, "Name", TableAction.Click);
                if (!(FastDriver.DocumentRepository.RTMPackage.IsEnabled().ToString() == "True"))
                {
                    Reports.StatusUpdate("RTMPackage button is in disabled state.", false);
                }
                FastDriver.DocumentRepository.RTMPackage.FAClick();
                FastDriver.RTMPackageCountDlg.WaitForScreenToLoad();
                Support.AreEqual("RTM", FastDriver.RTMPackageCountDlg.Package1Name.FAGetText().ToString(), true);
                FastDriver.DialogBottomFrame.ClickCancel();
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region REG0002_GetRTMPackageDetails
        [TestMethod]
        public void REG0002_GetRTMPackageDetails()
        {
            try
            {
                #region Data
                string DocumentsTable = string.Empty;
                string responseattention = string.Empty;
                string reference = string.Empty;
                string[] responsecreationDate = new string[4];
                int[] reponseDocID = new int[4];
                string[] responseDocName = new string[4];
                string[] responseDocType = new string[4];
                string[] noOfCopies = new string[4];
                string[] tabName = new string[4];
                string[] status = new string[4];
                string[] responseAddress = new string[4];
                string[] incReturnEnvelope = new string[4];
                string[] name = new string[4];
                string[] courierType = new string[4];
                string[] packaging = new string[4];
                int[] owingOffice = new int[4];
                int[] owingOfficeID = new int[4];
                int[] responseRTMAddrId = new int[4];
                int[] RTMDocId = new int[4];
                string[] signatureRequired = new string[4];
                string[] skipAddValidation = new string[4];
                string returnOffice = string.Empty;
                string returnToAttention = string.Empty;
                string returnToReference = string.Empty;
                string[] copies = new string[4];
                string[] printOption = new string[4];
                string[] colour = new string[4];
                string RTMdescription = string.Empty;
                int RTMPackageId = 0;
                string returntoaddress = string.Empty;
                string returnToName = string.Empty;
                #endregion
                Reports.TestDescription = "Validate GetRTMPackageDetails web service.";

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Navigate to target file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add a document to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID = Convert.ToInt32(response.Templates[0].TemplateID);
                string templateName = response.Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Validate the presence of document in doc rep, all items list.";
                FastDriver.DocumentRepository.Open();
                DocumentsTable = FastDriver.DocumentRepository.DocumentsTable.FAGetText().ToString();
                Support.AreEqual("True", DocumentsTable.Contains(templateName).ToString(), true);

                Reports.TestStep = "Invoke CreateRTMPackageRequest method and validate response (WS)";
                var CreateRTMpackageReq = FASTWCFHelpers.Factories.DocumentRequestFactory.CreateRTMPackageReq(fileID, docID);
                var CreateRTMpackageRes = FASTWCFHelpers.DocumentService.CreateRTMPackage(CreateRTMpackageReq);
                Support.AreEqual("1", CreateRTMpackageRes.Status.ToString(), "Operation Status");
                Support.AreEqual(true, CreateRTMpackageRes.StatusDescription.ToString().Contains("RTM Package created successfully"), "Operation Status Description");

                Reports.TestStep = "Add additional details to Return To.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.RTMPackagesTab.FAClick();
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.ReturnTo.FAClick();
                FastDriver.RTM.WaitForScreenToLoad(FastDriver.RTM.ReturnToAttention);
                FastDriver.RTM.ReturnToOfficeName.FASelectItemByIndex(2);
                FastDriver.RTM.ReturnToAttention.FASetText("123456");
                FastDriver.RTM.ReturnToReference.FASetText("654321");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Invoke GetRTMPackageDetailsRequest method and validate response (WS)";
                var GetRTMpackageReq = FASTWCFHelpers.Factories.DocumentRequestFactory.GetRTMpackageDetails(fileID);
                var GetRTMpackageRes = FASTWCFHelpers.DocumentService.GetRTMPackageDetails(GetRTMpackageReq);
                Support.AreEqual("1", GetRTMpackageRes.Status.ToString(), "Operation Status");
                Support.AreEqual(true, GetRTMpackageRes.StatusDescription.ToString().Contains("RTM Package details loaded successfully"), "Operation Status Description");

                #region Response Variables
                RTMdescription = GetRTMpackageRes.RTMPackage[0].Descr.ToString();
                RTMPackageId = GetRTMpackageRes.RTMPackage[0].RTMDocuments[0].RTMPackageID;

                //Documents
                #region RTM Package Documents Tab
                if (GetRTMpackageRes.RTMPackage[0].RTMDocuments.Length > 0)
                    for (int i = 0; i < GetRTMpackageRes.RTMPackage[0].RTMDocuments.Length; i++)
                    {
                        RTMDocId[i] = GetRTMpackageRes.RTMPackage[0].RTMDocuments[i].RTMDocID;
                        responsecreationDate[i] = GetRTMpackageRes.RTMPackage[0].RTMDocuments[i].CreatedDate.ToString("M/d/yyyy");
                        responseDocName[i] = GetRTMpackageRes.RTMPackage[0].RTMDocuments[i].DocName.ToString();
                        responseDocType[i] = GetRTMpackageRes.RTMPackage[0].RTMDocuments[i].DocType.ToString();
                        copies[i] = GetRTMpackageRes.RTMPackage[0].RTMDocuments[i].NumOfCopies.ToString(); ;
                        tabName[i] = GetRTMpackageRes.RTMPackage[0].RTMDocuments[i].TabName.ToString();

                        if (GetRTMpackageRes.RTMPackage[0].RTMDocuments[i].StatusCd == 188)
                            status[i] = "Finalized";
                        else if (GetRTMpackageRes.RTMPackage[0].RTMDocuments[i].StatusCd == 242)
                            status[i] = "Created";
                        else if (GetRTMpackageRes.RTMPackage[0].RTMDocuments[i].StatusCd == 243)
                            status[i] = "Edited";
                        else
                            status[i] = "Imaged";

                        if (GetRTMpackageRes.RTMPackage[0].RTMDocuments[i].ColorYesNo == 0 || GetRTMpackageRes.RTMPackage[0].RTMDocuments[i].ColorYesNo == null)
                            colour[i] = "";
                        else
                            colour[i] = "ü";
                    }
                #endregion

                //MailTo Tab
                #region MailTo Tab
                if (GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses.Length > 0)
                {
                    responseattention = GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses[0].Attention.ToString();
                    reference = GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses[0].Reference.ToString();

                    for (int i = 0; i < GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses.Length; i++)
                    {
                        responseRTMAddrId[i] = GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses[i].RTMAddrID;
                        responseAddress[i] = GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses[i].Address.ToString();
                        incReturnEnvelope[i] = GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses[i].IncludeReturnEnvelope.ToString();
                        name[i] = GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses[i].Name.ToString();
                        noOfCopies[i] = GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses[i].NumOfCopies.ToString();
                        owingOffice[i] = GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses[i].OwningProductionOffice;
                        owingOfficeID[i] = GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses[i].OwningProductionOfficeID;

                        //CourierType
                        if (GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses[i].CourierType == 1310)
                            courierType[i] = "First Class";
                        else if (GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses[i].CourierType == 1311)
                            courierType[i] = "Special Courier";
                        else if (GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses[i].CourierType == 1312)
                            courierType[i] = "Next Day";
                        else
                            courierType[i] = "Certified Mail";

                        //Packaging Type
                        if (GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses[i].PackageType == 1278)
                            packaging[i] = "Standard";
                        else if (GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses[i].PackageType == 1279)
                            packaging[i] = "Spiral Bound Booklet";
                        else if (GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses[i].PackageType == 1280)
                            packaging[i] = "3 - Hole Booklet";
                        else if (GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses[i].PackageType == 1281)
                            packaging[i] = "3 - Ring Binder";
                        else if (GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses[i].PackageType == 1547)
                            packaging[i] = "3 - Hole Clip";
                        else if (GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses[i].PackageType == 1809)
                            packaging[i] = "2 - Hole Clip Top Binding";

                        signatureRequired[i] = GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses[i].SignatureRequired.ToString();
                        if (GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses[i].SingleDoubleSided.ToString() == "True")
                            printOption[i] = "Double Sided";
                        else
                            printOption[i] = "Single Sided";
                        skipAddValidation[i] = GetRTMpackageRes.RTMPackage[0].RTMMailToAddresses[i].SkipAddressValidation.ToString();
                    }
                }
                #endregion

                //ReturnTo Tab
                #region ReturnTo Tab
                returnToAttention = GetRTMpackageRes.RTMPackage[0].RTMReturnToAddresses[0].Attention.ToString();
                returnToReference = GetRTMpackageRes.RTMPackage[0].RTMReturnToAddresses[0].Reference.ToString();
                // if (GetRTMpackageRes.RTMPackage[0].RTMReturnToAddresses[0].Name)
                returntoaddress = GetRTMpackageRes.RTMPackage[0].RTMReturnToAddresses[0].Address.ToString();
                returnToName = GetRTMpackageRes.RTMPackage[0].RTMReturnToAddresses[0].Name.ToString();
                if (GetRTMpackageRes.RTMPackage[0].RTMReturnToAddresses[0].OwningProductionOfficeID == 191)
                    returnOffice = "QA SANDPOINT OFFICE (Escrow Production)";

                #endregion
                #endregion

                #region Validate the UI data with WS data
                Reports.TestStep = "Validate the UI data with WS data.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.RTMPackagesTab.FAClick();
                FastDriver.DocumentRepository.WaitForRTMPackageTabToLoad();


                //RTM Package Documents
                #region RTM Package Documents
                Support.AreEqual(responseDocName[0], FastDriver.DocumentRepository.DocumentDescription1.FAGetText().ToString(), true);
                Support.AreEqual(responsecreationDate[0], FastDriver.DocumentRepository.IssueDate1.FAGetText().ToString(), true);
                Support.AreEqual(responseDocType[0], FastDriver.DocumentRepository.DocumentType1.FAGetText().ToString(), true);
                Support.AreEqual(tabName[0], FastDriver.DocumentRepository.Tab1.FAGetText().ToString(), true);
                Support.AreEqual(copies[0], FastDriver.DocumentRepository.Copies1.FAGetText().ToString(), true);
                Support.AreEqual(status[0], FastDriver.DocumentRepository.Status1.FAGetText().ToString(), true);
                string Colour1 = FastDriver.DocumentRepository.Colour1.FAGetText().ToString();//FAFindElement(ByLocator.Id, "TC_RTM_RTMDOC_tabRTMSubTab_PkgDocs_dgRTMPackageDocs_0_lblColor").FAGetAttribute("text");
                Support.AreEqual(colour[0], Colour1, true);
                #endregion

                //Mail To Tab
                #region MailTo Tab
                FastDriver.DocumentRepository.RTMPackageMailTo.FAClick();
                FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.RTMPackageSelectAddress);
                Support.AreEqual(name[0], FastDriver.DocumentRepository.MailTo1.FAGetText().ToString(), true);
                string Address = FastDriver.DocumentRepository.MailToAddress1.FAGetText().ToString().Replace(",", "").Replace("\r", "").Replace("\n", "").Replace("\t", "").Replace(" ", "").Trim();
                string ResponseAddrs = responseAddress[0].Replace(",", "").Replace("\r", "").Replace("\n", "").Replace("\t", "").Replace(" ", "").Trim();
                Support.AreEqual(ResponseAddrs, Address, true);
                Support.AreEqual(responseattention, FastDriver.DocumentRepository.Attention.FAGetValue().ToString(), true);
                Support.AreEqual(reference, FastDriver.DocumentRepository.Reference.FAGetText().ToString(), true);
                Support.AreEqual(packaging[0], FastDriver.DocumentRepository.Packaging.FAGetSelectedItem().ToString(), true);
                Support.AreEqual(courierType[0], FastDriver.DocumentRepository.CourierMethod1.FAGetSelectedItem().ToString(), true);
                Support.AreEqual(printOption[0], FastDriver.DocumentRepository.PrintOption1.FAGetSelectedItem().ToString(), true);
                Support.AreEqual(incReturnEnvelope[0], (FastDriver.DocumentRepository.IncludeReturnEnvelope.IsSelected().ToString()), true);
                Support.AreEqual(signatureRequired[0], (FastDriver.DocumentRepository.SignatureRequired1.IsSelected().ToString()), true);
                Support.AreEqual(skipAddValidation[0], (FastDriver.DocumentRepository.SkipAddressValidation1.IsSelected().ToString()), true);
                #endregion

                //ReturnTo Tab
                #region ReturnTo Tab
                FastDriver.DocumentRepository.RTMPackageReturnTo.FAClick();
                Support.AreEqual(returnToAttention, FastDriver.DocumentRepository.ReturnToAttention.FAGetValue().ToString(), true);
                Support.AreEqual(returnToReference, FastDriver.DocumentRepository.ReturnToReference.FAGetValue().ToString(), true);
                Support.AreEqual(FastDriver.DocumentRepository.ReturnToOfficeName.FAGetSelectedItem().ToString().Contains(returnToName).ToString(), "True", true);
                Support.AreEqual(returntoaddress.Replace(",", "").Replace("<BR>", "").Replace(" ", "").Trim(), FastDriver.DocumentRepository.ReturnToAddress.FAGetText().ToString().Replace(",", "").Replace("\r", "").Replace("\n", "").Replace("\t", "").Replace(" ", "").Trim(), true);
                #endregion

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region REG0003_GetRTMFileBusinessParties
        [TestMethod]
        public void REG0003_GetRTMFileBusinessParties()
        {
            try
            {
                Reports.TestDescription = "Validate GetRTMPackageDetails web service.";

                #region Data
                string DocumentsTable = string.Empty;
                string RTMdescription = string.Empty;
                int RTMPackageId = 0;
                string ResRTMFBPlength = string.Empty;
                string FBPTableLength = string.Empty;
                string[] ResName = new string[10];
                string[] ResRoleName = new string[10];
                string[] ResContact = new string[10];
                string[] ResFullAddress = new string[10];
                string[] UIName = new string[10];
                string[] UIRoleName = new string[10];
                string[] UIContact = new string[10];
                string[] UIFullAddress = new string[10];


                #endregion

                #region Login and create basic file
                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Add document
                Reports.TestStep = "Navigate to target file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Add a document to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID = Convert.ToInt32(response.Templates[0].TemplateID);
                string templateName = response.Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Validate the presence of document in doc rep, all items list.";
                FastDriver.DocumentRepository.Open();
                DocumentsTable = FastDriver.DocumentRepository.DocumentsTable.FAGetText().ToString();
                Support.AreEqual("True", DocumentsTable.Contains(templateName).ToString(), true);
                #endregion

                #region Invoke CreateRTMPackageRequest
                Reports.TestStep = "Invoke CreateRTMPackageRequest method and validate response (WS)";
                var CreateRTMpackageReq = FASTWCFHelpers.Factories.DocumentRequestFactory.CreateRTMPackageReq(fileID, docID);
                var CreateRTMpackageRes = FASTWCFHelpers.DocumentService.CreateRTMPackage(CreateRTMpackageReq);
                Support.AreEqual("1", CreateRTMpackageRes.Status.ToString(), "Operation Status");
                Support.AreEqual(true, CreateRTMpackageRes.StatusDescription.ToString().Contains("RTM Package created successfully"), "Operation Status Description");
                #endregion

                #region Add additional details to Return To
                Reports.TestStep = "Add additional details to Return To.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.RTMPackagesTab.FAClick();
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.ReturnTo.FAClick();
                FastDriver.RTM.WaitForScreenToLoad(FastDriver.RTM.ReturnToAttention);
                FastDriver.RTM.ReturnToOfficeName.FASelectItemByIndex(2);
                FastDriver.RTM.ReturnToAttention.FASetText("123456");
                FastDriver.RTM.ReturnToReference.FASetText("654321");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                #region nvoke GetRTMPackageDetailsRequest
                Reports.TestStep = "Invoke GetRTMPackageDetailsRequest method and validate response (WS)";
                var GetRTMpackageReq = FASTWCFHelpers.Factories.DocumentRequestFactory.GetRTMpackageDetails(fileID);
                var GetRTMpackageRes = FASTWCFHelpers.DocumentService.GetRTMPackageDetails(GetRTMpackageReq);
                Support.AreEqual("1", GetRTMpackageRes.Status.ToString(), "Operation Status");
                Support.AreEqual(true, GetRTMpackageRes.StatusDescription.ToString().Contains("RTM Package details loaded successfully"), "Operation Status Description");
                #endregion

                #region Store RTM Package ID
                RTMdescription = GetRTMpackageRes.RTMPackage[0].Descr.ToString();
                RTMPackageId = GetRTMpackageRes.RTMPackage[0].RTMDocuments[0].RTMPackageID;
                #endregion

                #region Invoke GetRTMFileBusinessParties
                Reports.TestStep = "Invoke GetRTMFileBusinessParties request method and validate response (WS)";
                var GetRTMFBPReq = FASTWCFHelpers.Factories.DocumentRequestFactory.GetRTMFileBusinessPartyRequest(fileID, RTMPackageId);
                var GetRTMFBPRes = FASTWCFHelpers.DocumentService.GetRTMFileBusinessParties(GetRTMFBPReq);
                Support.AreEqual("1", GetRTMFBPRes.Status.ToString(), "Operation Status");
                Support.AreEqual(true, GetRTMFBPRes.StatusDescription.ToString().Contains("Getting RTM File Business Parties operation completed"), "Operation Status Description");
                #endregion

                #region Validate the Response Variables with UI values.
                Reports.TestStep = "Naviagate to RTM mail to addresses dialog.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.RTMPackagesTab.FAClick();
                FastDriver.RTM.WaitForScreenToLoad();
                FastDriver.RTM.MailTo.FAClick();
                FastDriver.RTM.SelectAddressees.FAClick();
                FastDriver.RTMMailToAddresseesDlg.WaitForScreenToLoad();
                FastDriver.RTMMailToAddresseesDlg.FileBusinessParties.FAClick();

                #region Store the response variables.
                Reports.TestStep = "Validate the FBP count, store the response and UI values and validate the values.";
                ResRTMFBPlength = GetRTMFBPRes.RTMFileBusinessParties.Length.ToString();
                FBPTableLength = FastDriver.RTMMailToAddresseesDlg.FileBusinessPartyTable.GetRowCount().ToString();

                #endregion

                Support.AreEqual(ResRTMFBPlength, (Convert.ToInt32(FBPTableLength) - 1).ToString(), true);
                if (Convert.ToInt32(ResRTMFBPlength) == (Convert.ToInt32(FBPTableLength) - 1))
                {
                    for (int i = 0; i < Convert.ToInt32(ResRTMFBPlength); i++)
                    {
                        ResName[i] = GetRTMFBPRes.RTMFileBusinessParties[i].Name.ToString().Trim();
                        ResRoleName[i] = GetRTMFBPRes.RTMFileBusinessParties[i].RoleName.ToString().Trim();
                        ResContact[i] = GetRTMFBPRes.RTMFileBusinessParties[i].ContactName.ToString().Trim();
                        ResFullAddress[i] = GetRTMFBPRes.RTMFileBusinessParties[i].FullAddress.ToString().Trim();
                    }

                    for (int l = 0; l <= Convert.ToInt32(FBPTableLength); l++ )
                    {
                        UIName[l] = FastDriver.RTMMailToAddresseesDlg.FileBusinessPartyTable.PerformTableAction(l+2, 4, TableAction.GetText).Message.ToString();
                        UIRoleName[l] = FastDriver.RTMMailToAddresseesDlg.FileBusinessPartyTable.PerformTableAction(l+2, 6, TableAction.GetText).Message.ToString();
                        UIContact[l] = FastDriver.RTMMailToAddresseesDlg.FileBusinessPartyTable.PerformTableAction(l+2, 7, TableAction.GetText).Message.ToString();
                        UIFullAddress[l] = FastDriver.RTMMailToAddresseesDlg.FileBusinessPartyTable.PerformTableAction(l+2, 9, TableAction.GetText).Message.ToString();
                        if (l == Convert.ToInt32(ResRTMFBPlength)-1)
                        {
                            break;
                        }
                    }
                    #region Commented block of code
                    //for (int j = 0; j <= Convert.ToInt32(ResRTMFBPlength); j++)
                        //{
                        //    if (j == 0)
                        //    {
                        //        UIName[j] = FastDriver.RTMMailToAddresseesDlg.FileBusinessPartyTable.PerformTableAction(2, 4, TableAction.GetText).Message.ToString();
                        //        UIRoleName[j] = FastDriver.RTMMailToAddresseesDlg.FileBusinessPartyTable.PerformTableAction(2, 6, TableAction.GetText).Message.ToString();
                        //        UIContact[j] = FastDriver.RTMMailToAddresseesDlg.FileBusinessPartyTable.PerformTableAction(2, 7, TableAction.GetText).Message.ToString();
                        //        UIFullAddress[j] = FastDriver.RTMMailToAddresseesDlg.FileBusinessPartyTable.PerformTableAction(2, 9, TableAction.GetText).Message.ToString();
                        //    }
                        //    if (j == 1)
                        //    {
                        //        UIName[j] = FastDriver.RTMMailToAddresseesDlg.FileBusinessPartyTable.PerformTableAction(3, 4, TableAction.GetText).Message.ToString();
                        //        UIRoleName[j] = FastDriver.RTMMailToAddresseesDlg.FileBusinessPartyTable.PerformTableAction(3, 6, TableAction.GetText).Message.ToString();
                        //        UIContact[j] = FastDriver.RTMMailToAddresseesDlg.FileBusinessPartyTable.PerformTableAction(3, 7, TableAction.GetText).Message.ToString();
                        //        UIFullAddress[j] = FastDriver.RTMMailToAddresseesDlg.FileBusinessPartyTable.PerformTableAction(3, 9, TableAction.GetText).Message.ToString();
                        //    }
                        //    if (j == 2)
                        //    {
                        //        UIName[j] = FastDriver.RTMMailToAddresseesDlg.FileBusinessPartyTable.PerformTableAction(4, 4, TableAction.GetText).Message.ToString();
                        //        UIRoleName[j] = FastDriver.RTMMailToAddresseesDlg.FileBusinessPartyTable.PerformTableAction(4, 6, TableAction.GetText).Message.ToString();
                        //        UIContact[j] = FastDriver.RTMMailToAddresseesDlg.FileBusinessPartyTable.PerformTableAction(4, 7, TableAction.GetText).Message.ToString();
                        //        UIFullAddress[j] = FastDriver.RTMMailToAddresseesDlg.FileBusinessPartyTable.PerformTableAction(4, 9, TableAction.GetText).Message.ToString();
                        //    }
                        //    if (j == 3)
                        //    {
                        //        UIName[j] = FastDriver.RTMMailToAddresseesDlg.FileBusinessPartyTable.PerformTableAction(5, 4, TableAction.GetText).Message.ToString();
                        //        UIRoleName[j] = FastDriver.RTMMailToAddresseesDlg.FileBusinessPartyTable.PerformTableAction(5, 6, TableAction.GetText).Message.ToString();
                        //        UIContact[j] = FastDriver.RTMMailToAddresseesDlg.FileBusinessPartyTable.PerformTableAction(5, 7, TableAction.GetText).Message.ToString();
                        //        UIFullAddress[j] = FastDriver.RTMMailToAddresseesDlg.FileBusinessPartyTable.PerformTableAction(5, 9, TableAction.GetText).Message.ToString();
                        //    }
                    //}
                    #endregion
                    for (int k = 0; k < (Convert.ToInt32(ResRTMFBPlength)); k++)
                    {
                        Support.AreEqual(ResName[k].Trim(), UIName[k].Trim(), "Name" + k);
                        Support.AreEqual(ResRoleName[k].Trim(), UIRoleName[k].Trim(), "RoleName" + k);
                        Support.AreEqual(ResContact[k].Trim(), UIContact[k].Trim(), "Contact" + k);
                        Support.AreEqual(ResFullAddress[k].Trim(), UIFullAddress[k].Trim(), "FullAddress" + k);
                    }
                }
                FastDriver.DialogBottomFrame.ClickCancel();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion


        #region Private class methods

        private void Login(string url = null)
        {
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            FASTLogin.Login(url ?? AutoConfig.FASTHomeURL, credentials, true);
        }

        #endregion
    }
}
