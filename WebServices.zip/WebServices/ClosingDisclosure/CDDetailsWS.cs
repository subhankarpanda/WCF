﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.DataObjects;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastClosingDisclosureService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebServices.CD
{
    [CodedUITest]
    public class CDDetailsWS : MasterTestClass
    {
        [TestMethod]
        [Description("Verify Header Information from CD Form using GetCDDetails(*) web service")]
        public void REG0001_Test_GetCDDetails_SectionMainInformation()
        {
            try
            {
                Reports.TestDescription = "Verify Header Information from CD Form using GetCDDetails(*) web service";

                #region Create File with Buyer | Seller | New Loan
                Reports.TestStep = "Create File with Buyer | Seller | New Loan";
                FASTHelpers.WCF_Create_File(LenderID: "BOA", loanAmt: 123456789M, hasBuyer: true, hasSeller: true);
                #endregion

                #region Deliver CD Form by ImageDoc
                Reports.TestStep = "Deliver CD Form by ImageDoc";
                var request = CDRequestFactory.GetCDFormDeliveryRequest(FASTHelpers.File.FileID);
                FASTHelpers.ToJSON<CDDeliveryRequest>(request);
                request.ImageDocOptions = CDRequestFactory.GetImageDocOptions();
                request.eDeliveryMethod = FASTWCFHelpers.FastClosingDisclosureService.DeliveryMethod.ImageDoc;
                var response = ClosingDisclosureService.CDFormDelivery(request);
                FASTHelpers.ToJSON<DeliveryResponse>(response);
                Support.AreEqual("1", response.Status.ToString(), response.ToJSON());
                #endregion

                FASTHelpers.FAST_Login_IIS(int.Parse(FASTHelpers.File.FileNumber));

                #region Add a new Settlement Agent through Outside Escrow Company
                Reports.TestStep = "Add a new Settlement Agent through Outside Escrow Company";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("408");
                FastDriver.BottomFrame.Done();
                #endregion 

                #region Fill in Loan Information
                Reports.TestStep = "Fill in Loan Information";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.SetLoanInformation(new FASTSelenium.PageObjects.CDLoanInformation()
                {
                    Years = 10,
                    Months = 0,
                    ProductType = "Fixed Rate",
                    ProductComment = "@test_comment",
                    IsConventional = true,
                    Type = "Conventional",
                    LenderID = "1234",
                    MICNumber = "1234"
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Closing/Transaction/Loan information using GetCDDetails(*)
                Reports.TestStep = "Verify Closing/Transaction/Loan information using GetCDDetails(*)";
                FastDriver.ClosingDisclosure.Open();
                var reqDetails = CDRequestFactory.GetCDDetailsRequest(FASTHelpers.File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.HeaderInformation);
                FASTHelpers.ToJSON<ClosingDisclosureRequest>(reqDetails);
                var details = ClosingDisclosureService.GetCDDetails(reqDetails);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                FASTHelpers.ToJSON<ClosingDisclosureHeader>(details.ClosingDisclosureHeader);
                //  Closing
                var todaysDate = DateTime.Today.ToDateString(slash: true, trim: true);
                Support.AreEqual(todaysDate, details.ClosingDisclosureHeader.DisplayIssuedDate, "ClosingDisclosureHeader.DisplayIssuedDate");
                Support.AreEqual(todaysDate, details.ClosingDisclosureHeader.DisplayClosingDate, "ClosingDisclosureHeader.DisplayClosingDate");
                Support.AreEqual(todaysDate, details.ClosingDisclosureHeader.DisplayDisbursementDate, "ClosingDisclosureHeader.DisplayDisbursementDate");
                Support.AreEqual("*QA Automation Office - DO NOT TOUCH", details.ClosingDisclosureHeader.DisplaySettlementAgentName, "ClosingDisclosureHeader.DisplaySettlementAgentName");
                Support.AreEqual("Flannery, Hoover & Boyd ", details.ClosingDisclosureHeader.SettlementAgentColl[1].Name, "ClosingDisclosureHeader.SettlementAgentColl[1].Name");
                Support.AreEqual(FASTHelpers.File.FileNumber, details.ClosingDisclosureHeader.FileNum, "ClosingDisclosureHeader.FileNum");
                Support.AreEqual("91 NW Road", details.ClosingDisclosureHeader.DisplayPropertyAddress, "ClosingDisclosureHeader.DisplayPropertyAddress");
                Support.AreEqual("Santa Ana, CA 92701", details.ClosingDisclosureHeader.DisplayPropertyCSZ, "ClosingDisclosureHeader.DisplayPropertyCSZ");
                Support.AreEqual("$100,000", details.ClosingDisclosureHeader.PropertyValue, "ClosingDisclosureHeader.PropertyValue");
                //  Transaction
                Support.AreEqual("BuyerName BuyerLastName", details.ClosingDisclosureHeader.DisplayBorrowerName, "ClosingDisclosureHeader.DisplayBorrowerName");
                Support.AreEqual("SellerName SellerLastName", details.ClosingDisclosureHeader.DisplaySellerName, "ClosingDisclosureHeader.DisplaySellerName");
                Support.AreEqual("91 NW Road", details.ClosingDisclosureHeader.DisplaySellerAddress, "ClosingDisclosureHeader.DisplaySellerAddress");
                Support.AreEqual("Santa Ana, CA 92701", details.ClosingDisclosureHeader.DisplaySellerCSZ, "ClosingDisclosureHeader.DisplaySellerCSZ");
                Support.AreEqual("Bank of America", details.ClosingDisclosureHeader.DisplayLenderName1, "ClosingDisclosureHeader.DisplayLenderName1");
                //  Loan
                Support.AreEqual("10 years", details.ClosingDisclosureHeader.DisplayLoanTerm, "ClosingDisclosureHeader.DisplayLoanTerm");
                Support.AreEqual("Purchase", details.ClosingDisclosureHeader.DisplayLoanPurpose, "ClosingDisclosureHeader.DisplayLoanPurpose");
                Support.AreEqual("@test_comment Fixed Rate", details.ClosingDisclosureHeader.DisplayLoanProduct1, "ClosingDisclosureHeader.DisplayLoanProduct1");
                Support.AreEqual(LoanProductTypeCdID.FixedRate, details.ClosingDisclosureHeader.LoanProductTypeCDID, "ClosingDisclosureHeader.LoanProductTypeCDID");
                Support.AreEqual(LoanPurposeTypeCdID.Purchase, details.ClosingDisclosureHeader.LoanPurposeTypeCDID, "ClosingDisclosureHeader.LoanPurposeTypeCDID");
                Support.AreEqual("1234", details.ClosingDisclosureHeader.DisplayLoanID, "ClosingDisclosureHeader.DisplayLoanID");
                Support.AreEqual("1234", details.ClosingDisclosureHeader.DisplayMICNum, "ClosingDisclosureHeader.DisplayMICNum");
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Loan Terms from CD Form using GetCDDetails(*) web service")]
        public void REG0002_Test_GetDetails_SectionLoanTerms()
        {
            try
            {
                Reports.TestDescription = "Verify Loan Terms from CD Form using GetCDDetails(*) web service";

                #region Create File with Buyer | Seller | New Loan
                Reports.TestStep = "Create File with Buyer | Seller | New Loan";
                FASTHelpers.WCF_Create_File(LenderID: "BOA", loanAmt: 123456789M, hasBuyer: true, hasSeller: true);
                #endregion

                FASTHelpers.FAST_Login_IIS(int.Parse(FASTHelpers.File.FileNumber));

                #region Fill in Loan Terms
                Reports.TestStep = "Fill in Loan Terms";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.ExpandLoanTerm();
                FastDriver.ClosingDisclosure.SetLoanTerms(new FASTSelenium.PageObjects.CDLoanTerms() 
                { 
                    IsLoanAmountIncreasedAfterClosing = true,
                    LoanAmountCondition = "Goes",
                    LoanAmountAsHighAs = (decimal)2000000.00,
                    LoanAmountIncreasedUntilYear = 10,
                    InterestRate = (decimal)8.75,
                    IsInterestRateIncreasedAfterClosing = true,
                    InterestRateAdjustsEveryYears = 1,
                    InterestRateAdjustsStartingInYear = 1,
                    InterestRateCanGoAsHighAs = 20,
                    InterestRateCanGoAsHighAsInYear = 10,
                    MonthlyPayment = (decimal)10000.00,
                    IsMonthlyPaymentIncreasedAfterClosing = true,
                    MonthlyPaymentAdjustsEveryYears = 1,
                    MonthlyPaymentAdjustsStartingInYear = 1,
                    MonthlyPaymentCanGoAsHighAs = (decimal)50000.00,
                    MonthlyPaymentCanGoAsHighAsInYear = 10,
                    MonthlyPaymentOnlyInterestUntilYear = 2,
                    HasPrepaymentPenalty = true,
                    PrepaymentPenaltyGoesAsHighAs = (decimal)60000.00,
                    PrepaymentPenaltyGoesAsHighAsIfPaidDuringFirstYears = 5,
                    HasBalloonPayment = true,
                    BalloonPaymentAtTheEndOfLoanTerm = (decimal)15000.00
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Loan Terms using GetCDDetails(*)
                Reports.TestStep = "Verify Loan Terms using GetCDDetails(*)";
                FastDriver.ClosingDisclosure.Open();
                var reqDetails = CDRequestFactory.GetCDDetailsRequest(FASTHelpers.File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.LoanTerms);
                FASTHelpers.ToJSON<ClosingDisclosureRequest>(reqDetails);
                var details = ClosingDisclosureService.GetCDDetails(reqDetails);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                FASTHelpers.ToJSON<ClosingDisclosureHeader>(details.ClosingDisclosureLoanTerm);
                //  Loan Amount
                Support.AreEqual("$123,456,789", details.ClosingDisclosureLoanTerm.DisplayLoanAmount, "DisplayLoanAmount");
                Support.AreEqual("Yes", details.ClosingDisclosureLoanTerm.DisplayLoanAmountCanIncrease, "DisplayLoanAmountCanIncrease");
                Support.Match("Goes.*as high as.*\\$2,000,000\\.00.*Increases.*until year.*10", details.ClosingDisclosureLoanTerm.DisplayLoanAmountClauses, "DisplayLoanAmountClauses");
                //  Interest Rate
                Support.AreEqual("8.75%", details.ClosingDisclosureLoanTerm.DisplayInterestRate, "DisplayInterestRate");
                Support.AreEqual("Yes", details.ClosingDisclosureLoanTerm.DisplayInterestRateCanIncrease, "DisplayInterestRateCanIncrease");
                Support.Match("Adjusts .*every 1 year\\(s\\) .*starting in year 1.*Can go .*as high as .*20%.* in year", details.ClosingDisclosureLoanTerm.DisplayInterestRateClauses, "DisplayInterestRateClauses");
                //  Principal & Interest
                Support.AreEqual("$10,000.00", details.ClosingDisclosureLoanTerm.DisplayMonthlyPrincipalInterest, "DisplayMonthlyPrincipalInterest");
                Support.AreEqual("Yes", details.ClosingDisclosureLoanTerm.DisplayPrincipalInterestCanIncrease, "DisplayPrincipalInterestCanIncrease");
                Support.Match("Adjusts .*every 1 year\\(s\\) .*g>starting in year 1.*Can go .*as high as .*\\$50,000\\.00.* in year 10", details.ClosingDisclosureLoanTerm.DisplayPrincipalandInterestClauses, "DisplayPrincipalandInterestClauses");
                Support.Match("Includes .*only interest.* and .*no principal.* until year 2", details.ClosingDisclosureLoanTerm.DisplayPrincipalandInterestClauses, "DisplayPrincipalandInterestClauses");
                //  Prepayment Penalty
                Support.IsTrue(details.ClosingDisclosureLoanTerm.DisplayPrepaymentPenalty == null, "DisplayPrepaymentPenalty");
                Support.AreEqual("Yes", details.ClosingDisclosureLoanTerm.DisplayHasPrepaymentPenalty, "DisplayHasPrepaymentPenalty");
                Support.Match("As high as \\$60,000\\.00.* if you pay off the loan during the first 5 year\\(s\\)", details.ClosingDisclosureLoanTerm.DisplayPrepaymentPenaltyClauses, "DisplayPrepaymentPenaltyClauses");
                //  Balloon Payment
                Support.IsTrue(details.ClosingDisclosureLoanTerm.DisplayBalloonPayment == null, "DisplayBalloonPayment");
                Support.AreEqual("Yes", details.ClosingDisclosureLoanTerm.DisplayHasBalloonPayment, "DisplayHasBalloonPayment");
                Support.Match("You will have to pay .*\\$15,000\\.00.* at the end of year", details.ClosingDisclosureLoanTerm.DisplayBalloonPaymentClauses, "DisplayBalloonPaymentClauses");
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Projected Payments from CD Form using GetCDDetails(*) web service")]
        public void REG0003_Test_GetDetails_ProjectedPayments()
        { 
            try
            {
                Reports.TestDescription = "Verify Projected Payments from CD Form using GetCDDetails(*) web service";

                #region Create File with Buyer | Seller | New Loan
                Reports.TestStep = "Create File with Buyer | Seller | New Loan";
                FASTHelpers.WCF_Create_File(LenderID: "BOA", loanAmt: 123456789M, hasBuyer: true, hasSeller: true);
                #endregion

                FASTHelpers.FAST_Login_IIS(int.Parse(FASTHelpers.File.FileNumber));

                #region Fill in Proyected Payments
                Reports.TestStep = "Fill in Proyected Payments";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.ExpandProjectedPayment();
                var projectedPayments = new FASTSelenium.PageObjects.CDProjectedPayments()
                {
                    PaymentCalculations = new FASTSelenium.PageObjects.CDProjectedPayments.PaymentCalculation[] 
                    { 
                        new FASTSelenium.PageObjects.CDProjectedPayments.PaymentCalculation()
                        {
                            StartYear = 1,
                            EndYear = 2,
                            Interest = (decimal)2.75,
                            MortgageInsurance = (decimal)160000.00,
                            EstimatedEscrow = (decimal)12500.00
                        },
                        new FASTSelenium.PageObjects.CDProjectedPayments.PaymentCalculation()
                        {
                            StartYear = 3,
                            EndYear = 3,
                            PrincipalAndInterest = (decimal)8.75,
                            MortgageInsurance = (decimal)52000.00,
                            EstimatedEscrow = (decimal)4200.00
                        }
                    },
                    EstimatedTaxesInsuranceAndAssesments = (decimal)8000.00,
                    PropertyTaxes = true,
                    PropertyTaxesInEscrow = "YES",
                    HomeownerInsurance = true,
                    HomeownerInsuranceInEscrow = "SOME",
                    AdditionalEstimatedPropertyCosts = new FASTSelenium.PageObjects.CDProjectedPayments.AdditionalEstimatedPropertyCost[] 
                    { 
                        new FASTSelenium.PageObjects.CDProjectedPayments.AdditionalEstimatedPropertyCost()
                        {
                            ID = AdditionalEstimateCostOtherTypeCdID.Other,
                            ShowOnForm = true,
                            Included = true,
                            InEscrow = true,
                            Other = "test cost"
                        }
                    }
                };
                FastDriver.ClosingDisclosure.SetProjectedPayments(projectedPayments);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Projected Payments using GetCDDetails(*)
                Reports.TestStep = "Verify Projected Payments using GetCDDetails(*)";
                FastDriver.ClosingDisclosure.Open();
                var reqDetails = CDRequestFactory.GetCDDetailsRequest(FASTHelpers.File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.ProjectedPayments);
                FASTHelpers.ToJSON<ClosingDisclosureRequest>(reqDetails);
                var details = ClosingDisclosureService.GetCDDetails(reqDetails);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                FASTHelpers.ToJSON<ClosingDisclosureHeader>(details.ClosingDisclosureProjectedPayment);
                //
                var yearRange = projectedPayments.PaymentCalculations.Length;
                Support.AreEqual(yearRange, details.ClosingDisclosureProjectedPayment.YearRange, "YearRange");
                for (int i = 0; i < yearRange; i++)
                {
                    Support.AreEqual(projectedPayments.PaymentCalculations[i].StartYear.ToString(), details.ClosingDisclosureProjectedPayment.ProjectedPaymentRanges[i].StartRange.ToString(), "ProjectedPaymentRanges[" + i + "].StartRange");
                    Support.AreEqual(projectedPayments.PaymentCalculations[i].EndYear.ToString(), details.ClosingDisclosureProjectedPayment.ProjectedPaymentRanges[i].EndRange.ToString(), "ProjectedPaymentRanges[" + i + "].StartRange");
                    if(projectedPayments.PaymentCalculations[i].Interest != null)
                    {
                        Support.AreEqual(projectedPayments.PaymentCalculations[i].Interest.ToString("F2"), ((Decimal)details.ClosingDisclosureProjectedPayment.ProjectedPaymentRanges[i].Interest).ToString("F2"), "ProjectedPaymentRanges[" + i + "].Interest");
                    }
                    if (projectedPayments.PaymentCalculations[i].PrincipalAndInterest != null)
                    {
                        Support.AreEqual(projectedPayments.PaymentCalculations[i].PrincipalAndInterest.ToString("F2"), ((Decimal)details.ClosingDisclosureProjectedPayment.ProjectedPaymentRanges[i].PrincipalInterest).ToString("F2"), "ProjectedPaymentRanges[" + i + "].Interest");
                    }
                    Support.AreEqual(projectedPayments.PaymentCalculations[i].MortgageInsurance.ToString("N2"), details.ClosingDisclosureProjectedPayment.ProjectedPaymentRanges[i].MortgageInsurance, "ProjectedPaymentRanges[" + i + "].MortgageInsurance");
                    Support.AreEqual(projectedPayments.PaymentCalculations[i].EstimatedEscrow.ToString("N2"), details.ClosingDisclosureProjectedPayment.ProjectedPaymentRanges[i].EstimatedEscrow, "ProjectedPaymentRanges[" + i + "].EstimatedEscrow");
                }
                Support.AreEqual(projectedPayments.EstimatedTaxesInsuranceAndAssesments.ToString("C2"), details.ClosingDisclosureProjectedPayment.EstimatedTaxInsuranceAssesment, "EstimatedTaxInsuranceAssesment");
                Support.AreEqual(projectedPayments.PropertyTaxes, details.ClosingDisclosureProjectedPayment.IsPropertyTax == 1, "IsPropertyTax");
                Support.AreEqual(projectedPayments.PropertyTaxesInEscrow.ToUpperInvariant(), details.ClosingDisclosureProjectedPayment.DisplayPropertyTaxInEscrow, "DisplayPropertyTaxInEscrow");
                Support.AreEqual(projectedPayments.HomeownerInsurance, details.ClosingDisclosureProjectedPayment.IsHomeOwnerInsurance == 1, "IsHomeOwnerInsurance");
                Support.AreEqual(projectedPayments.HomeownerInsuranceInEscrow.ToUpperInvariant(), details.ClosingDisclosureProjectedPayment.DisplayHomeOwnerInsuranceInEscrow, "DisplayHomeOwnerInsuranceInEscrow");
                Support.AreEqual(projectedPayments.AdditionalEstimatedPropertyCosts[0].ID.ToString(), details.ClosingDisclosureProjectedPayment.PPAdditionalEstimatedPropertyCosts[0].EstimateIncludeID, "Other AdditionalEstimatedPropertyCost");
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Costs At Closing from CD Form using GetCDDetails(*) web service")]
        public void REG0004_Test_GetDetails_CostsAtClosing()
        {
            try
            {
                Reports.TestDescription = "Verify Costs At Closing from CD Form using GetCDDetails(*) web service";

                #region Create File with Buyer | Seller | New Loan
                Reports.TestStep = "Create File with Buyer | Seller | New Loan";
                FASTHelpers.WCF_Create_File(LenderID: "BOA", loanAmt: 123456789M, hasBuyer: true, hasSeller: true);
                #endregion

                FASTHelpers.FAST_Login_IIS(int.Parse(FASTHelpers.File.FileNumber));

                #region Update New Loan costs before/after closing and others
                Reports.TestStep = "Update New Loan costs before/after closing and others";
                var updateReq = FileRequestFactory.GetNewLoanUpdateRequest(FASTHelpers.File.FileID.ToString(), seqNum: 1);
                var updateRes = FileService.UpdateNewLoan(updateReq);
                Support.AreEqual("1", updateRes.Status.ToString(), updateRes.StatusDescription);
                #endregion

                #region Verify Costs At Closing using GetCDDetails(*)
                Reports.TestStep = "Verify Costs At Closing using GetCDDetails(*)";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.ExpandCostAtClosing();
                var reqDetails = CDRequestFactory.GetCDDetailsRequest(FASTHelpers.File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.CostsAtClosing);
                FASTHelpers.ToJSON<ClosingDisclosureRequest>(reqDetails);
                var details = ClosingDisclosureService.GetCDDetails(reqDetails);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                FASTHelpers.ToJSON<ClosingDisclosureHeader>(details.CostAtClosing);
                //
                Support.AreEqual("$115.33", details.CostAtClosing.DisplayClosingCostsAmount, "DisplayClosingCostsAmount");
                Support.AreEqual("Includes", details.CostAtClosing.ClosingCostDisplayText1, "ClosingCostDisplayText1");
                Support.AreEqual("$12.02", details.CostAtClosing.DisplayLenderCreditBorrowerPaidAmount, "DisplayLenderCreditBorrowerPaidAmount");
                Support.AreEqual("in Loan Costs +", details.CostAtClosing.ClosingCostDisplayText2, "ClosingCostDisplayText2");
                Support.AreEqual("$82.16", details.CostAtClosing.DisplaySectionDBorrowerPaidAmount, "DisplaySectionDBorrowerPaidAmount");
                Support.AreEqual("in Other Costs -", details.CostAtClosing.ClosingCostDisplayText3, "ClosingCostDisplayText3");
                Support.AreEqual("$45.19", details.CostAtClosing.DisplaySectionIBorrowerPaidAmount, "DisplaySectionIBorrowerPaidAmount");
                Support.AreEqual("-$555,455,455.74", details.CostAtClosing.DisplayCashToCloseAmount, "DisplayCashToCloseAmount");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Loan Costs from CD Form using GetCDDetails(*) web service")]
        public void REG0005_Test_GetDetails_LoanCosts()
        { 
            try
            {
                Reports.TestDescription = "Verify LoanCosts from CD Form using GetCDDetails(*) web service";

                #region Create File with Buyer | Seller | New Loan
                Reports.TestStep = "Create File with Buyer | Seller | New Loan";
                FASTHelpers.WCF_Create_File(LenderID: "BOA", loanAmt: 123456789M, hasBuyer: true, hasSeller: true);
                #endregion

                FASTHelpers.FAST_Login_IIS(int.Parse(FASTHelpers.File.FileNumber));

                #region Update New Loan costs before/after closing and others
                Reports.TestStep = "Update New Loan costs before/after closing and others";
                var updateReq = FileRequestFactory.GetNewLoanUpdateRequest(FASTHelpers.File.FileID.ToString(), seqNum: 1);
                var updateRes = FileService.UpdateNewLoan(updateReq);
                Support.AreEqual("1", updateRes.Status.ToString(), updateRes.StatusDescription);
                #endregion

                #region Verify Loan Costs using GetCDDetails(*)
                Reports.TestStep = "Verify Loan Costs using GetCDDetails(*)";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.ExpandLoanCost();
                var reqDetails = CDRequestFactory.GetCDDetailsRequest(FASTHelpers.File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.LoanCosts);
                FASTHelpers.ToJSON<ClosingDisclosureRequest>(reqDetails);
                var details = ClosingDisclosureService.GetCDDetails(reqDetails);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                FASTHelpers.ToJSON<ClosingDisclosureHeader>(details.LoanCosts);
                //
                Support.AreEqual("$34.09", details.LoanCosts.SectionACharges.DisplayTotal, "SectionACharges.DisplayTotal");
                Support.AreEqual("$48.07", details.LoanCosts.SectionBCharges.DisplayTotal, "SectionBCharges.DisplayTotal");
                Support.AreEqual("", details.LoanCosts.SectionCCharges.DisplayTotal, "SectionCCharges.DisplayTotal");
                Support.AreEqual("$82.16", details.LoanCosts.SectionDCharges.DisplayTotal, "SectionDCharges.DisplayTotal");
                Support.AreEqual("Loan Costs Subtotals (A + B + C)", details.LoanCosts.SectionDCharges.Charges[0].Description, "SectionDCharges.Charges[0].Description");
                Support.AreEqual("$46.08", details.LoanCosts.SectionDCharges.Charges[0].DisplayPaidByBuyerAtClosing, "SectionDCharges.Charges[0].DisplayPaidByBuyerAtClosing");
                Support.AreEqual("$36.08", details.LoanCosts.SectionDCharges.Charges[0].DisplayPaidByBuyerBeforeClosing, "SectionDCharges.Charges[0].DisplayPaidByBuyerBeforeClosing");
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Other Costs from CD Form using GetCDDetails(*) web service")]
        public void REG0006_Test_GetDetails_OtherCosts()
        {
            try
            {
                Reports.TestDescription = "Verify Other Costs from CD Form using GetCDDetails(*) web service";

                #region Create File with Buyer | Seller | New Loan
                Reports.TestStep = "Create File with Buyer | Seller | New Loan";
                FASTHelpers.WCF_Create_File(LenderID: "BOA", loanAmt: 123456789M, hasBuyer: true, hasSeller: true);
                #endregion

                FASTHelpers.FAST_Login_IIS(int.Parse(FASTHelpers.File.FileNumber));

                #region Update New Loan costs before/after closing and others
                Reports.TestStep = "Update New Loan costs before/after closing and others";
                var updateReq = FileRequestFactory.GetNewLoanUpdateRequest(FASTHelpers.File.FileID.ToString(), seqNum: 1);
                var updateRes = FileService.UpdateNewLoan(updateReq);
                Support.AreEqual("1", updateRes.Status.ToString(), updateRes.StatusDescription);
                #endregion

                #region Verify Other Costs using GetCDDetails(*)
                Reports.TestStep = "Verify Other Costs using GetCDDetails(*)";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.ExpandOtherCosts();
                var reqDetails = CDRequestFactory.GetCDDetailsRequest(FASTHelpers.File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.OtherCosts);
                FASTHelpers.ToJSON<ClosingDisclosureRequest>(reqDetails);
                var details = ClosingDisclosureService.GetCDDetails(reqDetails);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                FASTHelpers.ToJSON<ClosingDisclosureHeader>(details.OtherCosts);
                //
                Support.AreEqual("$34.15", details.OtherCosts.SectionECharges.DisplayTotal, "SectionECharges.DisplayTotal");
                Support.AreEqual("$10.03", details.OtherCosts.SectionFCharges.DisplayTotal, "SectionFCharges.DisplayTotal");
                Support.AreEqual("$1.01", details.OtherCosts.SectionGCharges.DisplayTotal, "SectionGCharges.DisplayTotal");
                Support.AreEqual("", details.OtherCosts.SectionHCharges.DisplayTotal, "SectionHCharges.DisplayTotal");
                Support.AreEqual("$45.19", details.OtherCosts.SectionICharges.DisplayTotal, "SectionICharges.DisplayTotal");
                Support.AreEqual("$115.33", details.OtherCosts.SectionJCharges.DisplayTotal, "SectionJCharges.DisplayTotal");
                Support.AreEqual("Closing Costs Subtotals (D + I)", details.OtherCosts.SectionJCharges.Charges[0].Description, "SectionJCharges.Charges[0].Description");
                Support.AreEqual("$87.26", details.OtherCosts.SectionJCharges.Charges[0].DisplayPaidByBuyerAtClosing, "SectionJCharges.Charges[0].DisplayPaidByBuyerAtClosing");
                Support.AreEqual("$40.09", details.OtherCosts.SectionJCharges.Charges[0].DisplayPaidByBuyerBeforeClosing, "SectionJCharges.Charges[0].DisplayPaidByBuyerBeforeClosing");
                Support.AreEqual("$42.10", details.OtherCosts.SectionJCharges.Charges[0].DisplayPaidBySellerAtClosing, "SectionJCharges.Charges[0].DisplayPaidBySellerAtClosing");
                Support.AreEqual("$30.09", details.OtherCosts.SectionJCharges.Charges[0].DisplayPaidBySellerBeforeClosing, "SectionJCharges.Charges[0].DisplayPaidBySellerBeforeClosing");
                Support.AreEqual("$3,641.10", details.OtherCosts.SectionJCharges.Charges[0].DisplayPaidByOthersForBuyer, "SectionJCharges.Charges[0].DisplayPaidByOthersForBuyer");
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Calculating Cash To Close from CD Form using GetCDDetails(*) web service")]
        public void REG0007_Test_GetDetails_CalculatingCashToClose()
        { 
            try
            {
                Reports.TestDescription = "Verify Calculating Cash To Close from CD Form using GetCDDetails(*) web service";

                #region Create File with Buyer | Seller | New Loan
                Reports.TestStep = "Create File with Buyer | Seller | New Loan";
                FASTHelpers.WCF_Create_File(LenderID: "BOA", loanAmt: 123456789M, hasBuyer: true, hasSeller: true);
                #endregion

                FASTHelpers.FAST_Login_IIS(int.Parse(FASTHelpers.File.FileNumber));

                #region Update New Loan costs before/after closing and others
                Reports.TestStep = "Update New Loan costs before/after closing and others";
                var updateReq = FileRequestFactory.GetNewLoanUpdateRequest(FASTHelpers.File.FileID.ToString(), seqNum: 1);
                var updateRes = FileService.UpdateNewLoan(updateReq);
                Support.AreEqual("1", updateRes.Status.ToString(), updateRes.StatusDescription);
                #endregion

                #region Make a Deposit Outside Escrow
                Reports.TestStep = "Make a Deposit Outside Escrow";
                FastDriver.DepositOutsideEscrow.SetDeposit(new FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.OEDeposit[]
                {
                    new FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.OEDeposit()
                    { 
                         HeldBy = FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.HeldBy.BuyersAttorney,
                         Amount = (decimal)1000.00,
                         Comment = "FASTQA07"
                    },
                    new FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.OEDeposit()
                    { 
                         HeldBy = FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.HeldBy.BuyersBroker,
                         Amount = (decimal)1000.00,
                         Comment = "FASTQA07"
                    }
                });
                #endregion

                #region Navigate to Closing Disclosure and update Calculate Cash to Close table
                Reports.TestStep = "Navigate to Closing Disclosure and update Calculate Cash to Close table";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Calculating_Cash_to_Close.Click();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.CCTotalClosingCostsJ_ImgPlus);
                FastDriver.ClosingDisclosure.CCTotalClosingCostsJ_ImgPlus.Click();
                FastDriver.ClosingDisclosure.CCTotalClosingCostsJ_OverrideCheck.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.CCTotalClosingCostsJ_newLEUnroundedAmt.FASetText("249999.99");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.CCTotalClosingCostsJ_btnOverrideDone.FAClick();
                FASTHelpers.FindVisibleElement(ByLocator.Id, "optCCC2973").Click(); 
                FastDriver.ClosingDisclosure.OtherComment.FASetText("test-other-reason-for-change");
                FASTHelpers.FindVisibleElement(ByLocator.Id, "btnCalculateCashToCloseDone").Click();
                FastDriver.ClosingDisclosure.CCFLoanEstimateAmount.FASetText("110000");
                FastDriver.ClosingDisclosure.CCC_spnDPLEAmount.FASetText("19999.99");
                FastDriver.ClosingDisclosure.CCC_spnDLEAmount.FASetText("19999.99");
                FastDriver.ClosingDisclosure.CCC_spnFBLEAmount.FASetText("19999.99");
                FastDriver.ClosingDisclosure.CCC_spnSCLEAmount.FASetText("19999.99");
                FastDriver.ClosingDisclosure.CCC_spnAOCLEAmount.FASetText("19999.99");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Calculating Cash To Close using GetCDDetails(*)
                Reports.TestStep = "Verify Calculating Cash To Close using GetCDDetails(*)";
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.ExpandCalculatingCashToClose();
                var reqDetails = CDRequestFactory.GetCDDetailsRequest(FASTHelpers.File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.CalculatingCashToClose);
                FASTHelpers.ToJSON<ClosingDisclosureRequest>(reqDetails);
                var details = ClosingDisclosureService.GetCDDetails(reqDetails);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                FASTHelpers.ToJSON<ClosingDisclosureHeader>(details.CalculateCashToClose);
                //

                #endregion

                return;
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
    }
}
