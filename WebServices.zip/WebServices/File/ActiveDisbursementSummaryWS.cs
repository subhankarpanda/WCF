﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.DataObjects;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Globalization;
using System.Linq;
using WebServices.Helpers.File;

namespace WebServices.File
{
    [CodedUITest]
    public class ActiveDisbursementSummaryWS:FASTHelpers
    {
        [TestMethod]
        public void REG_GetActiveDisbursementSummaryDetails()
        {
            try
            {


                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                var CRFileReq = RequestFactory.GetCreateFileDefaultRequest();
               var newFile = FASTWCFHelpers.FileService.CreateFile(CRFileReq);
               var fileID = (int)newFile.FileID;
               var _file = FASTWCFHelpers.FileService.GetOrderDetails(fileID);

               Reports.TestStep = "Search File.";
               FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                #endregion

               #region Invoke  Create Active Disbursement Summary service
               Reports.TestStep = "Invoke MiscellaneousDisbutrsement service";
                var MiscDisbusementReq = FileRequestFactory.CreateNewMiscDisbusementRequest(newFile.FileID);
                var MiscDisbusementRes = FASTWCFHelpers.FileService.CreateMiscellaneousDisbursement(MiscDisbusementReq);
                var ActiveDisRes = FASTWCFHelpers.FileService.ActiveDisbSummaryResponse(fileID);
                var disID= ActiveDisRes.Disbursements[0].DisbursementID.ToString();
               #endregion

                #region Validate the UI
                Reports.TestStep="Verify the Active Disbursement Summary details in the UI";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ActiveDisbursementSummary>(@"Home>Order Entry>Escrow Closing>Disbursements>Active Disbursement Summary");
                 FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad(FastDriver.ActiveDisbursementSummary.PrintAll);
                 Support.AreEqual(FastDriver.ActiveDisbursementSummary.DisbursementsAmount.FAGetText(), ActiveDisRes.ActiveDisbursementSummary.PendingAmount.Value.ToString());
                 Support.AreEqual("True",ActiveDisRes.Disbursements[0].EditDisbursement.DisbursementRecap.Payee.ToString().Contains(FastDriver.ActiveDisbursementSummary.Disbursementspayeename.FAGetText()).ToString());
                   
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG_GetDisbursementHistoryEditDetails()
        {
            try
            {
                Reports.TestDescription = "To verify the GetDisbursementHistoryViewDetails web service.";
                #region Login to IIS side and create file using the Web Services.
                Reports.TestStep = "Login to IIS side and create file using the Web Services.";
                FAST_Login_IIS();
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile(RequestFactory.GetDetailedCreateFileDefaultRequest());
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Navigate to file fee page, add charges and disburse the fee Manually.
                Reports.TestStep = "Navigate to the file fees page and add charges for the added fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee(FeeDescription: "New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount(FeeDesc: "New Home Rate (Title Only)", TitleEscrowTable: true, Buyer_Amt: "10.00", Seller_Amt: "20.00");

                Reports.TestStep = "Navigate to the active disbursement summary page and verify for the added charges.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Check", 1, TableAction.Click);

                Reports.TestStep = "Click on the Manual Button.";
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                Random value = new Random();
                int refNum = 1234 + value.Next(0, 10000);
                FastDriver.IssueManualCheck.CheckNo.FASetText(refNum.ToString());
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 20);
                try
                {
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                }
                catch (Exception)
                {
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }

                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("RElease the amount.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to the active disbursement summary page and validate the issue check related with split fee.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Check", 1, TableAction.GetText).Message.Trim(), "Status of the of the fee should be issued.");
                #endregion

                #region Invoke  Create Active Disbursement Summary service
                Reports.TestStep = "Invoke the GetDisbursementHistorySummary webservice and get the response.";
                DisbursementHistoryResponse response = ActiveDisbursementsHelpers.GetDisbursementHistorySummary(fileID, AutoConfig.UserName);

                Reports.TestStep = "Invoke GetDisbursementHistoryEditDetails webservice.";
                var ActiveDisEditReq = FileRequestFactory.DisbursementEditDetailsRequest(fileID, Convert.ToInt32(response.DisbursementActivities[1].DisbursementID));
                var ActiveDisEditRes = FASTWCFHelpers.FileService.GetDisbursementHistoryEditDetails(ActiveDisEditReq);
                if (ActiveDisEditRes.DisbursementDetails != null)
                {
                    Reports.StatusUpdate("GetDisbursementHistoryViewDetails web service invoked successfully", true);
                }
                else
                {
                    Reports.StatusUpdate("GetDisbursementHistoryViewDetails web service was not invoked successfully", false);
                }
                #endregion

                #region Verify the details in FAST application.
                Reports.TestStep = "Navigate to the Disbursement History page and select the activity for relavant disbursement.";
                FastDriver.DisbursementHistory.Open();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", ActiveDisEditRes.DisbursementRecap.Status, "Status", TableAction.Click);
                FastDriver.DisbursementHistory.ViewDetails.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "Validate the response values in the UI.";
                ServiceHelper.CompareWithUI(FastDriver.EditDisbursement.DisbursementAmnt, "text", string.Format("{0:0,000.00}", ActiveDisEditRes.DisbursementRecap.Amount));
                ServiceHelper.CompareWithUI(FastDriver.EditDisbursement.StatusLbl, "text", ActiveDisEditRes.DisbursementRecap.Status.ToUpper());
                ServiceHelper.CompareWithUI(FastDriver.EditDisbursement.IssueDate, "text", ActiveDisEditRes.DisbursementRecap.IssueDate.ToString("MM-dd-yyyy"));
                ServiceHelper.CompareWithUI(FastDriver.EditDisbursement.DocumentNo, "text", ActiveDisEditRes.DisbursementRecap.DocumentNo);
                ServiceHelper.CompareWithUI(FastDriver.EditDisbursement.Payee.FAGetText().Replace("Payee:", string.Empty).Trim(), ActiveDisEditRes.DisbursementRecap.Payee.Replace("\t", string.Empty).Replace("\n"," "));

                FastDriver.EditDisbursement.Expand(FastDriver.EditDisbursement.OpenDisbDetails);
                ServiceHelper.CompareWithUI(FastDriver.EditDisbursement.DisburseAs, "selecteditem", ActiveDisEditRes.DisbursementDetails.DisburseAs);
                ServiceHelper.CompareWithUI(FastDriver.EditDisbursement.PostedOnDate, "text", ActiveDisEditRes.DisbursementDetails.PostedOn.ToString("MM-dd-yyyy"));
                ServiceHelper.CompareWithUI(FastDriver.EditDisbursement.ManualCheckReason, "text", ActiveDisEditRes.DisbursementDetails.ManualCheckReason);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG_GetDisbursementHistoryViewDetails()
        {
            try
            {
                Reports.TestDescription = "To verify the GetDisbursementHistoryViewDetails web service.";
                #region Data Setup
                DepositParameters depositDetail = new DepositParameters()
                {
                    Amount = 1876.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Saurabh Jain",
                    CreditToSeller = false,
                    Comments = "Comments Before Save",
                };
                #endregion

                #region Login to IIS side and create file using the Web Services.
                Reports.TestStep = "Login to IIS side and create file using the Web Services.";
                FAST_Login_IIS();
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile(RequestFactory.GetDetailedCreateFileDefaultRequest());
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Navigate to the Deposit in escrow page and perform one deposit.
                Reports.TestStep = "Navigate to the deposit in escrow page and perform one deposit.";
                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(depositDetail);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                #endregion

                #region Navigate to file fee page, add charges and disburse the fee Manually.
                Reports.TestStep = "Navigate to the file fees page and add charges for the added fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee(FeeDescription: "New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount(FeeDesc: "New Home Rate (Title Only)", TitleEscrowTable: true, Buyer_Amt: "10.00", Seller_Amt: "20.00");

                Reports.TestStep = "Navigate to the active disbursement summary page and verify for the added charges.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Check", 1, TableAction.Click);

                Reports.TestStep = "Click on the Manual Button.";
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                Random value = new Random();
                int refNum = 1234 + value.Next(0, 10000);
                FastDriver.IssueManualCheck.CheckNo.FASetText(refNum.ToString());
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 20);
                try
                {
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                }
                catch (Exception)
                {
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }

                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("RElease the amount.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to the active disbursement summary page and validate the issue check related with split fee.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Check", 1, TableAction.GetText).Message.Trim(), "Status of the of the fee should be issued.");
                #endregion

                #region Select the disbursement summary related with escrow deposit and perform the Held disbursement.
                Reports.TestStep = "Select the deposit related to the escrow and perform to hold it.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Buyer1Firstname Buyer1Lastname", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "Expand the Held information section and enter the details for holding.";
                FastDriver.EditDisbursement.Expand(FastDriver.EditDisbursement.HoldInformation);
                FastDriver.EditDisbursement.SaveHoldDays(Days: "12");

                Reports.TestStep = "Verify the status of the hold disbursement in active disbursement summary page.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Held", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Buyer1Firstname Buyer1Lastname", 1, TableAction.GetText).Message.Trim(), "Status of the of the fee should be issued.");
                #endregion

                #region Select the disbursement of held status and click on button split.
                Reports.TestStep = "Select the disbursement of held status and click on button split.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Buyer1Firstname Buyer1Lastname", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();
                FastDriver.SplitDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "Enter the details to split the amount.";
                FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(2, 1, TableAction.SetText, "100" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify that one more disbursement with split status is added.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Buyer1Firstname Buyer1Lastname", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Split", 8, TableAction.GetText).Message.Trim(), "Verifying that one more row is added with split status.");
                #endregion

                #region  Invoke the GetDisbursementHistorySummary webservice and verify the values in file side.
                Reports.TestStep = "Invoke the GetDisbursementHistorySummary webservice and get the response.";
                DisbursementHistoryResponse response = ActiveDisbursementsHelpers.GetDisbursementHistorySummary(fileID, AutoConfig.UserName);

                Reports.TestStep = "Invoke the GetDisbursementHistoryViewDetails webservice and get the response.";
                var viewDtlRspns =FASTWCFHelpers.FileService.GetDisbursementHistoryViewDetails(fileID,Convert.ToInt32(response.DisbursementActivities[3].DisbursementID));
                if(viewDtlRspns.DisbursementDetails!=null)
                {
                    Reports.StatusUpdate("GetDisbursementHistoryViewDetails web service invoked successfully", true);
                }
                else
                {
                    Reports.StatusUpdate("GetDisbursementHistoryViewDetails web service was not invoked successfully", false);
                }
                #endregion

                #region Verify the details in FAST application.
                Reports.TestStep = "Navigate to the Disbursement History page and select the activity for relavant disbursement.";
                FastDriver.DisbursementHistory.Open();
                FastDriver.DisbursementHistory.DisbursementTable.PerformTableAction("Status", viewDtlRspns.DisbursementRecap.Status, "Status", TableAction.Click);
                FastDriver.DisbursementHistory.ViewDetails.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "Validate the response values in the UI.";
                ServiceHelper.CompareWithUI(FastDriver.EditDisbursement.DisbursementAmnt, "text", string.Format("{0:0,000.00}", viewDtlRspns.DisbursementRecap.Amount));
                ServiceHelper.CompareWithUI(FastDriver.EditDisbursement.StatusLbl, "text", viewDtlRspns.DisbursementRecap.Status.ToUpper());
                ServiceHelper.CompareWithUI(FastDriver.EditDisbursement.IssueDate, "text", viewDtlRspns.DisbursementRecap.IssueDate.ToString("MM-dd-yyyy"));
                ServiceHelper.CompareWithUI(FastDriver.EditDisbursement.DocumentNo, "text", viewDtlRspns.DisbursementRecap.DocumentNo);
                ServiceHelper.CompareWithUI(FastDriver.EditDisbursement.Payee.FAGetText().Replace("Payee:", string.Empty).Trim(), viewDtlRspns.DisbursementRecap.Payee.Replace("\t",string.Empty));

                FastDriver.EditDisbursement.Expand(FastDriver.EditDisbursement.OpenDisbDetails);
                ServiceHelper.CompareWithUI(FastDriver.EditDisbursement.DisburseAs, "selecteditem", viewDtlRspns.DisbursementDetails.DisburseAs);
                ServiceHelper.CompareWithUI(FastDriver.EditDisbursement.PostedOnDate, "text", viewDtlRspns.DisbursementDetails.PostedOn.ToString("MM-dd-yyyy"));
                ServiceHelper.CompareWithUI(FastDriver.EditDisbursement.ManualCheckReason, "text", viewDtlRspns.DisbursementDetails.ManualCheckReason);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        #region REG_GetDisbursementHistorySummary
        [TestMethod]
        public void REG_GetDisbursementHistorySummary()
        {
            try
            {
                Reports.TestDescription = "To verify the GetDisbursementHistorySummary web service.";
                #region Data Setup
                DepositParameters depositDetail = new DepositParameters()
                {
                    Amount = 1876.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Saurabh Jain",
                    CreditToSeller = false,
                    Comments = "Comments Before Save",
                };
                #endregion

                #region Login to IIS side and create file using the Web Services.
                Reports.TestStep = "Login to IIS side and create file using the Web Services.";
                FAST_Login_IIS();
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile(RequestFactory.GetDetailedCreateFileDefaultRequest());
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                #endregion

                #region Navigate to the Deposit in escrow page and perform one deposit.
                Reports.TestStep = "Navigate to the deposit in escrow page and perform one deposit.";
                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(depositDetail);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(clickAcceptButton: false, timeout: 10);
                #endregion

                #region Navigate to file fee page, add charges and disburse the fee Manually.
                Reports.TestStep = "Navigate to the file fees page and add charges for the added fee.";
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee(FeeDescription: "New Home Rate (Title Only)");
                FastDriver.FileFees.EnterAmount(FeeDesc: "New Home Rate (Title Only)", TitleEscrowTable: true, Buyer_Amt: "10.00", Seller_Amt: "20.00");

                Reports.TestStep = "Navigate to the active disbursement summary page and verify for the added charges.";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Check", 1, TableAction.Click);

                Reports.TestStep = "Click on the Manual Button.";
                FastDriver.ActiveDisbursementSummary.Manual.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                Random value = new Random();
                int refNum = 1234 + value.Next(0, 10000);
                FastDriver.IssueManualCheck.CheckNo.FASetText(refNum.ToString());
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: false, timeout: 20);
                try
                {
                    FastDriver.PasswordConfirmationDlg.ConfirmPassword();
                }
                catch (Exception)
                {
                    FastDriver.OverdraftConfirmationDlg.OverDraftConfirmationEnterDetails();
                }

                FastDriver.ManualCheckReceiptReason.WaitForScreenToLoad();
                FastDriver.ManualCheckReceiptReason.txtManualCheckReceiptReason.FASetText("RElease the amount.");
                FastDriver.ManualCheckReceiptReason.OK.FAClick();
                FastDriver.IssueManualCheck.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to the active disbursement summary page and validate the issue check related with split fee.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Issued", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Check", 1, TableAction.GetText).Message.Trim(), "Status of the of the fee should be issued.");
                #endregion

                #region Select the disbursement summary related with escrow deposit and perform the Held disbursement.
                Reports.TestStep = "Select the deposit related to the escrow and perform to hold it.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Buyer1Firstname Buyer1Lastname", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Edit.FAClick();
                FastDriver.EditDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "Expand the Held information section and enter the details for holding.";
                FastDriver.EditDisbursement.Expand(FastDriver.EditDisbursement.HoldInformation);
                FastDriver.EditDisbursement.SaveHoldDays(Days: "12");

                Reports.TestStep = "Verify the status of the hold disbursement in active disbursement summary page.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Held", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Buyer1Firstname Buyer1Lastname", 1, TableAction.GetText).Message.Trim(), "Status of the of the fee should be issued.");
                #endregion

                #region Select the disbursement of held status and click on button split.
                Reports.TestStep = "Select the disbursement of held status and click on button split.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(8, "Buyer1Firstname Buyer1Lastname", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();
                FastDriver.SplitDisbursement.WaitForScreenToLoad();

                Reports.TestStep = "Enter the details to split the amount.";
                FastDriver.SplitDisbursement.SplitDisbTable.PerformTableAction(2, 1, TableAction.SetText, "100" + FAKeys.Tab);
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Verify that one more disbursement with split status is added.";
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("Buyer1Firstname Buyer1Lastname", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Split", 8, TableAction.GetText).Message.Trim(), "Verifying that one more row is added with split status.");
                #endregion

                #region  Invoke the GetDisbursementHistorySummary webservice and verify the values in file side.
                Reports.TestStep = "Invoke the GetDisbursementHistorySummary webservice and get the response.";
                DisbursementHistoryResponse response = ActiveDisbursementsHelpers.GetDisbursementHistorySummary(fileID, AutoConfig.UserName);
                var disbElements = response.DisbursementActivities;
                FastDriver.ActiveDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual(disbElements.Length.ToString(), FastDriver.ActiveDisbursementSummary.Disbursements.GetRowCount().ToString(), "Verifying the total number of disbursement element");
                foreach (var disbElement in disbElements)
                {
                    Reports.TestStep = "Verify the response values in UI for the disbursement of status: " + disbElement.Status;
                    Support.AreEqual(disbElement.SplitIndicator, FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, disbElement.Status, 2, TableAction.GetText).Message.Trim(), "Verifying the Split Indicator value for disbursement of status: " + disbElement.Status);
                    Support.AreEqual(disbElement.Funds, FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, disbElement.Status, 3, TableAction.GetText).Message.Trim(), "Verifying the Funds value for disbursement of status: " + disbElement.Status);
                    Support.AreEqual(disbElement.Document, FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, disbElement.Status, 5, TableAction.GetText).Message.Trim(), "Verifying the Document# value for disbursement of status: " + disbElement.Status);
                    Support.AreEqual(((DateTime)disbElement.DisbursementDate).ToDateString(), FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, disbElement.Status, 6, TableAction.GetText).Message.Trim(), "Verifying the Issue Date value for disbursement of status: " + disbElement.Status);
                    Support.AreEqual(string.Format("{0:0,0.00}", disbElement.DisbursementAmount), FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, disbElement.Status, 7, TableAction.GetText).Message.Trim(), "Verifying the Disbursement Amount value for disbursement of status: " + disbElement.Status);
                    Support.AreEqual(true,disbElement.Payee.Replace("\t",string.Empty).Contains(FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, disbElement.Status, 8, TableAction.GetText).Message.Trim()), "Verifying the PayeeName value for disbursement of status: " + disbElement.Status);
                }
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

    }
}
