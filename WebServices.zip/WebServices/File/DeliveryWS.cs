﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Threading;
using WebServices.Helpers.File;


namespace WebServices.File
{
    [CodedUITest]
    public class DeliveryWS : MasterTestClass
    {
        [TestMethod]
        public void REG0001_EmailDelivery()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify EmailDelivery() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke GetDocTemplates method.";
                var getDocTemplatesResponse = FileService.GetDocTemplates(FileRequestFactory.GetDocTemplateRequest());
                Support.IsTrue(getDocTemplatesResponse.Templates.Length > 0, "Template amount > 0");

                if (getDocTemplatesResponse.Templates.Length > 0)
                {
                    Reports.TestStep = "Invoke CreateDocument method.";
                    var createDocResponse = FileService.CreateDocument(FileRequestFactory.GetCreateDocumentDefaultRequest(fileId, getDocTemplatesResponse.Templates[0].TemplateID.Value));
                    Support.AreEqual("1", createDocResponse.Status.ToString(), createDocResponse.StatusDescription);

                    Reports.TestStep = "Invoke FinalizeDocument method.";
                    var finalizeDocResponse = FileService.FinalizeDocument(FileRequestFactory.GetFinalizeDocumentRequest(fileId, (int)createDocResponse.DocumentID));
                    Support.AreEqual("1", finalizeDocResponse.Status.ToString(), finalizeDocResponse.StatusDescription);

                    Reports.TestStep = "Invoke EmailDelivery method.";
                    var emailDeliveryRequest = FileRequestFactory.GetEmailDeliveryRequest(fileId, new DocumentList[1] { new DocumentList { DocumentID = (int)createDocResponse.DocumentID } },
                        "jdelacruz@firstam.com", FASTWCFHelpers.FastFileService.DocumentFormat.PDF, new TOList[1] { new TOList { TO = AutoConfig.DeliverEmailTo } });
                    var emailDeliveryResponse = FileService.EmailDelivery(emailDeliveryRequest);
                    Support.AreEqual("1", emailDeliveryResponse.Status.ToString(), emailDeliveryResponse.StatusDescription);

                    Reports.TestStep = "Open the Event / Tracking Log screen.";
                    FastDriver.EventTrackingLog.Open();

                    Reports.TestStep = "Verify the Email Delivery event.";
                    FastDriver.EventTrackingLog.SelectEventCategory("Doc Delivery");
                    string eventInfo = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[E-mail]", "Comments", TableAction.GetText).Message.Clean();
                    Support.IsTrue(eventInfo.Contains(file.FileNumber), "Event Info contains: " + file.FileNumber);
                    Support.IsTrue(eventInfo.Contains("FAMOS"), "Event Info contains: FAMOS");
                    Support.IsTrue(eventInfo.Contains(AutoConfig.DeliverEmailTo), "Event Info contains: " + AutoConfig.DeliverEmailTo);
                    Support.IsTrue(eventInfo.Contains("Delivery Successful"), "Event Info contains: Delivery Successful");
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0002_FaxDelivery()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify FaxDelivery() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke GetDocTemplates method.";
                var getDocTemplatesResponse = FileService.GetDocTemplates(FileRequestFactory.GetDocTemplateRequest());
                Support.IsTrue(getDocTemplatesResponse.Templates.Length > 0, "Template amount > 0");

                if (getDocTemplatesResponse.Templates.Length > 0)
                {
                    Reports.TestStep = "Invoke CreateDocument method.";
                    var createDocResponse = FileService.CreateDocument(FileRequestFactory.GetCreateDocumentDefaultRequest(fileId, getDocTemplatesResponse.Templates[0].TemplateID.Value));
                    Support.AreEqual("1", createDocResponse.Status.ToString(), createDocResponse.StatusDescription);

                    Reports.TestStep = "Invoke FinalizeDocument method.";
                    var finalizeDocResponse = FileService.FinalizeDocument(FileRequestFactory.GetFinalizeDocumentRequest(fileId, (int)createDocResponse.DocumentID));
                    Support.AreEqual("1", finalizeDocResponse.Status.ToString(), finalizeDocResponse.StatusDescription);

                    Reports.TestStep = "Invoke FaxDelivery method.";
                    var faxDeliveryRequest = FileRequestFactory.GetFaxDeliveryRequest(fileId, new DocumentList[1] { new DocumentList { DocumentID = (int)createDocResponse.DocumentID } },
                        "Jorge de la Cruz", new FaxRecipientList[1] { new FaxRecipientList { FAXNumber = AutoConfig.DeliverFaxTo, Name = "Jorge de la Cruz" } });
                    var emailDeliveryResponse = FileService.FaxDelivery(faxDeliveryRequest);
                    Support.AreEqual("1", emailDeliveryResponse.Status.ToString(), emailDeliveryResponse.StatusDescription);

                    Reports.TestStep = "Open the Event / Tracking Log screen.";
                    FastDriver.EventTrackingLog.Open();

                    Reports.TestStep = "Verify the Fax Delivery event.";
                    FastDriver.EventTrackingLog.SelectEventCategory("Doc Delivery");
                    string eventInfo = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[Fax]", "Comments", TableAction.GetText).Message.Clean();
                    Support.IsTrue(eventInfo.Contains(file.FileNumber), "Event Info contains: " + file.FileNumber);
                    Support.IsTrue(eventInfo.Contains("FAMOS"), "Event Info contains: FAMOS");
                    Support.IsTrue(eventInfo.Contains("Jorge de la Cruz"), "Event Info contains: Jorge de la Cruz");
                    Support.IsTrue(eventInfo.Contains(AutoConfig.DeliverFaxTo), "Event Info contains: " + AutoConfig.DeliverFaxTo);
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0003_Hud1StatementDelivery()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify Hud1StatementDelivery() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (AutoConfig.UseCDFormType)
                {
                    Reports.StatusUpdate("This test case is not applicable for CD.", true);
                }
                else
                {
                    Reports.TestStep = "Create File using web service.";
                    int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                    var file = FileService.GetOrderDetails(fileId);
                    FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                    Reports.TestStep = "Invoke Hud1StatementDelivery method.";
                    var hud1StatementDeliveryResponse = FileService.Hud1StatementDelivery(FileRequestFactory.GetHud1StatementDeliveryRequest(fileId, "jdelacruz@firstam.com", FASTWCFHelpers.FastFileService.DocumentFormat.PDF, new TOList[] { new TOList { TO = AutoConfig.DeliverEmailTo } }));
                    Support.AreEqual("1", hud1StatementDeliveryResponse.Status.ToString(), hud1StatementDeliveryResponse.StatusDescription);

                    Reports.TestStep = "Open the Event / Tracking Log screen.";
                    FastDriver.EventTrackingLog.Open();

                    Reports.TestStep = "Verify the Hud1StatementDelivery Delivery event.";
                    FastDriver.EventTrackingLog.SelectEventCategory("Doc Delivery");
                    string eventInfo = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[E-mail]", "Comments", TableAction.GetText).Message.Clean();
                    Support.IsTrue(eventInfo.Contains(file.FileNumber), "Event Info contains: " + file.FileNumber);
                    Support.IsTrue(eventInfo.Contains("FAMOS"), "Event Info contains: FAMOS");
                    Support.IsTrue(eventInfo.Contains("HUD1 Combined"), "Event Info contains: HUD1 Combined");
                    Support.IsTrue(eventInfo.Contains(AutoConfig.DeliverEmailTo), "Event Info contains: " + AutoConfig.DeliverEmailTo);
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0004_WintrackDelivery()
        {
            try
            {
                Reports.TestDescription = "Validate WintrackDelivery web method";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.Source = "WINTRACK";
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a WinTrack file using web service.";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Add a Form document to the file (WS)";
                var templateReq = FileRequestFactory.GetDocTemplatesDefaultRequest();
                templateReq.DocTemplateTypeCdID = 10; //Form
                var templateRes = FileService.GetDocTemplates(templateReq);
                int templateID = Convert.ToInt32(templateRes.Templates[0].TemplateID);
                string templateName = templateRes.Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileId, templateID).DocumentID;

                Reports.TestStep = "Invoke WintrackDelivery web method and validate response (WS)";
                DocumentList[] docs = new DocumentList[]
                {
                    new DocumentList
                    {
                        DocumentID = docID
                    }
                };
                var request = FileRequestFactory.GetWintrackDeliveryRequest(fileId, docs);
                var response = DeliveryHelpers.WintrackDelivery(request);
                Support.AreEqual("1", response.Status.ToString(), "Status");
                Support.AreEqual("WINTRACK Delivery Request Posted Successfully.", response.StatusDescription, "Status Description");

                Reports.TestStep = "Navigate to Event Tracking Log, validate [Interface Doc Delivery] event";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.SelectEventCategory("Doc Delivery");
                Support.AreEqual("File Number: " + fileNum + " User Name: User, Super Documents: " + templateName + " Delivery Method: WINTRACK Delivery Status: Delivery Successful", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Interface Doc Delivery]", 5, TableAction.GetText).Message.Clean(), "[Interface Doc Delivery]");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0005_LACOMDelivery()
        {
            try
            {
                Reports.TestDescription = "Validate LACOMDelivery web method";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.Source = "LA.COM";
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a LA.COM file using web service.";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Add a Form document to the file (WS)";
                var templateReq = FileRequestFactory.GetDocTemplatesDefaultRequest();
                templateReq.DocTemplateTypeCdID = 10; //Form
                var templateRes = FileService.GetDocTemplates(templateReq);
                int templateID = Convert.ToInt32(templateRes.Templates[0].TemplateID);
                string templateName = templateRes.Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileId, templateID).DocumentID;

                Reports.TestStep = "Invoke LACOMDelivery web method and validate response (WS)";
                DocumentList[] docs = new DocumentList[]
                {
                    new DocumentList
                    {
                        DocumentID = docID
                    }
                };
                var request = FileRequestFactory.GetLACOMDeliveryRequest(fileId, docs);
                var response = DeliveryHelpers.LACOMDelivery(request);
                Support.AreEqual("1", response.Status.ToString(), "Status");
                Support.AreEqual("LA.COM Delivery Request Posted Successfully.", response.StatusDescription, "Status Description");

                Reports.TestStep = "Navigate to Event Tracking Log, validate [Interface Doc Delivery] event";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.SelectEventCategory("Doc Delivery");
                Support.AreEqual("File Number: " + fileNum + " User Name: User, Super Documents: " + templateName + " Delivery Method: LA.COM Delivery Status: Delivery Successful", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Interface Doc Delivery]", 5, TableAction.GetText).Message.Clean(), "[Interface Doc Delivery]");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0006_InvoiceDelivery()
        {
            try
            {
                Reports.TestDescription = "Validate InvoiceDelivery web method";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service.";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Navigate to Fee Entry screen, enter first title fee";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(1, 4, TableAction.SetText, "10.00" + FAKeys.Tab);

                Reports.TestStep = "Navigate to Invoice Fees screen, select the fee for the invoice";
                FastDriver.InvoiceFees.Open();
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(2, 8, TableAction.On);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Obtain InvoiceID using GetInvoiceDetails web method (WS)";
                var getInvoiceDetailsResponse = InvoiceHelpers.GetInvoiceDetails(fileId);
                int invoiceID = (int)getInvoiceDetailsResponse.Invoices[0].InvoiceID;

                Reports.TestStep = "Finalize the invoice using UpdateInvoiceDetails web method, validate response (WS)";
                var updateInvoiceDetailsResponse = InvoiceHelpers.UpdateInvoiceDetails(fileId, invoiceID, Operation.Final);

                Reports.TestStep = "Invoke InvoiceDelivery web method, validate response (WS)";
                TOList[] toList = new TOList[]
                {
                    new TOList{ TO = AutoConfig.DeliverEmailTo }
                };
                var request = FileRequestFactory.GetInvoiceFeesDeliveryRequest(fileId, invoiceID, "nhatnguyen@firstam.com", FASTWCFHelpers.FastFileService.DocumentFormat.PDF, toList);
                var response = FileService.InvoiceDelivery(request);
                Support.AreEqual("1", response.Status.ToString(), "Status");
                Support.AreEqual("Invoice Fees Delivery Request Posted Successfully.", response.StatusDescription, "Status Description");

                Reports.TestStep = "Navigate to Event Tracking Log, validate [E-mail] event";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.SelectEventCategory("Doc Delivery");
                string expectedMsg = "File Number: " + fileNum + " User Name: User, Super Documents: Invoice Delivery Method: Email Recipients: " + AutoConfig.DeliverEmailTo + " Sent By: nhatnguyen@firstam.com Subject: Test email delivery for HUD1 Statement [WCF] Delivery Status: Delivery Successful";
                Support.AreEqual(expectedMsg, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[E-mail]", 5, TableAction.GetText).Message.Clean(), "[E-mail]");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0007_FastWebDelivery()
        {
            try
            {
                Reports.TestDescription = "Validate FastWebDelivery web method";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "Log into FAST application, navigate to QA Sandpointe Office";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("191");

                //Need to use QA Sanpointe Office because files in QA Automation office are archived
                Reports.TestStep = "Find and existing FastWeb file in QA Sandpointe Office";
                int fileId = FASqlHelpers.FindFastWebOrder(191);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Add a Form document to the file (WS)";
                var templateReq = FileRequestFactory.GetDocTemplatesDefaultRequest();
                templateReq.RegionID = 189;
                templateReq.DocTemplateTypeCdID = 10; //Form
                var templateRes = FileService.GetDocTemplates(templateReq);
                int templateID = Convert.ToInt32(templateRes.Templates[0].TemplateID);
                string templateName = templateRes.Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileId, templateID).DocumentID;

                Reports.TestStep = "Invoke FastWebDelivery web method and validate response (WS)";
                DocumentList[] docs = new DocumentList[]
                {
                    new DocumentList
                    {
                        DocumentID = docID
                    }
                };
                var request = FileRequestFactory.GetFastWebDeliveryRequest(fileId, docs);
                var response = DeliveryHelpers.FastWebDelivery(request);
                Support.AreEqual("1", response.Status.ToString(), "Status");
                Support.AreEqual("FASTWEB Delivery Request Posted Successfully.", response.StatusDescription, "Status Description");
                Thread.Sleep(10000); // wait for delivery to complete

                Reports.TestStep = "Navigate to Event Tracking Log, validate [Interface Doc Delivery] event";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.SelectEventCategory("Doc Delivery");
                Support.AreEqual("File Number: " + fileNum + " User Name: User, Super Documents: " + templateName + " Delivery Method: FastWeb Delivery Status: Delivery Successful", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Interface Doc Delivery]", 5, TableAction.GetText).Message.Clean(), "[Interface Doc Delivery]");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
