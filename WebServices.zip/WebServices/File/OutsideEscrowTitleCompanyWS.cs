﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebServices;
using WebServices.Helpers.File;

namespace WebServices.File
{
    [CodedUITest]
    public class OutsideEscrowTitleCompanyWS : MasterTestClass
    {

        [TestMethod]
        public void REG0001_CreateOutsideEscrowCompany()
        {
            try
            {
                Reports.TestDescription = "Verify CreateOutsideEscrowCompany service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Invoke CreateOutsideEscrowCompany web method, validate response (WS)";
                var request = RequestFactory.GetCreateOECDefaultRequest(fileId);
                request.OECInformation.OECFileBusinessParty.AddrBookEntryID = AdminService.GetGABAddressBookEntryId("BOA", Convert.ToInt32(AutoConfig.SelectedRegionBUID));
                var response = OutsideEscrowTitleCompanyHelpers.CreateOutsideEscrowCompany(request);
                Support.AreEqual("1", response.Status.ToString(), "Status");
                Support.AreEqual("Create Outside Escrow Company details Successful.", response.StatusDescription, "Status Description");

                Reports.TestStep = "Navigate to Outside Escrow Company screen, validate OEC is added";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                Support.AreEqual("BOA", FastDriver.OutsideEscrowCompanyDetail.GABcodeLabel.FAGetText(), "GAB Code");

                Reports.TestStep = "Validate Buyer and Seller charges";
                Support.AreEqual(request.OECInformation.OECCharges.CDPaymentDetails[0].BuyerCharge.ToString().FormatAsMoney(), FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(1, "OEC1", 3, TableAction.GetInputValue).Message.Clean(), "OEC1: Buyer Charge");
                Support.AreEqual(request.OECInformation.OECCharges.CDPaymentDetails[0].SellerCharge.ToString().FormatAsMoney(), FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(1, "OEC1", 4, TableAction.GetInputValue).Message.Clean(), "OEC1: Seller Charge");
                Support.AreEqual(request.OECInformation.OECCharges.CDPaymentDetails[1].BuyerCharge.ToString().FormatAsMoney(), FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(1, "OEC2", 3, TableAction.GetInputValue).Message.Clean(), "OEC2: Buyer Charge");
                Support.AreEqual(request.OECInformation.OECCharges.CDPaymentDetails[1].SellerCharge.ToString().FormatAsMoney(), FastDriver.OutsideEscrowCompanyDetail.OutsideEscrowCompanyCharges.PerformTableAction(1, "OEC2", 4, TableAction.GetInputValue).Message.Clean(), "OEC2: Seller Charge");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0002_CreateOutsideTitleCompany()
        {
            try
            {
                Reports.TestDescription = "Verify CreateOutsideTitleCompany service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Invoke CreateOutsideTitleCompany web method, validate response (WS)";
                var request = RequestFactory.GetOTCRequest(fileId);
                request.OutsideTitleCompanyParty.AddrBookEntryID = AdminService.GetGABAddressBookEntryId("BOA", Convert.ToInt32(AutoConfig.SelectedRegionBUID));
                request.OutsideTitleCompanyParty.BusOrgContact.ContactID = AdminService.GetGABByAddressBookEntryID((int)request.OutsideTitleCompanyParty.AddrBookEntryID).GABContactID;
                var response = OutsideEscrowTitleCompanyHelpers.CreateOutsideTitleCompany(request);
                Support.AreEqual("1", response.OperationResponse.Status.ToString(), "Status");
                Support.AreEqual("CreateOutsideTitleCompany is successfull", response.OperationResponse.StatusDescription, "Status Description");

                Reports.TestStep = "Navigate to Outside Title Company screen, validate OTC is added";
                FastDriver.OutsideTitleCompanyDetail.Open();
                Support.AreEqual("BOA", FastDriver.OutsideTitleCompanyDetail.IDCode.FAGetText(), "GAB Code");

                Reports.TestStep = "Validate Funds Deposited and Outside Title Company Type";
                Support.AreEqual(request.OTCDetails.ChargesRetained.ToString().FormatAsMoney(), FastDriver.OutsideTitleCompanyDetail.FundsDeposited.FAGetText().Replace("$","").Clean(), "Funds Deposited");
                Support.AreEqual(request.OTCDetails.eOTCType.ToString(), FastDriver.OutsideTitleCompanyDetail.TypeSelect.FAGetSelectedItem(), "Outside Title Company Type");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
               
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
