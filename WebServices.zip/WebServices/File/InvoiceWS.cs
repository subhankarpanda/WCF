﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using WebServices.Helpers.File;

namespace WebServices.File
{
    [CodedUITest]
    public class InvoiceWS : MasterTestClass
    {
        #region REG0001_GetInvoiceDetails
        [TestMethod]
        public void REG0001_GetInvoiceDetails()
        {
            try
            {
                Reports.TestDescription = "Validate GetInvoiceDetails web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Fee Entry screen, enter first title fee";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(1, 1, TableAction.On); 
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(1, 4, TableAction.SetText, "10.00" + Keys.Tab);

                Reports.TestStep = "Navigate to Invoice Fees screen, obtain Total Charge amount";
                FastDriver.InvoiceFees.Open();
                string totalCharge = FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean();

                Reports.TestStep = "Invoke GetInvoiceDetails method, validate Total amount";
                var response = InvoiceHelpers.GetInvoiceDetails(fileID);
                Support.AreEqual(totalCharge, response.Invoices[0].Total.ToString(), "Total Amount");
                
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region REG0002_UpdateInvoiceDetails
        [TestMethod]
        public void REG0002_UpdateInvoiceDetails()
        {
            try
            {
                Reports.TestDescription = "Validate UpdateInvoiceDetails web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Fee Entry screen, enter first title fee";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(1, 4, TableAction.SetText, "10.00" + Keys.Tab);

                Reports.TestStep = "Navigate to Invoice Fees screen, select the fee for the invoice";
                FastDriver.InvoiceFees.Open();
                FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(2, 8, TableAction.On);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Obtain InvoiceID using GetInvoiceDetails web method (WS)";
                var getInvoiceDetailsResponse = InvoiceHelpers.GetInvoiceDetails(fileID);
                int invoiceID = (int) getInvoiceDetailsResponse.Invoices[0].InvoiceID;

                Reports.TestStep = "Finalize the invoice using UpdateInvoiceDetails web method, validate response (WS)";
                var updateInvoiceDetailsResponse = InvoiceHelpers.UpdateInvoiceDetails(fileID, invoiceID, Operation.Final);
                Support.AreEqual("InvoiceFees Updated Successfully", updateInvoiceDetailsResponse.StatusDescription.Clean(), "Status Description");

                Reports.TestStep = "Navigate to Invoice Fees screen, validate invoice status is 'FINAL'";
                FastDriver.InvoiceFees.Open();
                Support.AreEqual("FINAL", FastDriver.InvoiceFees.InvoicetosummaryTable.PerformTableAction(1, 5, TableAction.GetText).Message, "Invoice Status");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        /// <summary>
        /// "Escrow Fee" is used here as it has sales tax applicable.
        /// ANd US 213023 (referred by parent US 363429) explicitly talks about Fees with sales tax
        /// </summary>
        [TestMethod]
        public void REG0003_ValidateTotalInGetInvoiceDetails_US213023()
        {
            try
            {
                Reports.TestDescription = "Validate that The Invoice Total value is a total of all selected fees with the value of Buyer Paid at Closing including Sales Tax plus Seller Paid at Closing including Sales Tax.";
                //
                Reports.TestStep = "Log into FAST application";
                Login();

                FASTHelpers.FAST_WCF_File_IIS(GAB: "HUDFLINSR1", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                int fileID = (int)FASTHelpers.File.FileID;

                Reports.TestStep = "Navigate to Fee Entry screen, enter Escrow fee";
                FastDriver.FileFees.Open();
                int Row=FastDriver.FileFees.TitleandescrowTable.PerformTableAction("Description","Escrow Fee","Description" ,TableAction.GetCell).CurrentRow;
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(Row, 1,TableAction.On); 
                   FastDriver.FileFees.TitleandescrowTable.PerformTableAction(Row, 3,TableAction.Click);
                   FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                   PaymentDetailsParameters PDParams = new PaymentDetailsParameters();
                   PDParams.SellerPaidAtClosing = 10.10;
                   PDParams.SellerPaidBeforeClosing = 5.11;
                   PDParams.SellerPaidbyOthers = 6;
                   PDParams.SellerPaidbyOtherPaymentMthd = "POC";
                   PDParams.BuyerAtClosing = 11.11;
                   PDParams.BuyerBeforeClosing = 6.11;
                   PDParams.BuyerPaidbyOther = 7;
                   PDParams.BuyerPaidbyOtherPaymentMethod = "POC";
                   FastDriver.PaymentDetailsDlg.EnterPaymentDetails(PDParams);
                   FastDriver.FileFees.WaitForScreenToLoad();              
                Reports.TestStep = "Navigate to Invoice Fees screen, obtain Total Charge amount";
                FastDriver.InvoiceFees.Open();
                string totalCharge = FastDriver.InvoiceFees.InvoiceFeeListTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean();

                Reports.TestStep = "Invoke GetInvoiceDetails method, validate Total amount";
                var response = InvoiceHelpers.GetInvoiceDetails(fileID);
                Support.AreEqual(totalCharge, response.Invoices[0].Total.ToString(), "Total Amount Bug#917053");
                //
                //
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        //
        [TestMethod]
        public void REG0004_ValidateDiscloseTitlePremiumFlagInGetAndUpdateInvoiceDetails()
        {
            try
            {
                Reports.TestDescription = "US515285 - Web Service - File Services-GetInvoiceDetails()- Include Ability to read Title Premium Adj Check Box and UpdateInvoiceDetails() to set the same on Invoice Screen";
                //
                #region PreRequisite
                #region LOGIN
                Reports.TestStep = "login to the ADM Side.";
                ADMLOGIN();

                #endregion

                #region Select office
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("1486");
                #endregion

                #region Office Setup
                FastDriver.LeftNavigation.Navigate<ProcessingRegionSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices>7878");
                FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
                FastDriver.OfficeSetupOffice.Show_Promulgated_Rate_on_Fee_Entry.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Fee Summary and Create a Lender and Owner Policy Fee

                string TP1Fee_Des = Support.RandomString("ANANA") + "TLP";
                string TP1Fee_Code = Support.RandomString("ANANA") + "TLP";

                Reports.TestStep = "Navigate to Fee Summary and Create a Title Policy Fee = " + TP1Fee_Des;
                FastDriver.LeftNavigation.Navigate<FeeList2>(@"Home>System Maintenance>Fee Setup>Fee Summary").WaitScreenToLoad();
                FastDriver.FeeList2.WaitScreenToLoad();

                Reports.TestStep = "Select the Fee Form Types Based on the Configuration";
                if (ClosingDisclosureSupport.IMDFormType == "CD")
                {
                    FastDriver.FeeList2.WaitScreenToLoad(FastDriver.FeeList2.FeeFormType);
                    FastDriver.FeeList2.FeeFormType.FASelectItem("CD"); FastDriver.FeeList2.WaitScreenToLoad(FastDriver.FeeList2.FeeFormType);
                }

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                {
                    FastDriver.FeeList2.FeeFormType.FASelectItem("HUD"); FastDriver.FeeList2.WaitScreenToLoad(FastDriver.FeeList2.FeeFormType);
                }

                Reports.TestStep = "Create A Title and Owner Policy Fee";
                FastDriver.FeeSetup.CreateFeeWithDefaultValues(TP1Fee_Des, TP1Fee_Code, "Title - Lenders Policy");

                Reports.TestStep = "Verify Fee is created succesfully in Fee Setup with Fee Code " + TP1Fee_Des + " and Fee Description " + TP1Fee_Des;
                FastDriver.FeeList2.CheckFeeCodeExistsOnFeeTable(TP1Fee_Code, "Title - Lenders Policy", TP1Fee_Des);
                FastDriver.FeeList2.FeeTable.PerformTableAction(3, TP1Fee_Code, 3, TableAction.Click);


                string OP2Fee_Des = Support.RandomString("ANANA") + "TOP";
                string OP2Fee_Code = Support.RandomString("ANANA") + "TOP";


                Reports.TestStep = "Navigate to Fee Summary and Create a Owner Policy Fee = " + OP2Fee_Des;
                FastDriver.LeftNavigation.Navigate<FeeList2>(@"Home>System Maintenance>Fee Setup>Fee Summary").WaitScreenToLoad();
                FastDriver.FeeList2.WaitScreenToLoad();


                Reports.TestStep = "Select the Fee Form Types Based on the Configuration";
                if (ClosingDisclosureSupport.IMDFormType == "CD")
                {
                    FastDriver.FeeList2.WaitScreenToLoad(FastDriver.FeeList2.FeeFormType);
                    FastDriver.FeeList2.FeeFormType.FASelectItem("CD"); FastDriver.FeeList2.WaitScreenToLoad(FastDriver.FeeList2.FeeFormType);
                }

                if (ClosingDisclosureSupport.IMDFormType == "HUD")
                {
                    FastDriver.FeeList2.FeeFormType.FASelectItem("HUD"); FastDriver.FeeList2.WaitScreenToLoad(FastDriver.FeeList2.FeeFormType);
                }

                Reports.TestStep = "Create A Title and Owner Policy Fee";
                FastDriver.FeeSetup.CreateFeeWithDefaultValues(OP2Fee_Des, OP2Fee_Code, "Title - Owners Policy");

                Reports.TestStep = "Verify Fee is created succesfully in Fee Setup with Fee Code " + OP2Fee_Des + " and Fee Description " + OP2Fee_Des;
                FastDriver.FeeList2.CheckFeeCodeExistsOnFeeTable(OP2Fee_Code, "Title - Owners Policy", OP2Fee_Des);
                FastDriver.FeeList2.FeeTable.PerformTableAction(3, OP2Fee_Code, 3, TableAction.Click);

                #endregion
                #endregion

                Reports.TestStep = "Log into FAST application";
                Login();

                FASTHelpers.FAST_WCF_File_IIS(GAB: "HUDFLINSR1", GABRole: AdditionalRoleType.None, isTO: true, isEO: false, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                int fileID = (int)FASTHelpers.File.FileID;

                Reports.TestStep = "In Fee entry screen Select All fee checkbox & Click on Calculate Fees button.";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad(FastDriver.FileFees.AllFees);

                Reports.TestStep = "Add Lender and Owner Policy Fee via Add Fee button";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.AddFees);
                FastDriver.FileFees.AddFees.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Lenders Policy");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText(TP1Fee_Des);
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.FileFees.NewSearch.FAClick();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Title - Owners Policy");
                FastDriver.FileFees.FeeSearchFeeDescription.FASetText(OP2Fee_Des);
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.SearchResultsTable.PerformTableAction(2, 1, TableAction.On);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter the Buyer and Seller Charge for the Lender Policy";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TP1Fee_Des, 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TP1Fee_Des, 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, TP1Fee_Des, 7, TableAction.SetText, "2.99");

                Reports.TestStep = "Enter the Buyer and Seller Charge for the Owner Policy";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.TitleandescrowTable);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, OP2Fee_Des, 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, OP2Fee_Des, 4, TableAction.SetText, "3.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, OP2Fee_Des, 7, TableAction.SetText, "4.99");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Enter the Full Loan Premium amount and save the screen.";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.LenderAdjustmentAmount);
                FastDriver.FileFees.LenderAdjustmentAmount.FASetText("50");
                FastDriver.FileFees.LenderLoanEstimateAmount.Click();
                Reports.TestStep = "The system should calculate the TPA and the screen should be saved.";
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.BSSplitButtonLender);
                FastDriver.FileFees.VerifyTPACalculation(TP1Fee_Des, OP2Fee_Des);

                Reports.TestStep = "Invoke GetInvoiceDetails method, validate Disclose TPA checkbox";
                var response = InvoiceHelpers.GetInvoiceDetails(fileID);
                Support.AreEqual("False", response.Invoices[0].DiscloseSimultaneousPolicyAdjAmountCD.ToString(), "Disclose TPA");
                Reports.TestStep = "Select Disclose TPA checkbox on Invoice screen";
                FastDriver.InvoiceFees.Open();
                FastDriver.InvoiceFees.DiscloseTitlePremiumAdjustmentAmountCheckBox.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                Thread.Sleep(5000);
                //
                Reports.TestStep = "Validate flag for Disclose Title Premium Adjustment again in response of GetInvoiceDetails service";
                response = InvoiceHelpers.GetInvoiceDetails(fileID);
                Support.AreEqual("False", response.Invoices[0].DiscloseSimultaneousPolicyAdjAmountCD.ToString(), "Disclose TPA");
                Reports.StatusUpdate(@"Bug 922084 - Response does not contain any field related to Disclose TPA amount checkbox", false);
                //
                Reports.TestStep = "Invoke UpdateInvoiceDetails method, validate operation to set Disclose TPA checkbox is available";
                //if bug 922084 is resolved add appropriate operation in following statement to set Disclose TPA Amt checkbox
                var UpdateInvoiceResponse = InvoiceHelpers.UpdateInvoiceDetails(fileID, (int)response.Invoices[0].InvoiceID, Operation.Estimate);
                Reports.StatusUpdate(@"Bug 922084 - Request does not contain any operation related to Disclose TPA amount checkbox", false);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        //
        #region Private class methods

        private void Login(string url = null)
        {
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            FASTLogin.Login(url ?? AutoConfig.FASTHomeURL, credentials, true);
        }

        private void ADMLOGIN(string UserName = null, string Password = null)
        {
            Reports.TestStep = "Log in to the Admin site";
            string WebSite = AutoConfig.FASTAdmURL;
            UserName = UserName ?? AutoConfig.UserName;
            Password = Password ?? AutoConfig.UserPassword;
            Credentials Credentials = new Credentials() { UserName = UserName, Password = Password };
            FASTLogin.Login(WebSite, Credentials, true);
        }

        
        #endregion
    }
}
