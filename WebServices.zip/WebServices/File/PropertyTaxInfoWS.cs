﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using FASTSelenium.PageObjects.IIS;

namespace WebServices.File
{
    [CodedUITest]
    public class PropertyTaxInfoWS : MasterTestClass
    {
        [TestMethod]
        public void REG0001_NewPropertyAddress()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.Properties = new Property[]
                    {
                        new Property()
                        {
                            Name = "First Property",
                            PropertyAddress = new PhysicalAddress[]
                            {
                                new PhysicalAddress()
                                {
                                    AddrLine1 = "1 Property 1 Test Street",
                                    State = "CA",
                                    City = "ALBANY",
                                    County = "ALAMEDA",
                                    Country = "USA"
                                }
                            }
                        }
                    };
                #endregion

                Reports.TestDescription = "Verify NewPropertyAddress() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke NewPropertyAddress method.";
                var newPropertyAddressRequest = FileRequestFactory.GetNewPropertyAddressRequest(fileId, 1, "2 Property 1 Test Street");
                FileService.NewPropertyAddress(newPropertyAddressRequest).Validate();

                Reports.TestStep = "Validate new address is added";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction("Property Name", fileRequest.File.Properties[0].Name, "Address", TableAction.DoubleClick);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Support.IsTrue(FastDriver.PropertyTaxInfoGeneral.PropertyAdressTable.FAGetText().Clean().Contains(newPropertyAddressRequest.AddrLine1), "New address street name is visible");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0002_UpdatePropertyTax()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.Properties = new Property[]
                    {
                        new Property()
                        {
                            Name = "First Property",
                            PropertyAddress = new PhysicalAddress[]
                            {
                                new PhysicalAddress()
                                {
                                    AddrLine1 = "1 Property 1 Test Street",
                                    State = "CA",
                                    City = "ALBANY",
                                    County = "ALAMEDA",
                                    Country = "USA"
                                }
                            }
                        }
                    };
                #endregion

                Reports.TestDescription = "Verify UpdatePropertyTax() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke UpdatePropertyTax method.";
                var updatePropertyRequest = FileRequestFactory.GetUpdatePropertyTaxDefaultRequest(fileId);
                updatePropertyRequest.Property.PlantEffectiveDate = DateTime.Today.ToPST();
                updatePropertyRequest.Property.ReRecordingInfo.MapDate = DateTime.Today.ToPST();
                updatePropertyRequest.Property.RecordingInfo.MapDate = DateTime.Today.ToPST();
                updatePropertyRequest.Property.Taxes[0].Annuals[0].AssessmentDate = DateTime.Today.ToPST();
                updatePropertyRequest.Property.Taxes[0].Annuals[0].DatePaid = DateTime.Today.ToPST();
                updatePropertyRequest.Property.Taxes[0].Annuals[0].DelinquentDate = DateTime.Today.ToPST();
                updatePropertyRequest.Property.Taxes[0].Annuals[0].DueDate = DateTime.Today.ToPST();
                updatePropertyRequest.Property.Taxes[0].Annuals[0].PaymentGoodThrough = DateTime.Today.ToPST();
                updatePropertyRequest.Property.Taxes[0].Special[0].DatePaid = DateTime.Today.ToPST();
                updatePropertyRequest.Property.Taxes[0].Special[0].DelinquentDate = DateTime.Today.ToPST();
                updatePropertyRequest.Property.Taxes[0].Special[0].DueDate = DateTime.Today.ToPST();
                updatePropertyRequest.Property.Taxes[0].Special[0].PaymentGoodThrough = DateTime.Today.ToPST();
                updatePropertyRequest.Property.Taxes[0].Supplemental[0].DatePaid = DateTime.Today.ToPST();
                updatePropertyRequest.Property.Taxes[0].Supplemental[0].DelinquentDate = DateTime.Today.ToPST();
                updatePropertyRequest.Property.Taxes[0].Supplemental[0].DueDate = DateTime.Today.ToPST();
                updatePropertyRequest.Property.Taxes[0].Supplemental[0].PaymentGoodThrough = DateTime.Today.ToPST();
                FileService.UpdatePropertyTax(updatePropertyRequest).Validate();

                Reports.TestStep = "Navigate to Properties/Tax Info";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction("Property Name", updatePropertyRequest.Property.Name, "Address", TableAction.DoubleClick);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

                Reports.TestStep = "Validate Properties/Tax Info General Tab";
                Support.AreEqual(updatePropertyRequest.Property.PropertyAddress[0].AddrLine1, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FAGetValue().Clean(), "GeneralAddressDetailStreetLine1");
                Support.AreEqual(updatePropertyRequest.Property.PropertyAddress[0].AddrLine2, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FAGetValue().Clean(), "GeneralAddressDetailStreetLine2");
                Support.AreEqual(updatePropertyRequest.Property.PropertyAddress[0].AddrLine3, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FAGetValue().Clean(), "GeneralAddressDetailStreetLine3");
                Support.AreEqual(updatePropertyRequest.Property.PropertyAddress[0].AddrLine4, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FAGetValue().Clean(), "GeneralAddressDetailStreetLine4");
                Support.AreEqual(updatePropertyRequest.Property.PropertyAddress[0].Country, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCountry.FAGetSelectedItem().Clean(), "GeneralAddressDetailCountry");
                Support.AreEqual(updatePropertyRequest.Property.PropertyAddress[0].State, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FAGetSelectedItem().Clean(), "GeneralAddressDetailState");
                Support.AreEqual(updatePropertyRequest.Property.PropertyAddress[0].City, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FAGetValue().Clean(), "GeneralAddressDetailCity");
                Support.AreEqual(updatePropertyRequest.Property.PropertyAddress[0].County, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FAGetValue().Clean(), "GeneralAddressDetailCounty");
                Support.AreEqual(updatePropertyRequest.Property.Name, FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationName.FAGetValue(), "Property Name");
                Support.AreEqual("Single Family Residence", FastDriver.PropertyTaxInfoGeneral.GeneralPropertyInformationPropertyType.FAGetSelectedItem(), "Property Type");
                Support.AreEqual("U1-1 Year Update", FastDriver.PropertyTaxInfoGeneral.GeneralSearchType.FAGetSelectedItem(), "Search Type");
                Support.AreEqual(updatePropertyRequest.Property.AdditionalInstructions, FastDriver.PropertyTaxInfoGeneral.GeneralAdditionalInstructions.FAGetValue(), "Search Instructions");
                Support.AreEqual(updatePropertyRequest.Property.Comments, FastDriver.PropertyTaxInfoGeneral.GeneralComments.FAGetValue(), "Comments");

                Reports.TestStep = "Validate Properties/Tax Info Legal Description Tab";
                FastDriver.PropertyTaxInfoGeneral.LegalDescriptionTab.FAClick();
                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();
                Support.AreEqual(updatePropertyRequest.Property.Lot, FastDriver.PropertyTaxInfoLegalDesciption.Lot.FAGetValue().Clean(), "Lot");
                Support.AreEqual(updatePropertyRequest.Property.Block, FastDriver.PropertyTaxInfoLegalDesciption.Block.FAGetValue().Clean(), "Block");
                Support.AreEqual(updatePropertyRequest.Property.Unit, FastDriver.PropertyTaxInfoLegalDesciption.Unit.FAGetValue().Clean(), "Unit");
                Support.AreEqual(updatePropertyRequest.Property.Tract, FastDriver.PropertyTaxInfoLegalDesciption.Tract.FAGetValue().Clean(), "Tract");
                Support.AreEqual(updatePropertyRequest.Property.Fee, FastDriver.PropertyTaxInfoLegalDesciption.Fee.FAGetValue().Clean(), "Fee");
                Support.AreEqual(updatePropertyRequest.Property.Building, FastDriver.PropertyTaxInfoLegalDesciption.Building.FAGetValue().Clean(), "Building");
                Support.AreEqual(updatePropertyRequest.Property.Book, FastDriver.PropertyTaxInfoLegalDesciption.Book.FAGetValue().Clean(), "Book");
                Support.AreEqual(updatePropertyRequest.Property.Page, FastDriver.PropertyTaxInfoLegalDesciption.Page.FAGetValue().Clean(), "Page");
                Support.AreEqual(updatePropertyRequest.Property.Section, FastDriver.PropertyTaxInfoLegalDesciption.Section.FAGetValue().Clean(), "Section");
                Support.AreEqual(updatePropertyRequest.Property.Township, FastDriver.PropertyTaxInfoLegalDesciption.TownShip.FAGetValue().Clean(), "TownShip");
                Support.AreEqual(updatePropertyRequest.Property.Range, FastDriver.PropertyTaxInfoLegalDesciption.Range.FAGetValue().Clean(), "Range");
                Support.AreEqual(updatePropertyRequest.Property.Parcel, FastDriver.PropertyTaxInfoLegalDesciption.Parcel.FAGetValue().Clean(), "Parcel");
                Support.AreEqual(updatePropertyRequest.Property.Condominium, FastDriver.PropertyTaxInfoLegalDesciption.SubdivisionCondo.FAGetValue().Clean(), "SubdivisionCondo");
                Support.AreEqual(updatePropertyRequest.Property.Phase, FastDriver.PropertyTaxInfoLegalDesciption.Phase.FAGetValue().Clean(), "Phase");
                Support.AreEqual(updatePropertyRequest.Property.GovernmentLotNum, FastDriver.PropertyTaxInfoLegalDesciption.GovtLotNo.FAGetValue().Clean(), "GovernmentLotNum");
                Support.AreEqual(updatePropertyRequest.Property.Borough, FastDriver.PropertyTaxInfoLegalDesciption.Borough.FAGetValue().Clean(), "Borough");
                Support.AreEqual(updatePropertyRequest.Property.Province, FastDriver.PropertyTaxInfoLegalDesciption.Province.FAGetValue().Clean(), "Province");
                Support.AreEqual(updatePropertyRequest.Property.Parish, FastDriver.PropertyTaxInfoLegalDesciption.CountyParish.FAGetValue().Clean(), "Parish");
                Support.AreEqual(updatePropertyRequest.Property.ERegFlag == 1, FastDriver.PropertyTaxInfoLegalDesciption.Ereg.IsSelected(), "Ereg");
                Support.AreEqual(updatePropertyRequest.Property.ConversionRequiredFlag == 1, FastDriver.PropertyTaxInfoLegalDesciption.ConversionRequired.IsSelected(), "ConversionRequired");
                Support.AreEqual(updatePropertyRequest.Property.UnincorporatedFlag == 1, FastDriver.PropertyTaxInfoLegalDesciption.Unincorporated.IsSelected(), "Unincorporated");
                //Support.AreEqual("Fee Simple", FastDriver.PropertyTaxInfoLegalDesciption.EstateType.FAGetSelectedItem().Clean(), "EstateType");
                Support.AreEqual(updatePropertyRequest.Property.RecordingInfo.BookOrLiber, FastDriver.PropertyTaxInfoLegalDesciption.RecordingBook.FAGetValue().Clean(), "RecordingBook");
                Support.AreEqual(updatePropertyRequest.Property.RecordingInfo.Page, FastDriver.PropertyTaxInfoLegalDesciption.RecordingPage.FAGetValue().Clean(), "RecordingPage");
                Support.AreEqual(updatePropertyRequest.Property.RecordingInfo.MapNum, FastDriver.PropertyTaxInfoLegalDesciption.RecordingMapNo.FAGetValue().Clean(), "RecordingMapNo");
                Support.AreEqual(updatePropertyRequest.Property.RecordingInfo.MapDate.Value.ToDateString(), FastDriver.PropertyTaxInfoLegalDesciption.RecordingMapDate.FAGetValue().Clean(), "RecordingMapDate");
                Support.AreEqual(updatePropertyRequest.Property.ReRecordingInfo.BookOrLiber, FastDriver.PropertyTaxInfoLegalDesciption.ReRecordingBook.FAGetValue().Clean(), "ReRecordingBook");
                Support.AreEqual(updatePropertyRequest.Property.ReRecordingInfo.Page, FastDriver.PropertyTaxInfoLegalDesciption.ReRecordingPage.FAGetValue().Clean(), "ReRecordingPage");
                Support.AreEqual(updatePropertyRequest.Property.ReRecordingInfo.MapNum, FastDriver.PropertyTaxInfoLegalDesciption.ReRecordingMapNo.FAGetValue().Clean(), "ReRecordingMapNo");
                Support.AreEqual(updatePropertyRequest.Property.ReRecordingInfo.MapDate.Value.ToDateString(), FastDriver.PropertyTaxInfoLegalDesciption.ReRecordingMapDate.FAGetValue().Clean(), "ReRecordingMapDate");

                Reports.TestStep = "Validate Properties/Tax Info Tax Tab";
                FastDriver.PropertyTaxInfoAnnualTax.TaxTab.FAClick();
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.Summarytable1);
                FastDriver.PropertyTaxInfoAnnualTax.Summarytable1.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.PropertyTaxInfoAnnualTax.WaitForScreenToLoad(FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN);
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].APN, FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDetailforTaxIDAPN.FAGetValue().Clean(), "AnnualTaxAPN");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].TRANo, FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTraNo.FAGetValue().Clean(), "AnnualTaxTraNo");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].TaxYear, FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxTaxYear.FAGetValue().Clean(), "AnnualTaxTaxYear");

                Reports.TestStep = "Validate Properties/Tax Info Tax Tab - Annual tab details";
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Annuals[0].VolumeNum, FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxVolumeNo1.FAGetValue().Clean(), "AnnualTaxVolumeNo1");
                Support.AreEqual("OPEN", FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxStatus1.FAGetSelectedItem().Clean(), "AnnualTaxStatus1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Annuals[0].DueDate.Value.ToDateString(slash: true), FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDueDate1.FAGetValue().Clean(), "AnnualTaxDueDate1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Annuals[0].InstallmentAmount.ToString().FormatAsMoney(), FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInstallmentAmount1.FAGetValue().Clean(), "AnnualTaxInstallmentAmount1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Annuals[0].Interest.ToString().FormatAsMoney(), FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxInterest1.FAGetValue().Clean(), "AnnualTaxInterest1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Annuals[0].Penalty.ToString(), FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPenality1.FAGetValue().Clean(), "AnnualTaxPenality1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Annuals[0].PartialPaymentAmount.ToString(), FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxpartialPaymentAmount1.FAGetValue().Clean(), "AnnualTaxpartialPaymentAmount1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Annuals[0].DatePaid.Value.ToDateString(slash: true), FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDatePaid1.FAGetValue().Clean(), "AnnualTaxDatePaid1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Annuals[0].DelinquentDate.Value.ToDateString(slash: true), FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxDelinquentDate1.FAGetValue().Clean(), "AnnualTaxDelinquentDate1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Annuals[0].PaymentGoodThrough.Value.ToDateString(slash: true), FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPaymentGoodThroughDate1.FAGetValue().Clean(), "AnnualTaxPaymentGoodThroughDate1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Annuals[0].CertificateofPurchaseNo, FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxCertificateOfPurchase1.FAGetValue().Clean(), "AnnualTaxCertificateOfPurchase1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Annuals[0].AssessmentDate.Value.ToDateString(slash: true), FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxAssesmentDate1.FAGetValue().Clean(), "AnnualTaxAssesmentDate1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Annuals[0].PersonalPropValue.ToString().FormatAsMoney(), FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxPersonalPropValue1.FAGetValue().Clean(), "AnnualTaxPersonalPropValue1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Annuals[0].LandValue.ToString().FormatAsMoney(), FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxLandValue1.FAGetValue().Clean(), "AnnualTaxLandValue1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Annuals[0].ImprovementValue.ToString().FormatAsMoney(), FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxImprovementValue1.FAGetValue().Clean(), "AnnualTaxImprovementValue1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Annuals[0].Homeowner.ToString().FormatAsMoney(), FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxHomeOwner1.FAGetValue().Clean(), "AnnualTaxHomeOwner1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Annuals[0].Other1.ToString().FormatAsMoney(), FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther11.FAGetValue().Clean(), "AnnualTaxOther11");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Annuals[0].Other2.ToString().FormatAsMoney(), FastDriver.PropertyTaxInfoAnnualTax.AnnualTaxOther21.FAGetValue().Clean(), "AnnualTaxOther21");

                Reports.TestStep = "Validate Properties/Tax Info Tax Tab - Supplemental tab";
                FastDriver.PropertyTaxInfoAnnualTax.SupplementalTaxTab.FAClick();
                FastDriver.PropertyTaxInfoSupplementalTax.WaitForScreenToLoad();
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].APN, FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxDetailforTaxIDAPN.FAGetValue().Clean(), "SupplementalTaxDetailforTaxIDAPN");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].TRANo, FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxTRANo.FAGetValue().Clean(), "SupplementalTaxTRANo");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].TaxYear, FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxTaxYear.FAGetValue().Clean(), "SupplementalTaxTaxYear");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].SuppleNo, FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxSuppleNo.FAGetValue().Clean(), "SupplementalTaxSuppleNo");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].MiscNo, FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxMiscNo.FAGetValue().Clean(), "SupplementalTaxMiscNo");

                Reports.TestStep = "Validate Properties/Tax Info Tax Tab - Supplemental tab details";
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Supplemental[0].VolumeNum, FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxVolume1.FAGetValue().Clean(), "SupplementalTaxVolume1");
                Support.AreEqual("ARREARS", FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxStatus1.FAGetSelectedItem().Clean(), "SupplementalTaxStatus1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Supplemental[0].DueDate.Value.ToDateString(slash: true), FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxDueDate1.FAGetValue().Clean(), "SupplementalTaxDueDate1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Supplemental[0].InstallmentAmount.ToString().FormatAsMoney(), FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxInstallmentAmount1.FAGetValue().Clean(), "SupplementalTaxInstallmentAmount1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Supplemental[0].Interest.ToString(), FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxInterest1.FAGetValue().Clean(), "SupplementalTaxInterest1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Supplemental[0].Penalty.ToString(), FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxPenality1.FAGetValue().Clean(), "SupplementalTaxPenality1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Supplemental[0].PartialPaymentAmount.ToString(), FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxpartialPaymentAmount1.FAGetValue().Clean(), "SupplementalTaxpartialPaymentAmount1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Supplemental[0].DatePaid.Value.ToDateString(slash: true), FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxDatePaid1.FAGetValue().Clean(), "SupplementalTaxDatePaid1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Supplemental[0].DelinquentDate.Value.ToDateString(slash: true), FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxDelinquentDate1.FAGetValue().Clean(), "SupplementalTaxDelinquentDate1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Supplemental[0].PaymentGoodThrough.Value.ToDateString(slash: true), FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxPaymentGoodThroughDate1.FAGetValue().Clean(), "SupplementalTaxPaymentGoodThroughDate1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Supplemental[0].CertificateofPurchaseNo, FastDriver.PropertyTaxInfoSupplementalTax.SupplementalTaxCertificateOfPurchase1.FAGetValue().Clean(), "SupplementalTaxCertificateOfPurchase1");

                Reports.TestStep = "Validate Properties/Tax Info Tax Tab - Special tab";
                FastDriver.PropertyTaxInfoSupplementalTax.SpecialTaxTab.FAClick();
                FastDriver.PropertyTaxInfoSpecialTax.WaitForScreenToLoad();
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].APN, FastDriver.PropertyTaxInfoSpecialTax.SpecialTaxDetailforTaxIDAPN.FAGetValue().Clean(), "SpecialTaxDetailforTaxIDAPN");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].TaxYear, FastDriver.PropertyTaxInfoSpecialTax.SpecialTaxTaxYear.FAGetValue().Clean(), "SpecialTaxTaxYear");

                Reports.TestStep = "Validate Properties/Tax Info Tax Tab - Special tab details";
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Special[0].VolumeNum, FastDriver.PropertyTaxInfoSpecialTax.SpecialTaxVol1.FAGetValue().Clean(), "SpecialTaxVolume1");
                Support.AreEqual("PAID", FastDriver.PropertyTaxInfoSpecialTax.SpecialTaxStatus1.FAGetSelectedItem().Clean(), "SpecialTaxStatus1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Special[0].DueDate.Value.ToDateString(slash: true), FastDriver.PropertyTaxInfoSpecialTax.SpecialTaxDueDate1.FAGetValue().Clean(), "SpecialTaxDueDate1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Special[0].InstallmentAmount.ToString().FormatAsMoney(), FastDriver.PropertyTaxInfoSpecialTax.SpecialTaxInstallmentAmt1.FAGetValue().Clean(), "SpecialTaxInstallmentAmount1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Special[0].Interest.ToString(), FastDriver.PropertyTaxInfoSpecialTax.SpecialTaxInterest1.FAGetValue().Clean(), "SpecialTaxInterest1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Special[0].Penalty.ToString(), FastDriver.PropertyTaxInfoSpecialTax.SpecialTaxPenality1.FAGetValue().Clean(), "SpecialTaxPenality1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Special[0].PartialPaymentAmount.ToString(), FastDriver.PropertyTaxInfoSpecialTax.SpecialTaxpartialPayment1.FAGetValue().Clean(), "SpecialTaxpartialPaymentAmount1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Special[0].DatePaid.Value.ToDateString(slash: true), FastDriver.PropertyTaxInfoSpecialTax.SpecialTaxDatePaid1.FAGetValue().Clean(), "SpecialTaxDatePaid1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Special[0].DelinquentDate.Value.ToDateString(slash: true), FastDriver.PropertyTaxInfoSpecialTax.SpecialTaxDelinquentDate1.FAGetValue().Clean(), "SpecialTaxDelinquentDate1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Special[0].PaymentGoodThrough.Value.ToDateString(slash: true), FastDriver.PropertyTaxInfoSpecialTax.SpecialTaxPaymentGoodThroughDate1.FAGetValue().Clean(), "SpecialTaxPaymentGoodThroughDate1");
                Support.AreEqual(updatePropertyRequest.Property.Taxes[0].Special[0].CertificateofPurchaseNo, FastDriver.PropertyTaxInfoSpecialTax.SpecialTaxCertificateOfPurchase1.FAGetValue().Clean(), "SpecialTaxCertificateOfPurchase1");

                Reports.TestStep = "Validate Properties/Tax Info Tax Tab - Special tab";
                FastDriver.PropertyTaxInfoSupplementalTax.TitleProductionTab.FAClick();
                FastDriver.PropertyTaxInfoTitleProd.WaitForScreenToLoad();
                Support.AreEqual(updatePropertyRequest.Property.PlantEffectiveDate.Value.ToDateString(), FastDriver.PropertyTaxInfoTitleProd.TitleProductionPlanEffactiveDate.FAGetValue().Clean(), "TitleProductionPlanEffactiveDate");
                Support.AreEqual(updatePropertyRequest.Property.TitleMortgageInsurance, FastDriver.PropertyTaxInfoTitleProd.TitleProductionTitleMortgageInsuranceClause.FAGetValue().Clean(), "TitleProductionTitleMortgageInsuranceClause");
                Support.AreEqual(updatePropertyRequest.Property.TitleVesting, FastDriver.PropertyTaxInfoTitleProd.TitleProductionVesting.FAGetValue().Clean(), "TitleProductionVesting");
                Support.AreEqual(updatePropertyRequest.Property.EstateInterest, FastDriver.PropertyTaxInfoTitleProd.TitleProductionEstateInterest.FAGetValue().Clean(), "TitleProductionEstateInterest");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0003_CopyPropertyAddress()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.Properties = new Property[]
                    {
                        new Property()
                        {
                            Name = "First Property",
                            PropertyAddress = new PhysicalAddress[]
                            {
                                new PhysicalAddress()
                                {
                                    AddrLine1 = "1 Property 1 Test Street",
                                    AddrLine2 = "Address Line 2",
                                    AddrLine3 = "Address Line 3",
                                    AddrLine4 = "Address Line 4",
                                    State = "CA",
                                    City = "ALBANY",
                                    County = "ALAMEDA",
                                    Country = "USA"
                                }
                            }
                        }
                    };
                #endregion

                Reports.TestDescription = "Verify CopyPropertyAddress() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke CopyPropertyAddress method.";
                FileService.CopyPropertyAddress(FileRequestFactory.GetCopyPropertyAddressRequest(fileId, fromSeqNum: 1, propertyTaxSeqNum: 1)).Validate();

                Reports.TestStep = "Navigate to Property/Tax Info.";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction("Property Name", fileRequest.File.Properties[0].Name, "Address", TableAction.DoubleClick);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.PropertyAdressTable.PerformTableAction(3, 1, TableAction.Click);
                Playback.Wait(1000);
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FAGetValue().Clean(), "GeneralAddressDetailStreetLine1");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].AddrLine2, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FAGetValue().Clean(), "GeneralAddressDetailStreetLine2");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].AddrLine3, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FAGetValue().Clean(), "GeneralAddressDetailStreetLine3");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].AddrLine4, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FAGetValue().Clean(), "GeneralAddressDetailStreetLine4");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].Country, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCountry.FAGetSelectedItem().Clean(), "GeneralAddressDetailCountry");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].State, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FAGetSelectedItem().Clean(), "GeneralAddressDetailState");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].City, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCity.FAGetValue().Clean(), "GeneralAddressDetailCity");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].County, FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailCounty.FAGetValue().Clean(), "GeneralAddressDetailCounty");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0004_RemovePropertyAddress()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.Properties = new Property[]
                    {
                        new Property()
                        {
                            Name = "First Property",
                            PropertyAddress = new PhysicalAddress[]
                            {
                                new PhysicalAddress()
                                {
                                    AddrLine1 = "1 Property 1 Test Street",
                                    State = "CA",
                                    City = "ALBANY",
                                    County = "ALAMEDA",
                                    Country = "USA"
                                }
                            }
                        }
                    };
                #endregion

                Reports.TestDescription = "Verify RemovePropertyAddress() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke NewPropertyAddress method.";
                FileService.NewPropertyAddress(FileRequestFactory.GetNewPropertyAddressRequest(fileId, 1, "2 Property 1 Test Street")).Validate();

                Reports.TestStep = "Validate new address is added";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction("Property Name", fileRequest.File.Properties[0].Name, "Address", TableAction.DoubleClick);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Support.IsTrue(FastDriver.PropertyTaxInfoGeneral.PropertyAdressTable.FAGetText().Clean().Contains("2 Property 1 Test Street"), "New address street name is visible");

                Reports.TestStep = "Invoke the RemoveProperty method.";
                FileService.RemovePropertyAddress(FileRequestFactory.GetRemovePropertyAddressRequest(fileId, propertyAddrSeqNum: 2, propertyTaxSeqNum: 1)).Validate();

                Reports.TestStep = "Validate Address got removed";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction("Property Name", fileRequest.File.Properties[0].Name, "Address", TableAction.DoubleClick);
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.PropertyTaxInfoGeneral.PropertyAdressTable.FAGetText().Clean().Contains("2 Property 1 Test Street"), "New address street name is not visible");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0005_RemoveProperty()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "COMMERCIAL";
                fileRequest.File.Properties = new Property[2]
                {
                    new Property
                    {
                        SeqNum = 1,
                        Name = "First Property",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[]
                        {
                            new PhysicalAddress
                            {
                                AddrLine1 = "1 Test Street",
                                State = "CA",
                                City = "ALBANY",
                                County = "ALAMEDA",
                                Country = "USA"
                            }
                        }
                    },
                    new Property
                    {
                        SeqNum = 2,
                        Name = "Second Property",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[]
                        {
                            new PhysicalAddress
                            {
                                AddrLine1 = "2 Test Street",
                                State = "CA",
                                City = "ALBANY",
                                County = "ALAMEDA",
                                Country = "USA"
                            }
                        }
                    },
                };
                #endregion

                Reports.TestDescription = "Verify RemoveProperty() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Navigate to Properties/Tax Info and validate address";
                FastDriver.PropertiesSummary.Open();
                Support.AreEqual(true, FastDriver.PropertiesSummary.SummaryRow2.IsDisplayed(), "SummaryRow2 IsDisplayed");

                Reports.TestStep = "Invoke the RemoveProperty method.";
                FileService.RemoveProperty(FileRequestFactory.GetRemovePropertyRequest(fileId, seqNum: 2)).Validate();

                Reports.TestStep = "Navigate to Properties/Tax Info and validate address got removed";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction("Property Name", "Available", "Property Name", TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0005_CreateFile()
        {
            try
            {
                Reports.TestDescription = "To test US 847833 - Verify CreateFile() creates file with Property Type = Manufactured Home";
                #region Data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create Basic files via web method CreateFile() for myFASTNCS (Project Tracker), LVIS, EOS";
                Validate_MH_PropertyType("myFASTNCS");
                Validate_MH_PropertyType("LVIS");
                Validate_MH_PropertyType("EOS");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

      
        [TestMethod]
        public void REG0006_UpdatePropertyTax()
        {
            try
            {
                Reports.TestDescription = "To test US 847833 - Verify UpdatePropertyTax() updates file with Property Type = Manufactured Home";

                #region Data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                Reports.TestStep = "login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Using web method UpdatePropertyTax(), update Address Property Type to Manufactured Home, Using source as FAMOS, EOS, EWB";
                UpdatePropertyTaxValidation("FAMOS");
                UpdatePropertyTaxValidation("EOS");
                UpdatePropertyTaxValidation("EWB");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

 
        #region HelpMethods

        private void Validate_MH_PropertyType(string source = null)
        {
            #region Data setup
            string PropertyType = "Manufactured Home";
            string PropertyObjectCD = "MH";
            int PropertyTypeCdID = 3274;
            #endregion

            var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
            fileRequest.File.Properties[0].PropertyTypeObjectCD = PropertyObjectCD;
            fileRequest.File.Properties[0].ProperyTypeCdID = PropertyTypeCdID;
            fileRequest.Source = source;
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            Reports.TestStep = "Navigate to File Summary";
            FastDriver.LeftNavigation.Navigate<FileSummary>("Home>Order Entry>File Summary").WaitForScreenToLoad();

            if (source == "myFASTNCS")
                source = "myFAST NCS";

            Reports.TestStep = "Verified the order source for each file created";
            Support.AreEqual(source, FastDriver.FileSummary.OrderSource.FAGetText().Clean());

            Reports.TestStep = "Verified the Property Type for each file";
            Support.AreEqual(PropertyType, FastDriver.FileSummary.PropertyType.FAGetText().Clean());

        }

        private void UpdatePropertyTaxValidation(string source = null)
        {
            #region Data setup
            string PropertyType = "Manufactured Home";
            string PropertyObjectCD = "MH";
            int PropertyTypeCdID = 3274;
            #endregion

            Reports.TestStep = "Create Basic File";
            var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
            var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            Reports.TestStep = "Using web method UpdatePropertyTax(), update Address Property Type to Manufactured Home";
            PropertyUpdateRequest PtRequest = new PropertyUpdateRequest();
            PtRequest.FileID = File.FileID;
            PtRequest.Source = source;
            PtRequest.UpdatedEmployeeID = 1;
            PtRequest.Property = new Property()
            {
                ProperyTypeCdID = PropertyTypeCdID,
                PropertyTypeObjectCD = PropertyObjectCD,
                SeqNum = 1
            };
            var response = FileService.UpdatePropertyTax(PtRequest);
            Support.AreEqual("Property Details Updated Successfully", response.StatusDescription.Clean());

            Reports.TestStep = "Navigate to File Summary";
            FastDriver.LeftNavigation.Navigate<FileSummary>("Home>Order Entry>File Summary").WaitForScreenToLoad();

            Reports.TestStep = "Verified the Property Type for each file";
            Support.AreEqual(PropertyType, FastDriver.FileSummary.PropertyType.FAGetText().Clean());
        }

        #endregion
        

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}