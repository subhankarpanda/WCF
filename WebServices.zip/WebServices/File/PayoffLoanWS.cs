﻿using FASTSelenium.Common;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using FASTSelenium.DataObjects;
using FASTWCFHelpers;

namespace WebServices.File
{
    [CodedUITest]
    public class PayOffLoanWS : FASTHelpers
    {
        [TestMethod]
        public void REG0001_InitiatePayoffRequest()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify InitiatePayoffRequest() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create file using Web Service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId);

                Reports.TestStep = "Open file in FAST UI";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke CreatePayOffLoan service";
                var CreatePayoffLoanReq = FileRequestFactory.GetDefaultPayoffLoanRequestWithCharge(fileId.ToString());
                CreatePayoffLoanReq.LoanTypeCdID = 669;
                CreatePayoffLoanReq.PayOffLenderAddrBookEntryID = AdminService.GetGABAddressBookEntryId("1254", Convert.ToInt32(AutoConfig.SelectedRegionBUID));
                CreatePayoffLoanReq.PayOffLenderReference = "101";
                var CreatePayoffLoanRes = FileService.CreatePayoffLoan(CreatePayoffLoanReq);
                CreatePayoffLoanRes.Validate();

                Reports.TestStep = "Invoke InitiatePayoffRequest service";
                var request = FileRequestFactory.GetInitiatePayoffRequest(fileId, seqNum: 1);
                var response = FileService.InitiatePayoffRequest(request);
                response.Validate();

                Reports.TestStep = "Navigate to Event/Tracking Log";
                FastDriver.EventTrackingLog.Open();

                Reports.TestStep = "Verify the request has been initiated";
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Payoff Demand Request Initiated]", 1, TableAction.GetText).Message.Contains("Payoff Demand Request Initiated"), "Payoff Demand Request has been initiated");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verify CreatePayOffLoan() service functionality")]
        public void REG_CreatePayOffLoan()
        {
            try{
            Reports.TestStep = "Verify CreatePayOffLoan() service";

            #region FAST Login IIS side
            Reports.TestStep = "Login to IIS";
            FAST_Login_IIS();
            #endregion

            #region WCF Create File and open in FAST
            Reports.TestStep = "Create a basic file";
            FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
            #endregion

            Reports.TestStep = "Invoke CreatePayOffLoan service";
            var CreatePayoffLoanReq = FileRequestFactory.GetDefaultPayoffLoanRequestWithCharge(File.FileID.ToString());

            var CreatePayoffLoanRes = FASTWCFHelpers.FileService.CreatePayoffLoan(CreatePayoffLoanReq);

            Support.AreEqual("1", CreatePayoffLoanRes.Status.ToString(), CreatePayoffLoanRes.StatusDescription);

            #region Variables

            var cdPyoffLnLoancharges = CreatePayoffLoanReq.CDLoanCharges;
            var cdPyoffLnpayoffloancharges = CreatePayoffLoanReq.CDPayoffLoanCharges;
            var cdPyoffLnInterestCalSum = CreatePayoffLoanReq.CDInterestCalculationSummary[0].CDChargePaymentDetails;

            #endregion

            #region Navigate to PayOffLoan and verify PayOffLoan request
            Reports.TestStep = "Navigate to PayOff Loan and verify the Loan Details";

            FastDriver.PayoffLoanDetails.Open();
            #region Validate Payoff Loan Details page
            String loantype = "";

            ServiceHelper.CompareWithUI(FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FAGetValue().ToString(), CreatePayoffLoanReq.PayOffLenderOrigPrincipalBal.ToString(), true, true);

            if (CreatePayoffLoanReq.LoanTypeCdID.ToString().Equals("667"))
            {
                loantype = "Institutional";
            }
            if (CreatePayoffLoanReq.LoanTypeCdID.ToString().Equals("668"))
            {
                loantype = "Private Party";
            }
            else
                if (CreatePayoffLoanReq.LoanTypeCdID.ToString().Equals("669"))
                {
                    loantype = "Collection Payoff lender";
                }

            ServiceHelper.CompareWithUI(FastDriver.PayoffLoanDetails.LenderLoanType.FAGetSelectedItem().ToString(), loantype, true);
            #endregion

            #region Validate Loan Charges

            FastDriver.PayoffLoanDetails.ClickChargesTab();
            FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

            if (cdPyoffLnLoancharges.Description != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesDescription.FAGetValue(), cdPyoffLnLoancharges.Description, true, true);
            if (cdPyoffLnLoancharges.BuyerCharge != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FAGetValue().ToString(), cdPyoffLnLoancharges.BuyerCharge.ToString(), true, true);
            if (cdPyoffLnLoancharges.SellerCharge != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FAGetValue().ToString(), cdPyoffLnLoancharges.SellerCharge.ToString(), true, true);
            //if (cdPyoffLnLoancharges.BuyerCredit != null)
            //    Helper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.FAGetValue().ToString(), cdPyoffLnLoancharges.BuyerCredit.ToString(), true, true);
            //if (cdPyoffLnLoancharges.SellerCredit != null)
            //    Helper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesSellerCredit.FAGetValue().ToString(), cdPyoffLnLoancharges.SellerCredit.ToString(), true, true);
            if (cdPyoffLnLoancharges.LEAmount != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesEstimatedUnRounded.FAGetValue().ToString(), cdPyoffLnLoancharges.LEAmount.ToString(), true, true);

            if (FastDriver.PayoffLoanCharges.LoanChargesDescription.FAGetValue().ToString().Equals(cdPyoffLnLoancharges.Description.ToString()))
            {
                FastDriver.PayoffLoanCharges.PaymentDetails.FAClick();
                FastDriver.PayoffLoanCharges.LoanChargesDescription.FAClick();

                Playback.Wait(4000);    

            }
            ServiceHelper.ValidatePaymentAndGetCheckAMount(cdPyoffLnLoancharges);

            #endregion


            #region Validate Interest Calculation Summary
            String FromDateInclusive = "";
            String ToDateInclusive = "";

            FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
            
            FastDriver.PayoffLoanCharges.SwitchToContentFrame();

            Reports.TestStep = "Verify Interest Calculation Summary";
            string fromdate = FastDriver.PayoffLoanCharges.InterestCalculationProrFromDate.FAGetValue().ToString();
            fromdate = fromdate.Replace("-", "/").ToString();
            if (fromdate.StartsWith("0"))
            {
                fromdate = fromdate.Substring(1);
            }
            
            string todate = FastDriver.PayoffLoanCharges.InterestCalculationProrToDate.FAGetValue().ToString();
            todate = todate.Replace("-", "/").ToString();
            if (todate.StartsWith("0"))
            {
                todate = todate.Substring(1);
            }
            
            ServiceHelper.ContainsUIVal(FastDriver.PayoffLoanCharges.InterestCalculationProrPerDiem.FAGetValue().ToString(), CreatePayoffLoanReq.CDInterestCalculationSummary[0].PerDiemAmount.ToString());
            Assert.AreEqual("True",CreatePayoffLoanReq.CDInterestCalculationSummary[0].FromDate.ToString().Contains(fromdate).ToString());
            Assert.AreEqual("True", CreatePayoffLoanReq.CDInterestCalculationSummary[0].ToDate.ToString().Contains(todate).ToString());
            if (CreatePayoffLoanReq.CDInterestCalculationSummary[0].FromDateInclusive.ToString().Equals("1"))
            {
                FromDateInclusive = "on";
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.InterestCalculationInclusiveFrom.FAGetValue().ToString(), FromDateInclusive);
            }
            if (CreatePayoffLoanReq.CDInterestCalculationSummary[0].ToDateInclusive.ToString().Equals("1"))
            {
                ToDateInclusive = "on";
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.InterestCalculationInclusiveTo.FAGetValue().ToString(), ToDateInclusive);
            }
            //Helper.CompareWithUI(FastDriver.PayoffLoanCharges.InterestCalculationInclusiveFrom.FAGetValue().ToString(), CreatePayoffLoanReq.CDInterestCalculationSummary[0].FromDateInclusive.ToString());
            //Helper.CompareWithUI(FastDriver.PayoffLoanCharges.InterestCalculationInclusiveTo.FAGetValue().ToString(), CreatePayoffLoanReq.CDInterestCalculationSummary[0].ToDateInclusive.ToString());
            ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.InterestCalculationBasedonDays.FAGetSelectedItem().ToString(), CreatePayoffLoanReq.CDInterestCalculationSummary[0].CalendarBaseDays.ToString());

            #endregion

            #region Validate Payoff Loan Charges



            FastDriver.PayoffLoanCharges.ChargesTab.Click();

            if (cdPyoffLnpayoffloancharges[0].Description != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[0].Description.ToString(), true, true);
            if (cdPyoffLnpayoffloancharges[0].BuyerCharge != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCharge.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[0].BuyerCharge.ToString(), true, true);
            if (cdPyoffLnpayoffloancharges[0].BuyerCredit != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCredit.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[0].BuyerCredit.ToString(), true, true);
            if (cdPyoffLnpayoffloancharges[0].SellerCharge != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCharge.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[0].SellerCharge.ToString(), true, true);
            if (cdPyoffLnpayoffloancharges[0].SellerCredit != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCredit.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[0].SellerCredit.ToString(), true, true);
            if (cdPyoffLnpayoffloancharges[0].LEAmount != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeLoanEstimate.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[0].LEAmount.ToString(), true, true);


            if (cdPyoffLnpayoffloancharges[1].Description != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription8.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[1].Description.ToString(), true, true);
            if (cdPyoffLnpayoffloancharges[1].BuyerCharge != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCharge8.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[1].BuyerCharge.ToString(), true, true);
            if (cdPyoffLnpayoffloancharges[1].BuyerCredit != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCredit8.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[1].BuyerCredit.ToString(), true, true);
            if (cdPyoffLnpayoffloancharges[1].SellerCharge != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCharge8.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[1].SellerCharge.ToString(), true, true);
            if (cdPyoffLnpayoffloancharges[1].SellerCredit != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCredit8.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[1].SellerCredit.ToString(), true, true);
            if (cdPyoffLnpayoffloancharges[1].LEAmount != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeLoanEstimate8.FAGetValue().ToString(), CreatePayoffLoanReq.CDPayoffLoanCharges[1].LEAmount.ToString(), true, true);


            if (FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription.FAGetValue().ToString().Equals(cdPyoffLnpayoffloancharges[0].Description.ToString()))
            {
                FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription.FAClick();
                FastDriver.PayoffLoanCharges.PaymentDetails.FAClick();
            }

            ServiceHelper.ValidatePaymentAndGetCheckAMount(cdPyoffLnpayoffloancharges[0]);

            FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
            FastDriver.PayoffLoanCharges.SwitchToContentFrame();

            if (FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription8.FAGetValue().ToString().Equals(cdPyoffLnpayoffloancharges[1].Description.ToString()))
            {
                FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription8.FAClick();
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
            }

            ServiceHelper.ValidatePaymentAndGetCheckAMount(cdPyoffLnpayoffloancharges[1]);

            #endregion
            #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
           

        [TestMethod]
        [Description("Verify UpdatePayOffLoan() service functionality")]
        public void REG_UpdateOffLoan()
        {
            TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("Pacific SA Standard Time");

            DateTime newDateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);

            try { 
            Reports.TestStep = "Verify UpdatePayOffLoan() service";

            #region FAST Login IIS side
            Reports.TestStep = "Login to IIS";
            FAST_Login_IIS();
            #endregion

            #region WCF Create File and open in FAST
            Reports.TestStep = "Create a basic file";
            FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
            #endregion

            #region Creating PayoffLoan Instance

            Reports.TestStep = "Invoke CreatePayOffLoan service";
            var CreatePayoffLoanReq = FileRequestFactory.GetDefaultPayoffLoanRequestWithCharge(File.FileID.ToString());

            var CreatePayoffLoanRes = FASTWCFHelpers.FileService.CreatePayoffLoan(CreatePayoffLoanReq);

            Support.AreEqual("1", CreatePayoffLoanRes.Status.ToString(), CreatePayoffLoanRes.StatusDescription);
            #endregion

            Reports.TestStep = "Invoke UpdatePayOffLoan service";
            //var getresponse = EscrowService.GetPayOffLoanDetails(File.FileID.ToString());
           
            var UpdatePayoffLoanReq = FileRequestFactory.GetUpdatePayoffLoanRequestWithCharge(File.FileID.ToString());

            var UpdatePayoffLoanRes = FASTWCFHelpers.FileService.UpdatePayOffLoan(UpdatePayoffLoanReq);

            Support.AreEqual("1", UpdatePayoffLoanRes.Status.ToString(), UpdatePayoffLoanRes.StatusDescription);
            #region Variables

            var cdPyoffLnLoancharges = UpdatePayoffLoanReq.CDLoanCharges;
            var cdPyoffLnpayoffloancharges = UpdatePayoffLoanReq.CDPayoffLoanCharges;
            var cdPyoffLnInterestCalSum = UpdatePayoffLoanReq.CDInterestCalculationSummary[0].CDChargePaymentDetails;
                    
            #endregion

            #region Navigate to PayOffLoan and verify PayOffLoan request
            Reports.TestStep = "Navigate to PayOff Loan and verify the Loan Details";

            FastDriver.PayoffLoanDetails.Open();
            #region Validate Payoff Loan Details
            String loantype = "";

            ServiceHelper.CompareWithUI(FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FAGetValue().ToString(), UpdatePayoffLoanReq.PayOffLenderOrigPrincipalBal.ToString(), true, true);

            if (CreatePayoffLoanReq.LoanTypeCdID.ToString().Equals("667"))
            {
                loantype = "Institutional";
            }
            if (CreatePayoffLoanReq.LoanTypeCdID.ToString().Equals("668"))
            {
                loantype = "Private Party";
            }
            else
                if (CreatePayoffLoanReq.LoanTypeCdID.ToString().Equals("669"))
                {
                    loantype = "Collection Payoff lender";
                }

            ServiceHelper.CompareWithUI(FastDriver.PayoffLoanDetails.LenderLoanType.FAGetSelectedItem().ToString(), loantype, true);
            #endregion
            #endregion

            #region Validate Loan Charges

            FastDriver.PayoffLoanDetails.ClickChargesTab();
            FastDriver.PayoffLoanCharges.WaitForScreenToLoad();

            if (cdPyoffLnLoancharges.Description != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesDescription.FAGetValue(), cdPyoffLnLoancharges.Description, true, true);
            if (cdPyoffLnLoancharges.BuyerCharge != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesBuyerCharge.FAGetValue().ToString(), cdPyoffLnLoancharges.BuyerCharge.ToString(), true, true);
            if (cdPyoffLnLoancharges.SellerCharge != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesSellerCharge.FAGetValue().ToString(), cdPyoffLnLoancharges.SellerCharge.ToString(), true, true);
            //if (cdPyoffLnLoancharges.BuyerCredit != null)
            //    Helper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesBuyerCredit.FAGetValue().ToString(), cdPyoffLnLoancharges.BuyerCredit.ToString(), true, true); 
            //if (cdPyoffLnLoancharges.SellerCredit != null)
            //    Helper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesSellerCredit.FAGetValue().ToString(), cdPyoffLnLoancharges.SellerCredit.ToString(), true, true);
            if (cdPyoffLnLoancharges.LEAmount != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.LoanChargesEstimatedUnRounded.FAGetValue().ToString(), cdPyoffLnLoancharges.LEAmount.ToString(), true, true);

            if (FastDriver.PayoffLoanCharges.LoanChargesDescription.FAGetValue().ToString().Equals(cdPyoffLnLoancharges.Description.ToString()))
            {
                FastDriver.PayoffLoanCharges.PaymentDetails.FAClick();
                FastDriver.PayoffLoanCharges.LoanChargesDescription.FAClick();

               // FastDriver.PayoffLoanCharges.LoanChargesDescription.FADoubleClick();
                Playback.Wait(4000);

            }
            ServiceHelper.ValidatePaymentAndGetCheckAMount(cdPyoffLnLoancharges);

            #endregion


            #region Validate Interest Calculation Summary
            String FromDateInclusive = "";
            String ToDateInclusive = "";

            FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

            FastDriver.PayoffLoanCharges.SwitchToContentFrame();

            Reports.TestStep = "Verify Interest Calculation Summary";
            string fromdate = FastDriver.PayoffLoanCharges.InterestCalculationProrFromDate.FAGetValue().ToString();
            fromdate = fromdate.Replace("-", "/").ToString();
            if (fromdate.StartsWith("0"))
            {
                fromdate = fromdate.Substring(1);
            }

            string todate = FastDriver.PayoffLoanCharges.InterestCalculationProrToDate.FAGetValue().ToString();
            todate = todate.Replace("-", "/").ToString();
            if (todate.StartsWith("0"))
            {
                todate = todate.Substring(1);
            }
            ServiceHelper.ContainsUIVal(FastDriver.PayoffLoanCharges.InterestCalculationProrPerDiem.FAGetValue().ToString(), UpdatePayoffLoanReq.CDInterestCalculationSummary[0].PerDiemAmount.ToString());
            Support.AreEqual("True", UpdatePayoffLoanReq.CDInterestCalculationSummary[0].FromDate.ToString().Contains(fromdate).ToString());
            Support.AreEqual("True", UpdatePayoffLoanReq.CDInterestCalculationSummary[0].ToDate.ToString().Contains(todate).ToString());
            if (UpdatePayoffLoanReq.CDInterestCalculationSummary[0].FromDateInclusive.ToString().Equals("1"))
            {
                FromDateInclusive = "on";
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.InterestCalculationInclusiveFrom.FAGetValue().ToString(), FromDateInclusive, true);
            }
            if (UpdatePayoffLoanReq.CDInterestCalculationSummary[0].ToDateInclusive.ToString().Equals("1"))
            {
                ToDateInclusive = "on";
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.InterestCalculationInclusiveTo.FAGetValue().ToString(), ToDateInclusive, true);
            }
            ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.InterestCalculationBasedonDays.FAGetSelectedItem().ToString(), UpdatePayoffLoanReq.CDInterestCalculationSummary[0].CalendarBaseDays.ToString());

            #endregion

            #region Validate Payoff Loan Charges

            FastDriver.PayoffLoanCharges.ChargesTab.Click();
            FastDriver.PayoffLoanCharges.WaitForScreenToLoad();
            if (cdPyoffLnpayoffloancharges[0].Description != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[0].Description.ToString(), true, true);
            if (cdPyoffLnpayoffloancharges[0].BuyerCharge != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCharge.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[0].BuyerCharge.ToString(), true, true);
            if (cdPyoffLnpayoffloancharges[0].BuyerCredit != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCredit.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[0].BuyerCredit.ToString(), true, true);
            if (cdPyoffLnpayoffloancharges[0].SellerCharge != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCharge.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[0].SellerCharge.ToString(), true, true);
            if (cdPyoffLnpayoffloancharges[0].SellerCredit != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCredit.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[0].SellerCredit.ToString(), true, true);
            if (cdPyoffLnpayoffloancharges[0].LEAmount != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeLoanEstimate.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[0].LEAmount.ToString(), true, true);

            if (cdPyoffLnpayoffloancharges[1].Description != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription8.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[1].Description.ToString(), true, true);
            if (cdPyoffLnpayoffloancharges[1].BuyerCharge != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCharge8.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[1].BuyerCharge.ToString(), true, true);
            if (cdPyoffLnpayoffloancharges[1].BuyerCredit != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargesBuyerCredit8.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[1].BuyerCredit.ToString(), true, true);
            if (cdPyoffLnpayoffloancharges[1].SellerCharge != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCharge8.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[1].SellerCharge.ToString(), true, true);
            if (cdPyoffLnpayoffloancharges[1].SellerCredit != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeSellerCredit8.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[1].SellerCredit.ToString(), true, true);
            if (cdPyoffLnpayoffloancharges[1].LEAmount != null)
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanCharges.PayoffLoanChargeLoanEstimate8.FAGetValue().ToString(), UpdatePayoffLoanReq.CDPayoffLoanCharges[1].LEAmount.ToString(), true, true);

            //if (FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription.FAGetValue().ToString().Equals(cdPyoffLnpayoffloancharges[0].Description.ToString()))
            //{
            //    FastDriver.PayoffLoanCharges.PaymentDetails.FAClick();
            //}

            //ServiceHelper.ValidatePaymentAndGetCheckAMount(cdPyoffLnpayoffloancharges[0]);

            //FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
            //FastDriver.PayoffLoanCharges.SwitchToContentFrame();

            //if (FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription8.FAGetValue().ToString().Equals(cdPyoffLnpayoffloancharges[1].Description.ToString()))
            //{
            //    FastDriver.PayoffLoanCharges.PayoffLoanChargesDescription8.FADoubleClick();
            //}

            //ServiceHelper.ValidatePaymentAndGetCheckAMount(cdPyoffLnpayoffloancharges[1]);

            #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        [Description("Verify RemovePayOffLoan() service functionality")]
        public void REG_RemovePayoffLoanDetails()
        {
            try
            {
                Reports.TestStep = "Verify RemovePayOffLoan() service";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke CreatePayOffLoan service";
                var CreatePayoffLoanReq = FileRequestFactory.GetDefaultPayoffLoanRequestWithCharge(File.FileID.ToString());

                var CreatePayoffLoanRes = FASTWCFHelpers.FileService.CreatePayoffLoan(CreatePayoffLoanReq);

                Support.AreEqual("1", CreatePayoffLoanRes.Status.ToString(), CreatePayoffLoanRes.StatusDescription);

                #region Variables

                var cdPyoffLnLoancharges = CreatePayoffLoanReq.CDLoanCharges;
                var cdPyoffLnpayoffloancharges = CreatePayoffLoanReq.CDPayoffLoanCharges;
                var cdPyoffLnInterestCalSum = CreatePayoffLoanReq.CDInterestCalculationSummary[0].CDChargePaymentDetails;

                #endregion
                Reports.TestStep = "Verify the OriginalPrincipalBalance";
                FastDriver.PayoffLoanDetails.Open();
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FAGetValue().ToString(), CreatePayoffLoanReq.PayOffLenderOrigPrincipalBal.ToString(), true, true);
                FastDriver.AssumptionLoanDetails.Open();
                #region Navigate to PayOffLoan and verify PayOffLoan request

                Reports.TestStep = "Navigate to PayOff Loan and verify the payoff loan instance has removed";
                var RemovePayoffLoanReq = FileRequestFactory.RemovePaoffLoanRequest(File.FileID.ToString());

                var RemovePayoffLoanRes = FASTWCFHelpers.FileService.RemovePayOffLoan(RemovePayoffLoanReq);

                FastDriver.PayoffLoanDetails.Open();
                ServiceHelper.CompareWithUI(FastDriver.PayoffLoanDetails.OriginalPrincipalBalance.FAGetValue().ToString(),"0.00", true, true);
               
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
           

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
    
}
