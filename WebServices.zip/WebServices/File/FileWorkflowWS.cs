﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using FASTWCFHelpers;
using OpenQA.Selenium.Support.UI;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;

namespace WebServices.File
{
    [CodedUITest]
    public class FileWorkflowWS : MasterTestClass
    {
        bool isProductadded = false;

        [TestMethod]
        [Owner("Yusuf")]
        /// <summary>
        /// Author : Yusuf
        /// Date : 05-01-2015
        /// Test case to add a Task
        /// </summary>
        public void REG_AddTask()
        {
            //            IWebDriver a = new FirefoxDriver();
            try
            {

                Reports.TestDescription = "Test AddTask service operation.";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTHelpers.FAST_Login_IIS();
                #endregion

                Reports.TestStep = "Create a file using WCF and get the fileId.";
                int fileID = CreateFile();
                AddTaskAndVerify(fileID);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        /// <summary>
        /// Author : Yusuf
        /// Date : 07-01-2016
        /// Test case to update a Task
        /// </summary>
        [TestMethod]
        //[TestCategory("File Service::FileWorkflowTests")]
        [Owner("Yusuf")]
        public void REG_UpdateTask()
        {
            try
            {
                Reports.TestDescription = "Test UpdateTask service operation.";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTHelpers.FAST_Login_IIS();
                #endregion

                Reports.TestStep = "Create a file using WCF and get the fileId.";
                int fileID = CreateFile();

                Reports.TestStep = "Add Task by calling AddTask service operation. Verify the outcome as well.";
                AddTaskAndVerify(fileID);

                Reports.TestStep = "Invoke GetWorkflowDetails service operation.";
                var workflowDetailsResponse = FASTWCFHelpers.FileService.GetWorkflowDetails(fileID);

                var workflowProcessName = workflowDetailsResponse.WorkFlowProcesses[0].ProcessName.ToString();
                var taskID = workflowDetailsResponse.Tasks[0].TaskID;
                var taskOfficeID = workflowDetailsResponse.Tasks[0].OfficeID;
                var taskName = workflowDetailsResponse.Tasks[0].Name.ToString();

                Reports.TestStep = "Create request for UpdateTask.";
                var updateTaskRequest = CreateRequestForUpdateTask<UpdateTaskRequest>();
                updateTaskRequest.TaskID = taskID;
                updateTaskRequest.TaskOfficeID = taskOfficeID;
                updateTaskRequest.eTaskStatus = FASTWCFHelpers.FastFileService.TaskStatus.Started;
                var publishedTaskComment = updateTaskRequest.PublishedTaskComments.ToString();
                var nonPublishedTaskComment = updateTaskRequest.NonPublishedTaskComments.ToString();

                Reports.TestStep = "Invoke UpdateTask operation.";
                var updateTaskResponse = InvokeUpdateTaskOperation(updateTaskRequest);

                Reports.TestStep = "Validate the response.";
                Reports.TestStep = "Navigate to File Workflow page";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"Home>Order Entry>File Workflow").WaitForScreenToLoad();
                Playback.Wait(3000);

                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);


                ExpandProcess(workflowProcessName);
                bool isTaskUpdated = VerifyTaskStatus(taskName, "S", "1");
                if (isTaskUpdated)
                    Reports.StatusUpdate("Task was successfully started !", true);
                if (!isTaskUpdated)
                    Reports.StatusUpdate("Task was not started in FAST yet !", false);

                Reports.TestStep = "Verify the comments in task comment section";
                OpenTaskComment(taskName, "1");
                Playback.Wait(2000);

                FastDriver.TaskCommentEditDlg.WaitForScreenToLoad(FastDriver.TaskCommentEditDlg.Done, true);
                Support.AreEqual(publishedTaskComment, ServiceHelper.GetText(FastDriver.TaskCommentEditDlg.PublishedComment).Trim());
                Support.AreEqual(nonPublishedTaskComment, ServiceHelper.GetText(FastDriver.TaskCommentEditDlg.NonPublishedComment).Trim());

                FastDriver.TaskCommentEditDlg.Cancel.FAClick();
                Reports.StatusUpdate("UpdateTask is successfully executed !", true);
            }
            catch (Exception ex)
            {
                //Reports.StatusUpdate("Error Occured" + ex, false);
                FailTest(ex.Message);
            }
        }

        /// <summary>
        /// Author : Yusuf
        /// Date : 07-01-2015
        /// Test case to get workflow details
        /// </summary>
        [TestMethod]
        //[TestCategory("File Service::FileWorkflowTests")]
        [Owner("Yusuf")]
        public void REG_GetWorkflowDetails()
        {
            string[] creationDate = new string[3];
            //string[] creator = new string[3];
            string[] description = new string[3];

            string pendingAlert_Creator = "";
            string pendingAlert_description = "";
            string pendingAlert_CreationDate = "";

            try
            {
                Reports.TestDescription = "Test GetWorkflowDetails service operation.[N-ISSUE IMPACTED RESULT:PENDING ALERT DOES NOT GET ADDED].";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTHelpers.FAST_Login_IIS();
                #endregion

                Reports.TestStep = "Create a file using WCF and get the fileId.";
                int fileID = CreateFile();

                #region Pre-requisites - Add Workflow Reminders or Alerts

                var addReminderReq = CreateReminderOrAlertRequest("Reminder", DateTime.UtcNow.AddHours(-8), fileID);
                AddFileWorkflowReminderOrAlert("Reminder", addReminderReq, "ActiveAlert", 1);

                addReminderReq = CreateReminderOrAlertRequest("Alert", DateTime.UtcNow.AddHours(-8), fileID);
                AddFileWorkflowReminderOrAlert("Alert", addReminderReq, "ActiveAlert", 2);

                addReminderReq = CreateReminderOrAlertRequest("Reminder", DateTime.UtcNow.AddHours(-8).AddDays(1), fileID);
                AddFileWorkflowReminderOrAlert("Reminder", addReminderReq, "PendingAlert", 1);

                addReminderReq = CreateReminderOrAlertRequest("Alert", DateTime.UtcNow.AddHours(-8).AddDays(1), fileID);
                AddFileWorkflowReminderOrAlert("Alert", addReminderReq, "PendingAlert", 2, false);

                #endregion

                Reports.TestStep = "Invoke GetWorkflowDetails service operation.";
                var workflowDetailsResponse = FASTWCFHelpers.FileService.GetWorkflowDetails(fileID);
                Reports.StatusUpdate("GetWorkflowDetails operation invoked !", true);

                Reports.StatusUpdate("Status = " + workflowDetailsResponse.Status, Convert.ToInt16(workflowDetailsResponse.Status).Equals(1));
                Reports.StatusUpdate("Status Description = " + workflowDetailsResponse.StatusDescription, workflowDetailsResponse.StatusDescription.ToLower().ToString().Contains("getworkflow details returned sucessfully"));

                #region Response Variables
                creationDate[0] = Convert.ToDateTime(workflowDetailsResponse.Alerts[1].CreationDate.ToString().Split(' ').FirstOrDefault()).ToDateString();
                description[0] = workflowDetailsResponse.Alerts[1].Descr.ToString();

                creationDate[1] = Convert.ToDateTime(workflowDetailsResponse.Reminders[0].RemindDate.ToString().Split(' ').FirstOrDefault()).ToDateString();
                description[1] = workflowDetailsResponse.Reminders[0].Note.ToString();

                var creationDate_NIssue = Convert.ToDateTime(workflowDetailsResponse.Alerts[2].CreationDate.ToString().Split(' ').FirstOrDefault()).ToDateString();
                var description_NIssue = workflowDetailsResponse.Alerts[2].Descr.ToString();

                //System.DateTime pendingAlert_CreationDate = Convert.ToDateTime(workflowDetailsResponse.PendingAlerts[0].CreationDate).AddDays(1);
                /*var pendingAlert_Creator = workflowDetailsResponse.PendingAlerts[0].Creator.ToString();
                var pendingAlert_description = workflowDetailsResponse.PendingAlerts[0].Descr.ToString();
                var pendingAlert_CreationDate = Convert.ToDateTime(workflowDetailsResponse.PendingAlerts[0].CreationDate).ToString("MM/dd/yyyy");*/

                var pendingAlert_Count = workflowDetailsResponse.PendingAlerts.Count();

                var pendingReminder_Creator = workflowDetailsResponse.PendingReminders[0].Creator.ToString();
                var pendingReminder_Note = workflowDetailsResponse.PendingReminders[0].Note.ToString();
                var pendingReminder_RemindDate = Convert.ToDateTime(workflowDetailsResponse.PendingReminders[0].RemindDate.ToString().Split(' ').FirstOrDefault()).ToDateString();
                #endregion

                Reports.TestStep = "Navigate to File Workflow page";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"Home>Order Entry>File Workflow").WaitForScreenToLoad();
                Playback.Wait(3000);


                #region Validations
                //Validate Reminder in Pending Alerts


                Reports.TestStep = "Validate fields of Pending Alerts - Reminder.";
                ServiceHelper.ContainsUIVal(FastDriver.FileWorkflow.Visibility, "selecteditem", "Reminder");
                ServiceHelper.ContainsUIVal(FastDriver.FileWorkflow.Creator, "value", pendingReminder_Creator);
                ServiceHelper.ContainsUIVal(FastDriver.FileWorkflow.NotifyDate, "value", pendingReminder_RemindDate);
                ServiceHelper.ContainsUIVal(FastDriver.FileWorkflow.Note, "value", pendingReminder_Note);

                //Validate Alert in Pending Alerts

                if (pendingAlert_Count > 0)
                {
                    Reports.TestStep = "Validate fields of Pending Alerts - Alert.";
                    ServiceHelper.ContainsUIVal(FastDriver.FileWorkflow.Visibility2, "selecteditem", "Alert");
                    ServiceHelper.ContainsUIVal(FastDriver.FileWorkflow.Creator2, "value", pendingAlert_Creator);
                    ServiceHelper.ContainsUIVal(FastDriver.FileWorkflow.NotifyDate2, "value", pendingAlert_CreationDate);
                    ServiceHelper.ContainsUIVal(FastDriver.FileWorkflow.Note2, "value", pendingAlert_description);
                }
                else
                {
                    Reports.TestStep = "N-ISSUE EXISTS :  PENDING ALERT IS NOT GETTING ADDED !";
                    bool NoNIssue = true;
                    if (pendingAlert_Count == 0
                        && creationDate_NIssue == Convert.ToDateTime(DateTime.Now.ToString().Split(' ').FirstOrDefault()).ToDateString()
                        && description_NIssue == "Alert Message")
                    {
                        NoNIssue = false;
                        Reports.StatusUpdate("EXPECTED N-ISSUE : PENDING ALERT IS NOT GETTING ADDED !", NoNIssue);
                    }
                }
                //Validate Reminder in Active Alerts
                //FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"Home>Order Entry>File Workflow").WaitForScreenToLoad();

                Reports.TestStep = "Validate fields of Active Alerts - Alert.";
                var activeAlertMsg = FastDriver.FileWorkflow.MessagesTable.PerformTableAction(4, description[0], 4, TableAction.Click);
                int rowId = FastDriver.FileWorkflow.MessagesTable.PerformTableAction(4, description[0], 4, TableAction.GetText).CurrentRow;
                var activeAlertDate = FastDriver.FileWorkflow.MessagesTable.PerformTableAction(rowId + 1, 3, TableAction.GetText).Message;
                activeAlertDate = Convert.ToDateTime(activeAlertDate.Split(' ').FirstOrDefault()).ToString("MM/dd/yyyy");
                creationDate[0] = Convert.ToDateTime(creationDate[0]).ToString("MM/dd/yyyy");
                Support.AreEqual(creationDate[0], activeAlertDate);

                //Validate Alert in Active Alerts
                Reports.TestStep = "Validate fields of Active Alerts - Reminder.";
                activeAlertMsg = FastDriver.FileWorkflow.MessagesTable.PerformTableAction(4, description[1], 4, TableAction.Click);
                rowId = FastDriver.FileWorkflow.MessagesTable.PerformTableAction(4, description[1], 4, TableAction.GetText).CurrentRow;
                try
                {
                    activeAlertDate = FastDriver.FileWorkflow.MessagesTable.PerformTableAction(rowId + 1, 3, TableAction.GetText).Message;
                }
                catch
                {
                    activeAlertDate = FastDriver.FileWorkflow.MessagesTable.PerformTableAction(rowId, 3, TableAction.GetText).Message;
                }
                activeAlertDate = Convert.ToDateTime(activeAlertDate.Split(' ').FirstOrDefault()).ToString("MM/dd/yyyy");
                creationDate[1] = Convert.ToDateTime(creationDate[1]).ToString("MM/dd/yyyy");
                Support.AreEqual(creationDate[1], activeAlertDate);

                #endregion

                //Reports.StatusUpdate("GetWorkflowDetails operation executed successfully ?", Reports.TestResult);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetWorkflowDetails operation not executed successfully ! Error:" + ex.Message, false);
            }
        }

        [TestMethod]
        //[TestCategory("File Service::FileWorkflowTests")]
        [Owner("Yusuf")]
        //[TestCategory("CD")]

        /// <summary>
        /// Author : Yusuf
        /// Date : 04-02-2016
        /// Test method to add process type.
        /// </summary>
        public void REG_AddReminderOrAlert()
        {
            try
            {
                Reports.TestDescription = "Test Add Reminder Or Alert service operation.";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTHelpers.FAST_Login_IIS();
                #endregion

                Reports.TestStep = "Create a file using WCF and get the fileId.";
                int fileID = CreateFile();

                #region Add Workflow Reminders or Alerts

                var addReminderReq = CreateReminderOrAlertRequest("Reminder", DateTime.UtcNow.AddHours(-8), fileID);
                AddFileWorkflowReminderOrAlert("Reminder", addReminderReq, "ActiveAlert", 1);

                addReminderReq = CreateReminderOrAlertRequest("Alert", DateTime.UtcNow.AddHours(-8), fileID);
                AddFileWorkflowReminderOrAlert("Alert", addReminderReq, "ActiveAlert", 2);

                addReminderReq = CreateReminderOrAlertRequest("Reminder", DateTime.UtcNow.AddDays(1), fileID);
                AddFileWorkflowReminderOrAlert("Reminder", addReminderReq, "PendingAlert", 1);

                addReminderReq = CreateReminderOrAlertRequest("Alert", DateTime.UtcNow.AddDays(1), fileID);
                AddFileWorkflowReminderOrAlert("Alert", addReminderReq, "PendingAlert", 2);

                #endregion
            }
            catch
            {
                Reports.StatusUpdate("Error occurred ! Could not add Reminder or Alert !", false);
            }
        }

        [TestMethod]
        //[TestCategory("File Service::FileWorkflowTests")]
        [Owner("Yusuf")]
        //[TestCategory("CD")]

        /// <summary>
        /// Author : Yusuf
        /// Date : 11-01-2016
        /// Test method to add process type.
        /// </summary>
        public void REG_AddProcessType()
        {
            try
            {

                Reports.TestDescription = "Test AddProcessType service operation.";

                #region FAST Login IIS side
                FASTHelpers.FAST_Login_IIS();
                #endregion

                Reports.TestStep = "Create a file using WCF and get the fileId.";
                int fileID = CreateFile();

                //Create request for AddTask.
                var addProcessTypeRequest = new FASTWCFHelpers.FastFileService.AddProcessType
                {
                    FileID = fileID,
                    ProcessTypeID = 1,
                    LoginName = "fastts\fastqa07",                 //LoginName = "intl\ckurian",
                    Source = "FAST"
                };

                Reports.TestStep = "Invoke AddProcessType operation.";
                var response = ServiceFactory.GetFileService().AddProcessType(addProcessTypeRequest);

                Reports.TestStep = "Validate the operation response.";
                Reports.StatusUpdate("Status = " + response.Status, Convert.ToInt16(response.Status).Equals(1));
                Reports.StatusUpdate("Status Description = " + response.StatusDescription, response.StatusDescription.ToLower().ToString().Contains("add process successful"));

                Reports.TestStep = "Navigate to File Workflow page";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"Home>Order Entry>File Workflow").WaitForScreenToLoad();
                // Playback.Wait(3000);

                Reports.TestStep = "Verify the outcome of the operation invocation on File Workflow screen.";
                bool IsProcessAdded = VerifyIfProcessAdded("AUTO_DONOTTOUCH_Template Setup Maintenan", "2");
                if (IsProcessAdded)
                {
                    Reports.StatusUpdate("Process successfully added", true);
                }

                if (!IsProcessAdded)
                {
                    Reports.StatusUpdate("Process not added in FAST", false);
                }
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Error Occured : " + ex, false);
            }
        }

        [TestMethod]
        //[TestCategory("File Service::FileWorkflowTests")]
        [Owner("Yusuf")]

        /// <summary>
        /// Author : Yusuf
        /// Date : 12-01-2016
        /// Test method to get Task offices.
        /// </summary>
        public void REG_GetTaskOffices()
        {
            List<string> taskOffices = new List<string>();
            bool AllTaskOfficesFetched = false;
            try
            {
                Reports.TestDescription = "Test GetTaskOffices service operation.";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTHelpers.FAST_Login_IIS();
                #endregion

                Reports.TestStep = "Create a file using WCF and get the fileId.";
                var fileID = CreateFile();

                Reports.TestStep = "As a pre-requisite, invoke GetWorkflowDetails service operation to get TaskID, Task Name and WorkflowProcessName.";
                var workflowDetailsResponse = FASTWCFHelpers.FileService.GetWorkflowDetails(fileID);

                var workflowProcessName = workflowDetailsResponse.WorkFlowProcesses[0].ProcessName.ToString();
                var taskID = workflowDetailsResponse.Tasks[0].TaskID;
                var taskName = workflowDetailsResponse.Tasks[0].Name.ToString();

                Reports.TestStep = "Navigate to File Workflow page.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"Home>Order Entry>File Workflow").WaitForScreenToLoad();
                Playback.Wait(3000);

                Reports.TestStep = "Get the list of Task Offices from the UI.";
                taskOffices = GetTaskOffices(taskName, "1", ExpandProcess(workflowProcessName));

                Reports.TestStep = "Invoke GetTaskOffices service operation.";
                var response = FASTWCFHelpers.FileService.GetTaskOffices(fileID, Convert.ToInt32(taskID));

                Reports.TestStep = "Validate the operation response.";
                Reports.StatusUpdate("Status = " + response.Status, Convert.ToInt16(response.Status).Equals(1));
                Reports.StatusUpdate("Status Description = " + response.StatusDescription, response.StatusDescription.ToLower().ToString().Contains("task offices loaded sucessfully"));

                Reports.TestStep = "Verify the outcome on File Workflow screen.";
                int taskOfficesReferenceCount = response.TaskOfficesByFile.Length;
                for (int i = 0; i < taskOfficesReferenceCount; i++)
                {
                    if (response.TaskOfficesByFile[i].Name.ToString().Equals(taskOffices[i]))
                    {
                        AllTaskOfficesFetched = true;
                    }
                    else
                    {
                        AllTaskOfficesFetched = false;
                        break;
                    }
                }

                if (AllTaskOfficesFetched)
                {
                    Reports.StatusUpdate("The Task Offices are returned correctly !", true);
                }
                if (!AllTaskOfficesFetched)
                {
                    Reports.StatusUpdate("The Task Offices are not returned correctly !", false);
                }
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Error occured : " + ex, false);
            }
        }

        /// <summary>
        /// Author : Yusuf
        /// Date : 13-01-2015
        /// Test case to Get Task Details in File Workflow process
        /// </summary>
        [TestMethod]
        //[TestCategory("File Service::FileWorkflowTests")]
        [Owner("Yusuf")]
        public void REG_GetTaskDetails()
        {
            try
            {
                Reports.TestDescription = "Test GetTaskDetails service operation";


                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTHelpers.FAST_Login_IIS();
                #endregion

                Reports.TestStep = "Create a file using WCF and get the fileId.";
                int fileID = CreateFile();

                Reports.TestStep = "Invoke GetWorkflowDetails service operation to get TaskID, Task Name, Task Office ID and WorkflowProcessName.";
                var workflowDetailsResponse = FASTWCFHelpers.FileService.GetWorkflowDetails(fileID);

                var workflowProcessName = workflowDetailsResponse.WorkFlowProcesses[0].ProcessName.ToString();
                var taskOfficeID = workflowDetailsResponse.Tasks[0].OfficeID.ToString();
                var taskID = workflowDetailsResponse.Tasks[0].TaskID;
                var taskName = workflowDetailsResponse.Tasks[0].Name.ToString();

                var request = new GetTaskDetailsRequest()
                {
                    FileID = fileID,
                    TaskID = taskID,
                    LoginName = "fastts\\fastqa07",
                    Source = "FAMOS"
                };

                Reports.TestStep = "Invoke GetTaskDetails service operation.";
                var response = FASTWCFHelpers.FileService.GetTaskDetails(request);

                Reports.StatusUpdate("Status = " + response.Status, Convert.ToInt16(response.Status).Equals(1));
                Reports.StatusUpdate("Status Description = " + response.StatusDescription, response.StatusDescription.ToLower().ToString().Contains("task details loaded sucessfully"));

                Reports.StatusUpdate("Workflow Process Name:" + workflowProcessName, response.Task.ProcessName.Equals(workflowProcessName));
                Reports.StatusUpdate("Task Name:" + taskName, response.Task.Name.Equals(taskName));
                Reports.StatusUpdate("TaskID:" + taskID, response.Task.TaskID.Equals(taskID));
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Error Occured" + ex, false);
            }
        }

        [TestMethod]
        public void REG0001_RemoveFileWorkflowReminderOrAlert()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify RemoveFileWorkflowReminderOrAlert() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file.";
                var file = FileService.GetOrderDetails(FastDriver.FACreateFileGetFileId(fileRequest));
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke the RemoveFileWorkflowReminderOrAlert method.";
                var alertOrReminderRequest = FileRequestFactory.GetAlertOrReminderRequest(file.FileID.Value, visibilityType: 1, notifyDate: DateTime.Today.ToPST().AddDays(1));
                FileService.AddFileWorkflowReminderOrAlert(alertOrReminderRequest).Validate();

                Reports.TestStep = "Validate Alert in Workflow screen.";
                FastDriver.FileWorkflow.Open();
                Support.IsTrue(FastDriver.FileWorkflow.PendingReminderTable.FAGetText().Contains(alertOrReminderRequest.Note), "Alert note is visible");

                Reports.TestStep = "Invoke the GetWorkflowDetails method.";
                var response = FileService.GetWorkflowDetails(file.FileID.Value);
                response.Validate();
                alertOrReminderRequest.AlertOrReminderID = response.PendingReminders[0].PendingARID;

                Reports.TestStep = "Invoke the RemoveFileWorkflowReminderOrAlert method.";
                FileService.RemoveFileWorkflowReminderOrAlert(alertOrReminderRequest).Validate();

                Reports.TestStep = "Validate Alert in Workflow screen.";
                FastDriver.FileWorkflow.Open();
                Support.IsTrue(!FastDriver.FileWorkflow.PendingReminderTable.FAGetText().Contains(alertOrReminderRequest.Note), "Alert note is removed");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0002_TriggerATPReview()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify TriggerATPReview() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke TriggerATPReview request.";
                FileService.TriggerATPReview(FileRequestFactory.GetTriggerATPReviewRequest(fileid)).Validate();

                //Reports.TestStep = "Validate TriggerATPReview succeeded in Event/Tracking Log.";
                //FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                //FastDriver.EventTrackingLog.EventCategory.FASelectItem("File Process");
                //Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[File De-Archive]"), "Validating event for DeArchiveFileService");
                //Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("Documents De-Archived Successfully."), "Validating event for DeArchiveFileService");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0003_TriggerTaskEvent()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify TriggerTaskEvent() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke TriggerTaskEvent request.";
                FileService.TriggerTaskEvent(FileRequestFactory.GetTriggerTaskEventRequest(fileid, 2012, 1487)).Validate();

                Reports.TestStep = "Validate TriggerTaskEvent succeeded in Event/Tracking Log.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("File Process");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[Update Workflow]"), "Validating event for TriggerTaskEvent");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("File Workflow Update Received - Task Update"), "Validating event for TriggerTaskEvent");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0004_AddProcessEvent()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion
                Reports.TestDescription = "Verify AddProcessEvent() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").EnterBUID(AutoConfig.SelectedRegionBUID);

                Reports.TestStep = "Get the Inactive Document Name";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>("Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();
                Support.AreEqual("Endorsement/Guarantee", FastDriver.TemplateMaintenanceSummary.TemplateType.FAGetSelectedItem());
                FastDriver.TemplateMaintenanceSummary.TemplateStatus.FASelectItem("InActive");
                FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
                FastDriver.TemplateMaintenanceSummary.WaitForResultsTableToLoad();
                FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction(2, 2, TableAction.Click);
                string docTemplate = FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction(2, 2, TableAction.GetText).Message;
                Reports.TestStep = "Select the new template to activate it.";
                FastDriver.LeftNavigation.Navigate<RegionalProcessSummary>("Home>System Maintenance>Process Setup>Regional Process Summary").WaitForScreenToLoad();
                FastDriver.RegionalProcessSummary.New.FAClick();
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.ProcessType.FASelectItem("1099");
                var templateName = "WebServiceProcessTest - " + Support.RandomString("AAZNZNNA");
                FastDriver.RegionalProcessEdit.ProcessName.FASetText(templateName);
                FastDriver.RegionalProcessEdit.PriorityProcess.FASetCheckbox(true);
                FastDriver.RegionalProcessEdit.Description.FASetText("Selenium Web Service Regression Test.");
                string processName = FastDriver.RegionalProcessEdit.ProcessName.FAGetValue();
                FastDriver.RegionalProcessEdit.ProcessTemplateSelectionCriteriaSelect.FAClick();
                FastDriver.SelectionCriteriaDlg.WaitForScreenToLoad();
                FastDriver.SelectionCriteriaDlg.TranType.FASelectItem("Sale w/Mortgage");
                FastDriver.SelectionCriteriaDlg.Done.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                Reports.TestStep = "Navigates back to Regional Process Edit";
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.RegionalProcessEdit.ProcessEventSelectionCriteriaAddRemove.FAClick();
                FastDriver.ProcessEventSelectionDlg.WaitForScreenToLoad();
                FastDriver.ProcessEventSelectionDlg.ProcessEventTable1.PerformTableAction(2, "External System Response", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();

                Reports.TestStep = "Add External System Response.";
                FastDriver.RegionalProcessEdit.ProcessEventSelEllipse.FAClickAction();
                FastDriver.ExternalSystemResponseDlg.WaitForScreenToLoad();
                FastDriver.ExternalSystemResponseDlg.ExternalResponseEventTable.PerformTableAction(2, "EWB Process - Launch FASTSearch", 1, TableAction.On);
                FastDriver.ExternalSystemResponseDlg.Done.FAClick();
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();

                Reports.TestStep = "Add tasks to the process";
                FastDriver.RegionalProcessEdit.Add.FAClick();
                FastDriver.TaskTemplateSelectionDlg.OverrideTask(3, friendlyTaskName: "PSG_AUTO_Task1", isPublic: true, clickOnSelectTask: true);
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();

                Reports.TestStep = "Add workgroups to all tasks";
                FastDriver.RegionalProcessEdit.TaskTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.RegionalProcessEdit.WorkGrpEllipse.FAClick();
                FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectDlg.ViewMore.FAClick();
                FastDriver.WorkgroupSelectionDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectionDlg.Table.PerformTableAction(1, 1, TableAction.SelectItem, "1099");
                FastDriver.WorkgroupSelectionDlg.Select.FAClick();
                FastDriver.WorkgroupSelectDlg.WaitForScreenToLoad();
                FastDriver.WorkgroupSelectDlg.WorkgroupTable.PerformTableAction(2, "1099", 1, TableAction.On);
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 10);
                FastDriver.RegionalProcessEdit.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Activating Task";
                FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
                FastDriver.RegionalProcessSummary.ProcessSummaryTable.PerformTableAction(1, processName, 2, TableAction.Click);
                FastDriver.RegionalProcessSummary.ViewChangeStatus.FAClick();
                FastDriver.StatusEdit.WaitForScreenToLoad();
                FastDriver.StatusEdit.Deactivate.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(false, true, 10);
                FastDriver.WebDriver.HandleDialogMessage(false, true, 10);
                FastDriver.WebDriver.HandleDialogMessage(true, true, 10);
                FastDriver.RegionalProcessSummary.WaitForScreenToLoad();
                Reports.StatusUpdate("Template refresh successful.", FastDriver.PendingRefreshSummary.RefreshProcessTemplate(processName));
                FastDriver.WebDriver.Quit();

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Navigate to File Workflow.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad();
                FastDriver.FileWorkflow.CollapseAll.FASetCheckbox(false);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);
                FastDriver.FileWorkflow.WaitForScreenToLoad();
                FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);

                var tableID = FastDriver.FileWorkflow.GetWorkFlowTableID(templateName);
                Support.AreEqual(tableID == null, true, "Validating process is not on the file.");

                Reports.TestStep = "Invoke AddProcessEvent request.";
                FileService.AddProcessEvent(FileRequestFactory.GetAddProcessRequest(fileid, 1487, 1918, 1924)).Validate();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Validate AddProcessEvent succeeded in Event/Tracking Log.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("File Process");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[Update Workflow]"), "Validating event for AddProcessEvent");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("File Workflow Update Received - Process Update"), "Validating event for AddProcessEvent");

                Reports.TestStep = "Navigate to File Workflow.";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad();

                tableID = FastDriver.FileWorkflow.GetWorkFlowTableID(templateName);
                Support.AreEqual(tableID != null, true, "Validating process is on the file.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0005_AddFileWorkflowReminderOrAlert()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify AddFileWorkflowReminderOrAlert() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke AddFileWorkflowReminderOrAlert request.";
                FileService.AddFileWorkflowReminderOrAlert(FileRequestFactory.GetAlertOrReminderRequest(fileid, 1, DateTime.Now.AddDays(1))).Validate();

                Reports.TestStep = "Validate AddFileWorkflowReminderOrAlert succeeded in Event/Tracking Log.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Workflow");
                FastDriver.EventTrackingLog.WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[Add File Alert/Reminder]"), "Validating event for AddFileWorkflowReminderOrAlert");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("File Reminder added successfully."), "Validating event for AddFileWorkflowReminderOrAlert");

                Reports.TestStep = "Validate Reminder/Alert is pending on File Workflow screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.FileWorkflow>("Home>Order Entry>File Workflow").WaitForScreenToLoad();
                Support.AreEqual(true, FastDriver.FileWorkflow.Note.FAGetValue().Contains("Reminder Message"), "Validating Note message for AddFileWorkflowReminderOrAlert");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #region Private Functions
        private void AddTaskAndVerify(int fileID)
        {
            Reports.TestStep = "Invoke GetWorkflowDetails web method.";
            var workflowDetailsResponse = FASTWCFHelpers.FileService.GetWorkflowDetails(fileID);

            var workflowProcessName = workflowDetailsResponse.WorkFlowProcesses[0].ProcessName.ToString();
            String ProcessID = workflowDetailsResponse.WorkFlowProcesses[0].ServicefileProcessID.ToString();
            String workflowTemplateID = workflowDetailsResponse.WorkFlowProcesses[0].WorkflowTemplateID.ToString();
            String taskTemplateID = workflowDetailsResponse.Tasks[0].TaskTemplateID.ToString();
            var taskName = workflowDetailsResponse.Tasks[0].Name.ToString();

            Reports.TestStep = "Create request for AddTask.";
            var addTaskRequest = CreateRequestForAddTask<AddTaskRequest>(fileID);
            addTaskRequest.FileID = fileID;
            addTaskRequest.ProcessID = Convert.ToInt32(ProcessID);
            addTaskRequest.oTaskTemplate.TaskTemplateID = Convert.ToInt32(taskTemplateID);
            addTaskRequest.oTaskTemplate.WorkflowTemplateID = Convert.ToInt32(workflowTemplateID);



            Reports.TestStep = "Invoke AddTask operation.";
            var addTaskResponse = InvokeAddTaskOperation(addTaskRequest);

            Reports.TestStep = "Validate the response.";
            Reports.TestStep = "Navigate to File Workflow page";
            FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"Home>Order Entry>File Workflow").WaitForScreenToLoad();
            Playback.Wait(3000);

            FastDriver.FileWorkflow.ActiveOnly.FASetCheckbox(false);



            //bool isTaskAdded = VerifyIfTaskAdded(taskName,"2");

            Reports.StatusUpdate("Has Task successfully  been added ? ", VerifyIfTaskAdded(taskName, "2", ExpandProcess(workflowProcessName)));
        }

        private List<string> GetTaskOffices(string taskName, string instance, int processInRow)
        {
            if (processInRow == -1)
            {
                throw new Exception("Could not find or expand the specified Process !");
            }
            int Instance = Int32.Parse(instance);
            List<string> offices = new List<string>();
            string taskDetailsTablePropertyValue = "dgProc_" + processInRow + "_dgT";
            int taskCount = 0;
            bool IsIntendedTaskLocated = false;

            try
            {
                var taskDetailsTable = FastDriver.FileWorkflow.ProcessTable.FindElement(By.Id(taskDetailsTablePropertyValue));
                int rowCount = taskDetailsTable.GetRowCount();

                for (int i = 1; i <= rowCount; i++)
                {
                    if (taskDetailsTable.PerformTableAction(i, 5, TableAction.GetText).Message.Trim() == taskName)
                    {
                        taskCount++;
                        if (taskCount == Convert.ToInt16(instance))
                        {
                            taskDetailsTable.PerformTableAction(i, 7, TableAction.Click); //opens up Task Selection Dialog.
                            IsIntendedTaskLocated = true;
                            break;
                        }
                    }
                }

                if (!IsIntendedTaskLocated)
                {
                    Reports.StatusUpdate("The specified Task :" + taskName + "could not be found !", false);
                }

                try
                {
                    if (IsIntendedTaskLocated)
                    {
                        FastDriver.WebDriver.WaitForWindowAndSwitch("Task Office Selection -- Webpage Dialog", true, Convert.ToInt16(AutoConfig.WaitTime));
                        FastDriver.TaskOfficeSelectionDlg.SwitchToDialogContentFrame();
                        int officeCount = FastDriver.TaskOfficeSelectionDlg.TaskOfficeTable.GetRowCount();
                        for (int i = 1; i <= officeCount; i++)
                        {
                            FastDriver.TaskOfficeSelectionDlg.TaskOfficeTable.PerformTableAction(i, 3, TableAction.Click);
                            offices.Add(FastDriver.TaskOfficeSelectionDlg.TaskOfficeTable.PerformTableAction(i, 3, TableAction.GetText).Message);
                        }
                    }
                }

                catch (Exception e)
                {
                    Reports.StatusUpdate("Error in reading Task Office list :" + e.Message, false);
                    FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);

                }

                FastDriver.TaskOfficeSelectionDlg.Cancel.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName, true, 20);
            }

            catch (Exception ex)
            {
                Reports.StatusUpdate("Error in finding Task :" + ex.Message, false);
            }
            return offices;
        }

        private AlertOrReminderRequest CreateReminderOrAlertRequest(string type, DateTime date, int fileID)
        {
            var addReminderReq = RequestFactory.GetAddFileWorkflowReminderOrAlert(Convert.ToInt32(fileID));
            addReminderReq.NotifyDate = date;
            if (type == "Alert")
            {
                addReminderReq.VisibilityTypeCDID = 2;
                addReminderReq.AlertCDID = 26;
                addReminderReq.Note = "Alert Message";
            }
            return addReminderReq;
        }

        private void VerifyIfWorkflowReminderOrAlertIsAdded(AlertOrReminderRequest addReminderReq, string VerificationSection, int rowIndex)
        {
        }

        private void AddFileWorkflowReminderOrAlert(string type, AlertOrReminderRequest addReminderReq, string verificationSection, int rowIndex, bool IsToValidate = true)
        {
            try
            {
                Reports.TestStep = "Invoke AddFileWorkflowReminderOrAlert";
                var AddReminderRes = FASTWCFHelpers.FileService.AddFileWorkflowReminderOrAlert(addReminderReq);
                //                Reports.UpdateDebugLog("Invoke AddFileWorkflowReminderOrAlert", "", "", "", "", "", "Pass", "");

                Reports.TestStep = "Validate the response of AddFileWorkflowReminderOrAlert operation for - " + type;
                Support.AreEqual("1", AddReminderRes.Status.ToString(), true);

                if (type == "Reminder")
                {
                    if (AddReminderRes.StatusDescription.ToLower().Contains("addfilereminderoralert() : file alert/reminder created successfully."))
                    {
                        Reports.StatusUpdate("Reminder successfully created !", true);
                    }
                    else
                    {
                        Reports.StatusUpdate("Reminder creation failed !", false);
                    }
                }
                else if (type == "Alert")
                {
                    Support.AreEqual("File alert created successfully.", AddReminderRes.StatusDescription.ToString(), true);
                }

                String RType = "";
                if (addReminderReq.VisibilityTypeCDID == 1) RType = "Reminder";
                else if (addReminderReq.VisibilityTypeCDID == 2) RType = "Alert";
                string note = addReminderReq.Note.ToString();
                var creator = "Super User";
                var notifyDate = Convert.ToDateTime(addReminderReq.NotifyDate).ToDateString();

                Reports.TestStep = "Navigate to File Workflow";
                FastDriver.LeftNavigation.Navigate<FileWorkflow>(@"Home>Order Entry>File Workflow").WaitForScreenToLoad();

                if (verificationSection == "PendingAlert")
                {
                    Reports.TestStep = "Validate fields of Pending Alert.";
                    if (rowIndex == 1)
                    {
                        Support.AreEqual(RType, FastDriver.FileWorkflow.Visibility.FAGetSelectedItem().ToString(), true);
                        Support.AreEqual(creator, ServiceHelper.GetText(FastDriver.FileWorkflow.Creator), true);
                        Support.AreEqual(notifyDate, ServiceHelper.GetText(FastDriver.FileWorkflow.NotifyDate).ToString(), true);
                        Support.AreEqual(note, ServiceHelper.GetText(FastDriver.FileWorkflow.Note).ToString(), true);
                    }
                    if (rowIndex == 2 && IsToValidate)
                    {
                        Support.AreEqual(RType, FastDriver.FileWorkflow.Visibility2.FAGetSelectedItem().ToString(), true);
                        Support.AreEqual(creator, ServiceHelper.GetText(FastDriver.FileWorkflow.Creator2), true);
                        Support.AreEqual(notifyDate, ServiceHelper.GetText(FastDriver.FileWorkflow.NotifyDate2), true);
                        Support.AreEqual(note, ServiceHelper.GetText(FastDriver.FileWorkflow.Note2), true);
                    }
                }

                //use the below code in case the current validations have issues.
                //Support.AreEqual(RType, FastDriver.FileWorkflow.PendingReminderTable.PerformTableAction(1,RType,1,TableAction.GetSelectedItem).Message);
                //Support.AreEqual(note,  FastDriver.FileWorkflow.PendingReminderTable.PerformTableAction(4,creator,4,TableAction.GetText).Message);
                if (verificationSection == "ActiveAlert")
                {
                    Reports.TestStep = "Validate fields of Active Alert.";
                    if (FastDriver.FileWorkflow.MessagesTable.GetRowCount() > 1)
                    {
                        var activeAlertMsg = FastDriver.FileWorkflow.MessagesTable.PerformTableAction(4, note, 4, TableAction.Click);

                        int rowId = FastDriver.FileWorkflow.MessagesTable.PerformTableAction(4, note, 4, TableAction.GetText).CurrentRow;

                        var activeAlertDate = FastDriver.FileWorkflow.MessagesTable.PerformTableAction(rowId + 1, 3, TableAction.GetText).Message;//.ToString("MM/dd/yyyy");
                        activeAlertDate = Convert.ToDateTime(activeAlertDate.Split(' ').FirstOrDefault()).ToString("MM/dd/yyyy");
                        if (note == "Alert Message") // Checked with Vijay. He's of the view that this may not be a bug/N-Issue. The below logic is to handle the IST timezone appearing in the application only for the Active Alert type, not for the Active Reminder type.
                        {
                            notifyDate = DateTime.Now.ToString().Split(' ').FirstOrDefault();
                        }
                        notifyDate = Convert.ToDateTime(notifyDate).ToString("MM/dd/yyyy");
                        Support.AreEqual(notifyDate, activeAlertDate);
                    }
                }

                //use the below code in case the current validations have issues.
                /*   if(FastDriver.FileWorkflow.MessagesTable.FAGetText().Contains(note))
                   {
                        Reports.StatusUpdate("Located the specified note:"+note,true);
                   }
                   else
                   {
                        Reports.StatusUpdate("Could not locate the specified note:"+note,false);
                   }*/
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        private int ExpandProcess(string workflowProcessName)
        {
            //FastDriver.FileWorkflow.ProcessActiveTable(2,workflowProcessName,1,TableAction.Click);
            //                IWebElement processTable = FastDriver.FileWorkflow.ProcessTable.FindElements(By.TagName("Table")).ToList()[1];
            //              processTable.PerformTableAction(2,workflowProcessName,1,TableAction.Click);
            int processInRowNumber = -1;
            IWebElement mainProcessTable = null;
            IWebElement processElement = null;
            string processNameActualIdentifier = "dgProc_^^_lblPN";
            string expansionImageID = "pExpCol";
            string actualProcessName = "";

            try
            {
                int processTableRowCount = FastDriver.FileWorkflow.ProcessTable.FindElements(By.TagName("tr")).Where(r => r.Displayed).ToList().Count;
                for (int rowIdx = 0; rowIdx < processTableRowCount; rowIdx++)
                {
                    processNameActualIdentifier = processNameActualIdentifier.Replace("^^", rowIdx.ToString());

                    mainProcessTable = FastDriver.FileWorkflow.ProcessTable;
                    processElement = mainProcessTable.FindElement(By.Id(processNameActualIdentifier));
                    actualProcessName = processElement.FAGetValue() ?? processElement.FAGetText() ?? processElement.FAGetAttribute("text");


                    if (actualProcessName.Trim() == workflowProcessName.Trim())
                    {
                        var expansionImageElement = mainProcessTable.FindElements(By.Id(expansionImageID)).ToList().ElementAt(rowIdx);
                        expansionImageElement.FAClick();

                        //processElement.FAClick();
                        processInRowNumber = rowIdx;
                        break;
                    }
                }
                //processTable.PerformTableAction(2,workflowProcessName,1,TableAction.Click);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Process was not added ! Error :" + ex.Message, false);
            }
            Playback.Wait(1000);
            return processInRowNumber;
        }

        private bool VerifyTaskStatus(string taskName, string statusToCheck, string instance)
        {
            int taskCount = 0;
            bool status = false;
            int rowIndex = 0;
            int columnIndex = 0;
            try
            {
                int taskInstance = Int32.Parse(instance);
                IWebElement taskNamesTable = FastDriver.FileWorkflow.ProcessTable.FindElements(By.TagName("Table")).ToList()[2];
                List<IWebElement> taskNamesTableRows = taskNamesTable.FindElements(By.TagName("tr")).Where(r => r.Displayed).ToList();
                List<IWebElement> colElements = null;
                foreach (IWebElement task in taskNamesTableRows)
                {
                    rowIndex++;
                    colElements = task.FindElements(By.TagName("td")).Where(c => c.Displayed).ToList();
                    columnIndex = ((rowIndex - 1) * 12) + 5; //calcuting column index for Task Name column.
                    if (ServiceHelper.GetText(colElements[columnIndex]).Trim() == taskName.Trim())
                    {
                        taskCount++;
                        if (taskCount == taskInstance)
                        {
                            switch (statusToCheck.ToLower())
                            {
                                case "s":
                                    columnIndex = ((rowIndex - 1) * 12) + 1; //since all the cells of the table are returned by Selenium, need to use this formula to arrive at the correct column index, regardless of the row.
                                    status = VerifyIfTaskImageIsVisible(imageProperty: "imgStart", imageColumnElement: colElements[columnIndex]);
                                    //By elemBy = FAByFactory.From(() => elem);
                                    break;
                                case "c":
                                    columnIndex = ((rowIndex - 1) * 12) + 2;
                                    status = VerifyIfTaskImageIsVisible(imageProperty: "imgComplete", imageColumnElement: colElements[columnIndex]);
                                    break;
                                case "w":
                                    columnIndex = ((rowIndex - 1) * 12) + 3;
                                    status = VerifyIfTaskImageIsVisible(imageProperty: "imgWaive", imageColumnElement: colElements[columnIndex]);
                                    break;
                            }

                        }
                    }
                    if (status)
                    {
                        return status;
                    }
                }
                if (status)
                {
                    return status;
                }
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        private bool VerifyIfTaskImageIsVisible(string imageProperty, IWebElement imageColumnElement)
        {
            bool result = false;
            By elemBy = By.Id(imageProperty);
            var elem = imageColumnElement.FindElement(elemBy);
            //By elemBy = FAByFactory.From(() => elem);
            var wait = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromSeconds(10));
            IWebElement imgElement = wait.Until(ExpectedConditions.ElementIsVisible(elemBy));
            if (imgElement != null && elem != null)
            {
                result = true;
            }

            return result;
        }

        private bool VerifyIfTaskAdded(string taskName, string referenceTaskCount, int processInRow)
        {
            bool status = false;
            int taskCount = 0;
            //string taskNameBaseIdentifier = "dgProc_^^_lblPN";
            string taskDetailsTablePropertyValue = "dgProc_" + processInRow + "_dgT";

            try
            {
                /*IWebElement taskNamesTable = FastDriver.FileWorkflow.ProcessTable.FindElements(By.TagName("Table")).ToList()[2];
                //List<IWebElement> taskNamesTableRows = taskNamesTable.FindElements(By.TagName("tr")).Where(r => r.Displayed).ToList();
                //List<IWebElement> colElements = null;
                foreach (IWebElement task in taskNamesTableRows)
                {
                    colElements = task.FindElements(By.TagName("td")).Where(c => c.Displayed).ToList();
                    if(colElements[4].FAGetValue().Trim() == taskName.Trim())
                    {
                         taskCount++;
                    }
                }*/

                var taskDetailsTable = FastDriver.FileWorkflow.ProcessTable.FindElement(By.Id(taskDetailsTablePropertyValue));
                int rowCount = taskDetailsTable.GetRowCount();
                for (int i = 1; i <= rowCount; i++)
                {
                    if (taskDetailsTable.PerformTableAction(i, 5, TableAction.GetText).Message.Trim() == taskName)
                    {
                        taskCount++;
                    }
                }
            }

            catch (Exception ex)
            {
                Reports.StatusUpdate("Task was not added ! Error :" + ex.Message, false);
            }
            return taskCount == Convert.ToInt32(referenceTaskCount);
        }

        private bool VerifyIfProcessAdded(string processName, string instance)
        {
            bool status = false;
            int processCount = 0;
            string processNameBaseIdentifier = "dgProc_^^_lblPN";
            string processNameActualIdentifier = "dgProc_^^_lblPN";
            try
            {
                /*int processTableRowCount = FastDriver.WebDriver.FindElement(FAByFactory.From(FastDriver.FileWorkflow.ProcessTable)).FindElements(By.TagName("tr")).Where(row => row.Displayed).Count();
                processTableRowCount = FastDriver.WebDriver.FindElement(FAByFactory.From(FastDriver.FileWorkflow.ProcessTable)).FindElements(By.TagName("tr")).Where(row => FastDriver.WebDriver.FindElement(FAByFactory.From(row)).IsVisible()).Count();
                
                
                var temp = FastDriver.WebDriver.FindElement(FAByFactory.From(FastDriver.FileWorkflow.ProcessTable)).FindElements(By.XPath("./child::tr")).Where(row => row.Displayed);
                temp = FastDriver.WebDriver.FindElement(FAByFactory.From(FastDriver.FileWorkflow.ProcessTable)).FindElements(By.XPath("./child::tr")).Where(row => row.IsVisible());
                processTableRowCount = temp.Count();

                processTableRowCount = FastDriver.FileWorkflow.ProcessTable.GetRowCount();*/

                int processTableRowCount = FastDriver.FileWorkflow.ProcessTable.FindElements(By.XPath("./tbody/tr")).Count;


                for (int rowIdx = 0; rowIdx < processTableRowCount; rowIdx++)
                {
                    processNameActualIdentifier = processNameActualIdentifier.Replace("^^", rowIdx.ToString());

                    if (ServiceHelper.GetText(FastDriver.FileWorkflow.ProcessTable.FindElement(By.Id(processNameActualIdentifier))).Trim() == processName.Trim())
                    {
                        processCount++;
                    }
                    processNameActualIdentifier = processNameBaseIdentifier;
                }
                //processTable.PerformTableAction(2,workflowProcessName,1,TableAction.Click);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Process was not added ! Error :" + ex.Message, false);
            }
            return processCount == Convert.ToInt32(instance);
        }

        private static bool OpenTaskComment(String taskName, String instance)
        {
            int taskCount = 0;
            bool status = false;
            try
            {
                int taskInstance = Int32.Parse(instance);
                IWebElement taskNamesTable = FastDriver.FileWorkflow.ProcessTable.FAFindElements(ByLocator.TagName, "Table").ToList()[2];
                List<IWebElement> taskNamesTableRows = taskNamesTable.FAFindElements(ByLocator.TagName, "tr").Where(r => r.Displayed).ToList();
                List<IWebElement> colElements = null;
                foreach (IWebElement task in taskNamesTableRows)
                {
                    colElements = task.FAFindElements(ByLocator.TagName, "td").Where(c => c.Displayed).ToList();
                    if (ServiceHelper.GetText(colElements[5]).Trim() == taskName.Trim())
                    {
                        taskCount++;
                        if (taskCount == taskInstance)
                        {
                            colElements[12].FAFindElement(ByLocator.Id, "imgComment").FADoubleClick();
                            status = true;
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Task not found or some other error occurred :" + ex.Message, false);
                status = false;
            }
            return status;
        }

        private bool WaitForEnabled(IWebElement element = null)
        {
            Reports.TestStep = "Wait for the element until it becomes enabled.";

            //element = Principals;
            try
            {
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                //                element = element ?? FindNow;
                FastDriver.TermsDatesStatus.WaitCreation(element);
                FastDriver.TermsDatesStatus.Wait.Until(dr =>
                {
                    return element.IsEnabled();
                });
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }

        private long InvokeAddTaskOperation(AddTaskRequest request)
        {
            long response;
            try
            {
                Reports.TestStep = "Invoke AddTask operation and get the response.";
                response = ServiceFactory.GetFileService().AddTask(request);
            }
            catch (Exception ex)
            {
                throw new Exception("Invoking AddTask operation failed! Error : " + ex.Message);
            }
            return response;
        }

        private long InvokeUpdateTaskOperation(UpdateTaskRequest request)
        {
            long response;
            try
            {
                Reports.TestStep = "Invoke RemoveProduct operation and get the response.";
                response = ServiceFactory.GetFileService().UpdateTask(request);
            }
            catch (Exception ex)
            {
                throw new Exception("Invoking RemoveProduct operation failed! Error : " + ex.Message);
            }
            return response;
        }

        private int CreateFile()
        {
            int fileID;
            #region Create a file through WCF
            Reports.TestStep = "Create a file with required values through WCF.";
            var fileRequest = CreateFileRequest();

            var fileResponse = FASTWCFHelpers.FileService.CreateFile(fileRequest);
            fileID = (int)fileResponse.FileID;
            Support.IsTrue((int)(fileResponse.FileID ?? 0) > 0, "Is this FileId valid ? " + fileID);

            var fileDetails = FASTWCFHelpers.FileService.GetOrderDetails(fileID);
            Reports.TestStep = "Search File in MRU.";
            FastDriver.TopFrame.SearchFileByFileNumber(fileDetails.FileNumber);
            #endregion

            return fileID;
        }

        private AddTaskRequest CreateRequestForAddTask<T>(int fileID)
        {
            Reports.TestStep = "Construct AddProductRequest object.";
            var request = new FASTWCFHelpers.FastFileService.AddTaskRequest()
            {
                EmployeeID = 1,
                FileID = fileID,
                LoginName = "Fastts\\Fastqa07",
                ProcessID = 0,
                Source = "FAMOS",
                oTaskTemplate = new TaskTemplate()
                {
                    TaskCategoryID = 0,
                    TaskTemplateID = 0,
                    WorkflowTemplateID = 0
                },
            };
            return request;
        }

        private UpdateTaskRequest CreateRequestForUpdateTask<T>()
        {
            Reports.TestStep = "Construct RemoveProductRequest object.";
            var request = new FASTWCFHelpers.FastFileService.UpdateTaskRequest()
            {
                EmployeeID = 1,
                LoginName = "Fastts\\Fastqa07",
                NonPublishedTaskComments = "Non Pub Comment",
                PublishedTaskComments = "Pub Comment",
                Source = "FAMOS",
                TaskID = 1569300254,
                TaskOfficeID = 1487
            };
            return request;
        }

        private CreateFileRequest CreateFileRequest()
        {
            return new CreateFileRequest
            {
                EmployeeObjectCD = "1",
                Source = "FAMOS",
                formType = ClosingDisclosureSupport.FormType,
                File = new FASTWCFHelpers.FastFileService.File()
                {
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "Commercial",
                    ExternalFileNumber = "12345678905",
                    AutoNumberIndicator = true,

                    BusinessParties = new FileBusinessParty[]
                    {
                        new FileBusinessParty()
                        {
                            //AddrBookEntryID = AdminService.GetGABAddressBookEntryId("8835227"),
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE",
                        }
                    },

                    Services = new Service[]
                    {
                        new Service()
                        {
                            OfficeInfo = new OfficeInfo()
                            {
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID),
                                BUID = 1487,
                            },
                        ServiceTypeObjectCD = "TO"
                        },
                        new Service()
                        {
                            OfficeInfo = new OfficeInfo()
                            {
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID),
                                BUID = 1487,
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },

                    Properties = new Property[]
                    {
                        new Property()
                        {
                            Name = "my-test-property",
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[]
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress()
                                {
                                    State = "CA",
                                    City = "Santa Ana",
                                    County = "Orange",
                                    Country = "USA"
                                }
                            }
                        }
                    },
                }
            };
        }

        #endregion
    }
}
