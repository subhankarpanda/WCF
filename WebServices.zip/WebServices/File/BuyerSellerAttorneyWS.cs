﻿using FASTSelenium.Common;
using FASTWCFHelpers.FastFileService;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace WebServices.File
{
    [CodedUITest]
    public class BuyerSellerAttorney : FASTHelpers
    {
        [TestMethod]
        [Description("Verify CreateBuyerSellerAttorney service functionality")]
        public void REG_CreateBuyerSellerAttorney()
        {
            Reports.TestDescription = "Verify CreateBuyerSellerAttorney() service";

            #region FAST Login IIS side
            Reports.TestStep = "Login to IIS";
            FAST_Login_IIS();
            #endregion

            #region WCF Create File and open in FAST
            Reports.TestStep = @"Create a basic file";
            FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
            #endregion

            #region Create Buyer Seller Attorney
            Reports.TestStep = "Create Buyer Seller Attorney";
            var BSAttorneyRequest = RequestFactory.GetCreateBuyerSellerAttorneyRequest(File.FileID.ToString(), seqNum: 1, roleType: "BUYERATTY");
            var response = FASTWCFHelpers.FileService.CreateBuyerSellerAttorney(BSAttorneyRequest);
            Support.AreEqual("1", response.OperationResponse.Status.ToString(), response.OperationResponse.StatusDescription);
            #endregion

            #region Verify Buyer Seller Attorney is created in FAST
            Reports.TestStep = "Verify Buyer Seller Attorney is created in FAST";
            var chargeList = BSAttorneyRequest.CDChargeList[0];
            var chargeListAdhoc = BSAttorneyRequest.CDChargeList[1];
            double totalCharge = Convert.ToDouble(chargeList.SellerCharge) + Convert.ToDouble(chargeList.BuyerCharge) + Convert.ToDouble(chargeListAdhoc.SellerCharge) + Convert.ToDouble(chargeListAdhoc.BuyerCharge);

            FastDriver.AttorneyDetail.Open(true);
            FastDriver.AttorneyDetail.WaitForScreenToLoad();

            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.Type.FAGetSelectedItem().ToString(), "Attorney-Co-Counsel", true, true);
            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.BuyerCharge.FAGetValue(), chargeList.BuyerCharge.ToString(), true, true);
            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.SellerCharge.FAGetValue(), chargeList.SellerCharge.ToString(), true, true);
            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.ChargeDescription1.FAGetValue().ToString(), chargeListAdhoc.Description.ToString());
            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.BuyerCharge1.FAGetValue(), chargeListAdhoc.BuyerCharge.ToString(), true, true);
            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.SellerCharge1.FAGetValue(), chargeListAdhoc.SellerCharge.ToString(), true, true);

            FastDriver.AttorneyDetail.SellerAttorneyChargesTable.PerformTableAction(2, 2, TableAction.DoubleClick);
            // FastDriver.AttorneyDetail.SellerAttorneyChargesTable.PerformTableAction("Description", chargeList.BuyerCharge.ToString(), "Description", TableAction.DoubleClick);
            Playback.Wait(3000);
            ServiceHelper.ValidatePaymentAndGetCheckAMount(chargeList);
            FastDriver.AttorneyDetail.WaitForScreenToLoad();

            FastDriver.AttorneyDetail.SellerAttorneyChargesTable.PerformTableAction("Description", chargeListAdhoc.Description.ToString(), "Description", TableAction.DoubleClick);
            Playback.Wait(3000);
            ServiceHelper.ValidatePaymentAndGetCheckAMount(chargeListAdhoc);
            FastDriver.AttorneyDetail.WaitForScreenToLoad();


            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.TotalCharges.FAGetText(), "$" + totalCharge.ToString(), true, true);
            #endregion
        }
        
        [TestMethod]
        [Description("Verify GetBuyerSellerAttorneyDetails service functionality")]
        public void REG_GetBuyerSellerAttorneyDetails()
        {
            Reports.TestDescription = "Verify GetBuyerSellerAttorneyDetails() service";

            #region FAST Login IIS side
            Reports.TestStep = "Login to IIS";
            FAST_Login_IIS();
            #endregion

            #region WCF Create File and open in FAST
            Reports.TestStep = @"Create a basic file";
            FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
            #endregion

            #region Get Buyer Seller Attorney
            Reports.TestStep = "Get Buyer Seller Attorney";
            var BSAttorneyRequest = RequestFactory.GetCreateBuyerSellerAttorneyRequest(File.FileID.ToString(), seqNum: 1, roleType: "BUYERATTY");
            var response = FASTWCFHelpers.FileService.CreateBuyerSellerAttorney(BSAttorneyRequest);
            Support.AreEqual("1", response.OperationResponse.Status.ToString(), response.OperationResponse.StatusDescription);

            var BSAttorneyResponse = FASTWCFHelpers.FileService.GetBuyerSellerAttorneyDetails(File.FileID ?? 0);
            Support.AreEqual("1", BSAttorneyResponse.Status.ToString());
            #endregion

            #region Verify Buyer Seller Attorney details
            Reports.TestStep = "Verify Buyer Seller Attorney details";
            var chargeList = BSAttorneyResponse.BuyerAttorneyDetails[0].CDChargeList[0];
            var chargeListAdhoc = BSAttorneyResponse.BuyerAttorneyDetails[0].CDChargeList[1];
            double totalCharge = Convert.ToDouble(chargeList.SellerCharge) + Convert.ToDouble(chargeList.BuyerCharge) + Convert.ToDouble(chargeListAdhoc.SellerCharge) + Convert.ToDouble(chargeListAdhoc.BuyerCharge);

            FastDriver.AttorneyDetail.Open(true);
            FastDriver.AttorneyDetail.WaitForScreenToLoad();

            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.BuyerCharge.FAGetValue(), chargeList.BuyerCharge.ToString(), true, true);
            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.SellerCharge.FAGetValue(), chargeList.SellerCharge.ToString(), true, true);
            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.ChargeDescription1.FAGetValue(), chargeListAdhoc.Description.ToString());
            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.BuyerCharge1.FAGetValue(), chargeListAdhoc.BuyerCharge.ToString(), true, true);
            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.SellerCharge1.FAGetValue(), chargeListAdhoc.SellerCharge.ToString(), true, true);

            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.TotalCharges.FAGetText(), "$" + totalCharge.ToString(), true, true);

            FastDriver.AttorneyDetail.SellerAttorneyChargesTable.PerformTableAction(2, 2, TableAction.DoubleClick);
            // FastDriver.AttorneyDetail.SellerAttorneyChargesTable.PerformTableAction("Description", chargeList.BuyerCharge.ToString(), "Description", TableAction.DoubleClick);
            Playback.Wait(3000);
            ServiceHelper.ValidatePaymentAndGetCheckAMount(chargeList);
            FastDriver.AttorneyDetail.WaitForScreenToLoad();

            FastDriver.AttorneyDetail.SellerAttorneyChargesTable.PerformTableAction("Description", chargeListAdhoc.Description.ToString(), "Description", TableAction.DoubleClick);
            Playback.Wait(3000);
            ServiceHelper.ValidatePaymentAndGetCheckAMount(chargeListAdhoc);
            FastDriver.AttorneyDetail.WaitForScreenToLoad();
            #endregion
        }
        
        [TestMethod]
        [Description("Verify RemoveBuyerSellerAttorney service functionality")]
        public void REG_RemoveBuyerSellerAttorney()
        {
            Reports.TestDescription = "Verify RemoveBuyerSellerAttorney() service";

            #region FAST Login IIS side
            Reports.TestStep = "Login to IIS";
            FAST_Login_IIS();
            #endregion

            #region WCF Create File and open in FAST
            Reports.TestStep = @"Create a basic file";
            FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
            #endregion

            #region Create Buyer Seller Attorney
            Reports.TestStep = "Create Buyer Seller Attorney";
            var BSAttorneyRequest = RequestFactory.GetCreateBuyerSellerAttorneyRequest(File.FileID.ToString(), seqNum: 1, roleType: "BUYERATTY");
            var response = FASTWCFHelpers.FileService.CreateBuyerSellerAttorney(BSAttorneyRequest);
            Support.AreEqual("1", response.OperationResponse.Status.ToString(), response.OperationResponse.StatusDescription);
            #endregion

            #region Remove Buyer Seller Attorney
            Reports.TestStep = "Remove Buyer Seller Attorney";
            BSAttorneyRequest = RequestFactory.GetRemoveBuyerSellerAttorneyRequest(File.FileID.ToString(), seqNum: 1, roleType: "BUYERATTY");
            var BSAttorneyResponse = FASTWCFHelpers.FileService.RemoveBuyerSellerAttorney(BSAttorneyRequest);
            // new FastFileServiceClient().RemoveBuyerSellerAttorney(BSAttorneyRequest);
            Support.AreEqual("1", BSAttorneyResponse.OperationResponse.Status.ToString(), BSAttorneyResponse.OperationResponse.StatusDescription);
            #endregion

            #region Verify Buyer Seller Attorney is removed
            Reports.TestStep = "Verify Buyer Seller Attorney is removed";
            FastDriver.AttorneyDetail.Open(true);
            FastDriver.AttorneyDetail.WaitForScreenToLoad();

            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.BuyerCharge.FAGetValue(), "");
            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.SellerCharge.FAGetValue(), "");
            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.ChargeDescription1.FAGetValue(), "");
            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.BuyerCharge1.FAGetValue(), "");
            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.SellerCharge1.FAGetValue(), "");

            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.TotalCharges.FAGetText(), "0.00", true);
            #endregion
        }
        
        [TestMethod]
        [Description("Verify UpdateBuyerSellerAttorney service functionality")]
        public void REG_UpdateBuyerSellerAttorney()
        {
            Reports.TestDescription = "Verify CreateBuyerSellerAttorney() service";

            #region FAST Login IIS side
            Reports.TestStep = "Login to IIS";
            FAST_Login_IIS();
            #endregion

            #region WCF Create File and open in FAST
            Reports.TestStep = @"Create a basic file";
            FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
            #endregion

            #region Create Buyer Seller Attorney
            Reports.TestStep = "Create Buyer Seller Attorney";
            var BSAttorneyRequest = RequestFactory.GetCreateBuyerSellerAttorneyRequest(File.FileID.ToString(), seqNum: 1, roleType: "BUYERATTY");
            var response = FASTWCFHelpers.FileService.CreateBuyerSellerAttorney(BSAttorneyRequest);
            Support.AreEqual("1", response.OperationResponse.Status.ToString(), response.OperationResponse.StatusDescription);
            #endregion

            #region Update Buyer Seller Attorney
            Reports.TestStep = "Update Buyer Seller Attorney";
            BSAttorneyRequest = RequestFactory.GetUpdateBuyerSellerAttorneyRequest(File.FileID.ToString(), seqNum: 1, roleType: "BUYERATTY");
            response = FASTWCFHelpers.FileService.UpdateBuyerSellerAttorney(BSAttorneyRequest);
            Support.AreEqual("1", response.OperationResponse.Status.ToString(), response.OperationResponse.StatusDescription);
            #endregion

            #region Verify Buyer Seller Attorney
            Reports.TestStep = "Verify Buyer Seller Attorney";
            var chargeList = BSAttorneyRequest.CDChargeList[0];
            var chargeListAdhoc = BSAttorneyRequest.CDChargeList[1];
            double totalCharge = Convert.ToDouble(chargeList.SellerCharge) + Convert.ToDouble(chargeList.BuyerCharge) + Convert.ToDouble(chargeListAdhoc.SellerCharge) + Convert.ToDouble(chargeListAdhoc.BuyerCharge);

            FastDriver.AttorneyDetail.Open(true);
            FastDriver.AttorneyDetail.WaitForScreenToLoad();

            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.Type.FAGetSelectedItem().ToString(), "Attorney-Co-Counsel", true, true);
            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.BuyerCharge.FAGetValue(), chargeList.BuyerCharge.ToString(), true, true);
            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.SellerCharge.FAGetValue(), chargeList.SellerCharge.ToString(), true, true);
            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.ChargeDescription1.FAGetValue().ToString(), chargeListAdhoc.Description.ToString());
            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.BuyerCharge1.FAGetValue(), chargeListAdhoc.BuyerCharge.ToString(), true, true);
            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.SellerCharge1.FAGetValue(), chargeListAdhoc.SellerCharge.ToString(), true, true);

            FastDriver.AttorneyDetail.SellerAttorneyChargesTable.PerformTableAction(2, 2, TableAction.DoubleClick);
            // FastDriver.AttorneyDetail.SellerAttorneyChargesTable.PerformTableAction("Description", chargeList.BuyerCharge.ToString(), "Description", TableAction.DoubleClick);
            Playback.Wait(3000);
            ServiceHelper.ValidatePaymentAndGetCheckAMount(chargeList);
            FastDriver.AttorneyDetail.WaitForScreenToLoad();

            FastDriver.AttorneyDetail.SellerAttorneyChargesTable.PerformTableAction("Description", chargeListAdhoc.Description.ToString(), "Description", TableAction.DoubleClick);
            Playback.Wait(3000);
            ServiceHelper.ValidatePaymentAndGetCheckAMount(chargeListAdhoc);
            FastDriver.AttorneyDetail.WaitForScreenToLoad();

            ServiceHelper.CompareWithUI(FastDriver.AttorneyDetail.TotalCharges.FAGetText(), "$" + totalCharge.ToString(), true, true);
            #endregion
        }
    }
}
