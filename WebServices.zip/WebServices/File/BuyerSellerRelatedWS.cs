﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.DataObjects;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using WebServices.Helpers.File;

namespace WebServices.File
{
    [CodedUITest]
    public class BuyerSellerRelatedWS : MasterTestClass
    {

        #region BuyerSellerRelatedServices

        [TestMethod]
        public void REG_GetAdditionalInfoDetails()
        {

            try
            {
                Reports.TestDescription = "Verify GetAdditionalInfoDetails operation.";
                #region FAST Login IIS side
                FASTHelpers.FAST_Login_IIS();
                #endregion

                var fileID = CreateFile();
                Reports.TestStep = "[PRE-REQUISITE] Add a new Individual buyer.";
                BuyerSellerHelpers.AddBuyerSeller(fileID, 48, "BUYER");
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.BuyerSellerSummary>(@"Home>Order Entry>Buyers").WaitForScreenToLoad();
                Reports.StatusUpdate("Is Buyer Summary table displayed ?", FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.IsVisible());
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "Individual", 4, TableAction.DoubleClick);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();

                Reports.TestStep = "[PRE-REQUISITE] Add an Individual Authorized Signature.";
                FastDriver.BuyerSellerSetup.Expand(FastDriver.BuyerSellerSetup.IndividualAuthorizeddrop);
                FastDriver.BuyerSellerSetup.IndividualAuthorizedName.FASetText("test signature");
                FastDriver.BuyerSellerSetup.IndividualApply.FAClick();

                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Reports.TestStep = "[PRE-REQUISITE] Set the Langugae on Additional Info screen.";
                FastDriver.BuyerSellerSetup.btnAdditionalInfo.FAClick();
                FastDriver.BuyerSellerAdditionalInformation.LanguagePreference.FASelectItem("English");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "[PRE-REQUISTE] Invoke GetAuthorizedSignatures.";
                var authorizedSignaturesResponse = ServiceFactory.GetFileService().GetAuthorizedSignatures(fileID);
                Support.IsTrue(authorizedSignaturesResponse.authorizedSignatures.Length > 0, "AuthorizedSignatures is not an empty set");
                var individualPrincipleId = Convert.ToInt32(authorizedSignaturesResponse.authorizedSignatures[0].PrincipalID);
                Reports.StatusUpdate("GetAuthorizedSignatures operation invoked !", true);
                if (Convert.ToInt16(authorizedSignaturesResponse.Status).Equals(1))
                {

                }


                var request = new FASTWCFHelpers.FastFileService.AdditionalInfoRequest();
                request.PrincipalID = individualPrincipleId;
                request.LoginName = "fastts\\fastqa07";
                request.Source = "FAMOS";

                Reports.TestStep = "Invoke GetAdditionalInfoDetails operation.";
                var response = ServiceFactory.GetFileService().GetAdditionalInfoDetails(request);
                Reports.StatusUpdate("GetAdditionalInfoDetails operation invoked !", true);


                Reports.TestStep = "Verify the operation response.";
                Reports.StatusUpdate("Status = " + response.Status, Convert.ToInt16(response.Status).Equals(1));
                Reports.StatusUpdate("Status Description = " + response.StatusDescription, response.StatusDescription.ToLower().ToString().Contains("success"));

                Reports.TestStep = "Validate the outcome on UI. Navigate to Buyers screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.BuyerSellerSummary>(@"Home>Order Entry>Buyers").WaitForScreenToLoad();


                Reports.StatusUpdate("Is Buyer Summary table displayed ?", FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.IsVisible());
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "Individual", 4, TableAction.DoubleClick);

                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnAdditionalInfo.FAClick();
                FastDriver.BuyerSellerAdditionalInformation.WaitForScreenToLoad();
                Support.AreEqual("English", FastDriver.BuyerSellerAdditionalInformation.LanguagePreference.FAGetSelectedItem());
                if (response.LangPrefOther != null)
                    Support.AreEqual(response.LangPrefOther, FastDriver.BuyerSellerAdditionalInformation.LanguagePrefOther.FAGetValue());
            }
            catch { }
        }


        [TestMethod]
        public void REG_GetAKAService()
        {
            try
            {

                Reports.TestDescription = "Verify GetAdditionalInfoDetails operation.";
                #region FAST Login IIS side
                FASTHelpers.FAST_Login_IIS();
                #endregion

                var fileID = CreateFile();

                Reports.TestStep = "As a pre-requisite, add a new buyer of Individual type, add an authorized signature.";
                BuyerSellerHelpers.AddBuyerSeller(fileID, 48, "BUYER");
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.BuyerSellerSummary>(@"Home>Order Entry>Buyers").WaitForScreenToLoad();
                Reports.StatusUpdate("Is Buyer Summary table displayed ?", FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.IsVisible());
                //FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "Trust/Estate", 4, TableAction.DoubleClick);
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "Individual", 4, TableAction.DoubleClick);

                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnAKA.FAClick();
                FastDriver.AKANames.WaitForScreenToLoad();
                FastDriver.AKANames.SetDetails(new FASTSelenium.DataObjects.IIS.AkaParameters() { Aka = "AKA-1" });

                Reports.TestStep = "Invoke GetAKAService operation.";
                var response = ServiceFactory.GetFileService().GetAKAService(fileID);
                var AKANameID = response.AKAs[0].AKANameID;
                Reports.StatusUpdate("GetAKAService operation invoked !", true);


                //Reports.TestStep = "Verify the operation response.";
                //Reports.StatusUpdate("Status = " + response.Status, Convert.ToInt16(response.Status).Equals(1));
                //Reports.StatusUpdate("Status Description = " + response.StatusDescription, response.StatusDescription.ToLower().ToString().Contains("success"));


                Reports.TestStep = "Validate the outcome on UI. Navigate to Buyers screen.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.BuyerSellerSummary>(@"Home>Order Entry>Buyers").WaitForScreenToLoad();

                Reports.StatusUpdate("Is Buyer Summary table displayed ?", FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.IsVisible());
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "Individual", 4, TableAction.DoubleClick);

                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();


                FastDriver.BuyerSellerSetup.btnAKA.FAClick();
                FastDriver.AKANames.WaitForScreenToLoad();

                if (response.AKAs[0].ToString().Contains("1"))
                    Support.AreEqual("True", FastDriver.AKANames.UsedatSigning.IsSelected().ToString());
                else
                    Support.AreEqual("False", FastDriver.AKANames.UsedatSigning.IsSelected().ToString());

                Support.AreEqual(response.AKAs[0].Name, FastDriver.AKANames.AKA.FAGetValue());
            }
            catch (Exception)
            {
                
            }
        }
        #endregion

        
        #region Private Functions
        private CreateFileRequest CreateFileRequest()
        {
            return new CreateFileRequest
            {
                EmployeeObjectCD = "1",
                Source = "FAMOS",
                formType = ClosingDisclosureSupport.FormType,
                File = new FASTWCFHelpers.FastFileService.File()
                {
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "Commercial",
                    ExternalFileNumber = "12345678905",
                    AutoNumberIndicator = true,

                    BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            //AddrBookEntryID = AdminService.GetGABAddressBookEntryId("8835227"),
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE",
                        } 
                    },

                    Services = new Service[] 
                    { 
                        new Service() 
                        { 
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = 1487,
                            },
                        ServiceTypeObjectCD = "TO" 
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = 1487, 
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },

                    Properties = new Property[] 
                    { 
                        new Property() 
                        {
                            Name = "my-test-property",
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    State = "CA", 
                                    City = "Santa Ana", 
                                    County = "Orange", 
                                    Country = "USA" 
                                } 
                            } 
                        } 
                    },
                }
            };
        }

        private int CreateFile()
        {
            int fileID;
            #region Create a file through WCF
            Reports.TestStep = "Create a file with required values through WCF.";
            var fileRequest = CreateFileRequest();

            var fileResponse = FASTWCFHelpers.FileService.CreateFile(fileRequest);
            fileID = (int)fileResponse.FileID;
            Support.IsTrue((int)(fileResponse.FileID ?? 0) > 0, "Is this FileId valid ? " + fileID);

            var fileDetails = FASTWCFHelpers.FileService.GetOrderDetails(fileID);
            Reports.TestStep = "Search File in MRU.";
            FastDriver.TopFrame.SearchFileByFileNumber(fileDetails.FileNumber);
            #endregion

            return fileID;
        }
        #endregion
    }
}

