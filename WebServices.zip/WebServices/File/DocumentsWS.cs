﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using WebServices.Helpers.File;

namespace WebServices.File
{
    [CodedUITest]
    public class DocumentsWS : MasterTestClass
    {

        #region REG0001_CopyDocuments
        [TestMethod]
        public void REG0001_CopyDocuments()
        {
            try
            {
                Reports.TestDescription = "Validate CopyDocuments web method";

                Reports.TestStep = "Create starter file (WS)";
                int starterFileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string starterFileNumber = FASTWCFHelpers.FileService.GetOrderDetails(starterFileID).FileNumber;

                Reports.TestStep = "Create documents on starter file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int[] docIDs = new int[] { Convert.ToInt32(DocumentsHelpers.CreateDocument(starterFileID, templateID).DocumentID) };

                Reports.TestStep = "Create target file (WS)";
                int targetFileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string targetFileNumber = FASTWCFHelpers.FileService.GetOrderDetails(targetFileID).FileNumber;

                Reports.TestStep = "Copy document from starter file to target file (WS)";
                Support.AreEqual("1", DocumentsHelpers.CopyDocuments(starterFileNumber, targetFileNumber, docIDs).Status.ToString(), "Validate status operation");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to target file";
                FastDriver.TopFrame.SearchFileByFileNumber(targetFileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate document " + templateName + " is present";
                FastDriver.DocumentRepository.Open();
                Support.AreEqual(templateName, FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(9, "Created", 4, TableAction.GetText).Message, templateName);

                Reports.TestStep = "Navigate to event tracking log, validate [Starter Ref Copy Documents Completed] event";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqual("Starter Ref Copy Doc from \"" + starterFileNumber + "\" to \"" + targetFileNumber + "\" completed.", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Starter Ref Copy Documents Completed]", 5, TableAction.GetText).Message, "[Starter Ref Copy Documents Completed]");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region REG0002_AddPhrasesToDocument
        [TestMethod]
        public void REG0002_AddPhrasesToDocument()
        {
            try
            {
                Reports.TestDescription = "Validate AddPhrasesToDocument web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Add a phrase to the document (WS), validate response";
                var response = DocumentsHelpers.AddPhrasesToDocument(fileID: fileID, docID: docID, phraseCode: @"XRL/15");
                Support.AreEqual("1", response.Status.ToString(), "Validate status operation");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to event tracking log, validate [Update Document] event";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqual("Phrase(s) added successfully.DocumentID: " + docID.ToString() + " Document Name: " + templateName, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Update Document]", 5, TableAction.GetText).Message, "[Update Document]");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region REG0003_GetDocPrepDocument
        [TestMethod]
        public void REG0003_GetDocPrepDocument()
        {
            try
            {
                Reports.TestDescription = "Validate GetDocPrepDocument web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Invoke SubmitDocRequest service (WS)";
                int docRequestID = DocumentsHelpers.SubmitDocRequest(fileID: fileID, docID: docID);
                Thread.Sleep(10000);

                Reports.TestStep = "Invoke GetDocPrepDocument service and validate response (WS)";
                var response = DocumentsHelpers.GetDocPrepDocument(docRequestID: docRequestID);

                if (response.StatusMessage.ToString() != "Success")
                {
                    Thread.Sleep(10000); // wait 10 seconds and try again if status is not equal Success
                    response = DocumentsHelpers.GetDocPrepDocument(docRequestID: docRequestID);
                }

                Support.AreEqual("Success", response.StatusMessage.ToString(), "Status Message");
                Support.AreEqual(docRequestID.ToString(), response.DocRequestID.ToString(), "Document Request ID");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { }
        }
        #endregion

        #region REG0004_GetDocTemplates
        [TestMethod]
        public void REG0004_GetDocTemplates()
        {
            try
            {
                Reports.TestDescription = "Validate GetDocTemplates web method";

                Reports.TestStep = "Invoke GetDocTemplates and validate the response (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                Support.AreEqual("", response.Status.ToString(), "Response Status");
                Support.AreNotEqual("0", response.Templates.Count().ToString(), "Template count is not zero");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { }
        }
        #endregion

        #region REG0005_CreateImageDocument
        [TestMethod]
        public void REG0005_CreateImageDocument()
        {
            try
            {
                Reports.TestDescription = "Validate CreateImageDocument web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Invoke CreateImageDocument web method and validate response (WS)";
                var response = DocumentsHelpers.CreateImageDocument(fileID: fileID, docID: docID);
                Support.AreEqual("1", response.Status.ToString(), "Validate status operation");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate image document " + templateName + " is created";
                FastDriver.DocumentRepository.Open();
                Support.AreEqual(templateName, FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(9, "Imaged", 4, TableAction.GetText).Message, templateName);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region REG0006_GetDocumentDetails
        [TestMethod]
        public void REG0006_GetDocumentDetails()
        {
            try
            {
                Reports.TestDescription = "Validate GetDocumentDetails web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Invoke GetDocumentsDetails web method and validate response (WS)";
                var response = DocumentsHelpers.GetDocumentDetails(fileID: fileID, docID: docID);
                Support.AreEqual(templateName, response.DocName, "Document Name");
                Support.AreEqual(docID.ToString(), response.DocumentID.ToString(), "Document ID");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { }
        }
        #endregion

        #region REG0007_GetDocumentsForStarterRef
        [TestMethod]
        public void REG0007_GetDocumentsForStarterRef()
        {
            try
            {
                Reports.TestDescription = "Validate GetDocumentsForStarterRef web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                var GetDefaultDocTemplatesResponse = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID = Convert.ToInt32(GetDefaultDocTemplatesResponse.Templates[0].TemplateID);
                string templateName = GetDefaultDocTemplatesResponse.Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Invoke GetDocumentsForStarterRef web method and validate response (WS)";
                var response = DocumentsHelpers.GetDocumentsForStarterRef(fileID);
                string docName = "";

                for (int i = 0; i < response.Documents.Count(); i++)
                {
                    if (response.Documents[i].DocumentID == docID)
                    {
                        docName = response.Documents[i].DocumentName;
                        break;
                    }
                }

                Support.AreEqual(templateName, docName, "Document Name");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { }
        }
        #endregion

        #region REG0008_GetImageDocument
        [TestMethod]
        public void REG0008_GetImageDocument()
        {
            try
            {
                Reports.TestDescription = "Validate GetImageDocument web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Invoke CreateImageDocument web method and validate response (WS)";
                DocumentsHelpers.CreateImageDocument(fileID: fileID, docID: docID);
                Thread.Sleep(10000); // wait for image document to be created

                Reports.TestStep = "Get image document ID (WS)";
                if (DocumentsHelpers.GetDocuments(fileID).Images.Count() == 0)
                    Thread.Sleep(10000);

                int imageDocID = (int)DocumentsHelpers.GetDocuments(fileID).Images[0].ImageDocumentID;

                Reports.TestStep = "Invoke GetImageDocument web method and validate response (WS)";
                var response = DocumentsHelpers.GetImageDocument(imageDocID);
                Support.AreEqual("1", response.Status.ToString(), "Operation Status");
                Support.AreEqual("Successful.", response.StatusDescription.ToString(), "Operation Status Description");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { }
        }
        #endregion

        #region REG0009_GetImageDocumentDetails
        [TestMethod]
        public void REG0009_GetImageDocumentDetails()
        {
            try
            {
                Reports.TestDescription = "Validate GetImageDocumentDetails web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Invoke CreateImageDocument web method and validate response (WS)";
                DocumentsHelpers.CreateImageDocument(fileID: fileID, docID: docID);
                Thread.Sleep(10000); // wait for image document to be created

                Reports.TestStep = "Get image document ID (WS)";
                if (DocumentsHelpers.GetDocuments(fileID).Images.Count() == 0)
                    Thread.Sleep(10000);

                int imageDocID = (int)DocumentsHelpers.GetDocuments(fileID).Images[0].ImageDocumentID;

                Reports.TestStep = "Invoke GetImageDocumentDetails web method and validate response (WS)";
                var response = DocumentsHelpers.GetImageDocumentDetails(fileID, imageDocID);
                Support.AreEqual("1", response.StatusCD.ToString(), "Operation Status");
                Support.AreEqual(templateName, response.ImageName, "Image File Name");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { }
        }
        #endregion

        #region REG0010_GetImageDocument2
        [TestMethod]
        public void REG0010_GetImageDocument2()
        {
            try
            {
                Reports.TestDescription = "Validate GetImageDocument2 web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Invoke CreateImageDocument web method and validate response (WS)";
                DocumentsHelpers.CreateImageDocument(fileID: fileID, docID: docID);
                Thread.Sleep(10000); // wait for image document to be created

                Reports.TestStep = "Get image document ID (WS)";
                if (DocumentsHelpers.GetDocuments(fileID).Images.Count() == 0)
                    Thread.Sleep(10000);

                int imageDocID = (int)DocumentsHelpers.GetDocuments(fileID).Images[0].ImageDocumentID;

                Reports.TestStep = "Invoke GetImageDocument2 web method and validate response (WS)";
                var response = DocumentsHelpers.GetImageDocument2(imageDocID);
                Support.AreEqual(imageDocID.ToString(), response.ImageDocumentID.ToString(), "Image Document ID");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { }
        }
        #endregion

        #region REG0011_GetDocuments
        [TestMethod]
        public void REG0011_GetDocuments()
        {
            try
            {
                Reports.TestDescription = "Validate GetDocuments web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Invoke GetDocuments web method and validate response (WS)";
                var response = DocumentsHelpers.GetDocuments(fileID);
                Support.AreEqual(templateName, response.Documents[0].DocumentName, "Document Name");
                Support.AreEqual(docID.ToString(), response.Documents[0].DocumentID.ToString(), "Document ID");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { }
        }
        #endregion

        #region REG0012_GetStateListForDocTemplate
        [TestMethod]
        public void REG0012_GetStateListForDocTemplate()
        {
            try
            {
                Reports.TestDescription = "Validate GetStateListForDocTemplate web method";

                Reports.TestStep = "Get default template ID (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);

                Reports.TestStep = "Invoke GetStateListForDocTemplate web method and validate response (WS)";
                var response = DocumentsHelpers.GetStateListForDocTemplate(templateID);
                Support.AreEqual("1", response.Status.ToString(), "Operation Status");
                Support.AreEqual("Template States Loaded succesfully.", response.StatusDescription, "Operation Status Description");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { }
        }
        #endregion

        #region REG0013_RemoveDocument
        [TestMethod]
        public void REG0013_RemoveDocument()
        {
            try
            {
                Reports.TestDescription = "Validate RemoveDocument web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID = Convert.ToInt32(response.Templates[0].TemplateID);
                string templateName = response.Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Invoke RemoveDocument method and validate response (WS)";
                var RemoveDocumentResponse = DocumentsHelpers.RemoveDocument(fileID, docID);
                Support.AreEqual("1", RemoveDocumentResponse.Status.ToString(), "Operation Status");
                Support.AreEqual(true, RemoveDocumentResponse.StatusDescription.ToString().Contains("Status: Successful"), "Operation Status Description");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { }
        }
        #endregion

        #region REG0014_SubmitDocRequest
        [TestMethod]
        public void REG0014_SubmitDocRequest()
        {
            try
            {
                Reports.TestDescription = "Validate SubmitDocRequest web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID = Convert.ToInt32(response.Templates[0].TemplateID);
                string templateName = response.Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Invoke SubmitDocRequest web method and validate response (WS)";
                Support.AreNotEqual("-1", DocumentsHelpers.SubmitDocRequest(fileID: fileID, docID: docID).ToString(), "Document Request ID is not -1");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { }
        }
        #endregion

        #region REG0015_CreateDocument
        [TestMethod]
        public void REG0015_CreateDocument()
        {
            try
            {
                Reports.TestDescription = "Validate CreateDocument web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID = Convert.ToInt32(response.Templates[0].TemplateID);
                string templateName = response.Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to target file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate document " + templateName + " is present";
                FastDriver.DocumentRepository.Open();
                Support.AreEqual(templateName, FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(9, "Created", 4, TableAction.GetText).Message, templateName);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region REG0016_EditDocument
        [TestMethod]
        public void REG0016_EditDocument()
        {
            try
            {
                Reports.TestDescription = "Validate EditDocument web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID = Convert.ToInt32(response.Templates[0].TemplateID);
                string templateName = response.Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Edit document name and validate response (WS)";
                var editDocResponse = DocumentsHelpers.EditDocument(fileID, docID, "Edit Document Name");
                Support.AreEqual("1", editDocResponse.Status.ToString(), "Operation Status");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate document name has changed";
                FastDriver.DocumentRepository.Open();
                Support.AreEqual("Edit Document Name", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(9, "Created", 4, TableAction.GetText).Message, "Edit Document Name");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region REG0017_FinalizeDocument
        [TestMethod]
        public void REG0017_FinalizeDocument()
        {
            try
            {
                Reports.TestDescription = "Validate FinalizeDocument web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID = Convert.ToInt32(response.Templates[0].TemplateID);
                string templateName = response.Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Finalize the document and validate response(WS)";
                var finalizeDocResponse = DocumentsHelpers.FinalizeDocument(fileID, docID);
                Support.AreEqual("1", finalizeDocResponse.Status.ToString(), "Status Operation");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate document is finalized";
                FastDriver.DocumentRepository.Open();
                Support.AreEqual("Finalized", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, templateName, 9, TableAction.GetText).Message, templateName);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region REG0018_UpdateDocument
        [TestMethod]
        public void REG0018_UpdateDocument()
        {
            try
            {
                Reports.TestDescription = "Validate UpdateDocument web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID = Convert.ToInt32(response.Templates[0].TemplateID);
                string templateName = response.Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Update the document and validate response(WS)";
                var updateDocResponse = DocumentsHelpers.UpdateDocument(fileID, docID);
                Support.AreEqual("Document updated Successfully.DocumentID: " + docID + " Document Name: " + templateName, updateDocResponse.StatusDescription, "Status Description");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { }
        }
        #endregion

        #region REG0019_UnFinalizeDocument
        [TestMethod]
        public void REG0019_UnFinalizeDocument()
        {
            try
            {
                Reports.TestDescription = "Validate UnFinalizeDocument web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID = Convert.ToInt32(response.Templates[0].TemplateID);
                string templateName = response.Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Finalize the document and validate response(WS)";
                var finalizeDocResponse = DocumentsHelpers.FinalizeDocument(fileID, docID);
                Support.AreEqual("1", finalizeDocResponse.Status.ToString(), "Status Operation");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate document is finalized";
                FastDriver.DocumentRepository.Open();
                Support.AreEqual("Finalized", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, templateName, 9, TableAction.GetText).Message, templateName);

                Reports.TestStep = "UnFinalize the document and validate response(WS)";
                var unfinalizeDocResponse = DocumentsHelpers.UnfinalizeDocument(fileID, docID);
                Support.AreEqual("1", unfinalizeDocResponse.Status.ToString(), "Status Operation");

                Reports.TestStep = "Navigate to Document Repository, validate document is infinalized";
                FastDriver.DocumentRepository.Open();
                Support.AreEqual("Edited", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(4, templateName, 9, TableAction.GetText).Message, templateName);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region REG0020_DeletePhrases
        [TestMethod]
        public void REG0020_DeletePhrases()
        {
            try
            {
                Reports.TestDescription = "Validate DeletePhrases web method";

                #region Create a file using WS.
                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Add a document to the file using WS
                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;
                #endregion

                #region Add a phrase to the document using WS and validate response.
                Reports.TestStep = "Add a phrase to the document (WS), validate response";
                var response = DocumentsHelpers.AddPhrasesToDocument(fileID: fileID, docID: docID, phraseCode: @"XRL/15");
                Support.AreEqual("1", response.Status.ToString(), "Validate status operation");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to event tracking log, validate [Update Document] event";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqual("Phrase(s) added successfully.DocumentID: " + docID.ToString() + " Document Name: " + templateName, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Update Document]", 5, TableAction.GetText).Message, "[Update Document]");
                #endregion

                #region Delete the added phrase using web method.
                Reports.TestStep = "Get the added document details for getting the phrase id.";
                var docDtlRespnc = new DocumentDetailsResponse();
                docDtlRespnc = DocumentsHelpers.GetDocumentDetails(fileID, docID);

                Reports.TestStep = "Remove the added phrase from the document using the WS.";
                string phraseName = docDtlRespnc.Phrases[1].PhraseGrpCode + "/" + docDtlRespnc.Phrases[1].Code;
                DocumentsHelpers.DeletePhraseFromDocument(fileID, docID, Convert.ToInt64(docDtlRespnc.Phrases[1].DocPhraseID));
                #endregion

                #region Verfiy the deletion of the phrase in file side.
                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                Reports.TestStep = "Navigate to Document repository page and select the document.";
                FastDriver.DocumentRepository.Open();
                List<string> documentsToselet = new List<string> { docDtlRespnc.DocName };
                FastDriver.DocumentRepository.SelectDocumentsByName(documentsToselet);
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Verify whether the phrase has been deleted.";
                FastDriver.DocumentPreparation.WaitForScreenToLoad();
                string tableContent = FastDriver.DocumentPreparation.PhraseTable.FAGetText();
                Support.AreEqual(true, !tableContent.Contains(phraseName), "Verification of deletion of Phrase from the list.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region REG0021_UpdatePhrase
        [TestMethod]
        public void REG0021_UpdatePhrase()
        {
            try
            {
                Reports.TestDescription = "Validate UpdatePhrases web method";
                #region Create a file using WS.
                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Add a document to the file using WS
                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;
                #endregion

                #region Add a phrase to the document using WS and validate response.
                Reports.TestStep = "Add a phrase to the document (WS), validate response";
                var response = DocumentsHelpers.AddPhrasesToDocument(fileID: fileID, docID: docID, phraseCode: @"XRL/15");
                Support.AreEqual("1", response.Status.ToString(), "Validate status operation");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to event tracking log, validate [Update Document] event";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqual("Phrase(s) added successfully.DocumentID: " + docID.ToString() + " Document Name: " + templateName, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Update Document]", 5, TableAction.GetText).Message, "[Update Document]");
                #endregion

                #region Update the added phrase using web method.
                Reports.TestStep = "Get the added document details for getting the phrase id.";
                var docDtlRespnc = new DocumentDetailsResponse();
                docDtlRespnc = DocumentsHelpers.GetDocumentDetails(fileID, docID);

                Reports.TestStep = "Update the added phrase from the document using the WS.";
                string phraseName = docDtlRespnc.Phrases[1].PhraseGrpCode + "/" + docDtlRespnc.Phrases[1].Code;
                string phraseProp = docDtlRespnc.Phrases[1].Name;
                var response1 = DocumentsHelpers.UpdatePhraseOfDocument(fileID, docID, Convert.ToInt64(docDtlRespnc.Phrases[1].DocPhraseID));
                bool status = response1.Status == 1 ? true : false;
                Reports.StatusUpdate(response1.StatusDescription + status.ToString(), status, expectedValue: "True", actualValue: status.ToString());
                #endregion

                #region Verfiy the update of the phrase in file side.
                Reports.TestStep = "Navigate to the event log page and verify that phrase has been updated.";
                FastDriver.EventTrackingLog.Open();
                string commentStrng = FastDriver.EventTrackingLog.GetCommentForEvent("[Update Document]").Replace("\r\n", string.Empty);
                Support.AreEqual("DocPhrase:" + phraseProp + "Status:Successful", commentStrng, "Phrase is updated successfuly.");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region REG0022_MovePhrases
        [TestMethod]
        public void REG0022_MovePhrases()
        {
            try
            {
                Reports.TestDescription = "Validate MovePhrases web method";
                #region Create a file using WS.
                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Add a document to the file using WS
                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;
                #endregion

                #region Add a phrase to the document using WS and validate response.
                Reports.TestStep = "Add a phrase to the document (WS), validate response";
                var response = DocumentsHelpers.AddPhrasesToDocument(fileID: fileID, docID: docID, phraseCode: @"XRL/15");
                Support.AreEqual("1", response.Status.ToString(), "Validate status operation");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to event tracking log, validate [Update Document] event";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqual("Phrase(s) added successfully.DocumentID: " + docID.ToString() + " Document Name: " + templateName, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Update Document]", 5, TableAction.GetText).Message, "[Update Document]");
                #endregion

                #region Get the added phrase details and sequence using web method.
                Reports.TestStep = "Get the added document details for getting the phrase id.";
                DocumentDetailsResponse docDtlRespnc = new DocumentDetailsResponse();
                docDtlRespnc = DocumentsHelpers.GetDocumentDetails(fileID, docID);

                Reports.TestStep = "Get the sequence of the Phrases under the document.";
                Dictionary<string, int> phraseSeqWS = this.GetPhraseSequence(docDtlRespnc);

                Reports.TestStep = "Get the phrase id for which you want to move the sequence.";
                long phraseID = Convert.ToInt64(docDtlRespnc.Phrases[1].DocPhraseID);
                #endregion

                #region Move to the File side and verify the existing sequence of phrases.
                Reports.TestStep = "Navigate to the Document Repository page and verify the sequence of the phrases.";
                FastDriver.DocumentRepository.Open();
                List<string> documentsToselet = new List<string> { docDtlRespnc.DocName };
                FastDriver.DocumentRepository.SelectDocumentsByName(documentsToselet);
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Click on Move Phrases Option and get the existing sequence of phrases in UI.";
                Support.SendKeys("%P");
                Support.SendKeys("%o");
                FastDriver.PhraseResequenceDlg.WaitForScreenToLoad();
                Dictionary<string, int> phraseSeqUI = FastDriver.PhraseResequenceDlg.GetPhraseSequence();
                FastDriver.DialogBottomFrame.ClickDone();
                bool result = phraseSeqUI.SequenceEqual(phraseSeqWS);
                Reports.StatusUpdate("Verifying the sequence of phrases in UI and webservice: " + result.ToString(), result, expectedValue: "True", actualValue: result.ToString());
                #endregion

                #region Invoke the Move Phrase webservice and verify.
                Reports.TestStep = "Invoke the move phrase document web service.";
                response = DocumentsHelpers.MovePhraseOfDocument(docDtlRespnc);

                Reports.TestStep = "Get the document details and phrase details and verify whether the sequence of the phrase has been changed.";
                Dictionary<string, int> phraseSeqWSNew = this.GetPhraseSequence(DocumentsHelpers.GetDocumentDetails(fileID, docID));
                result = phraseSeqWSNew.SequenceEqual(phraseSeqWS);
                Reports.StatusUpdate("Verifying the sequence of phrases is changed: " + (!result).ToString(), !result);
                #endregion

                #region Verify changed sequence of phrases in UI.
                Reports.TestStep = "Navigate to the Document Repository page and verify the sequence of the phrases.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.SelectDocumentsByName(documentsToselet);
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Click on Move Phrases Option and get the existing sequence of phrases in UI.";
                Support.SendKeys("%P");
                Support.SendKeys("%o");
                FastDriver.PhraseResequenceDlg.WaitForScreenToLoad();
                Dictionary<string, int> phraseSeqUINew = FastDriver.PhraseResequenceDlg.GetPhraseSequence();
                FastDriver.DialogBottomFrame.ClickDone();
                result = phraseSeqUINew.SequenceEqual(phraseSeqWSNew);
                Reports.StatusUpdate("Verifying the sequence of phrases is changed in UI: " + (result).ToString(), result, expectedValue: "True", actualValue: result.ToString());
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region REG0023_UploadImage
        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void REG0023_UploadImage()
        {
            try
            {
                Reports.TestDescription = "Validate UploadImage web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Upload TIF file to file, validate response (WS)";
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                var response = DocumentsHelpers.UploadImage(fileID, "UploadImage TIF", ".TIF", 7, filePath);
                Support.AreEqual("1", response.Status.ToString(), "Status Operation");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to target file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                Thread.Sleep(10000);

                Reports.TestStep = "Navigate to Document Repository, validate image file is present";
                FastDriver.DocumentRepository.Open();
                Support.AreEqual("UploadImage TIF", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(9, "Active", 4, TableAction.GetText).Message, "UploadImage TIF");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region REG0024_UploadImage2
        [TestMethod, DeploymentItem(@"Common\Support\LoadTestImage 513k.tif")]
        public void REG0024_UploadImage2()
        {
            try
            {
                Reports.TestDescription = "Validate UploadImage2 web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Upload TIF file to file, validate response (WS)";
                string filePath = Reports.DEPLOYDIR + @"\LoadTestImage 513k.tif";
                var response = DocumentsHelpers.UploadImage2(fileID, "UploadImage2 TIF", ".TIF", 7, filePath);
                Support.AreEqual("1", response.Status.ToString(), "Status Operation");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to target file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                Thread.Sleep(10000);

                Reports.TestStep = "Navigate to Document Repository, validate image file is present";
                FastDriver.DocumentRepository.Open();
                Support.AreEqual("UploadImage2 TIF", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(9, "Active", 4, TableAction.GetText).Message, "UploadImage2 TIF");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region REG0025_CreateAssociateDocPackage
        [TestMethod]
        public void REG0025_CreateAssociateDocPackage()
        {
            try
            {
                Reports.TestDescription = "Validate CreateAssociateDocPackage web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add three documents to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID_1 = Convert.ToInt32(response.Templates[0].TemplateID);
                int templateID_2 = Convert.ToInt32(response.Templates[1].TemplateID);
                int templateID_3 = Convert.ToInt32(response.Templates[2].TemplateID);

                int docID_1 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_1).DocumentID;
                int docID_2 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_2).DocumentID;
                int docID_3 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_3).DocumentID;

                Document[] docs = new Document[]
                {
                    new Document()
                    {
                        DocumentID = docID_1
                    },
                    new Document()
                    {
                        DocumentID = docID_2
                    },
                    new Document()
                    {
                        DocumentID = docID_3
                    }
                };

                Reports.TestStep = "Create Associate Doc Package and validate response (WS)";
                var CreateAssociateDocPackageResponse = DocumentsHelpers.CreateAssociateDocPackage(fileID, docs, "TestAssociateDocPackage");
                Support.AreEqual("1", CreateAssociateDocPackageResponse.Status.ToString(), "Status Operation");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate the associate package is present";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.AssociateDocsTab.FAClick();
                FastDriver.DocumentRepository.WaitForAssociateDocTabToLoad();
                Support.AreEqual("TestAssociateDocPackage", FastDriver.DocumentRepository.AssPackageTable.PerformTableAction(1, 1, TableAction.GetText).Message, "Package Name");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region REG0026_GetAssociateDocPackages
        [TestMethod]
        public void REG0026_GetAssociateDocPackages()
        {
            try
            {
                Reports.TestDescription = "Validate GetAssociateDocPackages web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add three documents to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID_1 = Convert.ToInt32(response.Templates[0].TemplateID);
                int templateID_2 = Convert.ToInt32(response.Templates[1].TemplateID);
                int templateID_3 = Convert.ToInt32(response.Templates[2].TemplateID);

                int docID_1 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_1).DocumentID;
                int docID_2 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_2).DocumentID;
                int docID_3 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_3).DocumentID;

                Document[] docs = new Document[]
                {
                    new Document()
                    {
                        DocumentID = docID_1
                    },
                    new Document()
                    {
                        DocumentID = docID_2
                    },
                    new Document()
                    {
                        DocumentID = docID_3
                    }
                };

                Reports.TestStep = "Create Associate Doc Package (WS)";
                DocumentsHelpers.CreateAssociateDocPackage(fileID, docs, "TestAssociateDocPackage");

                Reports.TestStep = "Invoke GetAssociateDocPackage and validate response (WS)";
                var GetAssociateDocPackagesResponse = DocumentsHelpers.GetAssociateDocPackages(fileID);
                Support.AreEqual("TestAssociateDocPackage", GetAssociateDocPackagesResponse.PackageList[0].PackageName, "Package Name");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { }
        }
        #endregion

        #region REG0027_AddDocumentsToAssociateDocPackage
        [TestMethod]
        public void REG0027_AddDocumentsToAssociateDocPackage()
        {
            try
            {
                Reports.TestDescription = "Validate AddDocumentsToAssociateDocPackage web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add four documents to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID_1 = Convert.ToInt32(response.Templates[0].TemplateID);
                int templateID_2 = Convert.ToInt32(response.Templates[1].TemplateID);
                int templateID_3 = Convert.ToInt32(response.Templates[2].TemplateID);
                int templateID_4 = Convert.ToInt32(response.Templates[3].TemplateID);

                int docID_1 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_1).DocumentID;
                int docID_2 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_2).DocumentID;
                int docID_3 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_3).DocumentID;
                int docID_4 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_4).DocumentID;
                string docName_4 = response.Templates[3].Descr;

                Document[] docs = new Document[]
                {
                    new Document()
                    {
                        DocumentID = docID_1
                    },
                    new Document()
                    {
                        DocumentID = docID_2
                    },
                    new Document()
                    {
                        DocumentID = docID_3
                    }
                };

                Reports.TestStep = "Create Associate Doc Package with the first three documents(WS)";
                var CreateAssociateDocPackageResponse = DocumentsHelpers.CreateAssociateDocPackage(fileID, docs, "TestAssociateDocPackage");
                long packageID = CreateAssociateDocPackageResponse.AssociateDocPackageID;

                Reports.TestStep = "Invoke AddDocumentsToAssociateDocPackage and validate response (WS)";
                Document[] docs2 = new Document[]
                {
                    new Document()
                    {
                        DocumentID = docID_4
                    }
                };
                var addDocResponse = DocumentsHelpers.AddDocumentsToAssociateDocPackage(fileID, docs2, packageID);
                Support.AreEqual("1", addDocResponse.Status.ToString(), "Operation Status");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate the new document is added to the package";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.AssociateDocsTab.FAClick();
                FastDriver.DocumentRepository.WaitForAssociateDocTabToLoad();
                Support.AreEqual(docName_4, FastDriver.DocumentRepository.PackageDocumentsTable.PerformTableAction(4, 1, TableAction.GetText).Message, "Document Name");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }


        }
        #endregion

        #region REG0028_RemoveDocumentsFromAssociateDocPackage
        [TestMethod]
        public void REG0028_RemoveDocumentsFromAssociateDocPackage()
        {
            try
            {
                Reports.TestDescription = "Validate RemoveDocumentsFromAssociateDocPackage web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add four documents to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID_1 = Convert.ToInt32(response.Templates[0].TemplateID);
                int templateID_2 = Convert.ToInt32(response.Templates[1].TemplateID);
                int templateID_3 = Convert.ToInt32(response.Templates[2].TemplateID);
                int templateID_4 = Convert.ToInt32(response.Templates[3].TemplateID);

                int docID_1 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_1).DocumentID;
                int docID_2 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_2).DocumentID;
                int docID_3 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_3).DocumentID;
                int docID_4 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_4).DocumentID;
                string docName_4 = response.Templates[3].Descr;

                Document[] docs = new Document[]
                {
                    new Document()
                    {
                        DocumentID = docID_1
                    },
                    new Document()
                    {
                        DocumentID = docID_2
                    },
                    new Document()
                    {
                        DocumentID = docID_3
                    }
                };

                Reports.TestStep = "Create Associate Doc Package with the first three documents(WS)";
                var CreateAssociateDocPackageResponse = DocumentsHelpers.CreateAssociateDocPackage(fileID, docs, "TestAssociateDocPackage");
                long packageID = CreateAssociateDocPackageResponse.AssociateDocPackageID;

                Reports.TestStep = "Invoke AddDocumentsToAssociateDocPackage (WS)";
                Document[] docs2 = new Document[]
                {
                    new Document()
                    {
                        DocumentID = docID_4
                    }
                };
                DocumentsHelpers.AddDocumentsToAssociateDocPackage(fileID, docs2, packageID);

                Reports.TestStep = "Invoke RemoveDocumentsFromAssociateDocPackage and valiate response (WS)";
                var removeDocResponse = DocumentsHelpers.RemoveDocumentsToAssociateDocPackage(fileID, docs2, packageID);
                Support.AreEqual("1", removeDocResponse.Status.ToString(), "Operation Status");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate the document has been removed from the package";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.AssociateDocsTab.FAClick();
                FastDriver.DocumentRepository.WaitForAssociateDocTabToLoad();
                Support.AreEqual("3", FastDriver.DocumentRepository.PackageDocumentsTable.GetRowCount().ToString(), "Document Count");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }

        }
        #endregion

        #region REG0029_ModifyAssociateDocPackage
        [TestMethod]
        public void REG0029_ModifyAssociateDocPackage()
        {
            try
            {
                Reports.TestDescription = "Validate ModifyAssociateDocPackage web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add four documents to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID_1 = Convert.ToInt32(response.Templates[0].TemplateID);
                int templateID_2 = Convert.ToInt32(response.Templates[1].TemplateID);
                int templateID_3 = Convert.ToInt32(response.Templates[2].TemplateID);
                int templateID_4 = Convert.ToInt32(response.Templates[3].TemplateID);

                int docID_1 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_1).DocumentID;
                int docID_2 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_2).DocumentID;
                int docID_3 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_3).DocumentID;
                int docID_4 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_4).DocumentID;
                string docName_4 = response.Templates[3].Descr;

                Document[] docs = new Document[]
                {
                    new Document()
                    {
                        DocumentID = docID_1
                    },
                    new Document()
                    {
                        DocumentID = docID_2
                    },
                    new Document()
                    {
                        DocumentID = docID_3
                    }
                };

                Reports.TestStep = "Create Associate Doc Package with the first three documents(WS)";
                var CreateAssociateDocPackageResponse = DocumentsHelpers.CreateAssociateDocPackage(fileID, docs, "TestAssociateDocPackage");
                long packageID = CreateAssociateDocPackageResponse.AssociateDocPackageID;

                Reports.TestStep = "Invoke ModifyAssociateDocPackage and validate response (WS)";
                var modifiedDocResponse = DocumentsHelpers.ModifyAssociateDocPackage(fileID, docs, packageID, "TestAssociateDocPackage_Modified", true);
                Support.AreEqual("1", modifiedDocResponse.Status.ToString(), "Operation Status");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate package name has changed";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.AssociateDocsTab.FAClick();
                FastDriver.DocumentRepository.WaitForAssociateDocTabToLoad();
                Support.AreEqual("TestAssociateDocPackage_Modified", FastDriver.DocumentRepository.AssPackageTable.PerformTableAction(1, 1, TableAction.GetText).Message, "Package Name Changed");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }


        }
        #endregion

        #region REG0030_RemoveAssociateDocPackage
        [TestMethod]
        public void REG0030_RemoveAssociateDocPackage()
        {
            try
            {
                Reports.TestDescription = "Validate RemoveAssociateDocPackage web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add three documents to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID_1 = Convert.ToInt32(response.Templates[0].TemplateID);
                int templateID_2 = Convert.ToInt32(response.Templates[1].TemplateID);
                int templateID_3 = Convert.ToInt32(response.Templates[2].TemplateID);

                int docID_1 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_1).DocumentID;
                int docID_2 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_2).DocumentID;
                int docID_3 = (int)DocumentsHelpers.CreateDocument(fileID, templateID_3).DocumentID;

                Document[] docs = new Document[]
                {
                    new Document()
                    {
                        DocumentID = docID_1
                    },
                    new Document()
                    {
                        DocumentID = docID_2
                    },
                    new Document()
                    {
                        DocumentID = docID_3
                    }
                };

                Reports.TestStep = "Create Associate Doc Package with the three documents (WS)";
                var CreateAssociateDocPackageResponse = DocumentsHelpers.CreateAssociateDocPackage(fileID, docs, "TestAssociateDocPackage");
                long packageID = CreateAssociateDocPackageResponse.AssociateDocPackageID;

                Reports.TestStep = "Invoke RemoveAssociateDocPackage and validate response (WS)";
                var removeDocResponse = DocumentsHelpers.RemoveAssociateDocPackage(fileID, docs, packageID);
                Support.AreEqual("1", removeDocResponse.Status.ToString(), "Operation Status");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate package has been removed";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.AssociateDocsTab.FAClick();
                FastDriver.DocumentRepository.WaitForAssociateDocTabToLoad();
                Support.AreEqual("0", FastDriver.DocumentRepository.AssPackageTable.GetRowCount().ToString(), "Package Removed");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }

        }
        #endregion

        #region REG0031_ViewPhraseText
        [TestMethod]
        public void REG0031_ViewPhraseText()
        {
            try
            {
                Reports.TestDescription = "Validate ViewPhraseText web method";
                #region DataSetup
                string phraseName = null;
                var response1 = new ViewPhraseResponse();
                string phraseTextUI = null;
                string phraseTextWS = null;
                bool result = false;
                #endregion

                #region Create a file using WS.
                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Add a document to the file using WS
                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;
                #endregion

                #region Add a phrase to the document using WS and validate response.
                Reports.TestStep = "Add a phrase to the document (WS), validate response";
                var response = DocumentsHelpers.AddPhrasesToDocument(fileID: fileID, docID: docID, phraseCode: @"XRL/15");
                Support.AreEqual("1", response.Status.ToString(), "Validate status operation");

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to event tracking log, validate [Update Document] event";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqual("Phrase(s) added successfully.DocumentID: " + docID.ToString() + " Document Name: " + templateName, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Update Document]", 5, TableAction.GetText).Message, "[Update Document]");

                Reports.TestStep = "Get the added document details for getting the phrase id.";
                var docDtlRespnc = new DocumentDetailsResponse();
                docDtlRespnc = DocumentsHelpers.GetDocumentDetails(fileID, docID);

                Reports.TestStep = "Navigate to the document repository and open the added document.";
                FastDriver.DocumentRepository.Open();
                List<string> documentsToselet = new List<string> { docDtlRespnc.DocName };
                FastDriver.DocumentRepository.SelectDocumentsByName(documentsToselet);
                FastDriver.DocumentRepository.Edit.FAClick();
                #endregion

                #region Invoke viewpharsetext web service for each phrase and verify it in UI side.
                Reports.TestStep = "Invoke the viewphrasetext web service for each phrase available in document.";
                foreach (var phrase in docDtlRespnc.Phrases)
                {
                    FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                    FastDriver.DocumentPreparation.WaitForScreenToLoad();
                    phraseName = phrase.PhraseGrpCode + "/" + phrase.Code;
                    Reports.TestStep = "Invoking the viewphrasetext webservice for the phrase: " + phraseName;
                    response1 = DocumentsHelpers.ViewPhraseText(phraseName, Convert.ToInt16(AutoConfig.SelectedRegionBUID));
                    phraseTextWS = response1.Text;

                    Reports.TestStep = "Open the phrase details to verify the text in UI for the phrase: " + phraseName;
                    FastDriver.DocumentPreparation.SelectPhrasefromTable(phraseName: phraseName);
                    Support.SendKeys("%P");
                    Support.SendKeys("%V");
                    FastDriver.WebDriver.SwitchToWindowByUrl(AutoConfig.FASTHomeURL.ToLower() + "/FastNetApp4/DocRepGUI/Preview.aspx?PHRASEID=" + phrase.DocPhraseID.ToString() + "&FILEID=" + docDtlRespnc.FileID.ToString());
                    phraseTextUI = FastDriver.WebDriver.FindElement(By.TagName("P")).FAGetText();
                    FastDriver.WebDriver.Close();
                    result = phraseTextWS.Contains(phraseTextUI);
                    Reports.StatusUpdate("Verification of view phrase text for the phrase: " + phraseName, result);
                }
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region REG0032_AddPhraseMarker
        [TestMethod]
        public void REG0032_AddPhraseMarker()
        {
            try
            {
                Reports.TestDescription = "Validate AddPhraseMarker web method";
                #region DataSetup
                var response = new OperationResponse();
                #endregion

                #region Create a file using WS.
                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Add a document to the file using webservice and verify it in UI.
                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Get the document details for the added document using webservice.";
                var docDtlRespnc = new DocumentDetailsResponse();
                docDtlRespnc = DocumentsHelpers.GetDocumentDetails(fileID, docID);

                Reports.TestStep = "Login to FAST and Verify in UI.";
                Login();
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to the Event log and verify that document has been added.";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqual("Document:" + docDtlRespnc.DocName + "Status:Successful", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Create Document]", 5, TableAction.GetText).Message.Replace("\r\n", string.Empty), "Verifying the document is added at UI as well.");
                #endregion

                #region Invoke AddPhraseMarker web service for each phrase and verify it in UI side.
                Reports.TestStep = "Invoking the AddPhraseMarker webservice.";
                DocumentsHelpers.AddPhraseMarker(fileID, docID);

                Reports.TestStep = "Navigate to the document repository page and open the added document.";
                FastDriver.DocumentRepository.Open();
                List<string> documentsToselet = new List<string> { docDtlRespnc.DocName };
                FastDriver.DocumentRepository.SelectDocumentsByName(documentsToselet);
                FastDriver.DocumentRepository.Edit.FAClick();
                FastDriver.DocumentPreparation.WaitForScreenToLoad();

                Reports.TestStep = "Verify that phrase marker is added in given sequence.";
                Support.AreEqual(true, FastDriver.DocumentPreparation.PhraseTable.FAGetText().Contains("Phrase Marker"), "Verifying that Phrase Marker is added at UI");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region REG0033_WaiveorUnwaivePhrase
        [TestMethod]
        public void REG0033_WaiveorUnwaivePhrase()
        {
            try
            {
                Reports.TestDescription = "Validate WaiveorUnwaivePhrase web method";

                #region Create a file using WS.
                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Add a document to the file using webservice and verify it in UI.
                Reports.TestStep = "Add a document to the file (WS)";
                int templateID = Convert.ToInt32(DocumentsHelpers.GetDefaultDocTemplates().Templates[0].TemplateID);
                string templateName = DocumentsHelpers.GetDefaultDocTemplates().Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;
                #endregion

                #region Add a phrase to the document using WS and validate response.
                Reports.TestStep = "Add a phrase to the document (WS), validate response";
                var response = DocumentsHelpers.AddPhrasesToDocument(fileID: fileID, docID: docID, phraseCode: @"JV1/JV1");
                Support.AreEqual("1", response.Status.ToString(), "Validate status operation");

                Reports.TestStep = "Get the document details for the added document using webservice.";
                var docDtlRespnc = new DocumentDetailsResponse();
                docDtlRespnc = DocumentsHelpers.GetDocumentDetails(fileID, docID);
                #endregion

                #region Verify the document and phrases are added succuessfully in UI side as well.
                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to event tracking log, validate [Update Document] event";
                FastDriver.EventTrackingLog.Open();

                Support.AreEqual("Phrase(s) added successfully.DocumentID: " + docID.ToString() + " Document Name: " + templateName, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Update Document]", 5, TableAction.GetText).Message, "[Update Document]");
                #endregion

                #region Invoke the WaiveorUnwaivePhrase web method to waive the newly added phrase. Verify it in UI side as well.
                Reports.TestStep = "Invoke the WaiveorUnwaivePhrase web method to waive the newly added phrase.";
                response = DocumentsHelpers.WaiveorUnWaivePhrase(Convert.ToInt32(docDtlRespnc.FileID), Convert.ToInt32(docDtlRespnc.DocumentID), Convert.ToInt64(docDtlRespnc.Phrases[1].DocPhraseID), true);

                Reports.TestStep = "Navigate to the document repository page and edit the added document.";
                FastDriver.DocumentRepository.Open();
                List<string> documentsToselet = new List<string> { docDtlRespnc.DocName };
                FastDriver.DocumentRepository.SelectDocumentsByName(documentsToselet);
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Select the waived the phrase and verify for the waive checkbox for the waived phrase.";
                FastDriver.DocumentPreparation.WaitForScreenToLoad();
                string phraseName = docDtlRespnc.Phrases[1].PhraseGrpCode + "/" + docDtlRespnc.Phrases[1].Code;
                Reports.StatusUpdate("Phrase is waived successfully in UI as well", FastDriver.DocumentPreparation.VerifyPhraseWaivedorUnWaived(phraseName));
                #endregion

                #region Invoke the WaiveorUnwaivePhrase web method to Unwaive the newly added phrase. Verify it in UI side as well.
                Reports.TestStep = "Invoke the WaiveorUnwaivePhrase web method to unwaive the newly added phrase.";
                response = DocumentsHelpers.WaiveorUnWaivePhrase(Convert.ToInt32(docDtlRespnc.FileID), Convert.ToInt32(docDtlRespnc.DocumentID), Convert.ToInt64(docDtlRespnc.Phrases[1].DocPhraseID), false);

                Reports.TestStep = "Navigate to the document repository page and edit the added document.";
                FastDriver.DocumentRepository.Open();
                FastDriver.DocumentRepository.SelectDocumentsByName(documentsToselet);
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Select the unwaived the phrase and verify checkbox should not be available.";
                FastDriver.DocumentPreparation.WaitForScreenToLoad();
                Reports.StatusUpdate("Phrase is unwaived successfully in UI as well", !FastDriver.DocumentPreparation.VerifyPhraseWaivedorUnWaived(phraseName));
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region Private class methods

        private void Login(string url = null)
        {
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            FASTLogin.Login(url ?? AutoConfig.FASTHomeURL, credentials, true);
        }

        private Dictionary<string, int> GetPhraseSequence(DocumentDetailsResponse documentRspnc)
        {
            string phraseCode = null;
            Dictionary<string, int> phraseSeq = new Dictionary<string, int>();
            for (int i = 0; i < documentRspnc.Phrases.Length; i++)
            {
                phraseCode = documentRspnc.Phrases[i].PhraseGrpCode + "/" + documentRspnc.Phrases[i].Code;
                phraseSeq.Add(phraseCode, Convert.ToInt16(documentRspnc.Phrases[i].SeqNum));
            }
            return phraseSeq;
        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
