﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using WebServices.Helpers.File;
using System.Linq;

namespace WebServices.File
{
    [CodedUITest]
    public class NewLoanWS : MasterTestClass
    {

        [TestMethod]
        public void REG0001_CreateNewLoan()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify CreateNewLoan() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileid);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                var newloanRequest = FileRequestFactory.GetNewLoanCreateRequest(file.FileID.ToString(), seqNum: 1);
                newloanRequest.EmployeeID = 1;
                newloanRequest.LoanDetails.LoanDates.FundingDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionBeginDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionEnds = DateTime.Now.ToPST().AddDays(5);
                newloanRequest.LoanDetails.LoanDates.SigningDate = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.From = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.To = DateTime.Now.ToPST().AddDays(6);
                newloanRequest.LoanCharges.CDNewLoanCharges[0].SeqNum = 1;

                Reports.TestStep = "Invoke CreateNewLoan service";
                FileService.CreateNewLoan(newloanRequest).Validate();

                var InterestCalculationDetails = newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation;
                var InterestChargeDetails = newloanRequest.LoanCharges.CDInterestCalculationSummary.CDChargePaymentDetails;
                var NewLoanDetails = newloanRequest.LoanDetails;
                var NewLoanCharges = newloanRequest.LoanCharges.CDNewLoanCharges;
                var PrincipalBalanceCharges = newloanRequest.LoanCharges.CDPrincipalBalanceCharges;
                var BrokerFee = newloanRequest.MortgageBroker.CDBrokerFee;
                var MortgageBrokerCharge = newloanRequest.MortgageBroker.CDMortgageBrokerCharges;

                Reports.TestStep = "Navigate to New Loan";
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("Home>Order Entry>New Loan").WaitForScreenToLoad(FastDriver.NewLoanSummary.LoanSummaryTable);
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction("Loan Amount", "1,000.01", "Loan Amount", TableAction.DoubleClick);
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Verify New Loan screen is filled with data from the web service request.";
                Support.AreEqual(NewLoanDetails.LoanDates.FundingDate.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsFundingDate.FAGetValue(), "FundingDate");
                Support.AreEqual(NewLoanDetails.LoanDates.SigningDate.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsSigningDate.FAGetValue(), "SigningDate");
                Support.AreEqual(NewLoanDetails.LoanDates.RescissionDays.Value.ToString(), FastDriver.NewLoan.LoanDetailsDays.FAGetValue(), "RescissionDays");
                Support.AreEqual(NewLoanDetails.LoanDates.RescissionEnds.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsEnds.FAGetValue(), "RescissionEnds");
                Support.AreEqual(NewLoanDetails.LoanDates.RescissionBeginDate.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FAGetValue(), "RescissionBeginDate");
                Support.AreEqual(NewLoanDetails.LoanAmount.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue().FormatAsMoney(), "LoanAmount");
                Support.AreEqual(NewLoanDetails.MortgageInsuranceCaseNumber, FastDriver.NewLoan.LoanDetailsMortgageInsCase.FAGetValue(), "MortgageInsuranceCaseNumber");
                Support.AreEqual(NewLoanDetails.LoanNumber, FastDriver.NewLoan.LoanDetailsLoanNumber.FAGetValue(), "LoanNumber");

                Reports.TestStep = "Click Loan Charges";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                if (PrincipalBalanceCharges.Description != null)
                {
                    Reports.TestStep = "Verify Principal Balance Charges";
                    Support.AreEqual(PrincipalBalanceCharges.Description.ToString(), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesdescription.FAGetValue(), "Description");
                }

                Reports.TestStep = "Verify Interest Calculation Summary";
                Support.AreEqual(InterestCalculationDetails.PerDiemAmount.ToString().FormatAsMoney(decimalPlaces: 6), FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FAGetValue().FormatAsMoney(), "PerDiemAmount");
                Support.AreEqual(InterestCalculationDetails.From.Value.ToDateString(), FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FAGetValue(), "From");
                Support.AreEqual(InterestCalculationDetails.To.Value.ToDateString(), FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FAGetValue(), "To");
                Support.AreEqual(InterestCalculationDetails.ToInclusive.Value, FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.IsSelected(), "ToInclusive");
                Support.AreEqual(InterestCalculationDetails.FromInclusive.Value, FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.IsSelected(), "FromInclusive");
                Support.AreEqual(InterestCalculationDetails.BasedOnDays.ToString(), FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem(), "BasedOnDays");

                Reports.TestStep = "Verify New Loan Charges";
                FastDriver.NewLoan.LoanCharges_NewLoanTable.PerformTableAction("Description", NewLoanCharges[0].Description, "Description", TableAction.DoubleClick);
                ServiceHelper.ValidatePaymentAndGetCheckAMount(NewLoanCharges[0]);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                if (NewLoanCharges[0].Description != null)
                    Support.AreEqual(NewLoanCharges[0].Description.ToString(), FastDriver.NewLoan.LoanChargesNewLoanChargesDescription1.FAGetValue(), "Description");
                if (NewLoanCharges[0].BuyerCharge != null)
                    Support.AreEqual(NewLoanCharges[0].BuyerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesNewLoanChargesBuyerCharge1.FAGetValue().FormatAsMoney(), "BuyerCharge");
                if (NewLoanCharges[0].SellerCharge != null)
                    Support.AreEqual(NewLoanCharges[0].SellerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesNewLoanChargesSellerCharge1.FAGetValue().FormatAsMoney(), "SellerCharge");

                Reports.TestStep = "Navigate to Mortgage Broker";
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = "Verify the Mortgage Broker Fee";
                Support.AreEqual(BrokerFee.Description.ToString(), FastDriver.NewLoan.MortgageYieldSpreadPremiumdescription.FAGetValue(), "Description");
                Support.AreEqual(BrokerFee.FileCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FAGetValue().FormatAsMoney(), "FileCharge");

                Reports.TestStep = "Verify the Mortgage Broker Charges";
                if (MortgageBrokerCharge[0].Description != null)
                    Support.AreEqual(MortgageBrokerCharge[0].Description.ToString(), FastDriver.NewLoan.MBChargesDescription0.FAGetValue(), "Description");
                if (MortgageBrokerCharge[0].BuyerCharge != null)
                    Support.AreEqual(MortgageBrokerCharge[0].BuyerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesBuyerCharge.FAGetValue().FormatAsMoney(), "BuyerCharge");
                if (MortgageBrokerCharge[0].SellerCharge != null)
                    Support.AreEqual(MortgageBrokerCharge[0].SellerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesSellerCharge.FAGetValue().FormatAsMoney(), "SellerCharge");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0002_UpdateNewLoan()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify UpdateNewLoan() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileid);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke GetNewLoanDetails service";
                var getResponse = FileService.GetNewLoanDetails(file.FileID ?? 0, seqNum: 1);
                Support.AreEqual("1", getResponse.Status.ToString(), getResponse.StatusDescription);
                int orgChargeAdhocCount = getResponse.LoanCharges.CDOriginationCharges.Length;
                int loanChargeAdhocCount = getResponse.LoanCharges.CDNewLoanCharges.Length;
                int principalReductionAdhocCount = getResponse.LoanCharges.CDPrincipalReductionOrConstructionHoldBack.Length;

                var newloanRequest = FileRequestFactory.GetNewLoanUpdateRequest(file.FileID.ToString(), seqNum: 1);
                newloanRequest.EmployeeID = 1;
                newloanRequest.SeqNum = 1;
                newloanRequest.LoanDetails.LoanDates.FundingDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionBeginDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionEnds = DateTime.Now.ToPST().AddDays(5);
                newloanRequest.LoanDetails.LoanDates.SigningDate = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.From = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.To = DateTime.Now.ToPST().AddDays(6);
                //Give adhoc seq num from get 
                newloanRequest.LoanCharges.CDImpoundCharges.Impounds[1].SeqNum = getResponse.LoanCharges.CDImpoundCharges.Impounds.Length;
                newloanRequest.LoanCharges.CDNewLoanCharges[1].SeqNum = loanChargeAdhocCount;
                newloanRequest.LoanCharges.CDPrincipalReductionOrConstructionHoldBack[1].SeqNum = principalReductionAdhocCount;
                newloanRequest.LoanCharges.CDOriginationCharges[1].SeqNum = orgChargeAdhocCount;

                Reports.TestStep = "Invoke UpdateNewLoan method";
                var response = FileService.UpdateNewLoan(newloanRequest);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);

                Reports.TestStep = "Verify US#701439";
                getResponse = FileService.GetNewLoanDetails(file.FileID ?? 0, seqNum: 1);
                Reports.StatusUpdate("LoanCharges.CDPayCharges.DisbursementCharges[0].Description: " + getResponse.LoanCharges.CDPayCharges.DisbursementCharges[0].Description, true);
                Support.AreEqual(true, getResponse.LoanCharges.CDPayCharges.DisbursementCharges[0].Description.Contains("("), "Disbursement charge contains (");

                Reports.TestStep = "Verify US#688739";
                Reports.StatusUpdate("CDRecapInformation.MortgageBrokerGrossCheck: " + getResponse.CDRecapInformation.MortgageBrokerGrossCheck, true);
                Support.AreEqual(false, getResponse.CDRecapInformation.MortgageBrokerGrossCheck.Contains(",,"), "Disbursement charge doesn't contain ,,");

                var cdImpoundData = newloanRequest.LoanCharges.CDImpoundCharges.Impounds;
                var cdInterestCalDetails = newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation;
                var cdInterestChargeDetails = newloanRequest.LoanCharges.CDInterestCalculationSummary.CDChargePaymentDetails;
                var cdNewLoanDetails = newloanRequest.LoanDetails;
                var cdCreditOrChargePoints = newloanRequest.LoanCharges.CDCreditOrChargePoints;
                var cdFutureRecordingFeesCollectedByLender = newloanRequest.LoanCharges.CDFutureRecordingFeesCollectedByLender;
                var cdLenderCredits = newloanRequest.LoanCharges.CDLenderCredits;
                var cdNewLoanCharges = newloanRequest.LoanCharges.CDNewLoanCharges;
                var cdPrincipalReductionOrConstruction = newloanRequest.LoanCharges.CDPrincipalReductionOrConstructionHoldBack;
                var cdOriginationCharges = newloanRequest.LoanCharges.CDOriginationCharges;
                var cdPrincipalBalanceCharges = newloanRequest.LoanCharges.CDPrincipalBalanceCharges;
                var cdBrokerFee = newloanRequest.MortgageBroker.CDBrokerFee;
                var cdMortgageBrokerCharge = newloanRequest.MortgageBroker.CDMortgageBrokerCharges;
                var cdFutureRecordingFeescollectedbyMB = newloanRequest.MortgageBroker.CDFutureRecordingFeescollectedbyMB;
                var cdLenderCreditsMB = newloanRequest.MortgageBroker.CDLenderCredits;

                Reports.TestStep = "Navigate to New Loan";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsTab.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad();

                Reports.TestStep = "Validate New Loan information";
                Support.AreEqual(cdNewLoanDetails.LoanDates.FundingDate.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsFundingDate.FAGetValue(), "FundingDate");
                Support.AreEqual(cdNewLoanDetails.LoanDates.SigningDate.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsSigningDate.FAGetValue(), "SigningDate");
                Support.AreEqual(cdNewLoanDetails.LoanDates.RescissionDays.ToString(), FastDriver.NewLoan.LoanDetailsDays.FAGetValue(), "RescissionDays");
                Support.AreEqual(cdNewLoanDetails.LoanDates.RescissionEnds.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsEnds.FAGetValue(), "RescissionEnds");
                Support.AreEqual(cdNewLoanDetails.LoanDates.RescissionBeginDate.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FAGetValue(), "RescissionBeginDate");
                Support.AreEqual(cdNewLoanDetails.LoanAmount.Value.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue().FormatAsMoney(), "LoanAmount");
                Support.AreEqual(cdNewLoanDetails.MortgageInsuranceCaseNumber.ToString(), FastDriver.NewLoan.LoanDetailsMortgageInsCase.FAGetValue(), "MortgageInsuranceCaseNumber");
                Support.AreEqual(cdNewLoanDetails.LoanNumber.ToString(), FastDriver.NewLoan.LoanDetailsLoanNumber.FAGetValue(), "LoanNumber");

                Reports.TestStep = "Open New Loan Charges";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Validate CD impound data 1";
                FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction("Months", cdImpoundData[0].Months.ToString(), "Months", TableAction.DoubleClick);
                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdImpoundData[0]);

                Reports.TestStep = "Validate CD impound data 2";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction("Description", cdImpoundData[1].Description.ToString(), "Months", TableAction.DoubleClick);
                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdImpoundData[1]);

                Reports.TestStep = "Validate New Loan monthly charges";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                Support.AreEqual(cdImpoundData[0].MonthlyCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_MonthlyCharge.FAGetValue().FormatAsMoney(), "MonthlyCharge");
                Support.AreEqual(cdImpoundData[0].Months.ToString(), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_Months1.FAGetValue(), "Months");

                Reports.TestStep = "Validate New Loan Principal Balance charges";
                if (cdPrincipalBalanceCharges.Description != null)
                    Support.AreEqual(cdPrincipalBalanceCharges.Description.ToString(), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesdescription.FAGetValue(), "Principal Balance Description");
                if (cdPrincipalBalanceCharges.BuyerCredit != null)
                    Support.AreEqual(cdPrincipalBalanceCharges.BuyerCredit.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercredit.FAGetValue().FormatAsMoney(), "Principal Balance BuyerCredit");
                if (cdPrincipalBalanceCharges.SellerCharge != null)
                    Support.AreEqual(cdPrincipalBalanceCharges.SellerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesSellercharge.FAGetValue().FormatAsMoney(), "Principal Balance SellerCharge");

                Reports.TestStep = "Verify Interest Calculation Summary ";
                Support.AreEqual(cdInterestCalDetails.PerDiemAmount.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FAGetValue().FormatAsMoney(), "PerDiemAmount");
                Support.AreEqual(cdInterestCalDetails.From.Value.ToDateString(), FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FAGetValue(), "From");
                Support.AreEqual(cdInterestCalDetails.To.Value.ToDateString(), FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FAGetValue(), "To");
                Support.AreEqual(cdInterestCalDetails.ToInclusive.ToString(), FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.IsSelected().ToString(), "ToInclusive");
                Support.AreEqual(cdInterestCalDetails.FromInclusive.ToString(), FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.IsSelected().ToString(), "FromInclusive");
                Support.AreEqual(cdInterestCalDetails.BasedOnDays.ToString(), FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem().ToString(), "BasedOnDays");

                Reports.TestStep = "Verify Loan Charges details 1";
                FastDriver.NewLoan.LoanCharges_NewLoanTable.PerformTableAction(2, 2, TableAction.DoubleClick);
                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdNewLoanCharges[0]);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Verify Loan Charges details 2";
                FastDriver.NewLoan.LoanCharges_NewLoanTable.PerformTableAction("Description", cdNewLoanCharges[1].Description.ToString(), "Description", TableAction.DoubleClick);
                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdNewLoanCharges[1]);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Validate New Loan charges";
                if (cdNewLoanCharges[0].Description != null)
                    Support.AreEqual(cdNewLoanCharges[0].Description, FastDriver.NewLoan.LoanChargesNewLoanChargesDescription1.FAGetValue(), "Description");
                if (cdNewLoanCharges[0].BuyerCharge != null)
                    Support.AreEqual(cdNewLoanCharges[0].BuyerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesNewLoanChargesBuyerCharge1.FAGetValue().FormatAsMoney(), "BuyerCharge");
                if (cdNewLoanCharges[0].SellerCharge != null)
                    Support.AreEqual(cdNewLoanCharges[0].SellerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesNewLoanChargesSellerCharge1.FAGetValue().FormatAsMoney(), "SellerCharge");

                Reports.TestStep = "Verify the Origination Charges details 1";
                FastDriver.NewLoan.LoanChargesOriginationChargeTable.PerformTableAction(2, 2, TableAction.DoubleClick);
                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdOriginationCharges[0]);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "US#677520: Ad Hoc Origination Charges. Verify the Origination Charges details 2";
                FastDriver.NewLoan.LoanChargesOriginationChargeTable.PerformTableAction("Description", cdOriginationCharges[1].Description.ToString(), "Description", TableAction.DoubleClick);
                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdOriginationCharges[1]);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Verify the Origination Charges";
                if (cdOriginationCharges[0].Description != null)
                    Support.AreEqual(cdOriginationCharges[0].Description, FastDriver.NewLoan.LoanChargesOriginationChargeDescription.FAGetValue(), "Description");
                if (cdOriginationCharges[0].BuyerCharge != null)
                    Support.AreEqual(cdOriginationCharges[0].BuyerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesOriginationChargebuyercharge.FAGetValue().FormatAsMoney(), "BuyerCharge");
                if (cdOriginationCharges[0].SellerCharge != null)
                    Support.AreEqual(cdOriginationCharges[0].SellerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesOriginationChargeSellercharge.FAGetValue().FormatAsMoney(), "SellerCharge");

                Reports.TestStep = "Verify Principal Reduction or Construction payment details";
                FastDriver.NewLoan.LoanChargesPrincipalReductiontable.PerformTableAction(2, 2, TableAction.DoubleClick);
                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdPrincipalReductionOrConstruction[0]);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Verify Principal Reduction or Construction charges";
                if (cdPrincipalReductionOrConstruction[0].Description != null)
                    Support.AreEqual(cdPrincipalReductionOrConstruction[0].Description.ToString(), FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Description.FAGetValue(), "Description");
                if (cdPrincipalReductionOrConstruction[0].BuyerCharge != null)
                    Support.AreEqual(cdPrincipalReductionOrConstruction[0].BuyerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesPrincipalreduction_Payment_BuyerCharge.FAGetValue().FormatAsMoney(), "BuyerCharge");
                if (cdPrincipalReductionOrConstruction[0].SellerCharge != null)
                    Support.AreEqual(cdPrincipalReductionOrConstruction[0].SellerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_SellerCharge.FAGetValue().FormatAsMoney(), "SellerCharge");

                Reports.TestStep = "Verify the CD CreditOrChargePoints ";
                Support.AreEqual(cdCreditOrChargePoints.IRSDiscountPoints.ToString().FormatAsMoney(), FastDriver.NewLoan.CreditChargeIRSPoints.FAGetValue().FormatAsMoney(), "IRSDiscountPoints");

                Reports.TestStep = "Open the Mortgage Broker tab ";
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = "Verify the Mortgage Broker Fee";
                Support.AreEqual(cdBrokerFee.Description.ToString(), FastDriver.NewLoan.MortgageYieldSpreadPremiumdescription.FAGetValue(), "Description");
                Support.AreEqual(cdBrokerFee.FileCharge.ToString(), FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FAGetValue(), "FileCharge");

                Reports.TestStep = "Verify the Mortgage Broker Charges payment details";
                FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction(2, 2, TableAction.DoubleClick);
                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdMortgageBrokerCharge[0]);

                Reports.TestStep = "Verify the Mortgage Broker Charges details";
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                if (cdMortgageBrokerCharge[0].Description != null)
                    Support.AreEqual(cdMortgageBrokerCharge[0].Description.ToString(), FastDriver.NewLoan.MBChargesDescription0.FAGetValue(), "Description");
                if (cdMortgageBrokerCharge[0].BuyerCharge != null)
                    Support.AreEqual(cdMortgageBrokerCharge[0].BuyerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesBuyerCharge.FAGetValue().FormatAsMoney(), "BuyerCharge");
                if (cdMortgageBrokerCharge[0].SellerCharge != null)
                    Support.AreEqual(cdMortgageBrokerCharge[0].SellerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesSellerCharge.FAGetValue().FormatAsMoney(), "SellerCharge");

                Reports.TestStep = "Verify the Mortgage - Lender Credits";
                FastDriver.NewLoan.Mortgage_LenderCreditTable.PerformTableAction(2, 2, TableAction.DoubleClick);
                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdLenderCreditsMB[0]);
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                Support.AreEqual(cdLenderCreditsMB[0].BuyerCredit.ToString().FormatAsMoney(), FastDriver.NewLoan.MortgageBrokerLenderCreditBuyerCredit.FAGetValue().FormatAsMoney(), "BuyerCredit");

                //Reports.TestStep = "Verify the Future Recording Fees collected by Lender / MB";
                // if (cdFutureRecordingFeescollectedbyMB[0].Description != null)
                // ServiceHelper.Support.AreEqual(newLoanPage.GetControl("IIS.NewLoan", "DescriptionFutureRecording"), "Text", cdFutureRecordingFeescollectedbyMB[0].Description.ToString());
                // if (cdFutureRecordingFeescollectedbyMB[0].BuyerCharge != null)
                // ServiceHelper.Support.AreEqual(newLoanPage.GetControl("IIS.NewLoan", "BuyerChargeFutureRecording"), "Text", cdFutureRecordingFeescollectedbyMB[0].BuyerCharge.ToString());
                //// ServiceHelper.ValidatePaymentAndGetCheckAMount(newLoanPage, cdFutureRecordingFeescollectedbyMB, "tNL_tMB_NMB_aMCG78_dcs_", "tNL$tMB$NMB$aMCG78$dcs$");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void REG0003_GetNewLoanDetails()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify GetNewLoanDetails() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileid);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke GetNewLoanDetails service";
                var newLoanDetailsResponse = FileService.GetNewLoanDetails(file.FileID, seqNum: 1);
                int impoundAdhocCount = newLoanDetailsResponse.LoanCharges.CDImpoundCharges.Impounds.Length;
                int orgChargeAdhocCount = newLoanDetailsResponse.LoanCharges.CDOriginationCharges.Length;
                int loanChargeAdhocCount = newLoanDetailsResponse.LoanCharges.CDNewLoanCharges.Length;
                int principalReductionAdhocCount = newLoanDetailsResponse.LoanCharges.CDPrincipalReductionOrConstructionHoldBack.Length;

                var newloanRequest = FileRequestFactory.GetNewLoanUpdateRequest(file.FileID.ToString(), seqNum: 1);
                newloanRequest.EmployeeID = 1;
                newloanRequest.SeqNum = 1;
                newloanRequest.LoanDetails.LoanDates.FundingDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionBeginDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionEnds = DateTime.Now.ToPST().AddDays(5);
                newloanRequest.LoanDetails.LoanDates.SigningDate = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.From = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.To = DateTime.Now.ToPST().AddDays(6);
                //Give adhoc SeqNums from GetNewLoanDetails response
                newloanRequest.LoanCharges.CDImpoundCharges.Impounds[1].SeqNum = impoundAdhocCount;
                newloanRequest.LoanCharges.CDPrincipalReductionOrConstructionHoldBack[1].SeqNum = principalReductionAdhocCount;
                newloanRequest.LoanCharges.CDOriginationCharges[1].SeqNum = orgChargeAdhocCount;

                newloanRequest.LoanCharges.CDNewLoanCharges = new CDChargePaymentDetails[]
                {
                    new CDChargePaymentDetails()
                    {
                        SeqNum=1,
                        Description="NewLoanChargeUpdate",
                        BuyerCharge=12.03m,
                        PBBuyerAtClosing=12.03m,
                        AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.POC,
                        SellerCharge=6.03m,
                        PBSellerAtClosing=6.03m,
                        AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.POC,
                        LEAmount=5.02m
                    },
                    new CDChargePaymentDetails()
                    {
                        Description="AdhocCharge 1",
                        BuyerCharge=30.03m,
                        SellerCharge=15.03m,
                        LEAmount=5.66m
                    },
                    new CDChargePaymentDetails()
                    {
                        Description="AdhocCharge 2",
                        BuyerCharge=33.06m,
                        AtClosingBuyerPaymentMethodTypeID=AtClosingPaymentMethods.POC,
                        PBBuyerAtClosing=33.06m,
                        SellerCharge=18.09m,
                        AtClosingSellerPaymentMethodTypeID=AtClosingPaymentMethods.RBL,
                        PBSellerAtClosing=18.09m,
                        LEAmount=6.2m
                    },
                };

                Reports.TestStep = "Invoke UpdateNewLoan service";
                var response = FileService.UpdateNewLoan(newloanRequest);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);

                Reports.TestStep = "Invoke GetNewLoanDetails service";
                newLoanDetailsResponse = FileService.GetNewLoanDetails(file.FileID, seqNum: 1);
                Support.AreEqual("1", newLoanDetailsResponse.Status.ToString(), newLoanDetailsResponse.StatusDescription);
                impoundAdhocCount = newLoanDetailsResponse.LoanCharges.CDImpoundCharges.Impounds.Length;
                orgChargeAdhocCount = newLoanDetailsResponse.LoanCharges.CDOriginationCharges.Length;
                loanChargeAdhocCount = newLoanDetailsResponse.LoanCharges.CDNewLoanCharges.Length;
                principalReductionAdhocCount = newLoanDetailsResponse.LoanCharges.CDPrincipalReductionOrConstructionHoldBack.Length;

                Reports.TestStep = "US#665329: GetNewLoanDetails to provide flags to indicate if a charge is selectable";
                Support.AreEqual(false, newLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges.ToList().FirstOrDefault(ch => ch.BuyerCredit == 55555555555m).IsEnabledForSelection.Value, "Loan Charge");
                //Support.AreEqual(false, newLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges.ToList().FirstOrDefault(ch => ch.Description == "NewLoanChargeUpdate").IsEnabledForSelection.Value, "NewLoanChargeUpdate");
                Support.AreEqual(true, newLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges.ToList().FirstOrDefault(ch => ch.Description == "AdhocCharge 1").IsEnabledForSelection.Value, "AdhocCharge 1 - Default payment method");
                Support.AreEqual(true, newLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges.ToList().FirstOrDefault(ch => ch.Description == "AdhocCharge 2").IsEnabledForSelection.Value, "AdhocCharge 2 - Method: POC + RBL");

                var cdImpoundData = newLoanDetailsResponse.LoanCharges.CDImpoundCharges.Impounds;
                var cdInterestCalDetails = newLoanDetailsResponse.LoanCharges.CDInterestCalculationSummary.InterestCalculation;
                var cdInterestChargeDetails = newLoanDetailsResponse.LoanCharges.CDInterestCalculationSummary.CDChargePaymentDetails;
                var cdNewLoanDetails = newLoanDetailsResponse.LoanDetails;
                var cdCreditOrChargePoints = newLoanDetailsResponse.LoanCharges.CDCreditOrChargePoints;
                var cdFutureRecordingFeesCollectedByLender = newLoanDetailsResponse.LoanCharges.CDFutureRecordingFeesCollectedByLender;
                var cdLenderCredits = newLoanDetailsResponse.LoanCharges.CDLenderCredits;
                var cdNewLoanCharges = newLoanDetailsResponse.LoanCharges.CDNewLoanCharges;
                var cdPrincipalReductionOrConstruction = newLoanDetailsResponse.LoanCharges.CDPrincipalReductionOrConstructionHoldBack;
                var cdOriginationCharges = newLoanDetailsResponse.LoanCharges.CDOriginationCharges;
                var cdPrincipalBalanceCharges = newLoanDetailsResponse.LoanCharges.CDPrincipalBalanceCharges;
                var cdBrokerFee = newLoanDetailsResponse.MortgageBroker.CDBrokerFee;
                var cdMortgageBrokerCharge = newLoanDetailsResponse.MortgageBroker.CDMortgageBrokerCharges;
                var cdFutureRecordingFeescollectedbyMB = newLoanDetailsResponse.MortgageBroker.CDFutureRecordingFeescollectedbyMB;
                var cdLenderCreditsMB = newLoanDetailsResponse.MortgageBroker.CDLenderCredits;

                Reports.TestStep = "Navigate to New Loan screen";
                FastDriver.NewLoan.Open();

                Reports.TestStep = "Validate Loan Details";
                Support.AreEqual(cdNewLoanDetails.LoanDates.FundingDate.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsFundingDate.FAGetValue(), "FundingDate");
                Support.AreEqual(cdNewLoanDetails.LoanDates.SigningDate.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsSigningDate.FAGetValue(), "SigningDate");
                Support.AreEqual(cdNewLoanDetails.LoanDates.RescissionDays.ToString(), FastDriver.NewLoan.LoanDetailsDays.FAGetValue(), "RescissionDays");
                Support.AreEqual(cdNewLoanDetails.LoanDates.RescissionEnds.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsEnds.FAGetValue(), "RescissionEnds");
                Support.AreEqual(cdNewLoanDetails.LoanDates.RescissionBeginDate.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FAGetValue(), "RescissionBeginDate");
                Support.AreEqual(cdNewLoanDetails.LoanAmount.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue().FormatAsMoney(), "LoanAmount");
                Support.AreEqual(cdNewLoanDetails.MortgageInsuranceCaseNumber.ToString(), FastDriver.NewLoan.LoanDetailsMortgageInsCase.FAGetValue(), "MortgageInsuranceCaseNumber");
                Support.AreEqual(cdNewLoanDetails.LoanNumber.ToString(), FastDriver.NewLoan.LoanDetailsLoanNumber.FAGetValue(), "LoanNumber");

                Reports.TestStep = "Open Loan Charges tab";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Validate Impound charges payment details 1";
                FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction("Months", cdImpoundData[0].Months.ToString(), "Months", TableAction.DoubleClick);
                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdImpoundData[0]);

                Reports.TestStep = "Validate Impound charges payment details 2";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction("Description", cdImpoundData[1].Description.ToString(), "Months", TableAction.DoubleClick);
                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdImpoundData[1]);

                Reports.TestStep = "Validate Impound charges";
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                Support.AreEqual(cdImpoundData[0].MonthlyCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_MonthlyCharge.FAGetValue().FormatAsMoney(), "MonthlyCharge");
                Support.AreEqual(cdImpoundData[0].Months.ToString(), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_Months1.FAGetValue(), "Months");
                if (cdPrincipalBalanceCharges.Description != null)
                    Support.AreEqual(cdPrincipalBalanceCharges.Description.ToString(), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesdescription.FAGetValue(), "Description");
                if (cdPrincipalBalanceCharges.BuyerCredit != null)
                    Support.AreEqual(cdPrincipalBalanceCharges.BuyerCredit.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercredit.FAGetValue().FormatAsMoney(), "BuyerCredit");
                if (cdPrincipalBalanceCharges.SellerCharge != null)
                    Support.AreEqual(cdPrincipalBalanceCharges.SellerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesSellercharge.FAGetValue().FormatAsMoney(), "SellerCharge");

                Reports.TestStep = "Verify the Interest Calculation Summary";
                Support.AreEqual(cdInterestCalDetails.PerDiemAmount.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FAGetValue().FormatAsMoney(), "PerDiemAmount");
                Support.AreEqual(cdInterestCalDetails.From.Value.ToDateString(), FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FAGetValue(), "From");
                Support.AreEqual(cdInterestCalDetails.To.Value.ToDateString(), FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FAGetValue(), "To");
                Support.AreEqual(cdInterestCalDetails.ToInclusive.ToString(), FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.IsSelected().ToString(), "ToInclusive");
                Support.AreEqual(cdInterestCalDetails.FromInclusive.ToString(), FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.IsSelected().ToString(), "FromInclusive");
                Support.AreEqual(cdInterestCalDetails.BasedOnDays.ToString(), FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem().ToString(), "BasedOnDays");

                Reports.TestStep = "Validate loan charges payment details 1";
                FastDriver.NewLoan.LoanCharges_NewLoanTable.PerformTableAction(2, 2, TableAction.DoubleClick);
                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdNewLoanCharges[0]);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Validate loan charges payment details 2";
                FastDriver.NewLoan.LoanCharges_NewLoanTable.PerformTableAction("Description", cdNewLoanCharges[1].Description.ToString(), "Description", TableAction.DoubleClick);
                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdNewLoanCharges[1]);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Validate loan charges details 2";
                if (cdNewLoanCharges[0].Description != null)
                    Support.AreEqual(cdNewLoanCharges[0].Description.ToString(), FastDriver.NewLoan.LoanChargesNewLoanChargesDescription1.FAGetValue(), "Description");
                if (cdNewLoanCharges[0].BuyerCharge != null)
                    Support.AreEqual(cdNewLoanCharges[0].BuyerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesNewLoanChargesBuyerCharge1.FAGetValue().FormatAsMoney(), "BuyerCharge");
                if (cdNewLoanCharges[0].SellerCharge != null)
                    Support.AreEqual(cdNewLoanCharges[0].SellerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesNewLoanChargesSellerCharge1.FAGetValue().FormatAsMoney(), "SellerCharge");

                Reports.TestStep = "Verify the Origination Charges payment details 1";
                FastDriver.NewLoan.LoanChargesOriginationChargeTable.PerformTableAction(2, 2, TableAction.DoubleClick);
                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdOriginationCharges[0]);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Verify the Origination Charges payment details 2";
                FastDriver.NewLoan.LoanChargesOriginationChargeTable.PerformTableAction("Description", cdOriginationCharges[1].Description.ToString(), "Description", TableAction.DoubleClick);
                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdOriginationCharges[1]);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Verify the Origination Charges details";
                if (cdOriginationCharges[0].Description != null)
                    Support.AreEqual(cdOriginationCharges[0].Description.ToString(), FastDriver.NewLoan.LoanChargesOriginationChargeDescription.FAGetValue(), "Description");
                if (cdOriginationCharges[0].BuyerCharge != null)
                    Support.AreEqual(cdOriginationCharges[0].BuyerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesOriginationChargebuyercharge.FAGetValue().FormatAsMoney(), "BuyerCharge");
                if (cdOriginationCharges[0].SellerCharge != null)
                    Support.AreEqual(cdOriginationCharges[0].SellerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesOriginationChargeSellercharge.FAGetValue().FormatAsMoney(), "SellerCharge");

                Reports.TestStep = "Verify the Principal Reduction Or Construction payment details";
                FastDriver.NewLoan.LoanChargesPrincipalReductiontable.PerformTableAction(2, 2, TableAction.DoubleClick);
                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdPrincipalReductionOrConstruction[0]);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                Reports.TestStep = "Verify the Principal Reduction Or Construction details";
                if (cdPrincipalReductionOrConstruction[0].Description != null)
                    Support.AreEqual(cdPrincipalReductionOrConstruction[0].Description.ToString(), FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Description.FAGetValue(), "Description");
                if (cdPrincipalReductionOrConstruction[0].BuyerCharge != null)
                    Support.AreEqual(cdPrincipalReductionOrConstruction[0].BuyerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesPrincipalreduction_Payment_BuyerCharge.FAGetValue().FormatAsMoney(), "BuyerCharge");
                if (cdPrincipalReductionOrConstruction[0].SellerCharge != null)
                    Support.AreEqual(cdPrincipalReductionOrConstruction[0].SellerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_SellerCharge.FAGetValue().FormatAsMoney(), "SellerCharge");

                Reports.TestStep = "Verify the CD Credit/Charge points ";
                Support.AreEqual(cdCreditOrChargePoints.IRSDiscountPoints.ToString().FormatAsMoney(), FastDriver.NewLoan.CreditChargeIRSPoints.FAGetValue().FormatAsMoney(), "IRSDiscountPoints");

                Reports.TestStep = "Open the mortgage broker tab";
                FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                Reports.TestStep = "Verify the Mortgage Broker Fee";
                Support.AreEqual(cdBrokerFee.Description.ToString(), FastDriver.NewLoan.MortgageYieldSpreadPremiumdescription.FAGetValue(), "Description");
                Support.AreEqual(cdBrokerFee.FileCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FAGetValue().FormatAsMoney(), "FileCharge");

                Reports.TestStep = "Verify the Mortgage Broker Charges";
                FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction(2, 2, TableAction.DoubleClick);
                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdMortgageBrokerCharge[0]);
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                if (cdMortgageBrokerCharge[0].Description != null)
                    Support.AreEqual(cdMortgageBrokerCharge[0].Description.ToString(), FastDriver.NewLoan.MBChargesDescription0.FAGetValue(), "Description");
                if (cdMortgageBrokerCharge[0].BuyerCharge != null)
                    Support.AreEqual(cdMortgageBrokerCharge[0].BuyerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesBuyerCharge.FAGetValue().FormatAsMoney(), "BuyerCharge");
                if (cdMortgageBrokerCharge[0].SellerCharge != null)
                    Support.AreEqual(cdMortgageBrokerCharge[0].SellerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesSellerCharge.FAGetValue().FormatAsMoney(), "SellerCharge");

                Reports.TestStep = "Verify the Mortgage - Lender Credits";
                FastDriver.NewLoan.Mortgage_LenderCreditTable.PerformTableAction(2, 2, TableAction.DoubleClick);
                ServiceHelper.ValidatePaymentAndGetCheckAMount(cdLenderCreditsMB[0]);
                FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                Support.AreEqual(cdLenderCreditsMB[0].BuyerCredit.ToString().FormatAsMoney(), FastDriver.NewLoan.MortgageBrokerLenderCreditBuyerCredit.FAGetValue().FormatAsMoney(), "BuyerCredit");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void REG0004_RemoveNewLoan()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify RemoveNewLoan() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileid);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke GetNewLoanDetails service";
                var getNewLoanDetailsResponse = FileService.GetNewLoanDetails(file.FileID ?? 0, seqNum: 1);
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);
                int orgChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDOriginationCharges.Length;
                int loanChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDNewLoanCharges.Length;
                int principalReductionAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDPrincipalReductionOrConstructionHoldBack.Length;

                var newloanRequest = FileRequestFactory.GetNewLoanUpdateRequest(file.FileID.ToString(), seqNum: 1);
                newloanRequest.EmployeeID = 1;
                newloanRequest.SeqNum = 1;
                newloanRequest.LoanDetails.LoanDates.FundingDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionBeginDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionEnds = DateTime.Now.ToPST().AddDays(5);
                newloanRequest.LoanDetails.LoanDates.SigningDate = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.From = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.To = DateTime.Now.ToPST().AddDays(6);
                //Give adhoc seq num from get 
                newloanRequest.LoanCharges.CDImpoundCharges.Impounds[1].SeqNum = getNewLoanDetailsResponse.LoanCharges.CDImpoundCharges.Impounds.Length;
                newloanRequest.LoanCharges.CDNewLoanCharges[1].SeqNum = loanChargeAdhocCount;
                newloanRequest.LoanCharges.CDPrincipalReductionOrConstructionHoldBack[1].SeqNum = principalReductionAdhocCount;
                newloanRequest.LoanCharges.CDOriginationCharges[1].SeqNum = orgChargeAdhocCount;

                Reports.TestStep = "Invoke UpdateNewLoan method";
                var updateNewLoanResponse = FileService.UpdateNewLoan(newloanRequest);
                Support.AreEqual("1", updateNewLoanResponse.Status.ToString(), updateNewLoanResponse.StatusDescription);

                Reports.TestStep = "Invoke RemoveNewLoan service.";
                var removeNewLoanRequest = FileRequestFactory.GetRemoveNewLoanRequest(fileid, 1);
                var removeNewLoanResponse = FileService.RemoveNewLoan(removeNewLoanRequest);
                Support.AreEqual("1", removeNewLoanResponse.Status.ToString(), removeNewLoanResponse.StatusDescription);

                Reports.TestStep = "Navigate to New Loan screen in FAST UI.";
                FastDriver.NewLoan.Open();

                Reports.TestStep = "Validate New Loan Details fields after removing loan.";
                Support.AreEqual("", FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue().Clean(), "LoanDetailsLoanAmount");
                Support.AreEqual("0.00", FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue().Clean(), "LoanDetailsLoanLiability");
                Support.AreEqual("", FastDriver.NewLoan.LoanDetailsMortgageInsCase.FAGetValue().Clean(), "LoanDetailsMortgageInsCase");
                Support.AreEqual("", FastDriver.NewLoan.LoanDetailsLoanNumber.FAGetValue().Clean(), "LoanDetailsLoanNumber");
                Support.AreEqual("", FastDriver.NewLoan.LoanDetailsFundingDate.FAGetValue().Clean(), "LoanDetailsFundingDate");
                Support.AreEqual("", FastDriver.NewLoan.LoanDetailsSigningDate.FAGetValue().Clean(), "LoanDetailsSigningDate");
                Support.AreEqual("", FastDriver.NewLoan.LoanDetailsDays.FAGetValue().Clean(), "LoanDetailsDays");
                Support.AreEqual("", FastDriver.NewLoan.LoanDetailsEnds.FAGetValue().Clean(), "LoanDetailsEnds");
                Support.AreEqual("", FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FAGetValue().Clean(), "LoanDetailsRescissionPeriodBegins");

                Reports.TestStep = "Open New Loan Charges tab in FAST UI.";
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Validate New Loan Charges fields after removing loan.";
                Support.AreEqual("", FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge.FAGetValue().Clean(), "LoanChargesGFE_3NewLoanChargesBuyerCharge");
                Support.AreEqual("", FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesSellerCharge.FAGetValue().Clean(), "LoanChargesGFE_3NewLoanChargesSellerCharge");
                Support.AreEqual("", FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharges_BuyerCharge.FAGetValue().Clean(), "LoanChargesGFE_6NewLoanCharges_BuyerCharge");
                Support.AreEqual("", FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharges_SellerCharge.FAGetValue().Clean(), "LoanChargesGFE_6NewLoanCharges_SellerCharge");
                Support.AreEqual("", FastDriver.NewLoan.LoanChargesOriginationChargeGFEAmount.FAGetValue().Clean(), "LoanChargesOriginationChargeGFEAmount");
                Support.AreEqual("0.000000", FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FAGetValue().Clean(), "LoanChargesInterestCalculationPerDiemAmount");
                Support.AreEqual("", FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FAGetValue().Clean(), "LoanChargesInterestCalculationFromDate");
                Support.AreEqual("", FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FAGetValue().Clean(), "LoanChargesInterestCalculationToDate");
                Support.AreEqual(false, FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.IsSelected(), "LoanChargesInterestCalculationInclusiveTo");
                Support.AreEqual(true, FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.IsSelected(), "LoanChargesInterestCalculationInclusiveFrom");
                Support.AreEqual("365", FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem(), "LoanChargesInterestCalculationBasedOn");

                //Reports.TestStep = "Validate New Loan Impound Charges fields after removing loan.";
                //Support.AreEqual("0.00", FastDriver.NewLoan..FAGetValue().Clean(), "ImpoundGFE");
                //Support.AreEqual("0.00", FastDriver.NewLoan..FAGetValue().Clean(), "ImpoundBuyerTotalCharge");

                Reports.TestStep = "Open New Loan Mortgage Broker tab in FAST UI.";
                FastDriver.NewLoan.ClickMortgageBrokerTab();

                Reports.TestStep = "Validate New Loan Mortgage Broker fields after removing loan.";
                Support.AreEqual("", FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FAGetValue().Clean(), "MortgageYieldSpreadPremiumAmount");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void REG0005_RemoveNewLoanLenderInformation()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify RemoveNewLoanLenderInformation() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileid);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke GetNewLoanDetails service";
                var getNewLoanDetailsResponse = FileService.GetNewLoanDetails(fileid, seqNum: 1);
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);
                int orgChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDOriginationCharges.Length;
                int loanChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDNewLoanCharges.Length;
                int principalReductionAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDPrincipalReductionOrConstructionHoldBack.Length;

                var newloanRequest = FileRequestFactory.GetNewLoanUpdateRequest(fileid.ToString(), seqNum: 1);
                newloanRequest.EmployeeID = 1;
                newloanRequest.SeqNum = 1;
                newloanRequest.LoanDetails.LoanDates.FundingDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionBeginDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionEnds = DateTime.Now.ToPST().AddDays(5);
                newloanRequest.LoanDetails.LoanDates.SigningDate = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.From = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.To = DateTime.Now.ToPST().AddDays(6);
                //Give adhoc seq num from get 
                newloanRequest.LoanCharges.CDImpoundCharges.Impounds[1].SeqNum = getNewLoanDetailsResponse.LoanCharges.CDImpoundCharges.Impounds.Length;
                newloanRequest.LoanCharges.CDNewLoanCharges[1].SeqNum = loanChargeAdhocCount;
                newloanRequest.LoanCharges.CDPrincipalReductionOrConstructionHoldBack[1].SeqNum = principalReductionAdhocCount;
                newloanRequest.LoanCharges.CDOriginationCharges[1].SeqNum = orgChargeAdhocCount;

                Reports.TestStep = "Invoke UpdateNewLoan method";
                var updateNewLoanResponse = FileService.UpdateNewLoan(newloanRequest);
                Support.AreEqual("1", updateNewLoanResponse.Status.ToString(), updateNewLoanResponse.StatusDescription);

                Reports.TestStep = "Invoke RemoveNewLoanLenderInformation method";
                var removeNewLoanRequest = FileRequestFactory.GetRemoveNewLoanRequest(fileid, seqNum: 1);
                var removeNewLoanLenderInformationResponse = FileService.RemoveNewLoanLenderInformation(removeNewLoanRequest);
                Support.AreEqual("1", removeNewLoanLenderInformationResponse.Status.ToString(), removeNewLoanLenderInformationResponse.StatusDescription);

                Reports.TestStep = "Navigate to New Loan screen in FAST UI.";
                FastDriver.NewLoan.Open();

                Reports.TestStep = "Go to New Loan charges tab.";
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Validate LoanChargesPayCharges is not enabled.";
                Support.AreEqual(false, FastDriver.NewLoan.LoanChargesPayCharges.IsEnabled(), "LoanChargesPayCharges IsEnabled");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0006_NewLoanPayChargesAssociation()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify NewLoanPayChargesAssociation() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileid);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke GetNewLoanDetails service";
                var getNewLoanDetailsResponse = FileService.GetNewLoanDetails(fileid, seqNum: 1);
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);
                int orgChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDOriginationCharges.Length;
                int loanChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDNewLoanCharges.Length;
                int principalReductionAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDPrincipalReductionOrConstructionHoldBack.Length;

                var newloanRequest = FileRequestFactory.GetNewLoanUpdateRequest(fileid.ToString(), seqNum: 1);
                newloanRequest.EmployeeID = 1;
                newloanRequest.SeqNum = 1;
                newloanRequest.LoanDetails.LoanDates.FundingDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionBeginDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionEnds = DateTime.Now.ToPST().AddDays(5);
                newloanRequest.LoanDetails.LoanDates.SigningDate = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.From = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.To = DateTime.Now.ToPST().AddDays(6);
                //Give adhoc seq num from get 
                newloanRequest.LoanCharges.CDImpoundCharges.Impounds[1].SeqNum = getNewLoanDetailsResponse.LoanCharges.CDImpoundCharges.Impounds.Length;
                newloanRequest.LoanCharges.CDNewLoanCharges[1].SeqNum = loanChargeAdhocCount;
                newloanRequest.LoanCharges.CDPrincipalReductionOrConstructionHoldBack[1].SeqNum = principalReductionAdhocCount;
                newloanRequest.LoanCharges.CDOriginationCharges[1].SeqNum = orgChargeAdhocCount;

                Reports.TestStep = "Invoke UpdateNewLoan method";
                var updateNewLoanResponse = FileService.UpdateNewLoan(newloanRequest);
                Support.AreEqual("1", updateNewLoanResponse.Status.ToString(), updateNewLoanResponse.StatusDescription);

                Reports.TestStep = "Invoke GetNewLoanDetails service.";
                getNewLoanDetailsResponse = FileService.GetNewLoanDetails(fileid, seqNum: 1);
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);

                Reports.TestStep = "Invoke NewLoanPayChargesAssociation method";
                var newLoanPayChargesAssociationRequest = FileRequestFactory.GetNewLoanPayChargeAssociationRequest(fileid, seqNum: 1,
                    charge: null, fileBusParty: null);

                #region newLoanPayChargesAssociationRequest params
                newLoanPayChargesAssociationRequest.ChargeDetails = new NewLoanDisbursementCharge[2];
                newLoanPayChargesAssociationRequest.PayeeInformation = new NewLoanDisbursementPayeeInformation[2];

                newLoanPayChargesAssociationRequest.ChargeDetails[0] = new NewLoanDisbursementCharge
                {
                    IsSelected = true,
                    ChargeId = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].ChargeID,
                    FileBusinessPartyId = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID,
                };
                newLoanPayChargesAssociationRequest.ChargeDetails[1] = new NewLoanDisbursementCharge
                {
                    IsSelected = true,
                    ChargeId = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[2].ChargeID,
                    AddressBookEntryId = AdminService.GetGABAddressBookEntryId("boa")
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[0] = new NewLoanDisbursementPayeeInformation
                {
                    eOperationType = OperationType.Update,
                    FileBusinessParty = new FileBusinessParty()
                    {
                        FileBusinessPartyID = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID,
                    }
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[1] = new NewLoanDisbursementPayeeInformation
                {
                    eOperationType = OperationType.Create,
                    FileBusinessParty = new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("boa")
                    }
                };
                #endregion

                Reports.TestStep = "Invoke NewLoanPayChargesAssociation method";
                var newLoanPayChargesAssociationResponse = FileService.NewLoanPayChargesAssociation(newLoanPayChargesAssociationRequest);
                Support.AreEqual("1", newLoanPayChargesAssociationResponse.Status.ToString(), newLoanPayChargesAssociationResponse.StatusDescription);

                Reports.TestStep = "Invoke GetNewLoanDetails service.";
                getNewLoanDetailsResponse = FileService.GetNewLoanDetails(fileid, seqNum: 1);
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);
                string descriptionCharge = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].Description;
                string descriptionCharge2 = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[2].Description;
                string payeeName1 = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].PayeeName;
                string payeeName2 = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[2].PayeeName;

                Reports.TestStep = "US#704327: FBP shows 0 even when there is a GAB on Payee Summary in Pay Charges section.";
                Support.AreNotEqual("0", getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID.ToString(), "FileBusinessPartyID");
                Support.AreNotEqual("0", getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[2].FileBusinessPartyID.ToString(), "FileBusinessPartyID");

                Reports.TestStep = "Navigate to New Loan screen in FAST UI.";
                FastDriver.NewLoan.Open();

                Reports.TestStep = "Go to New Loan charges tab.";
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Validate New Loan New Loan charges fields.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                Support.AreEqual(payeeName1, FastDriver.NewLoanDisbursements.PayeeName1.FAGetText().Clean(), "PayeeName1");
                FastDriver.NewLoanDisbursements.PayeeName1.FAClick();
                Playback.Wait(500);
                Support.AreEqual(true, FastDriver.NewLoanDisbursements.Charges2.IsEnabled(), "Charges2 IsEnabled");
                Support.AreEqual(true, FastDriver.NewLoanDisbursements.Charges2.IsSelected(), "Charges2 IsSelected");
                Support.AreEqual(payeeName2, FastDriver.NewLoanDisbursements.PayeeName2.FAGetText().Clean(), "PayeeName2");
                FastDriver.NewLoanDisbursements.PayeeName2.FAClick();
                Playback.Wait(500);
                var charge2 = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction("Payee Name", payeeName2, "Sel", TableAction.GetElementFromTableCell, "input").Element;
                Support.AreEqual(true, charge2.IsEnabled(), "Charges2 IsEnabled");
                Support.AreEqual(true, charge2.IsSelected(), "Charges2 IsSelected");

                Reports.TestStep = "Validate New Loan Details fields after removing loan.";
                getNewLoanDetailsResponse = FileService.GetNewLoanDetails(fileid, seqNum: 1);
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);

                Reports.TestStep = "Invoke NewLoanPayChargesAssociation method";
                newLoanPayChargesAssociationRequest = FileRequestFactory.GetNewLoanPayChargeAssociationRequest(fileid, seqNum: 1,
                    charge: null, fileBusParty: null);

                #region newLoanPayChargesAssociationRequest params
                newLoanPayChargesAssociationRequest.ChargeDetails = new NewLoanDisbursementCharge[1];
                newLoanPayChargesAssociationRequest.PayeeInformation = new NewLoanDisbursementPayeeInformation[1];

                newLoanPayChargesAssociationRequest.ChargeDetails[0] = new NewLoanDisbursementCharge
                {
                    IsSelected = false,
                    ChargeId = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[2].ChargeID,
                    FileBusinessPartyId = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID,
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[0] = new NewLoanDisbursementPayeeInformation
                {
                    eOperationType = OperationType.Update,
                    FileBusinessParty = new FileBusinessParty()
                    {
                        FileBusinessPartyID = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID
                    }
                };
                #endregion

                Reports.TestStep = "Invoke NewLoanPayChargesAssociation method";
                newLoanPayChargesAssociationResponse = FileService.NewLoanPayChargesAssociation(newLoanPayChargesAssociationRequest);
                Support.AreEqual("1", newLoanPayChargesAssociationResponse.Status.ToString(), newLoanPayChargesAssociationResponse.StatusDescription);

                Reports.TestStep = "Navigate to New Loan screen in FAST UI.";
                FastDriver.NewLoan.Open();

                Reports.TestStep = "Go to New Loan charges tab.";
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Validate New Loan New Loan charges fields.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                Support.AreEqual(payeeName2, FastDriver.NewLoanDisbursements.PayeeName2.FAGetText().Clean(), "PayeeName2");
                FastDriver.NewLoanDisbursements.PayeeName2.FAClick();
                Playback.Wait(500);
                charge2 = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction("Payee Name", payeeName2, "Sel", TableAction.GetElementFromTableCell, "input").Element;
                Support.AreEqual(true, charge2.IsEnabled(), "Charges2 IsEnabled");
                Support.AreEqual(false, charge2.IsSelected(), "Charges2 IsSelected");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void REG0007_RemoveLenderThirdPartyPayee()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify RemoveLenderThirdPartyPayee() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileid);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke GetNewLoanDetails service";
                var getNewLoanDetailsResponse = FileService.GetNewLoanDetails(fileid, seqNum: 1);
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);
                int orgChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDOriginationCharges.Length;
                int loanChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDNewLoanCharges.Length;
                int principalReductionAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDPrincipalReductionOrConstructionHoldBack.Length;

                var newloanRequest = FileRequestFactory.GetNewLoanUpdateRequest(fileid.ToString(), seqNum: 1);
                newloanRequest.EmployeeID = 1;
                newloanRequest.SeqNum = 1;
                newloanRequest.LoanDetails.LoanDates.FundingDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionBeginDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionEnds = DateTime.Now.ToPST().AddDays(5);
                newloanRequest.LoanDetails.LoanDates.SigningDate = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.From = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.To = DateTime.Now.ToPST().AddDays(6);
                //Give adhoc seq num from get 
                newloanRequest.LoanCharges.CDImpoundCharges.Impounds[1].SeqNum = getNewLoanDetailsResponse.LoanCharges.CDImpoundCharges.Impounds.Length;
                newloanRequest.LoanCharges.CDNewLoanCharges[1].SeqNum = loanChargeAdhocCount;
                newloanRequest.LoanCharges.CDPrincipalReductionOrConstructionHoldBack[1].SeqNum = principalReductionAdhocCount;
                newloanRequest.LoanCharges.CDOriginationCharges[1].SeqNum = orgChargeAdhocCount;

                Reports.TestStep = "Invoke UpdateNewLoan method";
                var updateNewLoanResponse = FileService.UpdateNewLoan(newloanRequest);
                Support.AreEqual("1", updateNewLoanResponse.Status.ToString(), updateNewLoanResponse.StatusDescription);

                Reports.TestStep = "Invoke GetNewLoanDetails service.";
                getNewLoanDetailsResponse = FileService.GetNewLoanDetails(fileid, seqNum: 1);
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);

                Reports.TestStep = "Invoke NewLoanPayChargesAssociation method";
                var newLoanPayChargesAssociationRequest = FileRequestFactory.GetNewLoanPayChargeAssociationRequest(fileid, seqNum: 1,
                    charge: null, fileBusParty: null);

                #region newLoanPayChargesAssociationRequest params
                newLoanPayChargesAssociationRequest.ChargeDetails = new NewLoanDisbursementCharge[2];
                newLoanPayChargesAssociationRequest.PayeeInformation = new NewLoanDisbursementPayeeInformation[2];

                newLoanPayChargesAssociationRequest.ChargeDetails[0] = new NewLoanDisbursementCharge
                {
                    IsSelected = true,
                    ChargeId = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].ChargeID,
                    FileBusinessPartyId = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID,
                };
                newLoanPayChargesAssociationRequest.ChargeDetails[1] = new NewLoanDisbursementCharge
                {
                    IsSelected = true,
                    ChargeId = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[2].ChargeID,
                    AddressBookEntryId = AdminService.GetGABAddressBookEntryId("boa")
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[0] = new NewLoanDisbursementPayeeInformation
                {
                    eOperationType = OperationType.Update,
                    FileBusinessParty = new FileBusinessParty()
                    {
                        FileBusinessPartyID = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID,
                    }
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[1] = new NewLoanDisbursementPayeeInformation
                {
                    eOperationType = OperationType.Create,
                    FileBusinessParty = new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("boa")
                    }
                };
                #endregion

                Reports.TestStep = "Invoke NewLoanPayChargesAssociation method";
                var newLoanPayChargesAssociationResponse = FileService.NewLoanPayChargesAssociation(newLoanPayChargesAssociationRequest);
                Support.AreEqual("1", newLoanPayChargesAssociationResponse.Status.ToString(), newLoanPayChargesAssociationResponse.StatusDescription);

                Reports.TestStep = "Invoke GetNewLoanDetails service.";
                getNewLoanDetailsResponse = FileService.GetNewLoanDetails(fileid, seqNum: 1);
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);

                Reports.TestStep = "Invoke NewLoanPayChargesAssociation method";
                newLoanPayChargesAssociationRequest = FileRequestFactory.GetNewLoanPayChargeAssociationRequest(fileid, seqNum: 1,
                    charge: null, fileBusParty: null);

                #region newLoanPayChargesAssociationRequest params
                newLoanPayChargesAssociationRequest.ChargeDetails = new NewLoanDisbursementCharge[1];
                newLoanPayChargesAssociationRequest.PayeeInformation = new NewLoanDisbursementPayeeInformation[1];

                newLoanPayChargesAssociationRequest.ChargeDetails[0] = new NewLoanDisbursementCharge
                {
                    IsSelected = false,
                    ChargeId = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[2].ChargeID,
                    FileBusinessPartyId = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID,
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[0] = new NewLoanDisbursementPayeeInformation
                {
                    eOperationType = OperationType.Update,
                    FileBusinessParty = new FileBusinessParty()
                    {
                        FileBusinessPartyID = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID
                    }
                };
                #endregion

                Reports.TestStep = "Invoke NewLoanPayChargesAssociation method";
                newLoanPayChargesAssociationResponse = FileService.NewLoanPayChargesAssociation(newLoanPayChargesAssociationRequest);
                Support.AreEqual("1", newLoanPayChargesAssociationResponse.Status.ToString(), newLoanPayChargesAssociationResponse.StatusDescription);

                Reports.TestStep = "Invoke RemoveLenderThirdPartyPayee service.";
                var removeLenderThirdPartyPayeeRequest = FileRequestFactory.GetRemoveThirdPartyPayeeRequest(fileid, 1, getNewLoanDetailsResponse.LoanCharges.CDPayCharges.PayeeInformation[1].FileBusinessPartyID.Value);
                var removeLenderThirdPartyPayeeResponse = FileService.RemoveLenderThirdPartyPayee(removeLenderThirdPartyPayeeRequest);
                Support.AreEqual("1", removeLenderThirdPartyPayeeResponse.Status.ToString(), removeLenderThirdPartyPayeeResponse.StatusDescription);

                Reports.TestStep = "Navigate to New Loan screen in FAST UI.";
                FastDriver.NewLoan.Open();

                Reports.TestStep = "Go to New Loan charges tab.";
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Verify 3rd party payee got removed.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.NewLoanDisbursements.PayeeName2.IsDisplayed(), "PayeeName2 IsDisplayed");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0008_NewLoanMBPayChargesAssociation()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify NewLoanMBPayChargesAssociation() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileid);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke GetNewLoanDetails service";
                var getNewLoanDetailsResponse = FileService.GetNewLoanDetails(fileid, seqNum: 1);
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);
                int orgChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDOriginationCharges.Length;
                int loanChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDNewLoanCharges.Length;
                int principalReductionAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDPrincipalReductionOrConstructionHoldBack.Length;

                var newloanRequest = FileRequestFactory.GetNewLoanUpdateRequest(fileid.ToString(), seqNum: 1);
                newloanRequest.EmployeeID = 1;
                newloanRequest.SeqNum = 1;
                newloanRequest.LoanDetails.LoanDates.FundingDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionBeginDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionEnds = DateTime.Now.ToPST().AddDays(5);
                newloanRequest.LoanDetails.LoanDates.SigningDate = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.From = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.To = DateTime.Now.ToPST().AddDays(6);
                //Give adhoc seq num from get 
                newloanRequest.LoanCharges.CDImpoundCharges.Impounds[1].SeqNum = getNewLoanDetailsResponse.LoanCharges.CDImpoundCharges.Impounds.Length;
                newloanRequest.LoanCharges.CDNewLoanCharges[1].SeqNum = loanChargeAdhocCount;
                newloanRequest.LoanCharges.CDPrincipalReductionOrConstructionHoldBack[1].SeqNum = principalReductionAdhocCount;
                newloanRequest.LoanCharges.CDOriginationCharges[1].SeqNum = orgChargeAdhocCount;

                Reports.TestStep = "Invoke UpdateNewLoan method";
                var updateNewLoanResponse = FileService.UpdateNewLoan(newloanRequest);
                Support.AreEqual("1", updateNewLoanResponse.Status.ToString(), updateNewLoanResponse.StatusDescription);

                Reports.TestStep = "Invoke GetNewLoanDetails service.";
                getNewLoanDetailsResponse = FileService.GetNewLoanDetails(fileid, seqNum: 1);
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);

                Reports.TestStep = "Invoke NewLoanMBPayChargesAssociation method";
                var newLoanPayChargesAssociationRequest = FileRequestFactory.GetNewLoanPayChargeAssociationRequest(fileid, seqNum: 1,
                    charge: null, fileBusParty: null);

                #region newLoanPayChargesAssociationRequest params
                newLoanPayChargesAssociationRequest.ChargeDetails = new NewLoanDisbursementCharge[2];
                newLoanPayChargesAssociationRequest.PayeeInformation = new NewLoanDisbursementPayeeInformation[2];

                newLoanPayChargesAssociationRequest.ChargeDetails[0] = new NewLoanDisbursementCharge
                {
                    IsSelected = false,
                    ChargeId = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[1].ChargeID,
                    FileBusinessPartyId = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID,
                };
                newLoanPayChargesAssociationRequest.ChargeDetails[1] = new NewLoanDisbursementCharge
                {
                    IsSelected = true,
                    ChargeId = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[2].ChargeID,
                    AddressBookEntryId = AdminService.GetGABAddressBookEntryId("boa")
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[0] = new NewLoanDisbursementPayeeInformation
                {
                    eOperationType = OperationType.Update,
                    FileBusinessParty = new FileBusinessParty()
                    {
                        FileBusinessPartyID = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID,
                    }
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[1] = new NewLoanDisbursementPayeeInformation
                {
                    eOperationType = OperationType.Create,
                    FileBusinessParty = new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("boa")
                    }
                };
                #endregion

                Reports.TestStep = "Invoke NewLoanMBPayChargesAssociation method";
                var newLoanMBPayChargesAssociationResponse = FileService.NewLoanMBPayChargesAssociation(newLoanPayChargesAssociationRequest);
                Support.AreEqual("1", newLoanMBPayChargesAssociationResponse.Status.ToString(), newLoanMBPayChargesAssociationResponse.StatusDescription);

                Reports.TestStep = "Navigate to New Loan screen in FAST UI.";
                FastDriver.NewLoan.Open();

                Reports.TestStep = "Go to New Loan Mortgage Broker tab.";
                FastDriver.NewLoan.ClickMortgageBrokerTab();

                Reports.TestStep = "Invoke GetNewLoanDetails service.";
                getNewLoanDetailsResponse = FileService.GetNewLoanDetails(fileid, seqNum: 1);
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);
                string payeeName1 = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[1].PayeeName;
                string payeeName2 = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[2].PayeeName;

                Reports.TestStep = "Validate New Loan Mortgage Broker fields.";
                FastDriver.NewLoan.MortgagePayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                Support.AreEqual(payeeName1, FastDriver.NewLoanDisbursements.PayeeName1.FAGetText().Clean(), "PayeeName1");
                FastDriver.NewLoanDisbursements.PayeeName1.FAClick();
                Playback.Wait(500);
                Support.AreEqual(true, FastDriver.NewLoanDisbursements.Charges2.IsEnabled(), "Charges2 IsEnabled");
                Support.AreEqual(false, FastDriver.NewLoanDisbursements.Charges2.IsSelected(), "Charges2 IsSelected");
                Support.AreEqual(payeeName2, FastDriver.NewLoanDisbursements.PayeeName2.FAGetText().Clean(), "PayeeName2");
                FastDriver.NewLoanDisbursements.PayeeName2.FAClick();
                Playback.Wait(500);
                string charge3Name = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction("Payee Name", payeeName2, "Description", TableAction.GetText).Message.Clean();
                var charge3 = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction("Description", charge3Name, "Sel", TableAction.GetElementFromTableCell, "input").Element;
                Support.AreEqual(true, charge3.IsEnabled(), "Charges3 IsEnabled");
                Support.AreEqual(true, charge3.IsSelected(), "Charges3 IsSelected");

                Reports.TestStep = "Invoke NewLoanPayChargesAssociation method";
                newLoanPayChargesAssociationRequest = FileRequestFactory.GetNewLoanPayChargeAssociationRequest(fileid, seqNum: 1,
                    charge: null, fileBusParty: null);

                #region newLoanPayChargesAssociationRequest params
                newLoanPayChargesAssociationRequest.ChargeDetails = new NewLoanDisbursementCharge[1];
                newLoanPayChargesAssociationRequest.PayeeInformation = new NewLoanDisbursementPayeeInformation[1];

                newLoanPayChargesAssociationRequest.ChargeDetails[0] = new NewLoanDisbursementCharge
                {
                    IsSelected = false,
                    ChargeId = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[2].ChargeID,
                    FileBusinessPartyId = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.PayeeInformation[1].FileBusinessPartyID,
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[0] = new NewLoanDisbursementPayeeInformation
                {
                    eOperationType = OperationType.Update,
                    FileBusinessParty = new FileBusinessParty()
                    {
                        FileBusinessPartyID = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.PayeeInformation[1].FileBusinessPartyID
                    }
                };
                #endregion

                Reports.TestStep = "Invoke NewLoanMBPayChargesAssociation method";
                newLoanMBPayChargesAssociationResponse = FileService.NewLoanMBPayChargesAssociation(newLoanPayChargesAssociationRequest);
                Support.AreEqual("1", newLoanMBPayChargesAssociationResponse.Status.ToString(), newLoanMBPayChargesAssociationResponse.StatusDescription);

                Reports.TestStep = "Navigate to New Loan screen in FAST UI.";
                FastDriver.NewLoan.Open();

                Reports.TestStep = "Go to New Loan Mortgage Broker tab.";
                FastDriver.NewLoan.ClickMortgageBrokerTab();

                Reports.TestStep = "Validate New Loan Mortgage Broker fields.";
                FastDriver.NewLoan.MortgagePayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                Support.AreEqual(payeeName2, FastDriver.NewLoanDisbursements.PayeeName2.FAGetText().Clean(), "PayeeName2");
                FastDriver.NewLoanDisbursements.PayeeName2.FAClick();
                Playback.Wait(500);
                charge3 = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction("Description", charge3Name, "Sel", TableAction.GetElementFromTableCell, "input").Element;
                Support.AreEqual(true, charge3.IsEnabled(), "Charges3 IsEnabled");
                Support.AreEqual(false, charge3.IsSelected(), "Charges3 IsSelected");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void REG0009_RemoveMortgageBrokerThirdPartyPayee()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify RemoveMortgageBrokerThirdPartyPayee() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileid);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke GetNewLoanDetails service";
                var getNewLoanDetailsResponse = FileService.GetNewLoanDetails(fileid, seqNum: 1);
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);
                int orgChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDOriginationCharges.Length;
                int loanChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDNewLoanCharges.Length;
                int principalReductionAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDPrincipalReductionOrConstructionHoldBack.Length;

                var newloanRequest = FileRequestFactory.GetNewLoanUpdateRequest(fileid.ToString(), seqNum: 1);
                newloanRequest.EmployeeID = 1;
                newloanRequest.SeqNum = 1;
                newloanRequest.LoanDetails.LoanDates.FundingDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionBeginDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionEnds = DateTime.Now.ToPST().AddDays(5);
                newloanRequest.LoanDetails.LoanDates.SigningDate = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.From = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.To = DateTime.Now.ToPST().AddDays(6);
                //Give adhoc seq num from get 
                newloanRequest.LoanCharges.CDImpoundCharges.Impounds[1].SeqNum = getNewLoanDetailsResponse.LoanCharges.CDImpoundCharges.Impounds.Length;
                newloanRequest.LoanCharges.CDNewLoanCharges[1].SeqNum = loanChargeAdhocCount;
                newloanRequest.LoanCharges.CDPrincipalReductionOrConstructionHoldBack[1].SeqNum = principalReductionAdhocCount;
                newloanRequest.LoanCharges.CDOriginationCharges[1].SeqNum = orgChargeAdhocCount;

                Reports.TestStep = "Invoke UpdateNewLoan method";
                var updateNewLoanResponse = FileService.UpdateNewLoan(newloanRequest);
                Support.AreEqual("1", updateNewLoanResponse.Status.ToString(), updateNewLoanResponse.StatusDescription);

                Reports.TestStep = "Invoke GetNewLoanDetails service.";
                getNewLoanDetailsResponse = FileService.GetNewLoanDetails(fileid, seqNum: 1);
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);

                Reports.TestStep = "Invoke NewLoanMBPayChargesAssociation method";
                var newLoanPayChargesAssociationRequest = FileRequestFactory.GetNewLoanPayChargeAssociationRequest(fileid, seqNum: 1,
                    charge: null, fileBusParty: null);

                #region newLoanPayChargesAssociationRequest params
                newLoanPayChargesAssociationRequest.ChargeDetails = new NewLoanDisbursementCharge[2];
                newLoanPayChargesAssociationRequest.PayeeInformation = new NewLoanDisbursementPayeeInformation[2];

                newLoanPayChargesAssociationRequest.ChargeDetails[0] = new NewLoanDisbursementCharge
                {
                    IsSelected = false,
                    ChargeId = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[1].ChargeID,
                    FileBusinessPartyId = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID,
                };
                newLoanPayChargesAssociationRequest.ChargeDetails[1] = new NewLoanDisbursementCharge
                {
                    IsSelected = true,
                    ChargeId = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[2].ChargeID,
                    AddressBookEntryId = AdminService.GetGABAddressBookEntryId("boa")
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[0] = new NewLoanDisbursementPayeeInformation
                {
                    eOperationType = OperationType.Update,
                    FileBusinessParty = new FileBusinessParty()
                    {
                        FileBusinessPartyID = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID,
                    }
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[1] = new NewLoanDisbursementPayeeInformation
                {
                    eOperationType = OperationType.Create,
                    FileBusinessParty = new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("boa")
                    }
                };
                #endregion

                Reports.TestStep = "Invoke NewLoanMBPayChargesAssociation method";
                var newLoanMBPayChargesAssociationResponse = FileService.NewLoanMBPayChargesAssociation(newLoanPayChargesAssociationRequest);
                Support.AreEqual("1", newLoanMBPayChargesAssociationResponse.Status.ToString(), newLoanMBPayChargesAssociationResponse.StatusDescription);

                Reports.TestStep = "Invoke GetNewLoanDetails service.";
                getNewLoanDetailsResponse = FileService.GetNewLoanDetails(fileid, seqNum: 1);
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);
                string payeeName1 = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[1].PayeeName;
                string payeeName2 = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[2].PayeeName;

                Reports.TestStep = "Invoke NewLoanPayChargesAssociation method";
                newLoanPayChargesAssociationRequest = FileRequestFactory.GetNewLoanPayChargeAssociationRequest(fileid, seqNum: 1,
                    charge: null, fileBusParty: null);

                #region newLoanPayChargesAssociationRequest params
                newLoanPayChargesAssociationRequest.ChargeDetails = new NewLoanDisbursementCharge[1];
                newLoanPayChargesAssociationRequest.PayeeInformation = new NewLoanDisbursementPayeeInformation[1];

                newLoanPayChargesAssociationRequest.ChargeDetails[0] = new NewLoanDisbursementCharge
                {
                    IsSelected = false,
                    ChargeId = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[2].ChargeID,
                    FileBusinessPartyId = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.PayeeInformation[1].FileBusinessPartyID,
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[0] = new NewLoanDisbursementPayeeInformation
                {
                    eOperationType = OperationType.Update,
                    FileBusinessParty = new FileBusinessParty()
                    {
                        FileBusinessPartyID = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.PayeeInformation[1].FileBusinessPartyID
                    }
                };
                #endregion

                Reports.TestStep = "Invoke NewLoanMBPayChargesAssociation method";
                newLoanMBPayChargesAssociationResponse = FileService.NewLoanMBPayChargesAssociation(newLoanPayChargesAssociationRequest);
                Support.AreEqual("1", newLoanMBPayChargesAssociationResponse.Status.ToString(), newLoanMBPayChargesAssociationResponse.StatusDescription);

                Reports.TestStep = "Invoke RemoveMortgageBrokerThirdPartyPayee service.";
                var removeThirdPartyPayeeRequest = FileRequestFactory.GetRemoveThirdPartyPayeeRequest(fileid, 1, getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[2].FileBusinessPartyID.Value);
                var removeMortgageBrokerThirdPartyPayeeresponse = FileService.RemoveMortgageBrokerThirdPartyPayee(removeThirdPartyPayeeRequest);

                Reports.TestStep = "Navigate to New Loan screen in FAST UI.";
                FastDriver.NewLoan.Open();

                Reports.TestStep = "Go to New Loan Mortgage Broker tab.";
                FastDriver.NewLoan.ClickMortgageBrokerTab();

                Reports.TestStep = "Validate New Loan Mortgage Broker is removed.";
                FastDriver.NewLoan.MortgagePayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.NewLoanDisbursements.PayeeName2.IsDisplayed(), "PayeeName2 IsDisplayed");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void REG0010_RemoveMortgageBrokerInformation()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify RemoveMortgageBrokerInformation() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileid);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke GetNewLoanDetails service";
                var getNewLoanDetailsResponse = FileService.GetNewLoanDetails(fileid, seqNum: 1);
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);
                int orgChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDOriginationCharges.Length;
                int loanChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDNewLoanCharges.Length;
                int principalReductionAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDPrincipalReductionOrConstructionHoldBack.Length;

                var newloanRequest = FileRequestFactory.GetNewLoanUpdateRequest(fileid.ToString(), seqNum: 1);
                newloanRequest.EmployeeID = 1;
                newloanRequest.SeqNum = 1;
                newloanRequest.LoanDetails.LoanDates.FundingDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionBeginDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionEnds = DateTime.Now.ToPST().AddDays(5);
                newloanRequest.LoanDetails.LoanDates.SigningDate = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.From = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.To = DateTime.Now.ToPST().AddDays(6);
                //Give adhoc seq num from get 
                newloanRequest.LoanCharges.CDImpoundCharges.Impounds[1].SeqNum = getNewLoanDetailsResponse.LoanCharges.CDImpoundCharges.Impounds.Length;
                newloanRequest.LoanCharges.CDNewLoanCharges[1].SeqNum = loanChargeAdhocCount;
                newloanRequest.LoanCharges.CDPrincipalReductionOrConstructionHoldBack[1].SeqNum = principalReductionAdhocCount;
                newloanRequest.LoanCharges.CDOriginationCharges[1].SeqNum = orgChargeAdhocCount;

                Reports.TestStep = "Invoke UpdateNewLoan method";
                var updateNewLoanResponse = FileService.UpdateNewLoan(newloanRequest);
                Support.AreEqual("1", updateNewLoanResponse.Status.ToString(), updateNewLoanResponse.StatusDescription);

                Reports.TestStep = "Navigate to New Loan screen in FAST UI.";
                FastDriver.NewLoan.Open();

                Reports.TestStep = "Go to New Loan Mortgage Broker tab.";
                FastDriver.NewLoan.ClickMortgageBrokerTab();

                Reports.TestStep = "Validate New Loan Mortgage Broker is removed.";
                Support.AreEqual(true, FastDriver.NewLoan.MortgagePayCharges.IsEnabled(), "MortgagePayCharges IsEnabled");

                Reports.TestStep = "Invoke UpdateNewLoan method";
                var removeMortgageBrokerInformationResponse = FileService.RemoveMortgageBrokerInformation(FileRequestFactory.GetRemoveNewLoanRequest(fileid, 1));
                Support.AreEqual("1", removeMortgageBrokerInformationResponse.Status.ToString(), removeMortgageBrokerInformationResponse.StatusDescription);

                Reports.TestStep = "Navigate to New Loan screen in FAST UI.";
                FastDriver.NewLoan.Open();

                Reports.TestStep = "Go to New Loan Mortgage Broker tab.";
                FastDriver.NewLoan.ClickMortgageBrokerTab();

                Reports.TestStep = "Validate New Loan Mortgage Broker is removed.";
                Support.AreEqual(false, FastDriver.NewLoan.MortgagePayCharges.IsEnabled(), "MortgagePayCharges IsEnabled");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void REG0011_RemoveNewLoanRelatedParty()
        {
            try
            {
                Reports.TestDescription = "Verify RemoveNewLoanRelatedParty service.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Navigate to New Loan screen, add one Related Parties";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickRelatedPartiesTab();
                FastDriver.NewLoan.RelatedPartiesNew.FAClick();
                FastDriver.NewLoan.WaitForScreenToLoad(FastDriver.NewLoan.RelatedPartiesRelatedPartyGABcode);
                FastDriver.NewLoan.RelatedPartiesRelatedPartyGABcode.FASetText("BOA");
                FastDriver.NewLoan.RelatedPartiesRelatedParty_Find.FAClick();
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30, true);

                Reports.TestStep = "Obtain FileBusinessPartyID using GetOrderDetails WS";
                var getOrderDetailsResponse = FileService.GetOrderDetails(fileId);
                int fileBusinessPartyID = 0;

                foreach (FileBusinessParty element in getOrderDetailsResponse.FileBusinessParties)
                {
                    if (element.RoleTypeCdID == 702)
                    {
                        fileBusinessPartyID = (int)element.FileBusinessPartyID;
                        break;
                    }
                }

                Reports.TestStep = "Remove first related party using RemoveNewLoanRelatedParty, validate response (WS)";
                var request = FileRequestFactory.GetRemoveRelatedPartyRequest(fileId, 1, fileBusinessPartyID);
                var response = NewLoanHelpers.RemoveNewLoanRelatedParty(request);
                Support.AreEqual("1", response.Status.ToString(), "Status");
                Support.AreEqual("Related Business Party Removed Successfully", response.StatusDescription, "Status Description");

                Reports.TestStep = "Navigate to New Loan screen, validate related party has been removed";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickRelatedPartiesTab();
                Support.AreEqual("1", FastDriver.NewLoan.RelatedPartiesSummaryTable.GetRowCount().ToString(), "Only header row displayed");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0012_AddLenderLoanInvestor()
        {
            try
            {
                Reports.TestDescription = "Verify AddLenderLoanInvestor service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.NewLoan.FileBusinessParty.AddrBookEntryID = AdminService.GetGABAddressBookEntryId("BOA", Convert.ToInt32(AutoConfig.SelectedRegionBUID));
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file with BOA as a new lender using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Invoke AddLenderLoanInvestor web method, validate response (WS)";
                var request = FileRequestFactory.GetAddLenderLoanInvestorDefaultRequest(fileID: fileId);
                var response = NewLoanHelpers.AddLenderLoanInvestor(request);
                Support.AreEqual("1", response.Status.ToString(), "Status");
                Support.AreEqual("Loan Investor has been Added Successfully.", response.StatusDescription, "Status Description");

                Reports.TestStep = "Navigate to New Loan screen, click Loan Investors button";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanInvestors.FAClick();
                FastDriver.LoanInvestors.WaitForScreenToLoad();

                Reports.TestStep = "Validate Loan Investor is added";
                Support.AreEqual("1256", FastDriver.LoanInvestors.LoanInvestorSummmaryTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean(), "Loan Investor Addr Book ID");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
