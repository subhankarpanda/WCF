﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Linq;

namespace WebServices.File
{
    [CodedUITest]
    public class MiscellaneousDisbursementWS: FASTHelpers
    {
        [TestMethod]
        public void REG_CreateMiscellaneousDisbursement()
        {
            try
            {
                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                #region Invoke  Create Miscellaneous Disbutrsement services
                Reports.TestStep = "Invoke MiscellaneousDisbursement service";
                var MiscDisbusementReq = FileRequestFactory.CreateNewMiscDisbusementRequest(File.FileID);
                var MiscDisbusementRes = FASTWCFHelpers.FileService.CreateMiscellaneousDisbursement(MiscDisbusementReq);
                #endregion

                #region Validate the UI
                #region Verify the Business Party Details 
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                Support.AreEqual("248", FastDriver.MiscDisbursementDetail.IDCode.FAGetText());
                #endregion

                #region Verify the Miscellaneous Disbursement Buyer/Seller Charges
                Reports.TestStep = "Miscellaneous Disbursement Buyer/Seller Charges";
                Support.AreEqual(FastDriver.MiscDisbursementDetail.Description.FAGetValue(), MiscDisbusementReq.MiscDisbCDPaymentDetails[0].Description.ToString());
                Support.AreEqual(FastDriver.MiscDisbursementDetail.BuyerCharge.FAGetValue(), MiscDisbusementReq.MiscDisbCDPaymentDetails[0].BuyerCharge.ToString());
                Support.AreEqual(FastDriver.MiscDisbursementDetail.SellerCharge.FAGetValue(), MiscDisbusementReq.MiscDisbCDPaymentDetails[0].SellerCharge.ToString());
                FastDriver.MiscDisbursementDetail.SellerCharge.FAClick();
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Replace("$", "").ToString(), MiscDisbusementReq.MiscDisbCDPaymentDetails[0].BuyerCharge.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Replace("$", "").ToString(), MiscDisbusementReq.MiscDisbCDPaymentDetails[0].PBBuyerAtClosing.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Replace("$", "").ToString(), MiscDisbusementReq.MiscDisbCDPaymentDetails[0].PBBuyerBeforeClosing.ToString());
                string AtClosingBuyerPaymentMethodTypeID = FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem();
                if(AtClosingBuyerPaymentMethodTypeID=="Check")
                {
                    AtClosingBuyerPaymentMethodTypeID = "CHK";
                }
                Support.AreEqual(AtClosingBuyerPaymentMethodTypeID, MiscDisbusementReq.MiscDisbCDPaymentDetails[0].AtClosingBuyerPaymentMethodTypeID.ToString());

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Replace("$", "").ToString(), MiscDisbusementReq.MiscDisbCDPaymentDetails[0].SellerCharge.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Replace("$", "").ToString(), MiscDisbusementReq.MiscDisbCDPaymentDetails[0].PBSellerAtClosing.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Replace("$", "").ToString(), MiscDisbusementReq.MiscDisbCDPaymentDetails[0].PBSellerBeforeClosing.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue().Replace("$", "").ToString(), MiscDisbusementReq.MiscDisbCDPaymentDetails[0].PBOthersForSeller.ToString());

               string AtClosingSellerPaymentMethodTypeID = FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem();
               if (AtClosingSellerPaymentMethodTypeID == "Check")
                {
                    AtClosingSellerPaymentMethodTypeID = "CHK";
                }
               Support.AreEqual(AtClosingSellerPaymentMethodTypeID, MiscDisbusementReq.MiscDisbCDPaymentDetails[0].AtClosingSellerPaymentMethodTypeID.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem(), MiscDisbusementReq.MiscDisbCDPaymentDetails[0].PBOthersForSellerPMTypeCdID.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region
                Reports.TestStep = "Miscellaneous Disbursement Buyer/Seller Charges second record";
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.MiscDisbursementDetail.Description1.FAGetValue(), MiscDisbusementReq.MiscDisbCDPaymentDetails[1].Description.ToString());
                Support.AreEqual(FastDriver.MiscDisbursementDetail.BuyerCharge1.FAGetValue(), MiscDisbusementReq.MiscDisbCDPaymentDetails[1].BuyerCharge.ToString());
                Support.AreEqual(FastDriver.MiscDisbursementDetail.SellerCharge1.FAGetValue(), MiscDisbusementReq.MiscDisbCDPaymentDetails[1].SellerCharge.ToString());
                FastDriver.MiscDisbursementDetail.SellerCharge1.FAClick();
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Replace("$", "").ToString(), MiscDisbusementReq.MiscDisbCDPaymentDetails[1].BuyerCharge.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Replace("$", "").ToString(), MiscDisbusementReq.MiscDisbCDPaymentDetails[1].PBBuyerAtClosing.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Replace("$", "").ToString(), MiscDisbusementReq.MiscDisbCDPaymentDetails[1].PBBuyerBeforeClosing.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue().Replace("$", "").ToString(), MiscDisbusementReq.MiscDisbCDPaymentDetails[1].PBOthersForBuyer.ToString());
               
                AtClosingBuyerPaymentMethodTypeID = FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem();
                if(AtClosingBuyerPaymentMethodTypeID=="Check")
                {
                    AtClosingBuyerPaymentMethodTypeID = "CHK";
                }
                Support.AreEqual(AtClosingBuyerPaymentMethodTypeID, MiscDisbusementReq.MiscDisbCDPaymentDetails[0].AtClosingBuyerPaymentMethodTypeID.ToString());

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Replace("$", "").ToString(), MiscDisbusementReq.MiscDisbCDPaymentDetails[1].SellerCharge.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Replace("$", "").ToString(), MiscDisbusementReq.MiscDisbCDPaymentDetails[1].PBSellerAtClosing.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Replace("$", "").ToString(), MiscDisbusementReq.MiscDisbCDPaymentDetails[1].PBSellerBeforeClosing.ToString());
                
               AtClosingSellerPaymentMethodTypeID = FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem();
               if (AtClosingSellerPaymentMethodTypeID == "Check")
                {
                    AtClosingSellerPaymentMethodTypeID = "CHK";
                }
               Support.AreEqual(AtClosingSellerPaymentMethodTypeID, MiscDisbusementReq.MiscDisbCDPaymentDetails[1].AtClosingSellerPaymentMethodTypeID.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
                #endregion

               
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG_CreateMiscellaneousDisbursement_CheckOnly()
        {
            try
            {
                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                #region Invoke  Create Miscellaneous Disbutrsement services
                Reports.TestStep = "Invoke MiscellaneousDisbursement_CheckOnly service";
                var MiscDisbusementReq = FileRequestFactory.CreateNewMiscDisbusementRequestCheckOnly(File.FileID);
                var MiscDisbusementRes = FASTWCFHelpers.FileService.CreateMiscellaneousDisbursement(MiscDisbusementReq);
                #endregion

                #region Validate the UI
                Reports.TestStep = " Verify the Business Party Details";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                Support.AreEqual("248", FastDriver.MiscDisbursementDetail.IDCode.FAGetText());
                #endregion

                #region Miscellaneous Disbutrsement CheckOnly Details
                Reports.TestStep = "Miscellaneous Disbutrsement CheckOnly Details";
                Support.AreEqual(FastDriver.MiscDisbursementDetail.CheckOnlyDescription.FAGetValue(), MiscDisbusementReq.NonBuyerSellerCharge.Description.ToString());
                Support.AreEqual("True",FastDriver.MiscDisbursementDetail.CheckOnlyCharge.FAGetValue().Contains(MiscDisbusementReq.NonBuyerSellerCharge.Amount.ToString()).ToString());
               
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG_GetMiscellaneousDisbursement()
        {

            try
            {
                Reports.TestDescription = "Verify GetMiscellaneousDisbursement service";
                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";

                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();

                Reports.TestStep = "Create File using web service.";
               string fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);

                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
               int FileNo = FileService.GetFilesByFileNum(fileNumber.ToString(), int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 1).FileSearchResults.FirstOrDefault().FileID ?? 0;

                #endregion

                #region Invoke  Create Miscellaneous Disbutrsement services
                Reports.TestStep = "Invoke MiscellaneousDisbursement service";
                var MiscDisbusementReq = FileRequestFactory.CreateNewMiscDisbusementRequest(FileNo);
                FASTWCFHelpers.FileService.CreateMiscellaneousDisbursement(MiscDisbusementReq);
                var GetMisDisbursementRes = FASTWCFHelpers.FileService.GetMiscellaneousDisbursement(FileNo, 1);
                #endregion

                #region Validate the UI
                #region Verify the Business Party Details
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                Support.AreEqual("248", FastDriver.MiscDisbursementDetail.IDCode.FAGetText());
                #endregion

                #region Verify the Miscellaneous Disbursement Buyer/Seller Charges
                Reports.TestStep = "Miscellaneous Disbursement Buyer/Seller Charges";
                Support.AreEqual(FastDriver.MiscDisbursementDetail.Description.FAGetValue(), GetMisDisbursementRes.MiscDisbCDPaymentDetails[0].Description.ToString());
                Support.AreEqual(FastDriver.MiscDisbursementDetail.BuyerCharge.FAGetValue(), GetMisDisbursementRes.MiscDisbCDPaymentDetails[0].BuyerCharge.ToString());
                Support.AreEqual(FastDriver.MiscDisbursementDetail.SellerCharge.FAGetValue(), GetMisDisbursementRes.MiscDisbCDPaymentDetails[0].SellerCharge.ToString());
                FastDriver.MiscDisbursementDetail.SellerCharge.FAClick();
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Replace("$", "").ToString(), GetMisDisbursementRes.MiscDisbCDPaymentDetails[0].BuyerCharge.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Replace("$", "").ToString(), GetMisDisbursementRes.MiscDisbCDPaymentDetails[0].PBBuyerAtClosing.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Replace("$", "").ToString(), GetMisDisbursementRes.MiscDisbCDPaymentDetails[0].PBBuyerBeforeClosing.ToString());
                string AtClosingBuyerPaymentMethodTypeID = FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem();
                if (AtClosingBuyerPaymentMethodTypeID == "Check")
                {
                    AtClosingBuyerPaymentMethodTypeID = "CHK";
                }
                Support.AreEqual(AtClosingBuyerPaymentMethodTypeID, GetMisDisbursementRes.MiscDisbCDPaymentDetails[0].AtClosingBuyerPaymentMethodTypeID.ToString());

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Replace("$", "").ToString(), GetMisDisbursementRes.MiscDisbCDPaymentDetails[0].SellerCharge.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Replace("$", "").ToString(), GetMisDisbursementRes.MiscDisbCDPaymentDetails[0].PBSellerAtClosing.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Replace("$", "").ToString(), GetMisDisbursementRes.MiscDisbCDPaymentDetails[0].PBSellerBeforeClosing.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue().Replace("$", "").ToString(), GetMisDisbursementRes.MiscDisbCDPaymentDetails[0].PBOthersForSeller.ToString());

                string AtClosingSellerPaymentMethodTypeID = FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem();
                if (AtClosingSellerPaymentMethodTypeID == "Check")
                {
                    AtClosingSellerPaymentMethodTypeID = "CHK";
                }
                Support.AreEqual(AtClosingSellerPaymentMethodTypeID, GetMisDisbursementRes.MiscDisbCDPaymentDetails[0].AtClosingSellerPaymentMethodTypeID.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem(), GetMisDisbursementRes.MiscDisbCDPaymentDetails[0].PBOthersForSellerPMTypeCdID.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region
                Reports.TestStep = "Miscellaneous Disbursement Buyer/Seller Charges second record";
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.MiscDisbursementDetail.Description1.FAGetValue(), GetMisDisbursementRes.MiscDisbCDPaymentDetails[1].Description.ToString());
                Support.AreEqual(FastDriver.MiscDisbursementDetail.BuyerCharge1.FAGetValue(), GetMisDisbursementRes.MiscDisbCDPaymentDetails[1].BuyerCharge.ToString());
                Support.AreEqual(FastDriver.MiscDisbursementDetail.SellerCharge1.FAGetValue(), GetMisDisbursementRes.MiscDisbCDPaymentDetails[1].SellerCharge.ToString());
                FastDriver.MiscDisbursementDetail.SellerCharge1.FAClick();
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Replace("$", "").ToString(), GetMisDisbursementRes.MiscDisbCDPaymentDetails[1].BuyerCharge.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Replace("$", "").ToString(), GetMisDisbursementRes.MiscDisbCDPaymentDetails[1].PBBuyerAtClosing.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Replace("$", "").ToString(), GetMisDisbursementRes.MiscDisbCDPaymentDetails[1].PBBuyerBeforeClosing.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue().Replace("$", "").ToString(), GetMisDisbursementRes.MiscDisbCDPaymentDetails[1].PBOthersForBuyer.ToString());

                AtClosingBuyerPaymentMethodTypeID = FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem();
                if (AtClosingBuyerPaymentMethodTypeID == "Check")
                {
                    AtClosingBuyerPaymentMethodTypeID = "CHK";
                }
                Support.AreEqual(AtClosingBuyerPaymentMethodTypeID, GetMisDisbursementRes.MiscDisbCDPaymentDetails[0].AtClosingBuyerPaymentMethodTypeID.ToString());

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Replace("$", "").ToString(), GetMisDisbursementRes.MiscDisbCDPaymentDetails[1].SellerCharge.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Replace("$", "").ToString(), GetMisDisbursementRes.MiscDisbCDPaymentDetails[1].PBSellerAtClosing.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Replace("$", "").ToString(), GetMisDisbursementRes.MiscDisbCDPaymentDetails[1].PBSellerBeforeClosing.ToString());

                AtClosingSellerPaymentMethodTypeID = FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem();
                if (AtClosingSellerPaymentMethodTypeID == "Check")
                {
                    AtClosingSellerPaymentMethodTypeID = "CHK";
                }
                Support.AreEqual(AtClosingSellerPaymentMethodTypeID, GetMisDisbursementRes.MiscDisbCDPaymentDetails[1].AtClosingSellerPaymentMethodTypeID.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG_GetMiscellaneousDisbursementSummary()
        {
            try
            {
                Reports.TestDescription = "Verify GetMiscellaneousDisbursement service";
                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
            
                #endregion

                #region Invoke  Create Miscellaneous Disbutrsement services
                Reports.TestStep = "Invoke Miscellaneous Disbutrsement summary service";
                var MiscDisbusementReq = FileRequestFactory.CreateNewMiscDisbusementRequest(File.FileID);
                FASTWCFHelpers.FileService.CreateMiscellaneousDisbursement(MiscDisbusementReq);
                MiscDisbusementReq = FileRequestFactory.CreateNewMiscDisbusementRequest(File.FileID);
                FASTWCFHelpers.FileService.CreateMiscellaneousDisbursement(MiscDisbusementReq);

                var GetMisDisbursementSummaryReq = FileRequestFactory.GetMiscDisbSummaryRequest(File.FileID);
                var GetMisDisbursementSummaryRes = FASTWCFHelpers.FileService.GetMiscellaneousDisbursementSummary(GetMisDisbursementSummaryReq);
                #endregion

                #region Validate the UI
                Reports.TestStep=" Verify the Business Party Details";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement");
                FastDriver.MiscellaneousDisbursementSummary.WaitForScreenToLoad();
                Support.AreEqual("True", FastDriver.MiscellaneousDisbursementSummary.RecordCount.FAGetText().ToString().Contains("2").ToString());
                Support.AreEqual(FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction(2, 2, TableAction.GetText).Message.ToString(), GetMisDisbursementSummaryRes.MiscDisbSummary[0].Name.ToString());
                Support.AreEqual(FastDriver.MiscellaneousDisbursementSummary.SummaryTable.PerformTableAction(3, 2, TableAction.GetText).Message.ToString(), GetMisDisbursementSummaryRes.MiscDisbSummary[1].Name.ToString());
               
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG_UpdateMiscellaneousDisbursement()
        {
            try
            {
                #region FAST Login IIS side
                Reports.TestDescription = "Verify UpdateMiscellaneousDisbursement service";    
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                #region Invoke  Create Miscellaneous Disbutrsement services
                Reports.TestStep = "Invoke MiscellaneousDisbursement service";
                var MiscDisbusementReq = FileRequestFactory.CreateNewMiscDisbusementRequest(File.FileID);
                var MiscDisbusementRes = FASTWCFHelpers.FileService.CreateMiscellaneousDisbursement(MiscDisbusementReq);
                var UpdateDisbursementReq = FileRequestFactory.UpdateMiscDisbusementRequest(File.FileID);
                var UpdateDisbursementReS = FASTWCFHelpers.FileService.UpdateMiscellaneousDisbursement(UpdateDisbursementReq);
                #endregion

                #region Validate the UI
                #region Verify the Business Party Details
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                Support.AreEqual("247", FastDriver.MiscDisbursementDetail.IDCode.FAGetText());
                #endregion
                string c = UpdateDisbursementReq.MiscDisbCDPaymentDetails[0].BuyerCharge.ToString();
                #region Verify the Miscellaneous Disbursement Buyer/Seller Charges
                Reports.TestStep = "Miscellaneous Disbursement Buyer/Seller Charges";
                Support.AreEqual(FastDriver.MiscDisbursementDetail.Description.FAGetValue(), UpdateDisbursementReq.MiscDisbCDPaymentDetails[0].Description.ToString());
                Support.AreEqual(FastDriver.MiscDisbursementDetail.BuyerCharge.FAGetValue(), UpdateDisbursementReq.MiscDisbCDPaymentDetails[0].BuyerCharge.ToString());
                Support.AreEqual(FastDriver.MiscDisbursementDetail.SellerCharge.FAGetValue(), UpdateDisbursementReq.MiscDisbCDPaymentDetails[0].SellerCharge.ToString());
                FastDriver.MiscDisbursementDetail.SellerCharge.FAClick();
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Replace("$", "").ToString(), UpdateDisbursementReq.MiscDisbCDPaymentDetails[0].BuyerCharge.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Replace("$", "").ToString(), UpdateDisbursementReq.MiscDisbCDPaymentDetails[0].PBBuyerAtClosing.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Replace("$", "").ToString(), UpdateDisbursementReq.MiscDisbCDPaymentDetails[0].PBBuyerBeforeClosing.ToString());
                string AtClosingBuyerPaymentMethodTypeID = FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem();
                if (AtClosingBuyerPaymentMethodTypeID == "Check")
                {
                    AtClosingBuyerPaymentMethodTypeID = "CHK";
                }
                Support.AreEqual(AtClosingBuyerPaymentMethodTypeID, UpdateDisbursementReq.MiscDisbCDPaymentDetails[0].AtClosingBuyerPaymentMethodTypeID.ToString());

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Replace("$", "").ToString(), UpdateDisbursementReq.MiscDisbCDPaymentDetails[0].SellerCharge.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Replace("$", "").ToString(), UpdateDisbursementReq.MiscDisbCDPaymentDetails[0].PBSellerAtClosing.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Replace("$", "").ToString(), UpdateDisbursementReq.MiscDisbCDPaymentDetails[0].PBSellerBeforeClosing.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue().Replace("$", "").ToString(), UpdateDisbursementReq.MiscDisbCDPaymentDetails[0].PBOthersForSeller.ToString());

                string AtClosingSellerPaymentMethodTypeID = FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem();
                if (AtClosingSellerPaymentMethodTypeID == "Check")
                {
                    AtClosingSellerPaymentMethodTypeID = "CHK";
                }
                Support.AreEqual(AtClosingSellerPaymentMethodTypeID, UpdateDisbursementReq.MiscDisbCDPaymentDetails[0].AtClosingSellerPaymentMethodTypeID.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem(), UpdateDisbursementReq.MiscDisbCDPaymentDetails[0].PBOthersForSellerPMTypeCdID.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion

                #region
                Reports.TestStep = "Miscellaneous Disbursement Buyer/Seller Charges second record";
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.MiscDisbursementDetail.Description1.FAGetValue(), UpdateDisbursementReq.MiscDisbCDPaymentDetails[1].Description.ToString());
                Support.AreEqual(FastDriver.MiscDisbursementDetail.BuyerCharge1.FAGetValue(), UpdateDisbursementReq.MiscDisbCDPaymentDetails[1].BuyerCharge.ToString());
                Support.AreEqual(FastDriver.MiscDisbursementDetail.SellerCharge1.FAGetValue(), UpdateDisbursementReq.MiscDisbCDPaymentDetails[1].SellerCharge.ToString());
                FastDriver.MiscDisbursementDetail.SellerCharge1.FAClick();
                FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue().Replace("$", "").ToString(), UpdateDisbursementReq.MiscDisbCDPaymentDetails[1].BuyerCharge.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Replace("$", "").ToString(), UpdateDisbursementReq.MiscDisbCDPaymentDetails[1].PBBuyerAtClosing.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Replace("$", "").ToString(), UpdateDisbursementReq.MiscDisbCDPaymentDetails[1].PBBuyerBeforeClosing.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue().Replace("$", "").ToString(), UpdateDisbursementReq.MiscDisbCDPaymentDetails[1].PBOthersForBuyer.ToString());

                AtClosingBuyerPaymentMethodTypeID = FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem();
                if (AtClosingBuyerPaymentMethodTypeID == "Check")
                {
                    AtClosingBuyerPaymentMethodTypeID = "CHK";
                }
                Support.AreEqual(AtClosingBuyerPaymentMethodTypeID, UpdateDisbursementReq.MiscDisbCDPaymentDetails[0].AtClosingBuyerPaymentMethodTypeID.ToString());

                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue().Replace("$", "").ToString(), UpdateDisbursementReq.MiscDisbCDPaymentDetails[1].SellerCharge.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Replace("$", "").ToString(), UpdateDisbursementReq.MiscDisbCDPaymentDetails[1].PBSellerAtClosing.ToString());
                Support.AreEqual(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Replace("$", "").ToString(), UpdateDisbursementReq.MiscDisbCDPaymentDetails[1].PBSellerBeforeClosing.ToString());

                AtClosingSellerPaymentMethodTypeID = FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem();
                if (AtClosingSellerPaymentMethodTypeID == "Check")
                {
                    AtClosingSellerPaymentMethodTypeID = "CHK";
                }
                Support.AreEqual(AtClosingSellerPaymentMethodTypeID, UpdateDisbursementReq.MiscDisbCDPaymentDetails[1].AtClosingSellerPaymentMethodTypeID.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
                #endregion


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG_UpdateMiscellaneousDisbursement_CheckOnly()
        {
            try
            {
                #region FAST Login IIS side
                Reports.TestDescription = "Verify UpdateMiscellaneousDisbursement service";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                #region Invoke  Create Miscellaneous Disbutrsement services
                Reports.TestStep = "Invoke MiscellaneousDisbursement service";
                var MiscDisbusementReq = FileRequestFactory.CreateNewMiscDisbusementRequestCheckOnly(File.FileID);
                var MiscDisbusementRes = FASTWCFHelpers.FileService.CreateMiscellaneousDisbursement(MiscDisbusementReq);
                var UpdateDisbursementReq = FileRequestFactory.UpdateMiscDisbusementRequestCheckOnly(File.FileID);
                var UpdateDisbursementReS = FASTWCFHelpers.FileService.UpdateMiscellaneousDisbursement(UpdateDisbursementReq);
                #endregion


                #region Validate the UI
                Reports.TestStep = " Verify the Business Party Details";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                Support.AreEqual("242", FastDriver.MiscDisbursementDetail.IDCode.FAGetText());
                #endregion

                #region Miscellaneous Disbutrsement CheckOnly Details
                Reports.TestStep = "Miscellaneous Disbutrsement CheckOnly Details";
                Support.AreEqual(FastDriver.MiscDisbursementDetail.CheckOnlyDescription.FAGetValue(), UpdateDisbursementReq.NonBuyerSellerCharge.Description.ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.CheckOnlyCharge.FAGetValue().Contains(UpdateDisbursementReq.NonBuyerSellerCharge.Amount.ToString()).ToString());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG_DeleteMiscellaneousDisbursement_CheckOnly()
        {
            try
            {
                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                #region Invoke  Create Miscellaneous Disbutrsement services
                Reports.TestStep = "Invoke MiscellaneousDisbursement_CheckOnly service";
                var MiscDisbusementReq = FileRequestFactory.CreateNewMiscDisbusementRequestCheckOnly(File.FileID);
                var MiscDisbusementRes = FASTWCFHelpers.FileService.CreateMiscellaneousDisbursement(MiscDisbusementReq);
                #endregion

                #region Validate the UI
                Reports.TestStep = " Verify the Business Party Details";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                Support.AreEqual("248", FastDriver.MiscDisbursementDetail.IDCode.FAGetText());
                #endregion

                #region Miscellaneous Disbutrsement CheckOnly Details
                Reports.TestStep = "Miscellaneous Disbutrsement CheckOnly Details";
                Support.AreEqual(FastDriver.MiscDisbursementDetail.CheckOnlyDescription.FAGetValue(), MiscDisbusementReq.NonBuyerSellerCharge.Description.ToString());
                Support.AreEqual("True", FastDriver.MiscDisbursementDetail.CheckOnlyCharge.FAGetValue().Contains(MiscDisbusementReq.NonBuyerSellerCharge.Amount.ToString()).ToString());

                #endregion

                #region Invoke  Create Miscellaneous Disbutrsement services
                FastDriver.LeftNavigation.Navigate<DepositinEscrow>(@"Home>Order Entry>Escrow Closing>Deposits>Deposit In Escrow").WaitForScreenToLoad();

                Reports.TestStep = "Invoke  Create Miscellaneous Disbutrsement services";
                var DeleteMiscDisbusementReq = FileRequestFactory.GetDeleteMiscDisbRequest(File.FileID);
                var DeleteMiscDisbusementRes = FASTWCFHelpers.FileService.DeleteMiscellaneousDisbursement(DeleteMiscDisbusementReq);

                Reports.TestStep = "Vaidate Miscellaneous Disbutrsement is deleted";
                FastDriver.LeftNavigation.Navigate<MiscDisbursementDetail>(@"Home>Order Entry>Escrow Charge Processes>Miscellaneous Disbursement").WaitForScreenToLoad();
                Support.AreEqual(FastDriver.MiscDisbursementDetail.CheckAmount.FAGetText(), "Check Amount: $ 0.00");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

    }
}
