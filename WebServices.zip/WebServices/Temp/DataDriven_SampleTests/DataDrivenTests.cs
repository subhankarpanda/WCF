﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers.FastFileService;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using FASTWCFHelpers;


namespace Web_Services_Regression.Regression.FileService
{
    [CodedUITest]
    public class DataDrivenTests : FASTHelpers
    {
        //bool isProductadded = false;
        static WCFTestDataStoreEntity reqParams = new WCFTestDataStoreEntity();


        [TestMethod, DeploymentItem(@"..\..\RequestDataFiles\Product.xml")]
        public void REG_AddProduct()
        {
            int i = 2;
            try
            {
                Support.CloseAllProcessStartingWith("EXCEL");
                Reports.TestDescription = "Adding Product.";

                Reports.TestStep = "Login to FAST, create a file using QFE and get the fileId.";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                int fileID = CreateFile();

                Reports.TestStep = "Build the complete user Product List.";
                var ProductCollection = GetProductCollection();

                while (i <= 4)
                {
                    var reqParams = new WCFTestDataStoreEntity
                    {
                        //FilePath = @"E:\Test Automation\FAST\WCF_Automation\FASTSelenium_FAMOS\TestData\",
                        workBookName = "Product.xml",
                        workSheetName = "AddProduct",
                        columnNo = i
                    };

                    var request = ExcelDataSerializer.GetRequestThruExcelDataStore<AddProductRequest>(reqParams);
                    request.FielID = fileID;


                    InvokeAddProductAndValidateOutcome(request);

                    #region VALIDATIONS
                    Reports.TestStep = "Navigate to File HomePage and verify that the intended product has been added.";
                    FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();

                    string product_FromRequest = ProductCollection[(int)request.Product.ProductID];
                    var productSelectionChkBoxElement = FastDriver.FileHomepage.ProductSummaryTable.PerformTableAction(2, product_FromRequest, 1, TableAction.GetCell).Element.FAFindElement(ByLocator.XPath, "./span/input");
                    var e = productSelectionChkBoxElement.IsSelected();
                    Reports.StatusUpdate("Has the specified product been added to the list of products ?", productSelectionChkBoxElement.IsSelected());
                    var actualProductName = FastDriver.FileHomepage.ProductSummaryTable.PerformTableAction(2, product_FromRequest, 2, TableAction.GetText).Message;


                    if (actualProductName == product_FromRequest)
                    {
                        Reports.StatusUpdate("Product :" + product_FromRequest + " added successfully !", true);
                    }
                    else
                    {
                        Reports.StatusUpdate("Product :" + product_FromRequest + " could not be added !", false);
                    }
                    #endregion
                    Support.CloseAllProcessStartingWith("EXCEL");
                    i++;
                }

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally
            {
                Support.CloseAllProcessStartingWith("EXCEL");
            }
        }








        //[TestMethod, DeploymentItem(@"..\..\..\TestData\FileFees.xml")]\
        [TestMethod, DeploymentItem(@"..\..\RequestDataFiles\FileFees.xml")]
        [Description("Verify UpdateFeeEntryDetails() service  for US 741309")]
        public void UpdateFeeEntryDetails_DDDemo()
        {
            try
            {
                Reports.TestDescription = "Verify Adding Lender Policy using UpdateFeeEntryDetails service.";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Init_File();
                #endregion

                Reports.TestStep = "Call SearchFeeEntryFileFees operation to get FeeID";

                //******************CONSTRUCTION OF REQUEST THROUGH THE HARDCODED APPROACH***************************//

                var SFEFFReq = RequestFactory.GetSearchFeeEntryFileFeesRequest(Convert.ToInt32(File.FileID), false, FeeType.TitleLendersPolicy);

                //*************************************************************************************************//

                //Invoke SearchFeeEntryFileFees operation.
                var SFEFFRes = FASTWCFHelpers.FileService.SearchFeeEntryFileFees(SFEFFReq);

                int feeId1 = Convert.ToInt32(SFEFFRes.SearchFileFees[0].FeeID);
                int feeId2 = Convert.ToInt32(SFEFFRes.SearchFileFees[1].FeeID);
                string Desc1 = SFEFFRes.SearchFileFees[0].Description.ToString();
                string Desc2 = SFEFFRes.SearchFileFees[1].Description.ToString();

                #region Invoke UpdateFeeEntryDetails to add Lender Policies

                Reports.TestStep = "Invoke UpdateFeeEntryDetails operation to check successful addition of Lender policies without charge";

                //******************CONSTRUCTION OF REQUEST THROUGH DATA-DRIVEN APPROACH***************************//

                var UFEDReq = RequestFactory.GetUpdateFeeEntry_DDRequest(Convert.ToInt32(File.FileID), 2);

                //*************************************************************************************************//

                UFEDReq.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.FeeID = feeId1;
                UFEDReq.TitleAndEscrow.CdFileFees[1].FeePaymentDetails.FeeID = feeId2;

                var UFEDRes = FASTWCFHelpers.FileService.UpdateFeeEntryDetails(UFEDReq);

                Support.AreEqual("1", UFEDRes.TitleEscrowFileFeesResponse.Status.ToString());
                Support.AreEqual("Title and Escrow File Fee(s) Updated Successfully", UFEDRes.TitleEscrowFileFeesResponse.StatusDescription);

                Reports.TestStep = "Navigate to File Fees page and verify in FAST UI";
                FastDriver.FileFees.Open();
                Support.AreEqual("true", FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, Desc1, 1, TableAction.GetAttribute, "checked").Message.Trim());
                Support.AreEqual("true", FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, Desc2, 1, TableAction.GetAttribute, "checked").Message.Trim());

                Reports.TestStep = "Verify error when multiple lender policies are set as primary policy using UpdateFeeEntryDetails service.";

                //Invoke the operation.
                var GFERes = FASTWCFHelpers.FileService.GetFeeEntryDetails(Convert.ToInt32(File.FileID));

                int LPSFFeeId1 = -1;
                int LPSFFeeId2 = -1;
                for (int i = 0; i < GFERes.TitleAndEscrow.CdFileFees.Length; i++)
                {
                    if (GFERes.TitleAndEscrow.CdFileFees[i].FeePaymentDetails.Description.Equals(Desc1))
                    {
                        LPSFFeeId1 = Convert.ToInt32(GFERes.TitleAndEscrow.CdFileFees[i].FeePaymentDetails.ServiceFileFeeId);
                    }
                    else if (GFERes.TitleAndEscrow.CdFileFees[i].FeePaymentDetails.Description.Equals(Desc2))
                    {
                        LPSFFeeId2 = Convert.ToInt32(GFERes.TitleAndEscrow.CdFileFees[i].FeePaymentDetails.ServiceFileFeeId);
                    }
                }

                //******************CONSTRUCTION OF REQUEST THROUGH DATA-DRIVEN APPROACH***************************//

                UFEDReq = RequestFactory.GetUpdateFeeEntry_DDRequest(Convert.ToInt32(File.FileID), 3);

                //*************************************************************************************************//
                UFEDReq.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.FeeID = feeId1;
                UFEDReq.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.ServiceFileFeeId = LPSFFeeId1;
                UFEDReq.TitleAndEscrow.CdFileFees[1].FeePaymentDetails.FeeID = feeId2;
                UFEDReq.TitleAndEscrow.CdFileFees[1].FeePaymentDetails.ServiceFileFeeId = LPSFFeeId2;

                UFEDRes = FASTWCFHelpers.FileService.UpdateFeeEntryDetails(UFEDReq);
                Support.AreEqual("-1", UFEDRes.TitleEscrowFileFeesResponse.Status.ToString());
                Support.AreEqual("Lender Policy can/Must have only one Primary policy.", UFEDRes.TitleEscrowFileFeesResponse.StatusDescription);

                Reports.TestStep = "Verify the successful addition of Lender policies when one primary policy is set";

                //******************CONSTRUCTION OF REQUEST THROUGH DATA-DRIVEN APPROACH***************************//

                UFEDReq = RequestFactory.GetUpdateFeeEntry_DDRequest(Convert.ToInt32(File.FileID), 4);

                //*************************************************************************************************//

                UFEDReq.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.FeeID = feeId1;
                UFEDReq.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.ServiceFileFeeId = LPSFFeeId1;
                UFEDReq.TitleAndEscrow.CdFileFees[1].FeePaymentDetails.FeeID = feeId2;
                UFEDReq.TitleAndEscrow.CdFileFees[1].FeePaymentDetails.ServiceFileFeeId = LPSFFeeId2;

                //Invoke the operation.
                UFEDRes = FASTWCFHelpers.FileService.UpdateFeeEntryDetails(UFEDReq);

                Support.AreEqual("1", UFEDRes.TitleEscrowFileFeesResponse.Status.ToString());
                Support.AreEqual("Title and Escrow File Fee(s) Updated Successfully", UFEDRes.TitleEscrowFileFeesResponse.StatusDescription);

                Reports.TestStep = "Navigate to File Fees page and verify in FAST UI";
                FastDriver.FileFees.Open();
                Support.AreEqual("true", FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, Desc1, 1, TableAction.GetAttribute, "checked").Message.Trim());
                Support.AreEqual("true", FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, Desc2, 1, TableAction.GetAttribute, "checked").Message.Trim());
                Support.AreEqual(UFEDReq.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.BuyerDetails.ChargeAmount.ToString(), FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, Desc1, 4, TableAction.GetAttribute, "value").Message.Trim());
                Support.AreEqual(UFEDReq.TitleAndEscrow.CdFileFees[1].FeePaymentDetails.BuyerDetails.ChargeAmount.ToString(), FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, Desc2, 4, TableAction.GetAttribute, "value").Message.Trim());

                #endregion

                #region Invoke UpdateFeeEntryDetails to add Owner Policies

                Reports.TestStep = "Call SearchFeeEntryFileFees operation to get FeeID";
                SFEFFReq = RequestFactory.GetSearchFeeEntryFileFeesRequest(Convert.ToInt32(File.FileID), false, FeeType.TitleOwnersPolicy);
                SFEFFRes = FASTWCFHelpers.FileService.SearchFeeEntryFileFees(SFEFFReq);

                int ifeeId1 = Convert.ToInt32(SFEFFRes.SearchFileFees[0].FeeID);
                int ifeeId2 = Convert.ToInt32(SFEFFRes.SearchFileFees[1].FeeID);
                int ifeeTypeCDID = Convert.ToInt32(SFEFFRes.SearchFileFees[0].FeeTypeCDID);
                string sDesc1 = SFEFFRes.SearchFileFees[0].Description.ToString();
                string sDesc2 = SFEFFRes.SearchFileFees[1].Description.ToString();

                Reports.TestStep = "Invoke UpdateFeeEntryDetails operation to check successful addition of Owner policies without charge";

                UFEDReq = RequestFactory.GetUpdateFeeEntry_DDRequest(Convert.ToInt32(File.FileID), 5);
                UFEDReq.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.FeeID = ifeeId1;
                UFEDReq.TitleAndEscrow.CdFileFees[1].FeePaymentDetails.FeeID = ifeeId2;

                UFEDRes = FASTWCFHelpers.FileService.UpdateFeeEntryDetails(UFEDReq);
                Support.AreEqual("1", UFEDRes.TitleEscrowFileFeesResponse.Status.ToString());
                Support.AreEqual("Title and Escrow File Fee(s) Updated Successfully", UFEDRes.TitleEscrowFileFeesResponse.StatusDescription);

                Reports.TestStep = "Navigate to File Fees page and verify in FAST UI";
                FastDriver.FileFees.Open();
                Support.AreEqual("true", FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, sDesc1, 1, TableAction.GetAttribute, "checked").Message.Trim());
                Support.AreEqual("true", FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, sDesc2, 1, TableAction.GetAttribute, "checked").Message.Trim());

                GFERes = FASTWCFHelpers.FileService.GetFeeEntryDetails(Convert.ToInt32(File.FileID));
                int OPSFFeeId1 = -1;
                int OPSFFeeId2 = -1;
                for (int i = 0; i < GFERes.TitleAndEscrow.CdFileFees.Length; i++)
                {
                    if (GFERes.TitleAndEscrow.CdFileFees[i].FeePaymentDetails.Description.Equals(sDesc1))
                    {
                        OPSFFeeId1 = Convert.ToInt32(GFERes.TitleAndEscrow.CdFileFees[i].FeePaymentDetails.ServiceFileFeeId);
                    }
                    else if (GFERes.TitleAndEscrow.CdFileFees[i].FeePaymentDetails.Description.Equals(sDesc2))
                    {
                        OPSFFeeId2 = Convert.ToInt32(GFERes.TitleAndEscrow.CdFileFees[i].FeePaymentDetails.ServiceFileFeeId);
                    }
                }

                Reports.TestStep = "Verify error when multiple Owner policies are set as primary policy using UpdateFeeEntryDetails operation.";

                UFEDReq = RequestFactory.GetUpdateFeeEntry_DDRequest(Convert.ToInt32(File.FileID), 6);
                UFEDReq.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.FeeID = ifeeId1;
                UFEDReq.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.ServiceFileFeeId = OPSFFeeId1;
                UFEDReq.TitleAndEscrow.CdFileFees[1].FeePaymentDetails.FeeID = ifeeId2;
                UFEDReq.TitleAndEscrow.CdFileFees[1].FeePaymentDetails.ServiceFileFeeId = OPSFFeeId2;

                UFEDRes = FASTWCFHelpers.FileService.UpdateFeeEntryDetails(UFEDReq);
                Support.AreEqual("-1", UFEDRes.TitleEscrowFileFeesResponse.Status.ToString());
                Support.AreEqual("Owner Policy can/Must have only one Primary policy.", UFEDRes.TitleEscrowFileFeesResponse.StatusDescription);

                Reports.TestStep = "Verify the successful addition of Owner policies when one primary policy is set";

                UFEDReq = RequestFactory.GetUpdateFeeEntry_DDRequest(Convert.ToInt32(File.FileID), 7);
                UFEDReq.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.FeeID = ifeeId1;
                UFEDReq.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.ServiceFileFeeId = OPSFFeeId1;
                UFEDReq.TitleAndEscrow.CdFileFees[1].FeePaymentDetails.FeeID = ifeeId2;
                UFEDReq.TitleAndEscrow.CdFileFees[1].FeePaymentDetails.ServiceFileFeeId = OPSFFeeId2;

                UFEDRes = FASTWCFHelpers.FileService.UpdateFeeEntryDetails(UFEDReq);
                Support.AreEqual("1", UFEDRes.TitleEscrowFileFeesResponse.Status.ToString());
                Support.AreEqual("Title and Escrow File Fee(s) Updated Successfully", UFEDRes.TitleEscrowFileFeesResponse.StatusDescription);

                Reports.TestStep = "Navigate to File Fees page and verify in FAST UI";
                FastDriver.FileFees.Open();
                Support.AreEqual("true", FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, sDesc1, 1, TableAction.GetAttribute, "checked").Message.Trim());
                Support.AreEqual("true", FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, sDesc2, 1, TableAction.GetAttribute, "checked").Message.Trim());
                Support.AreEqual(UFEDReq.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.BuyerDetails.ChargeAmount.ToString(), FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, sDesc1, 4, TableAction.GetAttribute, "value").Message.Trim());
                Support.AreEqual(UFEDReq.TitleAndEscrow.CdFileFees[1].FeePaymentDetails.BuyerDetails.ChargeAmount.ToString(), FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, sDesc2, 4, TableAction.GetAttribute, "value").Message.Trim());

                #endregion


                #region UpdateFeeEntryDetails service to add Loan Estimate Unrounded amount
                Reports.TestStep = "Verify adding Loan Estimate Unrounded amount for Lender policy";
                FastDriver.FileHomepage.Open();

                UFEDReq = RequestFactory.GetUpdateFeeEntry_DDRequest(Convert.ToInt32(File.FileID), 8);
                UFEDReq.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.FeeID = feeId1;
                UFEDReq.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.ServiceFileFeeId = LPSFFeeId1;
                UFEDReq.TitleAndEscrow.CdFileFees[1].FeePaymentDetails.FeeID = feeId2;
                UFEDReq.TitleAndEscrow.CdFileFees[1].FeePaymentDetails.ServiceFileFeeId = LPSFFeeId2;

                UFEDRes = FASTWCFHelpers.FileService.UpdateFeeEntryDetails(UFEDReq);
                Support.AreEqual("1", UFEDRes.TitleEscrowFileFeesResponse.Status.ToString());
                Support.AreEqual("Title and Escrow File Fee(s) Updated Successfully", UFEDRes.TitleEscrowFileFeesResponse.StatusDescription);
                Reports.TestStep = "Navigate to File Fees page and verify in FAST UI";
                FastDriver.FileFees.Open();
                Support.AreEqual("$" + UFEDReq.TitleAndEscrow.TitlePolicyCalculationsForCD.FullLoanPremium.LoanEstimateUnrounded.ToString(), FastDriver.FileFees.LenderLoanEstimateAmount.FAGetValue());
                Support.AreEqual(UFEDReq.TitleAndEscrow.TitlePolicyCalculationsForCD.FullLoanPremium.LoanEstimateUnrounded.ToString(), FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, Desc1, 11, TableAction.GetAttribute, "value").Message.Trim());
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, Desc1, 3, TableAction.Click);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$" + UFEDReq.TitleAndEscrow.TitlePolicyCalculationsForCD.FullLoanPremium.LoanEstimateUnrounded.ToString(), FastDriver.PaymentDetailsDlg.LoanEstimateUnrounded.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify switching of Primary Lender Policy";
                FastDriver.FileHomepage.Open();

                UFEDReq = RequestFactory.GetUpdateFeeEntry_DDRequest(Convert.ToInt32(File.FileID), 9);
                UFEDReq.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.FeeID = feeId1;
                UFEDReq.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.ServiceFileFeeId = LPSFFeeId1;
                UFEDReq.TitleAndEscrow.CdFileFees[1].FeePaymentDetails.FeeID = feeId2;
                UFEDReq.TitleAndEscrow.CdFileFees[1].FeePaymentDetails.ServiceFileFeeId = LPSFFeeId2;

                UFEDRes = FASTWCFHelpers.FileService.UpdateFeeEntryDetails(UFEDReq);

                Support.AreEqual("1", UFEDRes.TitleEscrowFileFeesResponse.Status.ToString());
                Support.AreEqual("Title and Escrow File Fee(s) Updated Successfully", UFEDRes.TitleEscrowFileFeesResponse.StatusDescription);
                Reports.TestStep = "Navigate to File Fees page and verify in FAST UI";
                FastDriver.FileFees.Open();
                Support.AreEqual(UFEDReq.TitleAndEscrow.TitlePolicyCalculationsForCD.FullLoanPremium.LoanEstimateUnrounded.ToString(), FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, Desc2, 11, TableAction.GetAttribute, "value").Message.Trim());
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, Desc2, 3, TableAction.Click);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual("$" + UFEDReq.TitleAndEscrow.TitlePolicyCalculationsForCD.FullLoanPremium.LoanEstimateUnrounded.ToString(), FastDriver.PaymentDetailsDlg.LoanEstimateUnrounded.FAGetValue());
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify adding disclosed loan premium amount.";

                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        /*    [TestMethod, DeploymentItem(@"..\..\..\TestData\OutsideEscrowCompany.xml")]
            public void REG_CreateOutsideEscrowCompany()
            {
                int i = 2;
                try
                {
                    #region FAST Login IIS side
                    Reports.TestStep = "Login to IIS";
                    FAST_Login_IIS();
                    #endregion

                    Reports.TestStep = "Create a file using WCF and get the fileId.";
                    int fileId = CreateFile();

                    while (i <= 3)
                    {

                        //CreateOutsideEscrowCompany
                        var createOECRequest = RequestFactory.BuildOutsideEscrowCompanyRequest(fileId, "CreateOutsideEscrowCompany", i);

                        //var setSignatureSigningRequest = ExcelDataSerializer.GetRequestThruExcelDataStore<SetOrderSigningRequest>(request);
                        //setSignatureSigningRequest.SigningDetails.FileID = fileId;

                        //var req1 = CreateOrderSigningRequest(fileId);

                        var createOECResponse = ServiceFactory.GetFileService().CreateOutsideEscrowCompany(createOECRequest);

                        //var setSignatureSigningResponse1 = ServiceFactory.GetFileService().SetSignatureSigning(req1);


                        #region Navigate to Outside Escrow Company screen

                        FastDriver.OutsideEscrowCompanyDetail.Open();
                        Playback.Wait(5000);
                        var a = FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FAGetValue() ?? FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FAGetText();
                        ServiceHelper.ContainsUIVal(FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FAGetValue() ?? FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FAGetText(), createOECRequest.OECInformation.OECCharges.CDPaymentDetails[0].Description.ToString(), false, true);
                        ServiceHelper.ContainsUIVal(FastDriver.OutsideEscrowCompanyDetail.BuyerCharge.GetAttribute("value"), createOECRequest.OECInformation.OECCharges.CDPaymentDetails[0].BuyerCharge.ToString(), false, true);
                        ServiceHelper.ContainsUIVal(FastDriver.OutsideEscrowCompanyDetail.SellerCharge.GetAttribute("value"), createOECRequest.OECInformation.OECCharges.CDPaymentDetails[0].SellerCharge.ToString(), false, true);
                        ServiceHelper.ContainsUIVal(FastDriver.OutsideEscrowCompanyDetail.LoanEstimate.GetAttribute("value"), createOECRequest.OECInformation.OECCharges.CDPaymentDetails[0].LEAmount.ToString(), false, true);

                        ServiceHelper.ContainsUIVal(FastDriver.OutsideEscrowCompanyDetail.ChargeDescription2.GetAttribute("value"), createOECRequest.OECInformation.OECCharges.CDPaymentDetails[1].Description.ToString(), false, true);
                        ServiceHelper.ContainsUIVal(FastDriver.OutsideEscrowCompanyDetail.BuyerCharge2.GetAttribute("value"), createOECRequest.OECInformation.OECCharges.CDPaymentDetails[1].BuyerCharge.ToString(), false, true);
                        ServiceHelper.ContainsUIVal(FastDriver.OutsideEscrowCompanyDetail.SellerCharge2.GetAttribute("value"), createOECRequest.OECInformation.OECCharges.CDPaymentDetails[1].SellerCharge.ToString(), false, true);
                        ServiceHelper.ContainsUIVal(FastDriver.OutsideEscrowCompanyDetail.LoanEstimate2.GetAttribute("value"), createOECRequest.OECInformation.OECCharges.CDPaymentDetails[1].LEAmount.ToString(), false, true);

                        #endregion

                        Support.CloseAllProcessStartingWith("EXCEL");
                        i++;
                    }
                }
                catch (Exception ex)
                {
                    Reports.StatusUpdate(ex.Message, false);
                }
            }




            [TestMethod, DeploymentItem(@"..\..\..\TestData\SetSignatureSigning.xml")]
            public void REG_SetSignatureSigning()
            {
                int i = 2;
                Reports.TestStep = "Login to FAST";
                try
                {
                    Reports.TestStep = "Login to FAST and create a file";

                    #region FAST Login IIS side
                    Reports.TestStep = "Login to IIS";
                    FAST_Login_IIS();
                    #endregion

                    Reports.TestStep = "Create a file using WCF and get the fileId.";
                    int fileId = CreateFile();

                    while (i <= 3)
                    {
                       // var reqParams = new WCFTestDataStoreEntity
                        //{
                          //  fileID = fileId,
                            //workBookName = "SetSignatureSigning.xml",
    //                        workSheetName = "SetSignatureSigning",
      //                      columnNo = i
        //                };

                        var setSignatureSigningRequest = RequestFactory.BuildSignatureSigningRequest(fileId, "SetSignatureSigning", i);


                        //var setSignatureSigningRequest = ExcelDataSerializer.GetRequestThruExcelDataStore<SetOrderSigningRequest>(request);
                        //setSignatureSigningRequest.SigningDetails.FileID = fileId;

                        var req1 = CreateOrderSigningRequest(fileId);

                        var setSignatureSigningResponse = ServiceFactory.GetFileService().SetSignatureSigning(setSignatureSigningRequest);

                        var setSignatureSigningResponse1 = ServiceFactory.GetFileService().SetSignatureSigning(req1);

                        Reports.TestStep = "Verifying the Service Response";

                        Reports.StatusUpdate("Is status == 1 in the response ?", Convert.ToInt16(setSignatureSigningResponse.Status).Equals(1));
                        Reports.StatusUpdate("Is the status description as expected in the response ?", setSignatureSigningResponse.StatusDescription.ToLower().ToString().Contains("signing [s.no. 01] created successfully in pending status"), "", "", "", "signing [s.no. 01] created successfully in pending status", setSignatureSigningResponse.StatusDescription.ToString());

                        FastDriver.LeftNavigation.Navigate<SignatureSigning>(@"Home>Order Entry>Escrow Closing>Signature Signing").WaitForScreenToLoad();

                        ServiceHelper.CompareUIDate(FastDriver.SignatureSigning.ProposedDate, "value", setSignatureSigningRequest.SigningDetails.ProposedDate.ToString());
                        ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.ProposedTime, "value", setSignatureSigningRequest.SigningDetails.ProposedTime.ToString());
                        ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.SpecialInstructions, "text", setSignatureSigningRequest.SigningDetails.SpecialInstructions.ToString());

                        ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.SigningAddressLine1, "text", setSignatureSigningRequest.SigningAddress.PhysicalAddress.AddrLine1.ToString());
                        ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.SigningAddressLine2, "text", setSignatureSigningRequest.SigningAddress.PhysicalAddress.AddrLine2.ToString());
                        ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.SigningAddressCity, "text", setSignatureSigningRequest.SigningAddress.PhysicalAddress.City.ToString());
                        ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.SigningAddressstate, "selecteditem", setSignatureSigningRequest.SigningAddress.PhysicalAddress.State.ToString());
                        ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.SigningAddressZip, "text", setSignatureSigningRequest.SigningAddress.PhysicalAddress.Zip.ToString());


                        ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.DeliveryAddressLine1, "text", setSignatureSigningRequest.DeliverAddress.PhysicalAddress.AddrLine1.ToString());
                        ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.DeliveryAddressLine2, "text", setSignatureSigningRequest.DeliverAddress.PhysicalAddress.AddrLine2.ToString());
                        ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.DeliveryAddressCity, "text", setSignatureSigningRequest.DeliverAddress.PhysicalAddress.City.ToString());
                        ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.DeliveryAddressState, "selecteditem", setSignatureSigningRequest.DeliverAddress.PhysicalAddress.State.ToString());
                        ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.DeliveryAddressZip, "text", setSignatureSigningRequest.DeliverAddress.PhysicalAddress.Zip.ToString());


                        ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.PrimaryAddressLine1, "text", setSignatureSigningRequest.PrimaryAddress.PhysicalAddress.AddrLine1.ToString());
                        ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.PrimaryAddressLine2, "text", setSignatureSigningRequest.PrimaryAddress.PhysicalAddress.AddrLine2.ToString());
                        ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.PrimaryAddressCity, "text", setSignatureSigningRequest.PrimaryAddress.PhysicalAddress.City.ToString());
                        ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.PrimaryAddressState, "selecteditem", setSignatureSigningRequest.PrimaryAddress.PhysicalAddress.State.ToString());
                        ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.PrimaryAddressZip, "text", setSignatureSigningRequest.PrimaryAddress.PhysicalAddress.Zip.ToString());


                        if ((FastDriver.SignatureSigning.BuyerSummaryTable.GetRowCount()) == setSignatureSigningRequest.BuyerDetails.Length)
                        {
                            ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.BuyerDetailsFirstName, "text", setSignatureSigningRequest.BuyerDetails[0].FirstName.ToString());
                            ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.BuyerDetailsLastName, "text", setSignatureSigningRequest.BuyerDetails[0].LastName.ToString());
                            ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.BuyerPhonesHomeNumber, "text", setSignatureSigningRequest.BuyerDetails[0].PhoneDetails[0].Number.ToString(), true);
                            ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.BuyerPhonesHomeExtension, "text", setSignatureSigningRequest.BuyerDetails[0].PhoneDetails[0].Ext.ToString(), true);
                        }

                        //Loan Details

                        if ((FastDriver.SignatureSigning.LoanSummaryTable.GetRowCount() - 1) != setSignatureSigningRequest.LoanDetails.Length)
                        {
                            Reports.StatusUpdate("Loan details not matching the request", false);
                        }
                        dynamic LoanDetail = setSignatureSigningRequest.LoanDetails[0];
                        ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.LoanAmount, "text", setSignatureSigningRequest.LoanDetails[0].LoanAmount.ToString(), true, true);
                        ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.LoanNumber, "text", setSignatureSigningRequest.LoanDetails[0].LoanNum.ToString(), true, true);

                        Support.CloseAllProcessStartingWith("EXCEL");
                        i++;
                    }
                }
                catch (Exception ex)
                {
                    Reports.StatusUpdate(ex.Message, false);
                }
            }


            [TestMethod]
            public void REG_RemoveProduct()
            {
                Reports.TestDescription = "Removing Product.";

                Reports.TestStep = "Login to FAST.";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                Reports.TestStep = "Create a file through WCF and get the fileId.";

                var fileID = CreateFile();
                var addProductRequest = CreateRequestForAddProduct<AddProductRequest>(fileID);

                if (InvokeAddProductAndValidateOutcome(addProductRequest))
                {
                    var removeProductRequest = CreateRequestForRemoveProduct<RemoveProductRequest>(fileID);
                    var removeProductResponse = InvokeRemoveProductAndValidateOutcome(removeProductRequest);

                    Reports.TestStep = "Navigate to File HomePage";
                    FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                    Playback.Wait(3000);

                    #region VALIDATIONS
                    var ProductCollection = GetProductCollection();
                    string product_FromRequest = ProductCollection[(int)removeProductRequest.Product.ProductID];

                    //Reports.StatusUpdate("Product is removed from the list of products ?", !FastDriver.FileHomepage.Products.IsSelected().ToString().ToLower().Contains("true"));
                    if (FastDriver.FileHomepage.ProductLabel.FAGetText().Contains(product_FromRequest))
                    {
                        Reports.TestResult = false;
                    }
                    #endregion
                    if (Reports.TestResult)
                    {
                        Reports.StatusUpdate("Product removed successfully !", Reports.TestResult);
                        Support.IsTrue(Reports.TestResult, "Test Passed !");
                    }
                    if (!Reports.TestResult)
                    {
                        Reports.StatusUpdate("Product could not be removed !", false);
                        Support.IsTrue(!Reports.TestResult, "Test Failed !");
                    }

                }
                else
                {
                    Reports.StatusUpdate("Product could not be added successfully ! ", false);
                    Assert.Fail();
                }
            }*/

        #region Private Functions
        private bool WaitForEnabled(IWebElement element = null)
        {
            Reports.TestStep = "Wait for the element until it becomes enabled.";

            //element = Principals;
            try
            {
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                //                element = element ?? FindNow;
                FastDriver.TermsDatesStatus.WaitCreation(element);
                FastDriver.TermsDatesStatus.Wait.Until(dr =>
                {
                    return element.IsEnabled();
                });
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }


        private bool InvokeAddProductAndValidateOutcome(AddProductRequest request)
        {
            bool result = false;
            try
            {
                Reports.StatusUpdate("INVOKING AddProduct OPERATION !", true);
                var response = ServiceFactory.GetFileService().AddProduct(request);

                Reports.TestStep = "Validate the response.";

                Reports.StatusUpdate("Status = " + response.Status, Convert.ToInt16(response.Status).Equals(1));
                Reports.StatusUpdate("Status Description = " + response.StatusDescription, response.StatusDescription.ToLower().ToString().Contains("product added successfully."));
                if (Convert.ToInt16(response.Status).Equals(1) && response.StatusDescription.ToLower().ToString().Contains("product added successfully."))
                {
                    Reports.StatusUpdate("AddProduct operation is successful !", true);
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Invoking AddProduct operation failed! Error : " + ex.Message);
            }
            return result;
        }


        private bool InvokeRemoveProductAndValidateOutcome(RemoveProductRequest request)
        {
            bool result = false;
            try
            {
                Reports.TestStep = "Invoke RemoveProduct operation and get the response.";
                var response = ServiceFactory.GetFileService().RemoveProduct(request);

                Reports.TestStep = "Validate the response.";

                Reports.StatusUpdate("Status = " + response.Status, Convert.ToInt16(response.Status).Equals(1));
                Reports.StatusUpdate("Status Description = " + response.StatusDescription, response.StatusDescription.ToLower().ToString().Contains("product removed successfully."));
                if (Convert.ToInt16(response.Status).Equals(1) && response.StatusDescription.ToLower().ToString().Contains("product removed successfully."))
                {
                    Reports.StatusUpdate("RemoveProduct operation is successful !", true);
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Invoking RemoveProduct operation failed! Error : " + ex.Message);
            }
            return result;
        }


        private int CreateFile()
        {
            int fileID;
            #region Create a file through WCF
            Reports.TestStep = "Create a file with required values through WCF.";
            var fileRequest = CreateFileRequest();

            var fileResponse = FASTWCFHelpers.FileService.CreateFile(fileRequest);
            fileID = (int)fileResponse.FileID;
            Support.IsTrue((int)(fileResponse.FileID ?? 0) > 0, "Is this FileId valid ? " + fileID);

            var fileDetails = FASTWCFHelpers.FileService.GetOrderDetails(fileID);
            Reports.TestStep = "Search File in MRU.";
            FastDriver.TopFrame.SearchFileByFileNumber(fileDetails.FileNumber);
            #endregion

            return fileID;
        }

        private AddProductRequest CreateRequestForAddProduct<T>(int fileID)
        {
            Reports.TestStep = "Construct AddProductRequest object.";
            var request = new FASTWCFHelpers.FastFileService.AddProductRequest()
            {
                FielID = fileID,
                Product = new Product()
                {
                    ProductID = 866
                }
            };
            return request;
        }


        private RemoveProductRequest CreateRequestForRemoveProduct<T>(int fileID)
        {
            Reports.TestStep = "Construct RemoveProductRequest object.";
            var request = new FASTWCFHelpers.FastFileService.RemoveProductRequest()
            {
                FielID = fileID,
                Product = new Product()
                {
                    ProductID = 866
                }
            };
            return request;
        }

        private CreateFileRequest CreateFileRequest()
        {
            return new CreateFileRequest
            {
                EmployeeObjectCD = "1",
                Source = "FAMOS",
                formType = ClosingDisclosureSupport.FormType,

                File = new FASTWCFHelpers.FastFileService.File()
                {
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "Commercial",
                    ExternalFileNumber = "12345678905",
                    AutoNumberIndicator = true,

                    BusinessParties = new FileBusinessParty[]
                    {
                        new FileBusinessParty()
                        {
                            //AddrBookEntryID = AdminService.GetGABAddressBookEntryId("8835227"),
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE",
                        }
                    },

                    Services = new Service[]
                    {
                        new Service()
                        {
                            OfficeInfo = new OfficeInfo()
                            {
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID),
                                BUID = 1487,
                            },
                        ServiceTypeObjectCD = "TO"
                        },
                        new Service()
                        {
                            OfficeInfo = new OfficeInfo()
                            {
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID),
                                BUID = 1487,
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },

                    Properties = new Property[]
                    {
                        new Property()
                        {
                            Name = "my-test-property",
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[]
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress()
                                {
                                    State = "CA",
                                    City = "Santa Ana",
                                    County = "Orange",
                                    Country = "USA"
                                }
                            }
                        }
                    },
                }
            };
        }


        private SetOrderSigningRequest CreateOrderSigningRequest(int fileId)
        {
            return new SetOrderSigningRequest()
            {
                BuyerDetails = new BuyerDetail[]
                {
                    new BuyerDetail()
                    {
                        FirstName = "BuyerFirst",
                        LangPrefTypeCdID = 2545,
                        LastName = "BuyerLast",
                        NameEditable = true,
                        PhoneDetails = new PhoneDetail[]
                        {
                            new PhoneDetail()
                            {
                                ElectronicAddrCdID = 1398,
                                Ext = "11",
                                Number = "1231231234",
                            }
                        }
                    }
                },

                DeliverAddress = new SigningAddress()
                {
                    PhysicalAddrTypeCdID = 1375,
                    PhysicalAddress = new PhysicalAddress()
                    {
                        AddrLine1 = "DelAddress",
                        AddrLine2 = "Del Street",
                        City = "Del City",
                        Country = "Del Country",
                        Enddated = false,
                        State = "CA",
                        Zip = "12312"
                    }
                },

                LoanDetails = new LoanDetail[]
                {
                    new LoanDetail()
                    {
                        AddButtonEditable = true,
                        LenderAddressBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        LoanAmount = "100.02",
                        LoanNum = "1212333",
                        SearchButtonEditable = true
                    }
                },

                PrimaryAddress = new SigningAddress()
                {
                    PhysicalAddrTypeCdID = 1376,
                    PhysicalAddress = new PhysicalAddress()
                    {
                        AddrLine1 = "Pri Addr",
                        AddrLine2 = "Pri street",
                        City = "Pri City",
                        Enddated = false,
                        State = "CA",
                        Zip = "12312"
                    },
                },
                SigningAddress = new SigningAddress()
                {
                    PhysicalAddress = new PhysicalAddress()
                    {
                        AddrLine1 = "Sig addr",
                        AddrLine2 = "Sig Street",
                        City = "Sig City",
                        Enddated = false,
                        State = "CA",
                        Zip = "11223",
                    }
                },

                SigningDetails = new SigningDetail()
                {
                    FileID = (int?)fileId,
                    OrderSource = "FAST",
                    SigningLocTypeCdID = 2543,
                    SigningMethodTypeCdID = 2534,
                    SpecialInstructions = "Validate set",
                    ProposedDate = DateTime.Today.AddDays(2).ToDateString(),
                    ProposedTime = "07:56:03 AM"
                },
            };
        }


        private Dictionary<int, string> GetProductCollection()
        {
            return new Dictionary<int, string>
            {
                {884,"Abstract"},
                {1254,"Agency File Scanning"},
                {1255,"Agency Policy Typing"},
                {1256,"Agency Post Closing"},
                {866, "*ALTA Construction Loan 1992 Policy"},
                {886, "*ALTA Expanded (Eagle Loan) Policy"},
                {868, "ALTA Extended Leasehold Loan Policy"},
                {869,"ALTA Extended Leasehold Owners Policy"},
                {1317,"ALTA Extended Loan Policy"},
                {1318,"ALTA Extended Owner Policy"},
                {2189,"ALTA Homeowner’s Policy (Agent Use Only)"},
                {887,"ALTA Homeowners (Eagle Owner) Policy"},
                {1257,"ALTA Res Ltd Cov Jr Loan Policy (Express)"},
                {877,"ALTA Residential Plain Language Owners Policy"},
                {888,"ALTA Short Form Commercial Loan Policy"},
                {903,"ALTA Short Form Expanded Coverage Residential Loan Policy"},
                {1711,"ALTA Short Form Residential Loan Policy"},
                {1828,"ALTA Short Form Residential Loan Policy - Extended"},
                {875,"ALTA Standard Leasehold Loan Policy"},
                {876,"ALTA Standard Leasehold Owners Policy"},
                {1320,"ALTA Standard Loan Policy"},
                {1838,"ALTA Standard Mtgees Assur Rec Title (SMART)"},
                {1321,"ALTA Standard Owner Policy"},
                {881,"ALTA Standard U.S. Policy 1991"},
                {1674,"America First Loan Policy"},
                {1678,"America First Protection Homeowner’s Binder Policy"},
                {1676,"America First Protection Homeowner’s Policy"},
                {1677,"America First Protection New Home Policy"},
                {1675,"America First Short Form Loan Policy"},
                {1259,"Attorney Assistance"},
                {1260,"Back Plant Request"},
                {900,"Closing Table OP – Land Contract"},
                {906,"CLTA Chain of Title Guar Form"},
                {907,"CLTA Fin Stmt Ln Guar with Add Verif"},
                {908,"CLTA Financing Statement/Lien Guarantee"},
                {1261,"CLTA Interim Binder - Resale"},
                {909,"CLTA Judgment/Tax Lien Guarantee"},
                {1262,"CLTA Lender's Datedown Guarantee"},
                {910,"CLTA Litigation Guar Form 1992"},
                {911,"CLTA Lot Book Guarantee Form 12"},
                {912,"CLTA Mechanic's Lien Guarantee"},
                {1263,"CLTA Parcel Map Guarantee"},
                {913,"CLTA Plant Info Guar Form 17 1992"},
                {914,"CLTA Record Owner Guarantee Form"},
                {915,"CLTA Recorded Doc Guar Form 1990"},
                {882,"CLTA Standard Coverage Loan Policy"},
                {883,"CLTA Standard Coverage Owners Policy"},
                {916,"CLTA Subdivision Guar Form"},
                {1552,"Combo Guarantee"},
                {885,"Commerce Title Eagle Owners"},
                {1147,"Commitment"},
                {928,"Commitment to Endorse"},
                {1264,"Construction Loan Continuation"},
                {917,"Contract Forfeiture Guarantee"},
                {1265,"Copies Only"},
                {1008,"Eagle Search Product"},
                {929,"Endorsement"},
                {1148,"FACT"},
                {1647,"Foreclosure Guarantee and Commitment"},
                {891,"Foreclosure Report"},
                {918,"Future Financing Binder"},
                {1582,"HOA Trustee Sale Guarantee"},
                {1266,"International Loan Policy"},
                {1267,"International Owner Policy"},
                {1550,"Judicial Foreclosure"},
                {919,"Legal, Vesting Information Report"},
                {893,"Letter Report"},
                {920,"Limited Liability Report"},
                {894,"Limited Pre-Foreclosure Policy"},
                {1268,"Limited Trustee Sale Guarantee"},
                {921,"Litigation Guarantee"},
                {922,"Lot Book Guarantee"},
                {1269,"Lot Book Report"},
                {1654,"Manufactured Home Loan Policy"},
                {1653,"Manufactured Home Owner Policy"},
                {1270,"Measure 37 Report"},
                {895,"Misc Report"},
                {1746,"Mortgage Guarantee"},
                {1697,"Mortgage Priority Guarantee"},
                {901,"Mortgagee Policy"},
                {930,"No Product Issued"},
                {902,"Owner Policy of Land"},
                {896,"Ownership & Encumbrances Report"},
                {1149,"Prelim"},
                {1271,"Preliminary Judicial Report"},
                {897,"Prime Loan Policy"},
                {1272,"Private Examination"},
                {898,"Pro Forma"},
                {923,"Property Report"},
                {1273,"Property Search Guarantee"},
                {1734,"Record Owner and Lien Certificate"},
                {924,"Recorded Document Guarantee"},
                {710,"RPIR"},
                {1150,"RPIR-GI"},
                {1733,"Sheriff's Distribution Policy"},
                {1152,"Short Form Commitment"},
                {1274,"Signature Services"},
                {1275,"Standard Owners 1992 - Top"},
                {1577,"Streamline Trustee Sales Guarantee"},
                {925,"Subdivision Guarantee"},
                {1136,"Super Eagle"},
                {1151,"Super Eagle-24 mo"},
                {1549,"Tax Foreclosure Search"},
                {1783,"Texas Chain of Title Policy (T-53)"},
                {1735,"Texas Limited Pre-Foreclosure Policy (T-98)"},
                {1304,"Texas Mortgage Binder on Construction Loan (T13)"},
                {1302,"Texas Mortgagee Policy (T2)"},
                {1305,"Texas Nothing Further Certificate"},
                {1300,"Texas Owner Policy (T1)"},
                {1301,"Texas Residential Owner Policy (T1R)"},
                {1303,"Texas Short Form Mortgagee Policy (T2R)"},
                {1276,"Title Examination"},
                {926,"Title Guaranty"},
                {927,"Title Opinion"},
                {1277,"Tract Search Report"},
                {931,"Trustee Sale Guarantee"},
                {1799,"TX-City Planning Letter"},
                {1286,"UCC - Annual Reports"},
                {1287,"UCC - Articles of Organization"},
                {1288, "UCC - Bankruptcy Search"},
                {1289, "UCC - Corporate Certificate"},
                {1290,"UCC - Judgments Search"},
                {1291,"UCC - Litigation Search"},
                {1292,"UCC - Pending Civil" },
                {1293,"UCC - Tax Lien Search" },
                {1294,"UCC - The Assisted UCC Filing" },
                {1295,"UCC - The Assisted UCC Search" },
                {1296, "UCC - The EAGLE 9 Buyers Policy"},
                {1297,"UCC - The EAGLE 9 UCC Insurance Policy for Lenders" },
                {1298, "UCC - The Insured UCC Filing" },
                {1299, "UCC - The Insured UCC Search"},
                {932,"UCC Policy" },
                {1322,"Water Right Loan Policy" },
                {1323,"Water Right Owners Policy" },
                {1324, "Water Right Search"},
                {1153,"Water Rights Conveyance Report" },
                {1651, "WY Foreclosure Title Policy"}
            };
        }
        #endregion
    }
}
