﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0040_Attorney
{
    [CodedUITest]
    public class US403736_Update_Buyer_Seller_Attorney_Information : FASTHelpers
    {
        private void CreateAttorneyInstance(bool isBuyer)
        {
            FastDriver.LeftNavigation.Navigate<AttorneyDetail>("Home>Order Entry>Attorney - " + (isBuyer ? "Buyer" : "Seller"));
            FastDriver.AttorneyDetail.FindGABcode("415");
            FastDriver.AttorneyDetail.Attention.FASelectItem("automation-user");
            FastDriver.AttorneyDetail.PaymentDetails.Click();
            FAST_UpdatePDD(new FASTSelenium.DataObjects.IIS.PDD()
            {
                BuyerAtClosing = (double)1000000,
                SellerPaidAtClosing = (double)500000,
                LoanEstimateUnrounded = (double)999999.99
            });
            FastDriver.BottomFrame.Done();
        }

        [TestMethod]
        [Description("Verify update Attorney - Buyer license information using UpdateBuyerSellerAttorney web service")]
        public void Scenario_1_Update_Buyer_Attorney()
        {
            try
            {
                Reports.TestDescription = "Verify update Attorney - Buyer license information using UpdateBuyerSellerAttorney web service";

                FAST_Init_File();

                #region Navigate to Attorney - Buyer and create a new instance
                Reports.TestStep = "Navigate to Attorney - Buyer and create a new instance";
                CreateAttorneyInstance(isBuyer: true);
                #endregion

                #region Update Attorney - Buyer contact details with UpdateBuyerSellerAttorney()
                Reports.TestStep = "Update Attorney - Buyer contact details with UpdateBuyerSellerAttorney()";
                var details = FileService.GetBuyerSellerAttorneyDetails(File.FileID ?? 0);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                var request = RequestFactory.GetCreateBuyerSellerAttorneyRequest(File.FileID ?? 0, seqNum: 1);
                request.AttorneyTypeObjectCD = "987";
                request.AttorneyParty = new FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"),
                    BusOrgContact = new BusOrgContact() {
                        ContactID = AdminService.GetGABByAddressBookEntryID(details.BuyerAttorneyDetails[0].AttorneyParty.AddrBookEntryID ?? 0).GABContactID,
                        LicenseInfo = (details.BuyerAttorneyDetails[0].AttorneyParty.BusOrgContact.Licenses != null) ? details.BuyerAttorneyDetails[0].AttorneyParty.BusOrgContact.Licenses[0] : null,
                    },
                    RoleTypeCdID = 322,
                    RoleTypeObjectCD = "BUYERATTY",
                };
                request.AttorneyParty.LicenseInfo = details.BuyerAttorneyDetails[0].AttorneyParty.Licenses != null ? details.BuyerAttorneyDetails[0].AttorneyParty.Licenses[0] : null;
                var response = FileService.UpdateBuyerSellerAttorney(request);
                Support.AreEqual("1", response.OperationResponse.Status.ToString(), response.OperationResponse.StatusDescription);
                #endregion

                #region Navigate to New Loan and Verify NMLS ID and ST License ID after UpdateNewLoan request
                Reports.TestStep = "Navigate to New Loan and Verify NMLS ID and ST License ID after UpdateNewLoan request";
                FastDriver.AttorneyDetail.Open();
                Support.AreEqual("CA, TEST06STATTORNEY", FastDriver.AttorneyDetail.BusOrgStateLicense.FAGetSelectedItem(), "BusOrgStateLicense");
                Support.AreEqual("CA, TEST06STATTORNEY", FastDriver.AttorneyDetail.BusContactStateLicense.FAGetSelectedItem(), "BusContactStateLicense");
                Support.AreEqual("Lender- Originating Branch", FastDriver.AttorneyDetail.Type.FAGetSelectedItem(), "Type");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify update Attorney - Seller license information using UpdateBuyerSellerAttorney web service")]
        public void Scenario_2_Update_Seller_Attorney()
        {
            try
            {
                Reports.TestDescription = "Verify update Attorney - Seller license information using UpdateBuyerSellerAttorney web service";

                FAST_Init_File();

                #region Navigate to Attorney - Seller and create a new instance
                Reports.TestStep = "Navigate to Attorney - Seller and create a new instance";
                CreateAttorneyInstance(isBuyer: false);
                #endregion

                #region Update Attorney - Seller contact details with UpdateBuyerSellerAttorney()
                Reports.TestStep = "Update Attorney - Seller contact details with UpdateBuyerSellerAttorney()";
                var details = FileService.GetBuyerSellerAttorneyDetails(File.FileID ?? 0);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                var request = RequestFactory.GetCreateBuyerSellerAttorneyRequest(File.FileID ?? 0, seqNum: 1);
                request.AttorneyTypeObjectCD = "987";
                request.AttorneyParty = new FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"),
                    BusOrgContact = new BusOrgContact()
                    {
                        ContactID = AdminService.GetGABByAddressBookEntryID(details.SellerAttorneyDetails[0].AttorneyParty.AddrBookEntryID ?? 0).GABContactID,
                        LicenseInfo = (details.SellerAttorneyDetails[0].AttorneyParty.BusOrgContact.Licenses != null) ? details.SellerAttorneyDetails[0].AttorneyParty.BusOrgContact.Licenses[0] : null,
                    },
                    RoleTypeCdID = 325,
                    RoleTypeObjectCD = "SELLATTY",
                };
                request.AttorneyParty.LicenseInfo = details.SellerAttorneyDetails[0].AttorneyParty.Licenses != null ? details.SellerAttorneyDetails[0].AttorneyParty.Licenses[0] : null;
                var response = FileService.UpdateBuyerSellerAttorney(request);
                Support.AreEqual("1", response.OperationResponse.Status.ToString(), response.OperationResponse.StatusDescription);
                #endregion

                #region Navigate to New Loan and Verify NMLS ID and ST License ID after UpdateNewLoan request
                Reports.TestStep = "Navigate to New Loan and Verify NMLS ID and ST License ID after UpdateNewLoan request";
                FastDriver.AttorneyDetail.Open(isBuyer: false);
                Support.AreEqual("CA, TEST06STATTORNEY", FastDriver.AttorneyDetail.BusOrgStateLicense.FAGetSelectedItem(), "BusOrgStateLicense");
                Support.AreEqual("CA, TEST06STATTORNEY", FastDriver.AttorneyDetail.BusContactStateLicense.FAGetSelectedItem(), "BusContactStateLicense");
                Support.AreEqual("Lender- Originating Branch", FastDriver.AttorneyDetail.Type.FAGetSelectedItem(), "Type");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
