﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0040_Attorney
{
    [CodedUITest]
    public class US334463_Retrieve_Payment_Details : FASTHelpers
    {
        #region var paymentDetails
        protected PDD paymentDetails = new PDD()
        {
            ChargeDescription = "test-charge-description",
            UseDefaultChecked = false,
            PayeeName = "test-payee-name",
            LoanEstimateUnrounded = (double)15099.99,
            PartOfCheckbox = true,
            //SectionCDidShopFor = true,
            BuyerAtClosing = (double)15000,
            BuyerBeforeClosing = (double)5000,
            BuyerPaidbyOther = (double)10000,
            BuyerPaidbyOtherPaymentMethod = "POC",
            BuyerLenderCheckbox = false,
            BuyerDoubleAsteriskChecked = false,
            SellerPaidAtClosing = (double)12000,
            SellerPaidBeforeClosing = (double)6000,
            SellerPaidbyOthers = (double)6000,
            SellerPaidbyOtherPaymentMthd = "POC",
        };
        #endregion

        [TestMethod]
        [Description("Verify retrieve Buyer Attorney charge payment details using GetBuyerSellerAttorneyDetails")]
        public void Scenario_1_Retrieve_BuyerAttorney_PDD()
        {
            try
            {
                Reports.TestDescription = "Verify retrieve Buyer Attorney charge payment details using GetBuyerSellerAttorneyDetails";

                FAST_Init_File();

                #region Navigate to Attorney - Buyer and create a new instance
                Reports.TestStep = "Navigate to Attorney - Buyer and create a new instance";
                FastDriver.AttorneyDetail.Open();
                FastDriver.AttorneyDetail.FindGABcode("415");
                FastDriver.AttorneyDetail.Type.FASelectItemBySendingKeys("Attorney- Local");
                FastDriver.AttorneyDetail.PaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Attorney - Buyer information using GetBuyerSellerAttorneyDetails()
                Reports.TestStep = "Verify Attorney - Buyer information using GetBuyerSellerAttorneyDetails()";
                var details = FileService.GetBuyerSellerAttorneyDetails(File.FileID ?? 0);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                Support.AreEqual("704", details.BuyerAttorneyDetails[0].AttorneyTypeObjectCD, "AttorneyTypeObjectCD");
                Support.AreEqual("415", details.BuyerAttorneyDetails[0].AttorneyParty.IDCode ?? "", "IDCode");
                Support.AreEqual(paymentDetails.ChargeDescription, details.BuyerAttorneyDetails[0].CDChargeList[0].Description, "Description");
                Support.AreEqual(paymentDetails.UseDefaultChecked.ToString(), details.BuyerAttorneyDetails[0].CDChargeList[0].UseDefault.ToString(), "UseDefault");
                Support.AreEqual(paymentDetails.PayeeName, details.BuyerAttorneyDetails[0].CDChargeList[0].PayeeNameOnCDOrSettlementStmt, "PayeeName");
                Support.AreEqual(((Decimal)paymentDetails.LoanEstimateUnrounded).ToString("C2"), ((Decimal)details.BuyerAttorneyDetails[0].CDChargeList[0].LEAmount).ToString("C2"), "LEAmount");
                Support.AreEqual(paymentDetails.PartOfCheckbox.ToString(), details.BuyerAttorneyDetails[0].CDChargeList[0].PartOf.ToString(), "PartOf");
                Support.AreEqual(((Decimal)paymentDetails.BuyerAtClosing).ToString("C2"), ((Decimal)details.BuyerAttorneyDetails[0].CDChargeList[0].PBBuyerAtClosing).ToString("C2"), "PBBuyerAtClosing");
                Support.AreEqual(((Decimal)paymentDetails.BuyerBeforeClosing).ToString("C2"), ((Decimal)details.BuyerAttorneyDetails[0].CDChargeList[0].PBBuyerBeforeClosing).ToString("C2"), "PBBuyerBeforeClosing");
                Support.AreEqual(((Decimal)paymentDetails.BuyerPaidbyOther).ToString("C2"), ((Decimal)details.BuyerAttorneyDetails[0].CDChargeList[0].PBOthersForBuyer).ToString("C2"), "PBOthersForBuyer");
                Support.AreEqual(paymentDetails.BuyerPaidbyOtherPaymentMethod, details.BuyerAttorneyDetails[0].CDChargeList[0].PBOthersForBuyerPMTypeCdID.ToString(), "PBOthersForBuyerPMTypeCdID");
                Support.AreEqual(paymentDetails.BuyerLenderCheckbox.ToString(), details.BuyerAttorneyDetails[0].CDChargeList[0].DisplayLBuyer.ToString(), "DisplayLBuyer");
                Support.AreEqual(paymentDetails.BuyerDoubleAsteriskChecked.ToString(), details.BuyerAttorneyDetails[0].CDChargeList[0].DoubleAsteriskIndicator.ToString(), "DoubleAsteriskIndicator");
                Support.AreEqual(((Decimal)paymentDetails.SellerPaidAtClosing).ToString("C2"), ((Decimal)details.BuyerAttorneyDetails[0].CDChargeList[0].PBSellerAtClosing).ToString("C2"), "PBSellerAtClosing");
                Support.AreEqual(((Decimal)paymentDetails.SellerPaidBeforeClosing).ToString("C2"), ((Decimal)details.BuyerAttorneyDetails[0].CDChargeList[0].PBSellerBeforeClosing).ToString("C2"), "PBSellerBeforeClosing");
                Support.AreEqual(((Decimal)paymentDetails.SellerPaidbyOthers).ToString("C2"), ((Decimal)details.BuyerAttorneyDetails[0].CDChargeList[0].PBOthersForSeller).ToString("C2"), "PBOthersForSeller");
                Support.AreEqual(paymentDetails.SellerPaidbyOtherPaymentMthd, details.BuyerAttorneyDetails[0].CDChargeList[0].PBOthersForSellerPMTypeCdID.ToString(), "PBOthersForSellerPMTypeCdID");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify retrieve Seller Attorney charge payment details using GetBuyerSellerAttorneyDetails")]
        public void Scenario_2_Retrieve_SellerAttorney_PDD()
        {
            try
            {
                Reports.TestDescription = "Verify retrieve Seller Attorney charge payment details using GetBuyerSellerAttorneyDetails";

                FAST_Init_File();

                #region Navigate to Attorney - Seller and create a new instance
                Reports.TestStep = "Navigate to Attorney - Seller and create a new instance";
                FastDriver.AttorneyDetail.Open(isBuyer:false);
                FastDriver.AttorneyDetail.FindGABcode("415");
                FastDriver.AttorneyDetail.Type.FASelectItemBySendingKeys("Attorney- Local");
                FastDriver.AttorneyDetail.PaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Attorney - Seller information using GetBuyerSellerAttorneyDetails()
                Reports.TestStep = "Verify Attorney - Seller information using GetBuyerSellerAttorneyDetails()";
                var details = FileService.GetBuyerSellerAttorneyDetails(File.FileID ?? 0);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                Support.AreEqual("704", details.SellerAttorneyDetails[0].AttorneyTypeObjectCD, "AttorneyTypeObjectCD");
                Support.AreEqual("415", details.SellerAttorneyDetails[0].AttorneyParty.IDCode ?? "", "IDCode");
                Support.AreEqual(paymentDetails.ChargeDescription, details.SellerAttorneyDetails[0].CDChargeList[0].Description, "Description");
                Support.AreEqual(paymentDetails.UseDefaultChecked.ToString(), details.SellerAttorneyDetails[0].CDChargeList[0].UseDefault.ToString(), "UseDefault");
                Support.AreEqual(paymentDetails.PayeeName, details.SellerAttorneyDetails[0].CDChargeList[0].PayeeNameOnCDOrSettlementStmt, "PayeeName");
                Support.AreEqual(((Decimal)paymentDetails.LoanEstimateUnrounded).ToString("C2"), ((Decimal)details.SellerAttorneyDetails[0].CDChargeList[0].LEAmount).ToString("C2"), "LEAmount");
                Support.AreEqual(paymentDetails.PartOfCheckbox.ToString(), details.SellerAttorneyDetails[0].CDChargeList[0].PartOf.ToString(), "PartOf");
                Support.AreEqual(((Decimal)paymentDetails.BuyerAtClosing).ToString("C2"), ((Decimal)details.SellerAttorneyDetails[0].CDChargeList[0].PBBuyerAtClosing).ToString("C2"), "PBBuyerAtClosing");
                Support.AreEqual(((Decimal)paymentDetails.BuyerBeforeClosing).ToString("C2"), ((Decimal)details.SellerAttorneyDetails[0].CDChargeList[0].PBBuyerBeforeClosing).ToString("C2"), "PBBuyerBeforeClosing");
                Support.AreEqual(((Decimal)paymentDetails.BuyerPaidbyOther).ToString("C2"), ((Decimal)details.SellerAttorneyDetails[0].CDChargeList[0].PBOthersForBuyer).ToString("C2"), "PBOthersForBuyer");
                Support.AreEqual(paymentDetails.BuyerPaidbyOtherPaymentMethod, details.SellerAttorneyDetails[0].CDChargeList[0].PBOthersForBuyerPMTypeCdID.ToString(), "PBOthersForBuyerPMTypeCdID");
                Support.AreEqual(paymentDetails.BuyerLenderCheckbox.ToString(), details.SellerAttorneyDetails[0].CDChargeList[0].DisplayLBuyer.ToString(), "DisplayLBuyer");
                Support.AreEqual(paymentDetails.BuyerDoubleAsteriskChecked.ToString(), details.SellerAttorneyDetails[0].CDChargeList[0].DoubleAsteriskIndicator.ToString(), "DoubleAsteriskIndicator");
                Support.AreEqual(((Decimal)paymentDetails.SellerPaidAtClosing).ToString("C2"), ((Decimal)details.SellerAttorneyDetails[0].CDChargeList[0].PBSellerAtClosing).ToString("C2"), "PBSellerAtClosing");
                Support.AreEqual(((Decimal)paymentDetails.SellerPaidBeforeClosing).ToString("C2"), ((Decimal)details.SellerAttorneyDetails[0].CDChargeList[0].PBSellerBeforeClosing).ToString("C2"), "PBSellerBeforeClosing");
                Support.AreEqual(((Decimal)paymentDetails.SellerPaidbyOthers).ToString("C2"), ((Decimal)details.SellerAttorneyDetails[0].CDChargeList[0].PBOthersForSeller).ToString("C2"), "PBOthersForSeller");
                Support.AreEqual(paymentDetails.SellerPaidbyOtherPaymentMthd, details.SellerAttorneyDetails[0].CDChargeList[0].PBOthersForSellerPMTypeCdID.ToString(), "PBOthersForSellerPMTypeCdID");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
