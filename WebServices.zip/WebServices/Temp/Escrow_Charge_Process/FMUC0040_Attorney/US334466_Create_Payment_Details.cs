﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0040_Attorney
{
    [CodedUITest]
    public class US334466_Create_Payment_Details : FASTHelpers
    {
        #region var paymentDetails
        protected PDD paymentDetails = new PDD()
        {
            ChargeDescription = "test-charge-description",
            UseDefaultChecked = false,
            PayeeName = "test-payee-name",
            LoanEstimateUnrounded = (double)15099.99,
            PartOfCheckbox = true,
            //SectionCDidShopFor = true,
            BuyerAtClosing = (double)15000,
            BuyerBeforeClosing = (double)5000,
            BuyerPaidbyOther = (double)10000,
            BuyerPaidbyOtherPaymentMethod = "POC",
            BuyerLenderCheckbox = false,
            BuyerDoubleAsteriskChecked = false,
            SellerPaidAtClosing = (double)12000,
            SellerPaidBeforeClosing = (double)6000,
            SellerPaidbyOthers = (double)6000,
            SellerPaidbyOtherPaymentMthd = "POC",
        };
        #endregion

        [TestMethod]
        [Description("Verify create Buyer Attorney information using CreateBuyerSellerAttorney web service")]
        public void Scenario_1_Create_BuyerAttorney_PDD_with_CreateBuyerSellerAttorney()
        {
            try
            {
                Reports.TestDescription = "Verify create Buyer Attorney information using CreateBuyerSellerAttorney web service";

                FAST_Init_File();

                #region Add Buyer Attorney details using CreateBuyerSellerAttorney()
                Reports.TestStep = "Add Buyer Attorney details using CreateBuyerSellerAttorney()";
                var request = RequestFactory.GetCreateBuyerSellerAttorneyRequest(File.FileID ?? 0, seqNum: 1);
                request.AttorneyTypeObjectCD = "702";
                request.AttorneyParty = new FileBusinessParty() { 
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"),
                    RoleTypeCdID = 322,
                    RoleTypeObjectCD = "BUYERATTY",
                };
                request.CDChargeList = new CDChargePaymentDetails[]{
                    new CDChargePaymentDetails(){
                        Description = "test-charge-description",
                        UseDefault = false,
                        PayeeNameOnCDOrSettlementStmt = "test-payee-name",
                        LEAmount = (decimal)15099.99,
                        PartOf = true,
                        //eSectionShop = SectionsShoppedFor.SectionCdidShopFor,
                        PBBuyerAtClosing = (decimal)15000,
                        AtClosingBuyerPaymentMethodTypeID = AtClosingPaymentMethods.CHK,
                        PBBuyerBeforeClosing = (decimal)5000,
                        PBOthersForBuyer = (decimal)10000,
                        PBOthersForBuyerPMTypeCdID = OtherPaymentMethods.POC,
                        DisplayLBuyer = false,
                        BuyerCreditPaymentMethodTypeCdID = CreditPaymentMethods.Lender,
                        DoubleAsteriskIndicator = false,
                        PBSellerAtClosing = (decimal)12000,
                        AtClosingSellerPaymentMethodTypeID = AtClosingPaymentMethods.CHK,
                        PBSellerBeforeClosing = (decimal)6000,
                        PBOthersForSeller = (decimal)6000,
                        PBOthersForSellerPMTypeCdID = OtherPaymentMethods.POC,
                        SellerCreditPaymentMethodTypeCdID = CreditPaymentMethods.Lender,
                        SeqNum = 1,
                    },
                };
                var response = FileService.CreateBuyerSellerAttorney(request);
                Support.AreEqual("1", response.OperationResponse.Status.ToString(), response.OperationResponse.StatusDescription);
                #endregion
                
                #region Verify Attorney - Buyer charge information in FAST
                Reports.TestStep = "Verify Attorney - Buyer charge information in FAST";
                FastDriver.AttorneyDetail.Open();
                FastDriver.AttorneyDetail.PaymentDetails.Click();
                FAST_VerifyPDD(paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify create Seller Attorney information using CreateBuyerSellerAttorney web service")]
        public void Scenario_2_Create_SellerAttorney_PDD_with_CreateBuyerSellerAttorney()
        {
            try
            {
                Reports.TestDescription = "Verify create Seller Attorney information using CreateBuyerSellerAttorney web service";

                FAST_Init_File();

                #region Add Seller Attorney details using CreateBuyerSellerAttorney()
                Reports.TestStep = "Add Seller Attorney details using CreateBuyerSellerAttorney()";
                var request = RequestFactory.GetCreateBuyerSellerAttorneyRequest(File.FileID ?? 0, seqNum: 1);
                request.AttorneyTypeObjectCD = "702";
                request.AttorneyParty = new FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"),
                    RoleTypeCdID = 325,
                    RoleTypeObjectCD = "SELLATTY",
                };
                request.CDChargeList = new CDChargePaymentDetails[]{
                    new CDChargePaymentDetails(){
                        Description = "test-charge-description",
                        UseDefault = false,
                        PayeeNameOnCDOrSettlementStmt = "test-payee-name",
                        LEAmount = (decimal)15099.99,
                        PartOf = true,
                        //eSectionShop = SectionsShoppedFor.SectionCdidShopFor,
                        PBBuyerAtClosing = (decimal)15000,
                        AtClosingBuyerPaymentMethodTypeID = AtClosingPaymentMethods.CHK,
                        PBBuyerBeforeClosing = (decimal)5000,
                        PBOthersForBuyer = (decimal)10000,
                        PBOthersForBuyerPMTypeCdID = OtherPaymentMethods.POC,
                        DisplayLBuyer = false,
                        BuyerCreditPaymentMethodTypeCdID = CreditPaymentMethods.Lender,
                        DoubleAsteriskIndicator = false,
                        PBSellerAtClosing = (decimal)12000,
                        AtClosingSellerPaymentMethodTypeID = AtClosingPaymentMethods.CHK,
                        PBSellerBeforeClosing = (decimal)6000,
                        PBOthersForSeller = (decimal)6000,
                        PBOthersForSellerPMTypeCdID = OtherPaymentMethods.POC,
                        SellerCreditPaymentMethodTypeCdID = CreditPaymentMethods.Lender,
                        SeqNum = 1,
                    },
                };
                var response = FileService.CreateBuyerSellerAttorney(request);
                Support.AreEqual("1", response.OperationResponse.Status.ToString(), response.OperationResponse.StatusDescription);
                #endregion

                #region Verify Attorney - Seller charge information in FAST
                Reports.TestStep = "Verify Attorney - Seller charge information in FAST";
                FastDriver.AttorneyDetail.Open(isBuyer: false);
                FastDriver.AttorneyDetail.PaymentDetails.Click();
                FAST_VerifyPDD(paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify create Buyer Attorney information using UpdateBuyerSellerAttorney web service")]
        public void Scenario_3_Create_BuyerAttorney_PDD_with_UpdateBuyerSellerAttorney()
        {
            try
            {
                Reports.TestDescription = "Verify create Buyer Attorney information using UpdateBuyerSellerAttorney web service";

                FAST_Init_File();

                #region Add Buyer Attorney details using UpdateBuyerSellerAttorney()
                Reports.TestStep = "Add Buyer Attorney details using UpdateBuyerSellerAttorney()";
                FastDriver.AttorneyDetail.Open();
                FastDriver.AttorneyDetail.FindGABcode("415");
                FastDriver.BottomFrame.Done();
                var request = RequestFactory.GetCreateBuyerSellerAttorneyRequest(File.FileID ?? 0, seqNum: 1);
                request.AttorneyTypeObjectCD = "702";
                request.AttorneyParty = new FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"),
                    RoleTypeCdID = 322,
                    RoleTypeObjectCD = "BUYERATTY",
                };
                request.CDChargeList = new CDChargePaymentDetails[]{
                    new CDChargePaymentDetails(){
                        Description = "test-charge-description",
                        UseDefault = false,
                        PayeeNameOnCDOrSettlementStmt = "test-payee-name",
                        LEAmount = (decimal)15099.99,
                        PartOf = true,
                        //eSectionShop = SectionsShoppedFor.SectionCdidShopFor,
                        PBBuyerAtClosing = (decimal)15000,
                        AtClosingBuyerPaymentMethodTypeID = AtClosingPaymentMethods.CHK,
                        PBBuyerBeforeClosing = (decimal)5000,
                        PBOthersForBuyer = (decimal)10000,
                        PBOthersForBuyerPMTypeCdID = OtherPaymentMethods.POC,
                        DisplayLBuyer = false,
                        BuyerCreditPaymentMethodTypeCdID = CreditPaymentMethods.Lender,
                        DoubleAsteriskIndicator = false,
                        PBSellerAtClosing = (decimal)12000,
                        AtClosingSellerPaymentMethodTypeID = AtClosingPaymentMethods.CHK,
                        PBSellerBeforeClosing = (decimal)6000,
                        PBOthersForSeller = (decimal)6000,
                        PBOthersForSellerPMTypeCdID = OtherPaymentMethods.POC,
                        SellerCreditPaymentMethodTypeCdID = CreditPaymentMethods.Lender,
                        SeqNum = 1,
                    },
                };
                var response = FileService.UpdateBuyerSellerAttorney(request);
                Support.AreEqual("1", response.OperationResponse.Status.ToString(), response.OperationResponse.StatusDescription);
                #endregion

                #region Verify Attorney - Buyer charge information in FAST
                Reports.TestStep = "Verify Attorney - Buyer charge information in FAST";
                FastDriver.AttorneyDetail.Open();
                FastDriver.AttorneyDetail.PaymentDetails.Click();
                FAST_VerifyPDD(paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        
        [TestMethod]
        [Description("Verify create Seller Attorney information using UpdateBuyerSellerAttorney web service")]
        public void Scenario_4_Create_SellerAttorney_PDD_with_UpdateBuyerSellerAttorney()
        {
            try
            {
                Reports.TestDescription = "Verify create Seller Attorney information using UpdateBuyerSellerAttorney web service";

                FAST_Init_File();

                #region Add Seller Attorney details using UpdateBuyerSellerAttorney()
                Reports.TestStep = "Add Seller Attorney details using UpdateBuyerSellerAttorney()";
                FastDriver.AttorneyDetail.Open();
                FastDriver.AttorneyDetail.FindGABcode("415");
                FastDriver.BottomFrame.Done();
                var request = RequestFactory.GetCreateBuyerSellerAttorneyRequest(File.FileID ?? 0, seqNum: 1);
                request.AttorneyTypeObjectCD = "702";
                request.AttorneyParty = new FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"),
                    RoleTypeCdID = 325,
                    RoleTypeObjectCD = "SELLATTY",
                };
                request.CDChargeList = new CDChargePaymentDetails[]{
                    new CDChargePaymentDetails(){
                        Description = "test-charge-description",
                        UseDefault = false,
                        PayeeNameOnCDOrSettlementStmt = "test-payee-name",
                        LEAmount = (decimal)15099.99,
                        PartOf = true,
                        //eSectionShop = SectionsShoppedFor.SectionCdidShopFor,
                        PBBuyerAtClosing = (decimal)15000,
                        AtClosingBuyerPaymentMethodTypeID = AtClosingPaymentMethods.CHK,
                        PBBuyerBeforeClosing = (decimal)5000,
                        PBOthersForBuyer = (decimal)10000,
                        PBOthersForBuyerPMTypeCdID = OtherPaymentMethods.POC,
                        DisplayLBuyer = false,
                        BuyerCreditPaymentMethodTypeCdID = CreditPaymentMethods.Lender,
                        DoubleAsteriskIndicator = false,
                        PBSellerAtClosing = (decimal)12000,
                        AtClosingSellerPaymentMethodTypeID = AtClosingPaymentMethods.CHK,
                        PBSellerBeforeClosing = (decimal)6000,
                        PBOthersForSeller = (decimal)6000,
                        PBOthersForSellerPMTypeCdID = OtherPaymentMethods.POC,
                        SellerCreditPaymentMethodTypeCdID = CreditPaymentMethods.Lender,
                        SeqNum = 1,
                    },
                };
                var response = FileService.CreateBuyerSellerAttorney(request);
                Support.AreEqual("1", response.OperationResponse.Status.ToString(), response.OperationResponse.StatusDescription);
                #endregion

                #region Verify Attorney - Seller charge information in FAST
                Reports.TestStep = "Verify Attorney - Seller charge information in FAST";
                FastDriver.AttorneyDetail.Open(isBuyer: false);
                FastDriver.AttorneyDetail.PaymentDetails.Click();
                FAST_VerifyPDD(paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
