﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0089_OutsideTitleCompany
{
    [CodedUITest]
    public class US336329_Remove_Outside_Title_Company : FASTHelpers
    {
        [TestMethod]
        [Description("Verify remove Outside Title Company instance using DeleteOutsideTitleCompany web service")]
        public void Scenario_1_Remove_Outside_Title_Company()
        {
            try
            {
                Reports.TestDescription = "Verify remove Outside Title Company instance using DeleteOutsideTitleCompany web service";

                FAST_Init_File();

                #region Navigate to Outside Title Company and create a new instance
                Reports.TestStep = "Navigate to Outside Title Company and create a new instance";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.FindGAB("415");
                FastDriver.OTCDetail.ChargesRetained.FASetText("1300000");
                FastDriver.OTCDetail.Type.FASelectItemBySendingKeys("Attorney");
                FastDriver.OTCDetail.OTCTitleServicesPaymentDetails.Click();
                var paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
                {
                    BuyerAtClosing = (double)500000,
                    BuyerCredit = (double)1000000,
                    SellerPaidAtClosing = (double)500000,
                    SellerCredit = (double)1000000,
                    LoanEstimateUnrounded = (double)999999.99
                };
                FAST_UpdatePDD(paymentDetails);
                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.DisplayAggregateOnCD.FASetCheckbox(true);
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementPaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.OTCOwnerPolicyEndorsementPaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.GRCLoanEstimateUnroundedAmount.FASetText("999999.99");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OTCDetail.TTLoanEstimateUnroundedAmount.FASetText("999999.99");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                FastDriver.OTCDetail.WaitForScreenToLoad();
                #endregion

                #region Remove OTC instance with DeleteOutsideTitleCompany()
                Reports.TestStep = "Remove OTC instance with DeleteOutsideTitleCompany()";
                var request = EscrowRequestFactory.GetOTCRequest(File.FileID, seqNum: 1);
                var response = EscrowService.DeleteOutsideTitleCompany(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify OTC instance was removed in FAST
                Reports.TestStep = "Verify OTC instance was removed in FAST";
                FastDriver.OTCDetail.Open();
                Support.AreEqual("", FastDriver.OTCDetail.GABcodeLabel.Text ?? "", "GABcodeLabel");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
