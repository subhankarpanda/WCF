﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0089_OutsideTitleCompany
{
    [CodedUITest]
    public class US403374_Retrieve_Outside_Title_Company_License_Info : FASTHelpers
    {
        [TestMethod]
        [Description("Verify Outside Title Company information with NMLS & STLicenseID")]
        public void Scenario_1_OTC_Info_having_STLicenseID()
        {
            try
            {
                Reports.TestDescription = "Verify Outside Title Company information with NMLS & STLicenseID";

                FAST_Init_File(GABCode:"415", GABRole:AdditionalRoleType.OutsideTitleCompany);

                #region Navigate to OTC and Verify ST License ID
                Reports.TestStep = "Navigate to OTC and Verify ST License ID";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.BusOrg_LicenseID.FASelectItemBySendingKeys("CA, TEST04STTITLEINS");
                FastDriver.OTCDetail.BusOrg_ContactLicenseID.FASelectItemBySendingKeys("CA, TEST04STTITLEINS");
                FastDriver.BottomFrame.Done();
                FastDriver.OTCDetail.WaitForScreenToLoad();
                Support.AreEqual("CA, TEST04STTITLEINS", FastDriver.OTCDetail.BusOrg_LicenseID.FAGetSelectedItem(), "BusOrg_LicenseID");
                Support.AreEqual("CA, TEST04STTITLEINS", FastDriver.OTCDetail.BusOrg_ContactLicenseID.FAGetSelectedItem(), "BusOrg_ContactLicenseID");
                #endregion

                #region Verify ST License ID with GetOutsideTitleCompanyDetails web service
                Reports.TestStep = "Verify ST License ID with GetOutsideTitleCompanyDetails web service";
                var details = EscrowService.GetOutsideTitleCompanyDetails(EscrowRequestFactory.GetServiceFileRequest(File.FileID ?? 0));
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                var busPartyLicenseInfo = details.OTCInformations[0].OTCFileBusinessPartyInfo.FileBusinessParty.LicenseInfo;
                Support.AreEqual("CA, TEST04STTITLEINS", busPartyLicenseInfo != null ? (busPartyLicenseInfo.StateLicenseNo ?? "null") : "null", "busPartyLicenseInfo.StateLicenseNo");
                var contactLicenseParty = details.OTCInformations[0].OTCFileBusinessPartyInfo.FileBusinessParty.BusOrgContact.LicenseInfo;
                Support.AreEqual("CA, TEST04STTITLEINS", contactLicenseParty != null ? (contactLicenseParty.StateLicenseNo ?? "null") : "null", "contactLicenseParty.StateLicenseNo");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
