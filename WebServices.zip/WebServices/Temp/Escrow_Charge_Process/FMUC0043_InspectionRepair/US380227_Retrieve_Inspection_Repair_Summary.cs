﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0043_InspectionRepair
{
    [CodedUITest]
    public class US380227_Retrieve_Inspection_Repair_Summary : FASTHelpers
    {
        [TestMethod]
        [Description("Verify retirieve Inspection Repair Pest information using GetInspectionRepairPestSummary web service")]
        public void Scenario_1_Retrieve_Inspection_Repair_Pest_Summary()
        {
            try
            {
                Reports.TestDescription = "Verify retirieve Inspection Repair Pest information using GetInspectionRepairPestSummary web service";

                FAST_Init_File();

                #region Navigate to Inspection Repair Pest and create a new instance
                Reports.TestStep = "Navigate to Inspection Repair Pest and create a new instance";
                FastDriver.InspectionRepairPest.Open();
                FastDriver.InspectionRepairPest.FindGAB("415");
                FastDriver.InspectionRepairPest.FurnishedBy.FASelectItemBySendingKeys("Seller");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("14");
                FastDriver.InspectionRepairPest.OrderDate.FASetText(DateTime.Today.ToDateString());
                FastDriver.InspectionRepairPest.DueDate.FASetText(DateTime.Today.AddDays(7).ToDateString());
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText(DateTime.Today.AddDays(14).ToDateString());
                FastDriver.InspectionRepairPest.CompleteDate.FASetText(DateTime.Today.AddDays(28).ToDateString());
                FastDriver.InspectionRepairPest.ReportDate.FASetText(DateTime.Today.AddDays(35).ToDateString());
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("5,000.00");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("5,000.00");
                FastDriver.InspectionRepairPest.LoanEstimate.FASetText("9,999.99");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Inspection Repair Pest with GetInspectionRepairPestSummary()
                Reports.TestStep = "Verify Inspection Repair Pest with GetInspectionRepairPestSummary()";
                var request = EscrowRequestFactory.GetIRPSRequest(File.FileID);
                var details = EscrowService.GetInspectionRepairPestSummary(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                Support.AreEqual("Continental Mortgage Corporation", details.InspectionRepairSummary[0].BusOrgName, "BusOrgName");
                Support.AreEqual("(847)797-9330", details.InspectionRepairSummary[0].BusinessFax, "BusinessFax");
                Support.AreEqual("(847)797-9330", details.InspectionRepairSummary[0].BusinessPhone, "BusinessPhone");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify retirieve Inspection Repair Septic information using GetInspectionRepairSepticSummary web service")]
        public void Scenario_2_Retrieve_Inspection_Repair_Septic_Summary()
        {
            try
            {
                Reports.TestDescription = "Verify retirieve Inspection Repair Septic information using GetInspectionRepairSepticSummary web service";

                FAST_Init_File();

                #region Navigate to Inspection Repair Septic and create a new instance
                Reports.TestStep = "Navigate to Inspection Repair Septic and create a new instance";
                FastDriver.InspectionRepairSeptic.Open();
                FastDriver.InspectionRepairSeptic.FindGAB("415");
                FastDriver.InspectionRepairSeptic.FurnishedBy.FASelectItemBySendingKeys("Seller");
                FastDriver.InspectionRepairSeptic.WithinDays.FASetText("14");
                FastDriver.InspectionRepairSeptic.OrderDate.FASetText(DateTime.Today.ToDateString());
                FastDriver.InspectionRepairSeptic.DueDate.FASetText(DateTime.Today.AddDays(7).ToDateString());
                FastDriver.InspectionRepairSeptic.FollowUpDate.FASetText(DateTime.Today.AddDays(14).ToDateString());
                FastDriver.InspectionRepairSeptic.CompleteDate.FASetText(DateTime.Today.AddDays(28).ToDateString());
                FastDriver.InspectionRepairSeptic.ReportDate.FASetText(DateTime.Today.AddDays(35).ToDateString());
                FastDriver.InspectionRepairSeptic.BuyerCharge.FASetText("5,000.00");
                FastDriver.InspectionRepairSeptic.SellerCharge.FASetText("5,000.00");
                FastDriver.InspectionRepairSeptic.LEAmount.FASetText("9,999.99");
                FastDriver.BottomFrame.Done();
                #endregion
                
                #region Verify Inspection Repair Septic with GetInspectionRepairSepticSummary()
                Reports.TestStep = "Verify Inspection Repair Septic with GetInspectionRepairSepticSummary()";
                var request = EscrowRequestFactory.GetIRSSRequest(File.FileID);
                var details = EscrowService.GetInspectionRepairSepticSummary(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                Support.AreEqual("Continental Mortgage Corporation", details.InspectionRepairSummary[0].BusOrgName, "BusOrgName");
                Support.AreEqual("(847)797-9330", details.InspectionRepairSummary[0].BusinessFax, "BusinessFax");
                Support.AreEqual("(847)797-9330", details.InspectionRepairSummary[0].BusinessPhone, "BusinessPhone");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
