﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0043_InspectionRepair
{
    [CodedUITest]
    public class USxxxxxx_Create_Inspection_Repair_Details : FASTHelpers
    {
        [TestMethod]
        [Description("Verify create new Inspection Repair Other instance using CreateInspectionRepairOther web service")]
        public void Scenario_1_US304198_Create_OTHER_instance()
        {
            try
            {
                Reports.TestStep = "Verify create new Inspection Repair Other instance using CreateInspectionRepairOther web service";

                FAST_Init_File();

                #region Create Inspection Repair Other datails with CreateInspectionRepairOther()
                Reports.TestStep = "Create Inspection Repair Other datails with CreateInspectionRepairOther()";
                var request = EscrowRequestFactory.GetIRORequest(File.FileID, null);
                request.oInspectionRepairDetails.CDChargeList[0].Description = "test-charge-description";
                request.oInspectionRepairDetails.ReportInfo.FurnishedType = FurnishedType.Other;
                var response = EscrowService.CreateInspectionRepairOther(request);
                Assert.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Inspection Repair Other details in FAST
                Reports.TestStep = "Verify Inspection Repair Other details in FAST";
                FastDriver.InspectionRepairOther.Open();
                Assert.AreEqual("501", FastDriver.InspectionRepairOther.GABcodeLabel.FAGetText() ?? "", "GABcodeLabel");
                Assert.AreEqual("Other", FastDriver.InspectionRepairOther.FurnishedBy.FAGetSelectedItem() ?? "", "FurnishedBy");
                Assert.AreEqual("28", FastDriver.InspectionRepairOther.WithinDays.FAGetValue() ?? "", "WithinDays");
                Assert.AreEqual(DateTime.Today.AddDays(70).ToDateString(), FastDriver.InspectionRepairOther.CompleteDate.FAGetValue() ?? "", "CompleteDate");
                Assert.AreEqual(DateTime.Today.AddDays(77).ToDateString(), FastDriver.InspectionRepairOther.ReportDate.FAGetValue() ?? "", "ReportDate");
                Assert.AreEqual("test-charge-description", FastDriver.InspectionRepairOther.description.FAGetValue() ?? "", "ChargeDescription");
                Assert.AreEqual("1,000,000.00", FastDriver.InspectionRepairOther.buyerCharge.FAGetValue() ?? "", "BuyerCharge");
                Assert.AreEqual("1,000,000.00", FastDriver.InspectionRepairOther.sellerCharge.FAGetValue() ?? "", "SellerCharge");
                Assert.AreEqual("999,999.99", FastDriver.InspectionRepairOther.LEAmount.FAGetValue() ?? "", "LEAmount");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify create new Inspection Repair Pest instance using CreateInspectionRepairPest web service")]
        public void Scenario_2_US356127_Create_PEST_instance()
        {
            try
            {
                Reports.TestStep = "Verify create new Inspection Repair Pest instance using CreateInspectionRepairPest web service";

                FAST_Init_File();

                #region Create Inspection Repair Pest datails with CreateInspectionRepairPest()
                Reports.TestStep = "Create Inspection Repair Pest datails with CreateInspectionRepairPest()";
                var request = EscrowRequestFactory.GetIRPRequest(File.FileID, null);
                request.oInspectionRepairDetails.CDChargeList[0].Description = "test-charge-description";
                request.oInspectionRepairDetails.ReportInfo.FurnishedType = FurnishedType.Buyer;
                var response = EscrowService.CreateInspectionRepairPest(request);
                Assert.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Inspection Repair Pest details in FAST
                Reports.TestStep = "Verify Inspection Repair Pest details in FAST";
                FastDriver.InspectionRepairPest.Open();
                Assert.AreEqual("501", FastDriver.InspectionRepairPest.LabelIDCode.FAGetText() ?? "", "GABcodeLabel");
                Assert.AreEqual("Buyer", FastDriver.InspectionRepairPest.FurnishedBy.FAGetSelectedItem() ?? "", "FurnishedBy");
                Assert.AreEqual("28", FastDriver.InspectionRepairPest.WithinDays.FAGetValue() ?? "", "WithinDays");
                Assert.AreEqual(DateTime.Today.AddDays(70).ToDateString(), FastDriver.InspectionRepairPest.CompleteDate.FAGetValue() ?? "", "CompleteDate");
                Assert.AreEqual(DateTime.Today.AddDays(77).ToDateString(), FastDriver.InspectionRepairPest.ReportDate.FAGetValue() ?? "", "ReportDate");
                Assert.AreEqual("test-charge-description", FastDriver.InspectionRepairPest.description.FAGetValue() ?? "", "ChargeDescription");
                Assert.AreEqual("1,000,000.00", FastDriver.InspectionRepairPest.BuyerCharge.FAGetValue() ?? "", "BuyerCharge");
                Assert.AreEqual("1,000,000.00", FastDriver.InspectionRepairPest.SellerCharge.FAGetValue() ?? "", "SellerCharge");
                Assert.AreEqual("999,999.99", FastDriver.InspectionRepairPest.LoanEstimate.FAGetValue() ?? "", "LEAmount");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify create new Inspection Repair Septic instance using CreateInspectionRepairSeptic web service")]
        public void Scenario_3_US356127_Create_SEPTIC_instance()
        {
            try
            {
                Reports.TestStep = "Verify create new Inspection Repair Septic instance using CreateInspectionRepairSeptic web service";

                FAST_Init_File();

                #region Create Inspection Repair Septic datails with CreateInspectionRepairSeptic()
                Reports.TestStep = "Create Inspection Repair Septic datails with CreateInspectionRepairSeptic()";
                var request = EscrowRequestFactory.GetIRSRequest(File.FileID, seqNum: 1);
                request.oInspectionRepairDetails.CDChargeList[0].Description = "test-charge-description";
                request.oInspectionRepairDetails.ReportInfo.FurnishedType = FurnishedType.Seller;
                var response = EscrowService.CreateInspectionRepairSeptic(request);
                Assert.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Inspection Repair Septic details in FAST
                Reports.TestStep = "Verify Inspection Repair Septic details in FAST";
                FastDriver.InspectionRepairSeptic.Open();
                Assert.AreEqual("501", FastDriver.InspectionRepairSeptic.GABcodeLabel.FAGetText() ?? "", "GABcodeLabel");
                Assert.AreEqual("Seller", FastDriver.InspectionRepairSeptic.FurnishedBy.FAGetSelectedItem() ?? "", "FurnishedBy");
                Assert.AreEqual("28", FastDriver.InspectionRepairSeptic.WithinDays.FAGetValue() ?? "", "WithinDays");
                Assert.AreEqual(DateTime.Today.AddDays(70).ToDateString(), FastDriver.InspectionRepairSeptic.CompleteDate.FAGetValue() ?? "", "CompleteDate");
                Assert.AreEqual(DateTime.Today.AddDays(77).ToDateString(), FastDriver.InspectionRepairSeptic.ReportDate.FAGetValue() ?? "", "ReportDate");
                Assert.AreEqual("test-charge-description", FastDriver.InspectionRepairSeptic.description.FAGetValue() ?? "", "ChargeDescription");
                Assert.AreEqual("1,000,000.00", FastDriver.InspectionRepairSeptic.BuyerCharge.FAGetValue() ?? "", "BuyerCharge");
                Assert.AreEqual("1,000,000.00", FastDriver.InspectionRepairSeptic.SellerCharge.FAGetValue() ?? "", "SellerCharge");
                Assert.AreEqual("999,999.99", FastDriver.InspectionRepairSeptic.LEAmount.FAGetValue() ?? "", "LEAmount");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
