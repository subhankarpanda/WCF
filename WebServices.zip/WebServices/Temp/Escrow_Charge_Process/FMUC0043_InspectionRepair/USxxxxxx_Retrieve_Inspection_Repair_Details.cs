﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0043_InspectionRepair
{
    [CodedUITest]
    public class USxxxxxx_Retrieve_Inspection_Repair_Details : FASTHelpers
    {
        #region payment details
        protected FASTSelenium.DataObjects.IIS.PDD paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
        {
            UseDefaultChecked = false,
            LoanEstimateUnrounded = (double)15099.99,
            LoanEstimateRounded = (double)15100.00,
            PartOfCheckbox = true,
            BuyerCharge = (double)30000,
            BuyerAtClosing = (double)15000,
            BuyerChargePaymentMethod = "Check",
            BuyerBeforeClosing = (double)5000,
            BuyerPaidbyOther = (double)10000,
            BuyerPaidbyOtherPaymentMethod = "POC",
            BuyerDoubleAsteriskChecked = false,
            SellerCharge = (double)24000,
            SellerPaidAtClosing = (double)12000,
            SellerChargePaymentMethod = "Check",
            SellerPaidBeforeClosing = (double)6000,
            SellerPaidbyOthers = (double)6000,
            SellerPaidbyOtherPaymentMthd = "POC",
            TotalCharge = (double)54000.00
        };

        protected FASTSelenium.DataObjects.IIS.PDD paymentDetails2 = new FASTSelenium.DataObjects.IIS.PDD()
        {
            UseDefaultChecked = false,
            LoanEstimateUnrounded = (double)15099.99,
            LoanEstimateRounded = (double)15100.00,
            PartOfCheckbox = true,
            BuyerCharge = (double)30000,
            BuyerAtClosing = (double)15000,
            BuyerChargePaymentMethod = "CHK",
            BuyerBeforeClosing = (double)5000,
            BuyerPaidbyOther = (double)10000,
            BuyerPaidbyOtherPaymentMethod = "POC",
            BuyerDoubleAsteriskChecked = false,
            SellerCharge = (double)24000,
            SellerPaidAtClosing = (double)12000,
            SellerChargePaymentMethod = "CHK",
            SellerPaidBeforeClosing = (double)6000,
            SellerPaidbyOthers = (double)6000,
            SellerPaidbyOtherPaymentMthd = "POC",
            SectionHOtherCosts = true,
            TotalCharge = (double)54000.00,
            NoMonthsPrepaid = "0",
        };
        #endregion        

        [TestMethod]
        [Description("Verify Inspection Repair Other information using GetInspectionRepairOtherDetails web service")]
        public void Scenario_1_US283279_Get_Inspection_Repair_Other_Details()
        {
            try 
            {
                Reports.TestDescription = "Verify Inspection Repair Other information using GetInspectionRepairOtherDetails web service";

                FAST_Init_File();

                #region Navigate to Inspection Repair Other and create a new instance
                Reports.TestStep = "Navigate to Inspection Other and create a new instance";
                FastDriver.InspectionRepairOther.Open();
                FastDriver.InspectionRepairOther.FindGAB("415");
                FastDriver.InspectionRepairOther.FurnishedBy.FASelectItemBySendingKeys("Other");
                FastDriver.InspectionRepairOther.WithinDays.FASetText("14");
                FastDriver.InspectionRepairOther.OrderDate.FASetText(DateTime.Today.ToDateString());
                FastDriver.InspectionRepairOther.DueDate.FASetText(DateTime.Today.AddDays(7).ToDateString());
                FastDriver.InspectionRepairOther.FollowUpDate.FASetText(DateTime.Today.AddDays(14).ToDateString());
                FastDriver.InspectionRepairOther.CompleteDate.FASetText(DateTime.Today.AddDays(28).ToDateString());
                FastDriver.InspectionRepairOther.ReportDate.FASetText(DateTime.Today.AddDays(35).ToDateString());
                FastDriver.InspectionRepairOther.PaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Inspection Repair Other details with GetInspectionRepairOtherDetails()
                Reports.TestStep = "Verify Inspection Repair Other details with GetInspectionRepairOtherDetails()";
                var request = EscrowRequestFactory.GetServiceFileRequest(File.FileID);
                var details = EscrowService.GetInspectionRepairOtherDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                //  FileBusinessParty
                Support.AreEqual("415", details.InspectionRepairList[0].FileBusinessParty.IDCode, "FileBusinessParty.IDCode");
                //  ReportInfo
                Support.AreEqual("other", details.InspectionRepairList[0].ReportInfo.FurnishedType.ToString().ToLowerInvariant(), "ReportInfo.FurnishedType");
                Support.AreEqual("14", details.InspectionRepairList[0].ReportInfo.Within.ToString(), "ReportInfo.Within");
                Support.AreEqual(DateTime.Today.ToDateString(), ((DateTime)details.InspectionRepairList[0].ReportInfo.DateOrdered).ToDateString(), "ReportInfo.DateOrdered");
                Support.AreEqual(DateTime.Today.AddDays(7).ToDateString(), ((DateTime)details.InspectionRepairList[0].ReportInfo.DueDate).ToDateString(), "ReportInfo.DueDate");
                Support.AreEqual(DateTime.Today.AddDays(14).ToDateString(), ((DateTime)details.InspectionRepairList[0].ReportInfo.FollowUpDate).ToDateString(), "ReportInfo.FollowUpDate");
                Support.AreEqual(DateTime.Today.AddDays(28).ToDateString(), ((DateTime)details.InspectionRepairList[0].ReportInfo.CompletionDate).ToDateString(), "ReportInfo.CompletionDate");
                Support.AreEqual(DateTime.Today.AddDays(35).ToDateString(), ((DateTime)details.InspectionRepairList[0].ReportInfo.ReportDate).ToDateString(), "ReportInfo.ReportDate");
                //  Charge Details
                FAST_WCF_VerifyEscrowPDD(details.InspectionRepairList[0].CDChargeList[0], paymentDetails2);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        
        [TestMethod]
        [Description("Verify Inspection Repair Pest information using GetInspectionRepairPestDetails web service")]
        public void Scenario_2_356119_Get_Inspection_Repair_Pest_Details()
        {
            try
            {
                Reports.TestDescription = "Verify Inspection Repair Pest information using GetInspectionRepairPestDetails web service";

                FAST_Init_File();

                #region Navigate to Inspection Repair Pest and create a new instance
                Reports.TestStep = "Navigate to Inspection Pest and create a new instance";
                FastDriver.InspectionRepairPest.Open();
                FastDriver.InspectionRepairPest.FindGAB("415");
                FastDriver.InspectionRepairPest.FurnishedBy.FASelectItemBySendingKeys("Buyer");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("14");
                FastDriver.InspectionRepairPest.OrderDate.FASetText(DateTime.Today.ToDateString());
                FastDriver.InspectionRepairPest.DueDate.FASetText(DateTime.Today.AddDays(7).ToDateString());
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText(DateTime.Today.AddDays(14).ToDateString());
                FastDriver.InspectionRepairPest.CompleteDate.FASetText(DateTime.Today.AddDays(28).ToDateString());
                FastDriver.InspectionRepairPest.ReportDate.FASetText(DateTime.Today.AddDays(35).ToDateString());
                FastDriver.InspectionRepairPest.PaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Inspection Repair Pest details with GetInspectionRepairPestDetails()
                Reports.TestStep = "Verify Inspection Repair Pest details with GetInspectionRepairPestDetails()";
                var request = EscrowRequestFactory.GetIRPestDetailsRequest(File.FileID, seqNum: 1);
                var details = EscrowService.GetInspectionRepairPestDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                //  FileBusinessParty
                Support.AreEqual("415", details.FileBusinessParty.IDCode, "FileBusinessParty.IDCode");
                //  ReportInfo
                Support.AreEqual("buyer", details.ReportInfo.FurnishedType.ToString().ToLowerInvariant(), "ReportInfo.FurnishedType");
                Support.AreEqual("14", details.ReportInfo.Within.ToString(), "ReportInfo.Within");
                Support.AreEqual(DateTime.Today.ToDateString(), ((DateTime)details.ReportInfo.DateOrdered).ToDateString(), "ReportInfo.DateOrdered");
                Support.AreEqual(DateTime.Today.AddDays(7).ToDateString(), ((DateTime)details.ReportInfo.DueDate).ToDateString(), "ReportInfo.DueDate");
                Support.AreEqual(DateTime.Today.AddDays(14).ToDateString(), ((DateTime)details.ReportInfo.FollowUpDate).ToDateString(), "ReportInfo.FollowUpDate");
                Support.AreEqual(DateTime.Today.AddDays(28).ToDateString(), ((DateTime)details.ReportInfo.CompletionDate).ToDateString(), "ReportInfo.CompletionDate");
                Support.AreEqual(DateTime.Today.AddDays(35).ToDateString(), ((DateTime)details.ReportInfo.ReportDate).ToDateString(), "ReportInfo.ReportDate");
                //  Charge Details
                FAST_WCF_VerifyEscrowPDD(details.InspectionRepairCharges.CdChargesList[0], paymentDetails2);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Inspection Repair Septic information using GetInspectionRepairSepticDetails web service")]
        public void Scenario_3_356119_Get_Inspection_Repair_Septic_Details()
        {
            try
            {
                Reports.TestDescription = "Verify Inspection Repair Septic information using GetInspectionRepairSepticDetails web service";

                FAST_Init_File();

                #region Navigate to Inspection Repair Septic and create a new instance
                Reports.TestStep = "Navigate to Inspection Septic and create a new instance";
                FastDriver.InspectionRepairSeptic.Open();
                FastDriver.InspectionRepairSeptic.FindGAB("415");
                FastDriver.InspectionRepairSeptic.FurnishedBy.FASelectItemBySendingKeys("seller");
                FastDriver.InspectionRepairSeptic.WithinDays.FASetText("14");
                FastDriver.InspectionRepairSeptic.OrderDate.FASetText(DateTime.Today.ToDateString());
                FastDriver.InspectionRepairSeptic.DueDate.FASetText(DateTime.Today.AddDays(7).ToDateString());
                FastDriver.InspectionRepairSeptic.FollowUpDate.FASetText(DateTime.Today.AddDays(14).ToDateString());
                FastDriver.InspectionRepairSeptic.CompleteDate.FASetText(DateTime.Today.AddDays(28).ToDateString());
                FastDriver.InspectionRepairSeptic.ReportDate.FASetText(DateTime.Today.AddDays(35).ToDateString());
                FastDriver.InspectionRepairSeptic.PaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Inspection Repair Septic details with GetInspectionRepairSepticDetails()
                Reports.TestStep = "Verify Inspection Repair Septic details with GetInspectionRepairSepticDetails()";
                var request = EscrowRequestFactory.GetIRSepticDetailsRequest(File.FileID, seqNum: 1);
                var details = EscrowService.GetInspectionRepairSepticDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                //  FileBusinessParty
                Support.AreEqual("415", details.FileBusinessParty.IDCode, "FileBusinessParty.IDCode");
                //  ReportInfo
                Support.AreEqual("seller", details.ReportInfo.FurnishedType.ToString().ToLowerInvariant(), "ReportInfo.FurnishedType");
                Support.AreEqual("14", details.ReportInfo.Within.ToString(), "ReportInfo.Within");
                Support.AreEqual(DateTime.Today.ToDateString(), ((DateTime)details.ReportInfo.DateOrdered).ToDateString(), "ReportInfo.DateOrdered");
                Support.AreEqual(DateTime.Today.AddDays(7).ToDateString(), ((DateTime)details.ReportInfo.DueDate).ToDateString(), "ReportInfo.DueDate");
                Support.AreEqual(DateTime.Today.AddDays(14).ToDateString(), ((DateTime)details.ReportInfo.FollowUpDate).ToDateString(), "ReportInfo.FollowUpDate");
                Support.AreEqual(DateTime.Today.AddDays(28).ToDateString(), ((DateTime)details.ReportInfo.CompletionDate).ToDateString(), "ReportInfo.CompletionDate");
                Support.AreEqual(DateTime.Today.AddDays(35).ToDateString(), ((DateTime)details.ReportInfo.ReportDate).ToDateString(), "ReportInfo.ReportDate");
                //  Charge Details
                FAST_WCF_VerifyEscrowPDD(details.InspectionRepairCharges.CdChargesList[0], paymentDetails2);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
