﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0044_Insurance
{
    [CodedUITest]
    public class USxxxxxx_Update_Insurance : FASTHelpers
    {
        #region paymentDetails
        protected FASTSelenium.DataObjects.IIS.PDD paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
        {
            AdditionalDescription = "test-description",
            UseDefaultChecked = true,
            BuyerCredit = (double)0.00,
            BuyerCreditPaymentMethod = CreditPaymentMethods.AtClosing.ToString(),
            LoanEstimateUnrounded = (double)999999.99,
            LoanEstimateRounded = (double)1000000,
            BuyerCharge = (double)1000000,
            BuyerAtClosing = (double)900000.00,
            BuyerChargePaymentMethod = AtClosingPaymentMethods.CHK.ToString(),
            BuyerBeforeClosing = (double)99999.99,
            BuyerPaidbyOther = (double)0.01,
            BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
            BuyerLenderCheckbox = false,
            SellerCharge = (double)1000000,
            SellerCredit = (double)0.00,
            SellerCreditPaymentMethod = CreditPaymentMethods.AtClosing.ToString(),
            SellerPaidAtClosing = (double)900000.00,
            SellerChargePaymentMethod = AtClosingPaymentMethods.CHK.ToString(),
            SellerPaidBeforeClosing = (double)99999.99,
            SellerPaidbyOthers = (double)0.01,
            SellerPaidbyOtherPaymentMthd = OtherPaymentMethods.POC.ToString(),
            SellerLenderCheckbox = false,
            PartOfCheckbox = false,
            //SectionHOtherCosts = true,
            TotalCharge = (double)2000000,
        };
        #endregion

        [TestMethod]
        [Description("Verify update Insurance OTHER using UpdateInsurance web service")]
        public void Scenario_1_Update_Insurance_OTHER()
        {
            try
            {
                Reports.TestDescription = "Verify update Insurance OTHER using UpdateInsurance web service";

                FAST_Init_File();

                #region Navigate to Insurance and create a new instance of type OTHER
                Reports.TestStep = "Navigate to Insurance and create a new instance of type OTHER";
                FastDriver.InsuranceSummary.Open();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB("488");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Update Insurance OTHER with UpdateInsurance()
                Reports.TestStep = "Update Insurance OTHER with UpdateInsurance()";
                var request = EscrowRequestFactory.GetInsuranceRequest(File.FileID, seqNum: 1);
                request.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Others;
                request.InsuranceInformation.InsuranceAgentInformation = EscrowRequestFactory.GetFileBusinessParty("415");
                var response = EscrowService.UpdateInsurance(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Insurance OTHER is updated in FAST
                Reports.TestStep = "Verify Insurance OTHER is updated in FAST";
                FastDriver.InsuranceOther.Open();
                Support.AreEqual("415", FastDriver.InsuranceOther.GabCodeLabel.FAGetText(), "GabCodeLabel");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify update Insurance OTHER charge PDD using UpdateInsurance web service")]
        public void Scenario_2_Update_Insurance_OTHER_charge_PDD()
        {
            try
            {
                Reports.TestDescription = "Verify update Insurance OTHER charge PDD using UpdateInsurance web service";

                FAST_Init_File();

                #region Navigate to Insurance and create a new instance of type OTHER charge PDD
                Reports.TestStep = "Navigate to Insurance and create a new instance of type OTHER charge PDD";
                FastDriver.InsuranceSummary.Open();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB("415");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Update Insurance OTHER charge PDD with UpdateInsurance()
                Reports.TestStep = "Update Insurance OTHER charge PDD with UpdateInsurance()";
                var request = EscrowRequestFactory.GetInsuranceRequest(File.FileID, seqNum: 1);
                request.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Others;
                request.InsuranceInformation.InsuranceCharges = new FASTWCFHelpers.FastEscrowService.InsuCharges()
                {
                    CDInsuranceChargesList = new FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails[] { 
                        EscrowRequestFactory.GetCDChargePaymentDetails(),
                    }
                };
                var response = EscrowService.UpdateInsurance(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Insurance OTHER charge PDD is updated in FAST
                Reports.TestStep = "Verify Insurance OTHER charge PDD is updated in FAST";
                FastDriver.InsuranceOther.Open();
                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();
                FAST_VerifyPDD(paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify update Insurance FIRE charge PDD using UpdateInsurance web service")]
        public void Scenario_3_Update_Insurance_FIRE_charge_PDD()
        {
            try
            {
                Reports.TestDescription = "Verify update Insurance FIRE charge PDD using UpdateInsurance web service";

                FAST_Init_File();

                #region Navigate to Insurance and create a new instance of type FIRE charge PDD
                Reports.TestStep = "Navigate to Insurance and create a new instance of type FIRE charge PDD";
                FastDriver.InsuranceFire.Open();
                FastDriver.InsuranceFire.FindGAB("415");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Update Insurance FIRE charge PDD with UpdateInsurance()
                Reports.TestStep = "Update Insurance FIRE charge PDD with UpdateInsurance()";
                var request = EscrowRequestFactory.GetInsuranceRequest(File.FileID, seqNum: 1);
                request.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Fire;
                request.InsuranceInformation.InsuranceCharges = new FASTWCFHelpers.FastEscrowService.InsuCharges()
                {
                    CDInsuranceChargesList = new FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails[] { 
                        EscrowRequestFactory.GetCDChargePaymentDetails(),
                    }
                };
                var response = EscrowService.UpdateInsurance(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Insurance FIRE charge PDD is updated in FAST
                Reports.TestStep = "Verify Insurance FIRE charge PDD is updated in FAST";
                FastDriver.InsuranceFire.Open();
                FastDriver.InsuranceFire.FirePaymentDetails.FAClick();
                FAST_VerifyPDD(paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify update Insurance WIND charge PDD using UpdateInsurance web service")]
        public void Scenario_4_Update_Insurance_WIND_charge_PDD()
        {
            try
            {
                Reports.TestDescription = "Verify update Insurance WIND charge PDD using UpdateInsurance web service";

                FAST_Init_File();

                #region Navigate to Insurance and create a new instance of type WIND charge PDD
                Reports.TestStep = "Navigate to Insurance and create a new instance of type WIND charge PDD";
                FastDriver.InsuranceWind.Open();
                FastDriver.InsuranceWind.FindGAB("415");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Update Insurance WIND charge PDD with UpdateInsurance()
                Reports.TestStep = "Update Insurance WIND charge PDD with UpdateInsurance()";
                var request = EscrowRequestFactory.GetInsuranceRequest(File.FileID, seqNum: 1);
                request.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Wind;
                request.InsuranceInformation.InsuranceCharges = new FASTWCFHelpers.FastEscrowService.InsuCharges()
                {
                    CDInsuranceChargesList = new FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails[] { 
                        EscrowRequestFactory.GetCDChargePaymentDetails(),
                    }
                };
                var response = EscrowService.UpdateInsurance(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Insurance WIND charge PDD is updated in FAST
                Reports.TestStep = "Verify Insurance WIND charge PDD is updated in FAST";
                FastDriver.InsuranceWind.Open();
                FastDriver.InsuranceWind.WindPaymentDetails.FAClick();
                FAST_VerifyPDD(paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify update Insurance FLOOD charge PDD using UpdateInsurance web service")]
        public void Scenario_5_Update_Insurance_FLOOD_charge_PDD()
        {
            try
            {
                Reports.TestDescription = "Verify update Insurance FLOOD charge PDD using UpdateInsurance web service";

                FAST_Init_File();

                #region Navigate to Insurance and create a new instance of type FLOOD charge PDD
                Reports.TestStep = "Navigate to Insurance and create a new instance of type FLOOD charge PDD";
                FastDriver.Insuranceflood.Open();
                FastDriver.Insuranceflood.FindGAB("415");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Update Insurance FLOOD charge PDD with UpdateInsurance()
                Reports.TestStep = "Update Insurance FLOOD charge PDD with UpdateInsurance()";
                var request = EscrowRequestFactory.GetInsuranceRequest(File.FileID, seqNum: 1);
                request.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Flood;
                request.InsuranceInformation.InsuranceCharges = new FASTWCFHelpers.FastEscrowService.InsuCharges()
                {
                    CDInsuranceChargesList = new FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails[] { 
                        EscrowRequestFactory.GetCDChargePaymentDetails(),
                    }
                };
                var response = EscrowService.UpdateInsurance(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Insurance FLOOD charge PDD is updated in FAST
                Reports.TestStep = "Verify Insurance FLOOD charge PDD is updated in FAST";
                FastDriver.Insuranceflood.Open();
                FastDriver.Insuranceflood.FloodPaymentDetails.FAClick();
                FAST_VerifyPDD(paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify update Insurance EARTHQUAKE charge PDD using UpdateInsurance web service")]
        public void Scenario_6_Update_Insurance_EARTHQUAKE_charge_PDD()
        {
            try
            {
                Reports.TestDescription = "Verify update Insurance EARTHQUAKE charge PDD using UpdateInsurance web service";

                FAST_Init_File();

                #region Navigate to Insurance and create a new instance of type EARTHQUAKE charge PDD
                Reports.TestStep = "Navigate to Insurance and create a new instance of type EARTHQUAKE charge PDD";
                FastDriver.InsuranceEarth.Open();
                FastDriver.InsuranceEarth.FindGAB("415");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Update Insurance EARTHQUAKE charge PDD with UpdateInsurance()
                Reports.TestStep = "Update Insurance EARTHQUAKE charge PDD with UpdateInsurance()";
                var request = EscrowRequestFactory.GetInsuranceRequest(File.FileID, seqNum: 1);
                request.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Earthquake;
                request.InsuranceInformation.InsuranceCharges = new FASTWCFHelpers.FastEscrowService.InsuCharges()
                {
                    CDInsuranceChargesList = new FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails[] { 
                        EscrowRequestFactory.GetCDChargePaymentDetails(),
                    }
                };
                var response = EscrowService.UpdateInsurance(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Insurance EARTHQUAKE charge PDD is updated in FAST
                Reports.TestStep = "Verify Insurance EARTHQUAKE charge PDD is updated in FAST";
                FastDriver.InsuranceEarth.Open();
                FastDriver.InsuranceEarth.EarthPaymentDetails.FAClick();
                FAST_VerifyPDD(paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
