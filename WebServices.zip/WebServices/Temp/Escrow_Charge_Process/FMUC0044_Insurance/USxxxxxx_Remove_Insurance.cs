﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0044_Insurance
{
    [CodedUITest]
    public class USxxxxxx_Remove_Insurance : FASTHelpers
    {
        [TestMethod]
        [Description("Verify remove Insurance OTHER using RemoveInsurance web service")]
        public void Scenario_1_Remove_Insurance_OTHER()
        {
            try
            {
                Reports.TestDescription = "Verify remove Insurance OTHER using RemoveInsurance web service";

                FAST_Init_File();

                #region Navigate to Insurance and create a new instance of type OTHER
                Reports.TestStep = "Navigate to Insurance and create a new instance of type OTHER";
                FastDriver.InsuranceSummary.Open();
                FastDriver.InsuranceSummary.SummaryNew.FAClick();
                FastDriver.InsuranceOther.WaitForScreenToLoad();
                FastDriver.InsuranceOther.FindGAB("415");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Remove Insurance OTHER with RemoveInsurance()
                Reports.TestStep = "Remove Insurance OTHER with RemoveInsurance()";
                var request = EscrowRequestFactory.GetInsuranceRequest(File.FileID, seqNum: 1);
                request.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Others;
                var response = EscrowService.RemoveInsurance(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Insurance OTHER is removed in FAST
                Reports.TestStep = "Verify Insurance OTHER is removed in FAST";
                FastDriver.InsuranceOther.Open();
                Support.AreEqual("", FastDriver.InsuranceOther.GabCodeLabel.FAGetText(), "GabCodeLabel");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify remove Insurance FIRE using RemoveInsurance web service")]
        public void Scenario_2_Remove_Insurance_FIRE()
        {
            try
            {
                Reports.TestDescription = "Verify remove Insurance FIRE using RemoveInsurance web service";

                FAST_Init_File();

                #region Navigate to Insurance and create a new instance of type FIRE
                Reports.TestStep = "Navigate to Insurance and create a new instance of type FIRE";
                FastDriver.InsuranceFire.Open();
                FastDriver.InsuranceFire.FindGAB("415");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Remove Insurance FIRE with RemoveInsurance()
                Reports.TestStep = "Remove Insurance FIRE with RemoveInsurance()";
                var request = EscrowRequestFactory.GetInsuranceRequest(File.FileID, seqNum: 1);
                request.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Fire;
                var response = EscrowService.RemoveInsurance(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Insurance FIRE is removed in FAST
                Reports.TestStep = "Verify Insurance FIRE is removed in FAST";
                FastDriver.InsuranceFire.Open();
                Support.AreEqual("", FastDriver.InsuranceFire.FireGABLabel.FAGetText(), "GabCodeLabel");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify remove Insurance WIND using RemoveInsurance web service")]
        public void Scenario_3_Remove_Insurance_WIND()
        {
            try
            {
                Reports.TestDescription = "Verify remove Insurance WIND using RemoveInsurance web service";

                FAST_Init_File();

                #region Navigate to Insurance and create a new instance of type WIND
                Reports.TestStep = "Navigate to Insurance and create a new instance of type WIND";
                FastDriver.InsuranceWind.Open();
                FastDriver.InsuranceWind.FindGAB("415");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Remove Insurance WIND with RemoveInsurance()
                Reports.TestStep = "Remove Insurance WIND with RemoveInsurance()";
                var request = EscrowRequestFactory.GetInsuranceRequest(File.FileID, seqNum: 1);
                request.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Wind;
                var response = EscrowService.RemoveInsurance(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Insurance WIND is removed in FAST
                Reports.TestStep = "Verify Insurance WIND is removed in FAST";
                FastDriver.InsuranceWind.Open();
                Support.AreEqual("", FastDriver.InsuranceWind.WindGABLabel.FAGetText(), "GabCodeLabel");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify remove Insurance FLOOD using RemoveInsurance web service")]
        public void Scenario_4_Remove_Insurance_FLOOD()
        {
            try
            {
                Reports.TestDescription = "Verify remove Insurance FLOOD using RemoveInsurance web service";

                FAST_Init_File();

                #region Navigate to Insurance and create a new instance of type FLOOD
                Reports.TestStep = "Navigate to Insurance and create a new instance of type FLOOD";
                FastDriver.Insuranceflood.Open();
                FastDriver.Insuranceflood.FindGAB("415");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Remove Insurance FLOOD with RemoveInsurance()
                Reports.TestStep = "Remove Insurance FLOOD with RemoveInsurance()";
                var request = EscrowRequestFactory.GetInsuranceRequest(File.FileID, seqNum: 1);
                request.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Flood;
                var response = EscrowService.RemoveInsurance(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Insurance FLOOD is removed in FAST
                Reports.TestStep = "Verify Insurance FLOOD is removed in FAST";
                FastDriver.Insuranceflood.Open();
                Support.AreEqual("", FastDriver.Insuranceflood.FloodGABLabel.FAGetText(), "GabCodeLabel");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify remove Insurance EARTHQUAKE using RemoveInsurance web service")]
        public void Scenario_5_Remove_Insurance_EARTHQUAKE()
        {
            try
            {
                Reports.TestDescription = "Verify remove Insurance EARTHQUAKE using RemoveInsurance web service";

                FAST_Init_File();

                #region Navigate to Insurance and create a new instance of type EARTHQUAKE
                Reports.TestStep = "Navigate to Insurance and create a new instance of type EARTHQUAKE";
                FastDriver.InsuranceEarth.Open();
                FastDriver.InsuranceEarth.FindGAB("415");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Remove Insurance EARTHQUAKE with RemoveInsurance()
                Reports.TestStep = "Remove Insurance EARTHQUAKE with RemoveInsurance()";
                var request = EscrowRequestFactory.GetInsuranceRequest(File.FileID, seqNum: 1);
                request.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Earthquake;
                var response = EscrowService.RemoveInsurance(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Insurance EARTHQUAKE is removed in FAST
                Reports.TestStep = "Verify Insurance EARTHQUAKE is removed in FAST";
                FastDriver.InsuranceEarth.Open();
                Support.AreEqual("", FastDriver.InsuranceEarth.EarthGABLabel.FAGetText(), "GabCodeLabel");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
