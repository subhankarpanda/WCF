﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0053_Utilities
{
    [CodedUITest]
    public class US447056_Get_Utility_Details : FASTHelpers
    {
        #region payment details
        protected PDD paymentDetails = new PDD()
        {
            UseDefaultChecked = false,
            LoanEstimateUnrounded = (double)15099.99,
            LoanEstimateRounded = (double)15100.00,
            PartOfCheckbox = true,
            BuyerCharge = (double)30000,
            BuyerAtClosing = (double)15000,
            BuyerChargePaymentMethod = "Check",
            BuyerBeforeClosing = (double)5000,
            BuyerPaidbyOther = (double)10000,
            BuyerPaidbyOtherPaymentMethod = "POC",
            BuyerDoubleAsteriskChecked = false,
            SellerCharge = (double)24000,
            SellerPaidAtClosing = (double)12000,
            SellerChargePaymentMethod = "Check",
            SellerPaidBeforeClosing = (double)6000,
            SellerPaidbyOthers = (double)6000,
            SellerPaidbyOtherPaymentMthd = "POC",
            TotalCharge = (double)54000.00
        };

        protected PDD paymentDetails2 = new PDD()
        {
            UseDefaultChecked = false,
            LoanEstimateUnrounded = (double)15099.99,
            LoanEstimateRounded = (double)15100.00,
            PartOfCheckbox = true,
            BuyerCharge = (double)30000,
            BuyerAtClosing = (double)15000,
            BuyerChargePaymentMethod = "CHK",
            BuyerBeforeClosing = (double)5000,
            BuyerPaidbyOther = (double)10000,
            BuyerPaidbyOtherPaymentMethod = "POC",
            BuyerDoubleAsteriskChecked = false,
            SellerCharge = (double)24000,
            SellerPaidAtClosing = (double)12000,
            SellerChargePaymentMethod = "CHK",
            SellerPaidBeforeClosing = (double)6000,
            SellerPaidbyOthers = (double)6000,
            SellerPaidbyOtherPaymentMthd = "POC",
            SectionHOtherCosts = true,
            TotalCharge = (double)54000.00,
            NoMonthsPrepaid = "0",
        };
        #endregion
        
        protected void FAST_VerifyCDChargePaymentDetails(dynamic _pdd, PDD paymentDetails)
        {
            #region Verify Fee Payment Details
            var pdd = _pdd as FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails;

            //  BuyerDetails
            Support.AreEqual(((Decimal)paymentDetails.BuyerCharge).ToString("C2"), ((Decimal)pdd.BuyerCharge).ToString("C2"), "BuyerCharge");
            Support.AreEqual(paymentDetails.BuyerLenderCheckbox.ToString().ToLowerInvariant(), pdd.DisplayLBuyer.ToString().ToLowerInvariant(), "DisplayLBuyer");
            Support.AreEqual(((Decimal)paymentDetails.BuyerAtClosing).ToString("C2"), ((Decimal)pdd.PBBuyerAtClosing).ToString("C2"), "PBBuyerAtClosing");
            Support.AreEqual(((Decimal)paymentDetails.BuyerBeforeClosing).ToString("C2"), ((Decimal)pdd.PBBuyerBeforeClosing).ToString("C2"), "PBBuyerBeforeClosing");
            Support.AreEqual(((Decimal)paymentDetails.BuyerPaidbyOther).ToString("C2"), ((Decimal)pdd.PBOthersForBuyer).ToString("C2"), "PBOthersForBuyer");
            Support.AreEqual(paymentDetails.BuyerPaidbyOtherPaymentMethod.ToLowerInvariant(), pdd.PBOthersForBuyerPMTypeCdID.ToString().ToLowerInvariant(), "PBOthersForBuyerPMTypeCdID");
            Support.AreEqual(paymentDetails.BuyerChargePaymentMethod.ToLowerInvariant(), pdd.AtClosingBuyerPaymentMethodTypeID.ToString().ToLowerInvariant(), "AtClosingBuyerPaymentMethodTypeID");
            //
            Support.AreEqual(paymentDetails.ChargeDescription, pdd.Description, "Description");
            Support.AreEqual(paymentDetails.BuyerDoubleAsteriskChecked.ToString().ToLowerInvariant(), pdd.DoubleAsteriskIndicator.ToString().ToLowerInvariant(), "DoubleAsteriskIndicator");
            //  Loan Estimate
            Support.AreEqual(((Decimal)paymentDetails.LoanEstimateUnrounded).ToString("N2"), ((Decimal)pdd.LEAmount).ToString("N2"), "LEAmount");
            Support.AreEqual(((Decimal)paymentDetails.LoanEstimateRounded).ToString("N2"), ((Decimal)pdd.RoundedLEAmount).ToString("N2"), "RoundedLEAmount");
            // 
            Support.AreEqual(paymentDetails.PartOfCheckbox.ToString().ToLowerInvariant(), pdd.PartOf.ToString().ToLowerInvariant(), "PartOf");
            Support.IsTrue(!string.IsNullOrEmpty(pdd.PayTo), "PayTo= " + pdd.PayTo);
            Support.IsTrue(!string.IsNullOrEmpty(pdd.PayeeNameOnCDOrSettlementStmt), "PayeeNameOnCDOrSettlementStmt= " + pdd.PayeeNameOnCDOrSettlementStmt);
            //  SectionShopDetails
            if (pdd.eSectionShop == FASTWCFHelpers.FastEscrowService.SectionsShoppedFor.SectionBdidNotShopFor)
                Support.IsTrue(paymentDetails.SectionBdidnotShopFor, "SectionBdidnotShopFor");
            else if (pdd.eSectionShop == FASTWCFHelpers.FastEscrowService.SectionsShoppedFor.SectionCdidShopFor)
                Support.IsTrue(paymentDetails.SectionCDidShopFor, "SectionCDidShopFor");
            else if (pdd.eSectionShop == FASTWCFHelpers.FastEscrowService.SectionsShoppedFor.SectionHotherCosts)
                Support.IsTrue(paymentDetails.SectionHOtherCosts, "SectionHOtherCosts");
            //  SellerDetails
            Support.AreEqual(((Decimal)paymentDetails.SellerCharge).ToString("C2"), ((Decimal)pdd.SellerCharge).ToString("C2"), "SellerCharge");
            Support.AreEqual(paymentDetails.SellerLenderCheckbox.ToString().ToLowerInvariant(), pdd.DisplayLSeller.ToString().ToLowerInvariant(), "DisplayLSeller");
            Support.AreEqual(((Decimal)paymentDetails.SellerPaidAtClosing).ToString("C2"), ((Decimal)pdd.PBSellerAtClosing).ToString("C2"), "PBSellerAtClosing");
            Support.AreEqual(((Decimal)paymentDetails.SellerPaidBeforeClosing).ToString("C2"), ((Decimal)pdd.PBSellerBeforeClosing).ToString("C2"), "PBSellerBeforeClosing");
            Support.AreEqual(((Decimal)paymentDetails.SellerPaidbyOthers).ToString("C2"), ((Decimal)pdd.PBOthersForSeller).ToString("C2"), "PBOthersForSeller");
            Support.AreEqual(paymentDetails.SellerPaidbyOtherPaymentMthd.ToLowerInvariant(), pdd.PBOthersForSellerPMTypeCdID.ToString().ToLowerInvariant(), "PBOthersForSellerPMTypeCdID");
            Support.AreEqual(paymentDetails.SellerChargePaymentMethod.ToLowerInvariant(), pdd.AtClosingSellerPaymentMethodTypeID.ToString().ToLowerInvariant(), "AtClosingSellerPaymentMethodTypeID");
            //
            Support.AreEqual(((Decimal)paymentDetails.TotalCharge).ToString("C2"), ((Decimal)pdd.TotalCharge).ToString("C2"), "TotalCharge");
            #endregion
        }

        protected void FAST_VerifyProrationDetails(dynamic _prorationDetails, FASTSelenium.PageObjects.IIS.UtilityProration pData)
        {
            var details = _prorationDetails as Proration;

            #region Verify Proration Details
            Support.AreEqual(((Decimal)pData.ProrationAmount).ToString("N2"), ((Decimal)details.Amount).ToString("N2"), "Proration.Amount");
            Support.AreEqual(pData.Per.ToLowerInvariant(), details.AmountPeriod.ToString().ToLowerInvariant(), "Proration.AmountPeriod");
            Support.AreEqual(pData.BasedOn, details.BasedOnDays.ToString(), "Proration.BasedOnDays");
            Support.AreEqual(((Decimal)pData.ProrationBuyerCharge).ToString("C2"), ((Decimal)details.BuyerCharge).ToString("C2"), "Proration.BuyerCharge");
            Support.AreEqual(((Decimal)pData.ProrationBuyerCredit).ToString("C2"), ((Decimal)details.BuyerCredit).ToString("C2"), "Proration.BuyerCredit");
            Support.AreEqual(pData.CreditSeller.ToString(), details.CreditSeller.ToString(), "Proration.CreditSeller");
            Support.AreEqual(pData.DayofClosePaidbySeller.ToString(), details.DayOfClosePaidbySeller.ToString(), "Proration.DayOfClosePaidbySeller");
            Support.AreEqual(pData.Description, details.Description, "Proration.Description");
            Support.AreEqual(pData.FromDate, ((DateTime)details.FromDate).ToDateString(), "Proration.FromDate");
            Support.AreEqual(pData.fromInclusive.ToString(), details.FromDateInclusive.ToString(), "Proration.FromDateInclusive");
            Support.AreEqual(pData.fromProrateDate.ToString(), details.FromDateIsProrateDate.ToString(), "Proration.FromDateIsProrateDate");
            Support.AreEqual(((Decimal)pData.ProrationUtilityLE).ToString("C2"), ((Decimal)details.LEAmount).ToString("C2"), "Proration.LEAmount");
            Support.AreEqual(pData.prorationType.ToLowerInvariant(), details.ProrationType.ToString().ToLowerInvariant(), "Proration.ProrationType");
            Support.AreEqual(((Decimal)pData.ProrationSellerCharge).ToString("C2"), ((Decimal)details.SellerCharge).ToString("C2"), "Proration.SellerCharge");
            Support.AreEqual(((Decimal)pData.ProrationSellerCredit).ToString("C2"), ((Decimal)details.SellerCredit).ToString("C2"), "Proration.SellerCredit");
            Support.AreEqual(pData.ToDate, ((DateTime)details.ToDate).ToDateString(), "Proration.ToDate");
            Support.AreEqual(pData.toInclusive.ToString(), details.ToDateInclusive.ToString(), "Proration.ToDateInclusive");
            Support.AreEqual(pData.toProrateDate.ToString(), details.ToDateIsProrateDate.ToString(), "Proration.ToDateIsProrateDate");
            #endregion
        }

        [TestMethod]
        [Description("Verify retrieve Utility information using GetUtilityDetails web service")]
        public void Scenario_1_Get_Utility_Details()
        {
            try
            {
                Reports.TestDescription = "Verify retrieve Utility information using GetUtilityDetails web service";

                FAST_Init_File();

                #region Navigate to Utility and create a new instance with PDD
                Reports.TestDescription = "Navigate to Utility and create a new instance with PDD";
                FastDriver.UtilityDetail.Open();
                FastDriver.UtilityDetail.FindGABcode("415");
                var chargeDescription = FastDriver.UtilityDetail.UtilityChargesDescription.FAGetValue();
                FastDriver.UtilityDetail.PaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                var prorationData = new FASTSelenium.PageObjects.IIS.UtilityProration()
                {
                    CreditSeller = true,
                    DayofClosePaidbySeller = true,
                    ProrationAmount = (decimal)50000.00,
                    FromDate = DateTime.Today.ToDateString(),
                    fromInclusive = true,
                    fromProrateDate = false,
                    BasedOn = "365",
                    Per = "MONTH",
                    ToDate = DateTime.Today.AddDays(28).ToDateString(),
                    toInclusive = false,
                    toProrateDate = false,
                    ProrationBuyerCharge = (decimal)5000.00,
                    ProrationBuyerCredit = (decimal)10000.00,
                    ProrationSellerCharge = (decimal)5000.00,
                    ProrationSellerCredit = (decimal)10000.00,
                    ProrationUtilityLE = (decimal)9999.99,
                };
                FastDriver.UtilityDetail.SetProrarion( prorationData );
                FastDriver.BottomFrame.Done();
                #endregion 

                #region Verify Utility details with GetUtilityDetails()
                Reports.TestStep = "Verify Utility details with GetUtilityDetails()";
                FastDriver.UtilityDetail.Open();
                var details = EscrowService.GetUtilityDetails(EscrowRequestFactory.GetUtilityRequest(File.FileID, seqNum: 1));
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                Support.AreEqual("415", details.UtilityDetails.UtilityFileBusinessParty.IDCode, "UtilityFileBusinessParty.IDCode");
                //  Charge PDD
                paymentDetails2.ChargeDescription = chargeDescription;
                FAST_VerifyCDChargePaymentDetails(details.UtilityDetails.UtilityCharges.UtilityCDChargesList[0], paymentDetails2);
                //  Proration
                FAST_VerifyProrationDetails(details.UtilityDetails.Proration, prorationData);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
