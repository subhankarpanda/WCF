﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0053_Utilities
{
    [CodedUITest]
    public class US447090_Create_Utility_instance : FASTHelpers
    {
        #region PDD Object
        protected PDD paymentDetails = new PDD()
        {
            AdditionalDescription = "Utilities",
            UseDefaultChecked = true,
            PayeeName = "Continental Mortgage Corporation",
            LoanEstimateUnrounded = (double)999999.99,
            LoanEstimateRounded = (double)1000000.00,
            PartOfCheckbox = false,
            BuyerCharge = (double)1000000,
            BuyerAtClosing = (double)900000,
            BuyerChargePaymentMethod = "Check",
            BuyerBeforeClosing = (double)99999.99,
            BuyerPaidbyOther = (double)0.01,
            BuyerPaidbyOtherPaymentMethod = "POC",
            BuyerDoubleAsteriskChecked = false,
            SellerCharge = (double)1000000,
            SellerPaidAtClosing = (double)900000,
            SellerChargePaymentMethod = "Check",
            SellerPaidBeforeClosing = (double)99999.99,
            SellerPaidbyOthers = (double)0.01,
            SellerPaidbyOtherPaymentMthd = "POC",
            SectionHOtherCosts = true,
            TotalCharge = (double)2000000.00
        };
        #endregion
        
        #region Proration Object
        public FASTSelenium.PageObjects.IIS.UtilityProration prorationData = new FASTSelenium.PageObjects.IIS.UtilityProration()
        {
            CreditSeller = true,
            DayofClosePaidbySeller = true,
            ProrationAmount = (decimal)50000.00,
            FromDate = DateTime.Today.ToDateString(),
            fromInclusive = true,
            fromProrateDate = false,
            BasedOn = "365",
            Per = "MONTH",
            ToDate = DateTime.Today.AddDays(28).ToDateString(),
            toInclusive = false,
            toProrateDate = false,
            ProrationBuyerCharge = (decimal)5000.00,
            ProrationBuyerCredit = (decimal)10000.00,
            ProrationSellerCharge = (decimal)5000.00,
            ProrationSellerCredit = (decimal)10000.00,
            ProrationUtilityLE = (decimal)9999.99,
        };
        #endregion

        [TestMethod]
        [Description("Verify create Utility instance using CreateUtility web service")]
        public void Scenario_1_Create_Utility_instance()
        {
            try
            {
                Reports.TestDescription = "Verify create Utility instance using CreateUtility web service";
                
                FAST_Init_File();

                #region Create a new Utility instance with CreateUtility()
                Reports.TestStep = "Create a new Utility instance with CreateUtility()";
                var request = EscrowRequestFactory.GetCreateUtilityRequest(File.FileID, null);
                var response = EscrowService.CreateUtility(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify that the Utility instance in showing in FAST
                Reports.TestStep = "Verify that the Utility instance in showing in FAST";
                FastDriver.UtilityDetail.Open();
                Support.AreEqual("415", FastDriver.UtilityDetail.GabCodeLabel.FAGetText().Trim(), "GabCodeLabel");
                FastDriver.UtilityDetail.PaymentDetails.Click();
                FAST_VerifyPDD(paymentDetails);
                FastDriver.UtilityDetail.WaitForScreenToLoad();
                FAST_VerifyUtilityProration(prorationData);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
