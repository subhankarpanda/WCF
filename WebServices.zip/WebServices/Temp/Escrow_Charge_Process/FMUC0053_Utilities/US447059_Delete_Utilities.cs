﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0053_Utilities
{
    [CodedUITest]
    public class US447059_Delete_Utilities : FASTHelpers
    {
        [TestMethod]
        [Description("Verify Utilities instance is removed using RemoveUtility web service")]
        public void Scenario_1_Delete_Utility_instance()
        {
            try
            {
                Reports.TestDescription = "Verify Utilities instance is removed using RemoveUtility web service";

                FAST_Init_File();

                #region Navigate to Utilities and create a new instance
                Reports.TestStep = "Navigate to Utilities and create a new instance";
                FastDriver.UtilityDetail.Open();
                FastDriver.UtilityDetail.FindGABcode("415");
                FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FASetText("1,500.00");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Delete utility instance with RemoveUtility()
                Reports.TestStep = "Delete utility instance with RemoveUtility()";
                FastDriver.UtilityDetail.Open();
                var response = EscrowService.RemoveUtility(EscrowRequestFactory.GetRemoveUtilityRequest(File.FileID, 1));
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify utility instance is removed in FAST
                Reports.TestStep = "Verify utility instance is removed in FAST";
                FastDriver.UtilityDetail.Open();
                Support.AreEqual("", FastDriver.UtilityDetail.GabCodeLabel.FAGetText().Trim(), "GabCodeLabel");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
