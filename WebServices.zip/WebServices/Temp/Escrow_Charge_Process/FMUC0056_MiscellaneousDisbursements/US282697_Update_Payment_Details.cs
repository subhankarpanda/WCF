﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0056_MiscellaneousDisbursements
{
    [CodedUITest]
    public class US282697_Update_Payment_Details : FASTHelpers
    {
        #region CD Tests Data
        private CDChargePaymentDetails paymentDetailsCD = new CDChargePaymentDetails() { 
            Description = "test-charge-updated",
            LEAmount = (decimal)14999.99,
            PartOf = false,
            UseDefault = true,
            BuyerCharge = 10000,
            PBBuyerAtClosing = 5000,
            AtClosingBuyerPaymentMethodTypeID = AtClosingPaymentMethods.CHK,
            PBBuyerBeforeClosing = 3000,
            PBOthersForBuyer = 2000,
            PBOthersForBuyerPMTypeCdID = OtherPaymentMethods.POC,
            DisplayLBuyer = false,
            DoubleAsteriskIndicator = false,
            eSectionShop = SectionsShoppedFor.SectionHotherCosts,
            SellerCharge = 5000,
            PBSellerAtClosing = 3000,
            AtClosingSellerPaymentMethodTypeID = AtClosingPaymentMethods.CHK,
            PBSellerBeforeClosing = 1000,
            PBOthersForSeller = 1000,
            PBOthersForSellerPMTypeCdID = OtherPaymentMethods.POC,
            DisplayLSeller = false,
            SeqNum = 1,
        };

        private FASTSelenium.DataObjects.IIS.PDD pddFastCD = new FASTSelenium.DataObjects.IIS.PDD() {
            ChargeDescription = "test-charge-updated",
            LoanEstimateUnrounded = 14999.99,
            PartOfCheckbox = false,
            UseDefaultChecked = true,
            BuyerCharge = 10000,
            BuyerAtClosing = 5000,
            BuyerChargePaymentMethod = AtClosingPaymentMethods.CHK.ToString(),
            BuyerBeforeClosing = 3000,
            BuyerPaidbyOther = 2000,
            BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
            BuyerLenderCheckbox = false,
            BuyerDoubleAsteriskChecked = false,
            SectionHOtherCosts = true,
            SellerCharge = 5000,
            SellerPaidAtClosing = 3000,
            SellerChargePaymentMethod = AtClosingPaymentMethods.CHK.ToString(),
            SellerPaidBeforeClosing = 1000,
            SellerPaidbyOthers = 1000,
            SellerPaidbyOtherPaymentMthd = OtherPaymentMethods.POC.ToString(),
        };
        #endregion

        #region HUD Tests Data
        private PaymentDetailsWithGFE paymentDetailsHUD = new PaymentDetailsWithGFE() { 
            Description = "test-charge-update",
            LenderSelectedProvider = true,
            PaidOnBehalfOfBorrower = false,
            BuyerCharge = 10000,
            BuyerPaymentMethodTypeID = 384,
            SellerCharge = 5000,
            SellerPaymentMethodTypeID = 384,
            GfeEntryTypeCdID = 1589,
            SeqNum = 20,
            UseDefault = true,
        };

        private FASTSelenium.DataObjects.IIS.hudPDD pddFastHUD = new FASTSelenium.DataObjects.IIS.hudPDD() {
            Description = "test-charge-update",
            LenderSelectedProvider = true,
            PaidOnBehalfOfBorrower = false,
            BuyerCharge = 10000,
            BuyerPaymentMethod = AtClosingPaymentMethods.CHK.ToString(),
            SellerCharge = 5000,
            SellerPaymentMethod = AtClosingPaymentMethods.CHK.ToString(),
            GFE = "3",
            UseDefault = true,
        };
        #endregion

        private void TestUpdateMiscDisb(FormType ft) 
        {
            FAST_Login_IIS();

            FAST_WCF_File_IIS(formType: ft);

            #region Create Basic Miscallaneous Disbursement instance
            Reports.TestStep = "Create Basic Miscallaneous Disbursement instance";
            FastDriver.MiscDisbursementDetail.Open();
            FastDriver.MiscDisbursementDetail.FindGABcode("415");
            FastDriver.MiscDisbursementDetail.Description.FASetText("test-charge");
            FastDriver.BottomFrame.Done();
            #endregion

            #region Update Miscallaneous Disbursement payment details
            Reports.TestStep = "Update Miscallaneous Disbursement payment details";
            var request = RequestFactory.GetNewMiscDisbursementRequest(File.FileID, seqNum: 1);
            if(ft == FormType.CD)
                request.MiscDisbCDPaymentDetails = new CDChargePaymentDetails[] { paymentDetailsCD };
            else
                request.MiscDisbPaymentDetails = new MiscDisbPaymentDetail[] { new MiscDisbPaymentDetail() { GFEAmount = 15000, MDPaymentDetails = paymentDetailsHUD } };
            var response = FileService.UpdateMiscellaneousDisbursement(request);
            Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
            #endregion

            #region Verify Miscallaneous Disbursement is updated in FAST
            Reports.TestStep = "Verify Miscallaneous Disbursement is updated in FAST";
            FastDriver.MiscDisbursementDetail.Open();
            FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();
            if (ft == FormType.CD)
                FAST_VerifyPDD(pddFastCD);
            else
                FAST_VerifyPDD(pddFastHUD);
            #endregion
        }

        [TestMethod]
        [Description("Verify updating Miscellaneous Disbursement details using UpdateMiscellaneousDisbursement web service when File is CD")]
        public void Scenario_1_CD_Update_Payment_Details()
        {
            try
            {
                Reports.TestDescription = "Verify updating Miscellaneous Disbursement details using UpdateMiscellaneousDisbursement web service when File is CD";

                TestUpdateMiscDisb(FormType.CD);
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify updating Miscellaneous Disbursement details using UpdateMiscellaneousDisbursement web service when File is HUD")]
        public void Scenario_2_HUD_Update_Payment_Details()
        {
            try
            {
                Reports.TestDescription = "Verify updating Miscellaneous Disbursement details using UpdateMiscellaneousDisbursement web service when File is HUD";

                TestUpdateMiscDisb(FormType.HUD);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
