﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0047_NewLoan
{
    [CodedUITest]
    public class US271276_Update_BusParty_and_Contact_NMLS_and_STLicenseID : SlaveTestClass
    {
        [TestMethod]
        [Description("Verify UpdateNewLoan() for Update New Loan-Lender Business on Party Lender Information with ST License ID")]
        public void Scenario_1_Update_NMLS_and_STLicenseID()
        {
            try
            {
                Reports.TestStep = "Verify UpdateNewLoan() for Update New Loan-Lender Business on Party Lender Information with ST License ID";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = @"Create a basic file with New Loan Lender (415)";
                FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000, LenderID: "415");
                #endregion

                #region Navigate to New Loan and Verify NMLS ID and ST License ID
                Reports.TestStep = "Navigate to New Loan and Verify NMLS ID and ST License ID";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItem("automation-user");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                // give some time so FormType can be changed
                Support.AreEqual("", FastDriver.NewLoan.NewLoanDetails_NMLSID.FAGetValue(), "NewLoanDetails_NMLSID");
                Support.AreEqual("CA, TEST02STLENDER", FastDriver.NewLoan.NewLoanDetails_STLICENSEID.Text, "NewLoanDetails_STLICENSEID");
                Support.AreEqual("TEST01NMLS", FastDriver.NewLoan.NewLoanDetails_Contact_NMLSID.FAGetValue(), "NewLoanDetails_Contact_NMLSID");
                Support.AreEqual("CA, TEST02STLENDER", FastDriver.NewLoan.NewLoanDetails_Contact_STLICENSEID.Text, "NewLoanDetails_Contact_STLICENSEID");
                #endregion

                #region Update New Loan information for NMLS ID and ST License ID
                Reports.TestStep = "Update New Loan information for NMLS ID and ST License ID";
                var details = FileService.GetNewLoanDetails(File.FileID ?? 0, seqNum: 1);
                var request = RequestFactory.GetNewLoanDefaultRequest(File.FileID.ToString(), seqNum: 1);
                request.LoanDetails.LenderInformation.AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415");
                request.LoanDetails.LenderInformation.LicenseInfo = details.LoanDetails.LenderInformation.Licenses[0];
                request.LoanDetails.LenderInformation.BusOrgContact = new BusOrgContact()
                {
                    ContactID = AdminService.GetGABByAddressBookEntryID(request.LoanDetails.LenderInformation.AddrBookEntryID ?? 0).GABContactID,
                    LicenseInfo = (details.LoanDetails.LenderInformation.BusOrgContact != null) ? details.LoanDetails.LenderInformation.BusOrgContact.Licenses[0] : null,
                };
                var response = FileService.UpdateNewLoan(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Navigate to New Loan and Verify NMLS ID and ST License ID after UpdateNewLoan request
                Reports.TestStep = "Navigate to New Loan and Verify NMLS ID and ST License ID after UpdateNewLoan request";
                FastDriver.NewLoan.Open();
                Support.AreEqual("TEST01NMLS", FastDriver.NewLoan.NewLoanDetails_NMLSID.FAGetValue(), "NewLoanDetails_NMLSID");
                Support.AreEqual("CA, TEST02STLENDER", FastDriver.NewLoan.NewLoanDetails_STLICENSEID.Text, "NewLoanDetails_STLICENSEID");
                Support.AreEqual("TEST01NMLS", FastDriver.NewLoan.NewLoanDetails_Contact_NMLSID.FAGetValue(), "NewLoanDetails_Contact_NMLSID");
                Support.AreEqual("CA, TEST02STLENDER", FastDriver.NewLoan.NewLoanDetails_Contact_STLICENSEID.Text, "NewLoanDetails_Contact_STLICENSEID");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
