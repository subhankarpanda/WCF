﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;


namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0047_NewLoan
{
    [CodedUITest]
    public class US282668_Create_NewLoan_Instance : SlaveTestClass
    {
        private decimal FixedRatedBuyerCharge(NewLoanRequest request)
        {
            var buyerCharge = request.LoanCharges.PrincipalBalanceCharges.BuyerCharge ?? 0;
            var days = request.LoanCharges.InterestCalculationSummary.InterestCalculation.From.DaysPassed(request.LoanCharges.InterestCalculationSummary.InterestCalculation.To) + (request.LoanCharges.InterestCalculationSummary.InterestCalculation.ToInclusive.ToString().ToLowerInvariant() == "true" ? 1 : 0) + (request.LoanCharges.InterestCalculationSummary.InterestCalculation.FromInclusive.ToString().ToLowerInvariant() == "true" ? -2 : -1);
            var basedOnDays = request.LoanCharges.InterestCalculationSummary.InterestCalculation.BasedOnDays ?? 365;
            var i = (request.LoanCharges.InterestCalculationSummary.InterestCalculation.PercentageRate ?? 0) / 100;

            return (buyerCharge * i * days / basedOnDays);
        }
        
        private void VerifyCD2ndNewLoan(NewLoanRequest request)
        {
            Reports.TestStep = "Principal Balance Charges";
            Support.AreEqual(request.LoanCharges.CDPrincipalBalanceCharges.BuyerCredit.ToString("N2"), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercredit.FAGetValue(), "Buyer Credit");
            Support.AreEqual(request.LoanCharges.CDPrincipalBalanceCharges.SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesSellercharge.FAGetValue(), "Seller Charge");
            Support.AreEqual(request.LoanCharges.CDPrincipalBalanceCharges.LEAmount.ToString("N2"), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesLEAmount.FAGetValue(), "Loan Estimate");
            Reports.TestStep = "Interest Calculation";
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.InterestTypeCdID == 433 ? "Fixed Rate" : "Unexpected/Other", FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FAGetSelectedItem(), "Interest Type");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.BasedOnDays.ToString(), FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem(), "Based On (Days)");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.InterestFlag == 1 ? "true" : "false", FastDriver.NewLoan.LoanChargesInterestCalculationPercentage.FAGetAttribute("status").ToLowerInvariant(), "Percentage?");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.PercentageRate.ToString("N4"), FastDriver.NewLoan.LoanChargesInterestCalculationPercentageRate.FAGetValue(), "Percentage Rate");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.From.ToString("MM-dd-yyyy"), FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FAGetValue(), "From Date");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.FromInclusive.ToString().ToLowerInvariant(), FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.FAGetAttribute("status").ToLowerInvariant(), "From Inclusive");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.To.ToString("MM-dd-yyyy"), FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FAGetValue(), "To Date");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.ToInclusive.ToString().ToLowerInvariant(), FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.FAGetAttribute("status").ToLowerInvariant(), "To Inclusive");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.CDChargePaymentDetails.BuyerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.CDChargePaymentDetails.SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesInterestCalculationsellercharge.FAGetValue(), "Seller Charge");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.CDChargePaymentDetails.LEAmount.ToString("N2"), FastDriver.NewLoan.InterestCalculation_Loan_Estimates_Row1.FAGetValue(), "Loan Estimate");
            Reports.TestStep = "New Loan Charges";
            Support.AreEqual(request.LoanCharges.CDNewLoanCharges[0].BuyerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.CDNewLoanCharges[0].SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesSellerCharge.FAGetValue(), "Seller Charge");
            Support.AreEqual(request.LoanCharges.CDNewLoanCharges[0].LEAmount.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesGFEAmount.FAGetValue(), "Loan Estimate");
        }

        private void VerifyHUD2ndNewLoan(NewLoanRequest request)
        {
            Reports.TestStep = "Principal Balance Charges";
            Support.AreEqual(request.LoanCharges.PrincipalBalanceCharges.BuyerCharge.ToString("N2"), FastDriver.NewLoan.BorrowerCharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.PrincipalBalanceCharges.BuyerCredit.ToString("N2"), FastDriver.NewLoan.BorrowerCredit.FAGetValue(), "Buyer Credit");
            Support.AreEqual(request.LoanCharges.PrincipalBalanceCharges.SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesSellercharge.FAGetValue(), "Seller Charge");
            Support.AreEqual(request.LoanCharges.PrincipalBalanceCharges.SellerCredit.ToString("N2"), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargessellercredit.FAGetValue(), "Seller Credit");
            Reports.TestStep = "Interest Calculation";
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.InterestTypeCdID == 433 ? "Fixed Rate" : "Unexpected/Other", FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FAGetSelectedItem(), "Interest Type");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.BasedOnDays.ToString(), FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem(), "Based On (Days)");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.InterestFlag == 1 ? "true" : "false", FastDriver.NewLoan.LoanChargesInterestCalculationPercentage.FAGetAttribute("status").ToLowerInvariant(), "Percentage?");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.PercentageRate.ToString("N4"), FastDriver.NewLoan.LoanChargesInterestCalculationPercentageRate.FAGetValue(), "Percentage Rate");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.From.ToString("MM-dd-yyyy"), FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FAGetValue(), "From Date");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.FromInclusive.ToString().ToLowerInvariant(), FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.FAGetAttribute("status").ToLowerInvariant(), "From Inclusive");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.To.ToString("MM-dd-yyyy"), FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FAGetValue(), "To Date");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.ToInclusive.ToString().ToLowerInvariant(), FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.FAGetAttribute("status").ToLowerInvariant(), "To Inclusive");
            Support.AreEqual(FixedRatedBuyerCharge(request).ToString("N2"), FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.GFEAmount.ToString("N2"), FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FAGetValue(), "GFE Amount");
            Reports.TestStep = "New Loan Charges";
            Support.AreEqual(request.LoanCharges.NewLoanCharges[0].BuyerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.NewLoanCharges[0].BuyerCredit.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCredit.FAGetValue(), "Buyer Credit");
            Support.AreEqual(request.LoanCharges.NewLoanCharges[0].SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesSellerCharge.FAGetValue(), "Seller Charge");
            Support.AreEqual(request.LoanCharges.NewLoanCharges[0].SellerCredit.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesSellerCredit.FAGetValue(), "Seller Credit");
            Reports.TestStep = "Impounds";
            Support.AreEqual(request.LoanCharges.ImpoundCharges.InitialDepositBuyerChargeAmount.ToString("N2"), FastDriver.NewLoan.LoanCharges_InitialDepositBuyerChargeAmount.FAGetText(), "Initial Deposit Buyer Charge");
            Support.AreEqual(request.LoanCharges.ImpoundCharges.InitialDepositSellerChargeAmount.ToString("N2"), FastDriver.NewLoan.LoanCharges_InitialDepositSellerChargeAmount.FAGetText(), "Initial Deposit Seller Charge");
            Support.AreEqual(request.LoanCharges.ImpoundCharges.Impounds[0].Months.ToString(), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_Months1.FAGetValue(), "Months");
            Support.AreEqual(request.LoanCharges.ImpoundCharges.Impounds[0].MonthlyCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_MonthlyCharge.FAGetValue(), "Monthly Charge");
            Support.AreEqual(request.LoanCharges.ImpoundCharges.Impounds[0].PaymentDetails.BuyerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_BuyerCharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.ImpoundCharges.Impounds[0].PaymentDetails.SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_SellerCharge.FAGetValue(), "Seller Charge");

        }
        
        [TestMethod]
        [Description("Verify updating 2nd New Loan charges using CreateNewLoan web service when File is CD")]
        public void Scenario_1_CD_Create_2nd_New_Loan()
        {
            try
            {
                Reports.TestDescription = "Verify updating 2nd New Loan charges using CreateNewLoan web service when File is CD";

                FAST_Login_IIS();

                FAST_WCF_File_IIS(LenderID: "BOA");
                
                #region Update 2nd New Loan charges with CreateNewLoan()
                Reports.TestStep = "Update 2nd New Loan charges with CreateNewLoan()";
                var request = RequestFactory.GetNewLoanRequest(File.FileID ?? 0, seqNum: 2);
                request.LoanCharges = RequestFactory.GetCD2ndLoanCharge();
                request.LoanDetails = new NewLoanDetail() { LenderInformation = new PayChargeFileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("488") } };
                var response = FileService.CreateNewLoan(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify 2nd New Loan charges are updated in FAST
                Reports.TestStep = "Verify 2nd New Loan charges are updated in FAST";
                FastDriver.NewLoanSummary.Open(2);
                FastDriver.NewLoan.ClickChargesTab();
                VerifyCD2ndNewLoan(request);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        
        [TestMethod]
        [Description("Verify updating 2nd New Loan charges using CreateNewLoan web service when File is HUD")]
        public void Scenario_2_HUD_Create_2nd_New_Loan()
        {
            try
            {
                Reports.TestDescription = "Verify updating 2nd New Loan charges using CreateNewLoan web service when File is HUD";

                FAST_Login_IIS();

                FAST_WCF_File_IIS(LenderID: "BOA", formType: FormType.HUD);
                
                #region Update 2nd New Loan charges with CreateNewLoan()
                Reports.TestStep = "Update 2nd New Loan charges with CreateNewLoan()";
                var request = RequestFactory.GetNewLoanRequest(File.FileID ?? 0, seqNum: 2);
                request.LoanCharges = RequestFactory.GetHUD2ndLoanCharge();
                request.LoanDetails = new NewLoanDetail() { LenderInformation = new PayChargeFileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("488") } };
                var response = FileService.CreateNewLoan(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify 2nd New Loan charges are updated in FAST
                Reports.TestStep = "Verify 2nd New Loan charges are updated in FAST";
                FastDriver.NewLoanSummary.Open(2);
                FastDriver.NewLoan.ClickChargesTab();
                VerifyHUD2ndNewLoan(request);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
