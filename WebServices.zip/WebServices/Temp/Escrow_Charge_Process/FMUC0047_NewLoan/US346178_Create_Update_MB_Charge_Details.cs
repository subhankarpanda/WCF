﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0047_NewLoan
{
    [CodedUITest]
    public class US346178_Create_Update_MB_Charge_Details : SlaveTestClass
    {
        #region Payment Details
        protected FASTSelenium.DataObjects.IIS.PDD paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
        {
            UseDefaultChecked = true,
            LoanEstimateUnrounded = (double)999999.99,
            PartOfCheckbox = false,
            BuyerCharge = (double)1000000.00,
            BuyerAtClosing = (double)900000.00,
            BuyerBeforeClosing = (double)99999.99,
            BuyerPaidbyOther = (double)0.01,
            BuyerPaidbyOtherPaymentMethod = "POC",
            BuyerLenderCheckbox = false,
            BuyerDoubleAsteriskChecked = false,
            SellerCharge = (double)1000000.00,
            SellerPaidAtClosing = (double)900000.00,
            SellerPaidBeforeClosing = (double)99999.99,
            SellerPaidbyOthers = (double)0.01,
            SellerPaidbyOtherPaymentMthd = "POC",
            SectionBdidnotShopFor = false,
            SectionCDidShopFor = false,
            SectionHOtherCosts = false,
        };
        #endregion

        [TestMethod]
        [Description("Verify create New Loan - Mortgage Broker charge details using CreateNewLoan web service")]
        public void Scenario_1_Create_with_CreateNewLoan()
        {
            try
            {
                Reports.TestDescription = "Verify create New Loan - Mortgage Broker charge details using CreateNewLoan web service";

                FAST_Init_File();

                #region Create New Loan with MB charge details using CreateNewLoan()
                Reports.TestStep = "Create New Loan with MB charge details using CreateNewLoan()";
                var request = RequestFactory.GetNewLoanRequest(File.FileID, seqNum: null);
                request.LoanDetails = new FASTWCFHelpers.FastFileService.NewLoanDetail()
                {
                    LoanNumber = "1234567890",
                    LoanAmount = 1500000,
                    LenderInformation = new FASTWCFHelpers.FastFileService.PayChargeFileBusinessParty(){ AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415") }
                };
                request.MortgageBroker = new FASTWCFHelpers.FastFileService.MortgageBroker()
                {
                    MorgageBrokerInformation = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("501") },
                    CDMortgageBrokerCharges = new FASTWCFHelpers.FastFileService.CDChargePaymentDetails[] { 
                        RequestFactory.GetCDChargePaymentDetails(),
                    }
                };
                var response = FileService.CreateNewLoan(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify New Loan MB charge details in FAST
                Reports.TestStep = "Verify New Loan MB charge details in FAST";
                FastDriver.NewLoanSummary.Open(2);
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                Support.AreEqual("501", FastDriver.NewLoan.MortgageBrokerGABlabel.FAGetText().Trim(), "MortgageBrokerGABlabel");
                paymentDetails.ChargeDescription = FastDriver.NewLoan.MBChargesDescription0.FAGetValue();
                FastDriver.NewLoan.MBChargesPaymentDetails.Click();
                FAST_VerifyPDD(paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify update New Loan - Mortgage Broker charge details using UpdateNewLoan web service")]
        public void Scenario_2_Update_with_UpdateNewLoan()
        {
            try
            {
                Reports.TestDescription = "Verify update New Loan - Mortgage Broker charge details using UpdateNewLoan web service";

                FAST_Init_File(LenderID:"415", loanAmt:(decimal)1500000);

                #region Update New Loan with MB charge details using UpdateNewLoan()
                Reports.TestStep = "Update New Loan with MB charge details using UpdateNewLoan()";
                var request = RequestFactory.GetNewLoanRequest(File.FileID, seqNum: 1);
                request.MortgageBroker = new FASTWCFHelpers.FastFileService.MortgageBroker()
                {
                    MorgageBrokerInformation = new FASTWCFHelpers.FastFileService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("501") },
                    CDMortgageBrokerCharges = new FASTWCFHelpers.FastFileService.CDChargePaymentDetails[] { RequestFactory.GetCDChargePaymentDetails() },
                };
                var response = FileService.UpdateNewLoan(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify New Loan MB charge details in FAST
                Reports.TestStep = "Verify New Loan MB charge details in FAST";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                Support.AreEqual("501", FastDriver.NewLoan.MortgageBrokerGABlabel.FAGetText().Trim(), "MortgageBrokerGABlabel");
                paymentDetails.ChargeDescription = FastDriver.NewLoan.MBChargesDescription0.FAGetValue();
                FastDriver.NewLoan.MBChargesPaymentDetails.Click();
                FAST_VerifyPDD(paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
