﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0047_NewLoan
{
    [CodedUITest]
    public class US272074_Retrieve_MBParty_Contact_Info : SlaveTestClass
    {
        [TestMethod]
        [Description("Verify GetNewLoanDetails can retrieve Mortgage Broker information with NMLS & STLicenseID")]
        public void Scenario_1_Get_MB_NMLS_and_STLicenseID()
        {
            try
            {
                Reports.TestDescription = "Verify GetNewLoanDetails can retrieve Mortgage Broker information with NMLS & STLicenseID";

                FAST_Init_File();

                #region Navigate to New Loan and Verify NMLS ID and ST License ID
                Reports.TestStep = "Navigate to New Loan and Verify NMLS ID and ST License ID";
                FastDriver.NewLoan.Open();
                // give some time so FormType can be changed
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.MortgageFindGABCode("415");
                FastDriver.NewLoan.MortgageAttention.FASelectItem("automation-user");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                Support.AreEqual("TEST01NMLS", FastDriver.NewLoan.NewLoanMortgage_NMLSID.FAGetValue(), "NewLoanDetails_NMLSID");
                Support.AreEqual("CA, TEST02STLENDER", FastDriver.NewLoan.NewLoanMortgage_STLICENSEID.Text ?? "null", "NewLoanDetails_STLICENSEID");
                if (FastDriver.NewLoan.NewLoanMortgage_Contact_Expand.GetAttribute("class").Contains("cButtonExpandFalse"))
                    FastDriver.NewLoan.NewLoanMortgage_Contact_Expand.Click();
                FastDriver.NewLoan.WaitCreation(FastDriver.NewLoan.NewLoanMortgage_Contact_NMLSID);
                Support.AreEqual("TEST01NMLS", FastDriver.NewLoan.NewLoanMortgage_Contact_NMLSID.FAGetValue(), "NewLoanDetails_Contact_NMLSID");
                Support.AreEqual("CA, TEST02STLENDER", FastDriver.NewLoan.NewLoanMortgage_Contact_STLICENSEID.Text ?? "null", "NewLoanDetails_Contact_STLICENSEID");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                #endregion

                #region Verify NMLS ID and ST License ID with GetNewLoanDetails web service
                Reports.TestStep = "Verify NMLS ID and ST License ID with GetNewLoanDetails web service";
                var details = FileService.GetNewLoanDetails(File.FileID ?? 0, seqNum: 1);
                Support.AreEqual("TEST01NMLS", details.MortgageBroker.MorgageBrokerInformation.LicenseInfo.NMLSLicenseNo ?? "null", "LicenseInfo.NMLSLicenseNo");
                Support.AreEqual("CA, TEST02STLENDER", details.MortgageBroker.MorgageBrokerInformation.LicenseInfo.StateLicenseNo ?? "null", "LicenseInfo.StateLicenseNo");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
