﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0047_NewLoan
{
    [CodedUITest]
    public class US272132_Update_NewLoan_Lender_Charges : SlaveTestClass
    {
        private decimal FixedRatedBuyerCharge(NewLoanRequest request)
        { 
            var buyerCharge = request.LoanCharges.PrincipalBalanceCharges.BuyerCharge ?? 0;
            var days = request.LoanCharges.InterestCalculationSummary.InterestCalculation.From.DaysPassed(request.LoanCharges.InterestCalculationSummary.InterestCalculation.To) + (request.LoanCharges.InterestCalculationSummary.InterestCalculation.ToInclusive.ToString().ToLowerInvariant() == "true" ?  1:0 ) + (request.LoanCharges.InterestCalculationSummary.InterestCalculation.FromInclusive.ToString().ToLowerInvariant() == "true" ? -2:-1);
            var basedOnDays = request.LoanCharges.InterestCalculationSummary.InterestCalculation.BasedOnDays ?? 365;  
            var i = (request.LoanCharges.InterestCalculationSummary.InterestCalculation.PercentageRate ?? 0) / 100;

            return (buyerCharge * i * days / basedOnDays);
        }

        private void VerifyCDNewLoan(NewLoanRequest request)
        {
            Reports.TestStep = "Principal Balance Charges";
            Support.AreEqual(request.LoanCharges.CDPrincipalBalanceCharges.BuyerCredit.ToString("N2"), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercredit.FAGetValue(), "Buyer Credit");
            Support.AreEqual(request.LoanCharges.CDPrincipalBalanceCharges.SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesSellercharge.FAGetValue(), "Seller Charge");
            Support.AreEqual(request.LoanCharges.CDPrincipalBalanceCharges.LEAmount.ToString("N2"), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesLEAmount.FAGetValue(), "Loan Estimate");
            Reports.TestStep = "Interest Calculation";
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.InterestTypeCdID == 433 ? "Fixed Rate" : "Unexpected/Other", FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FAGetSelectedItem(), "Interest Type");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.BasedOnDays.ToString(), FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem(), "Based On (Days)");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.InterestFlag == 1 ? "true" : "false", FastDriver.NewLoan.LoanChargesInterestCalculationPercentage.FAGetAttribute("status").ToLowerInvariant(), "Percentage?");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.PercentageRate.ToString("N4"), FastDriver.NewLoan.LoanChargesInterestCalculationPercentageRate.FAGetValue(), "Percentage Rate");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.From.ToString("MM-dd-yyyy"), FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FAGetValue(), "From Date");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.FromInclusive.ToString().ToLowerInvariant(), FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.FAGetAttribute("status").ToLowerInvariant(), "From Inclusive");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.To.ToString("MM-dd-yyyy"), FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FAGetValue(), "To Date");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.ToInclusive.ToString().ToLowerInvariant(), FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.FAGetAttribute("status").ToLowerInvariant(), "To Inclusive");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.CDChargePaymentDetails.BuyerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.CDChargePaymentDetails.SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesInterestCalculationsellercharge.FAGetValue(), "Seller Charge");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.CDChargePaymentDetails.LEAmount.ToString("N2"), FastDriver.NewLoan.InterestCalculation_Loan_Estimates_Row1.FAGetValue(), "Loan Estimate");
            Reports.TestStep = "Credit/Charge Points";
            Support.AreEqual(request.LoanCharges.CDCreditOrChargePoints.DiscountPointPercent.ToString("N3"), FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FAGetValue(), "Loan Amount Percentage");
            Support.AreEqual(request.LoanCharges.CDCreditOrChargePoints.CDSelectedDispFrmt == 2475 ? ".n%" : "Unexpected/Other", FastDriver.NewLoan.CreditChargePointsPercentageDisplayFormat.FAGetSelectedItem(), "Display Format");
            Support.AreEqual(request.LoanCharges.CDCreditOrChargePoints.IRSDiscountPoints.ToString("N2"), FastDriver.NewLoan.CreditChargePointsPercentageIRSPoints.FAGetValue(), "IRS Points");
            Support.AreEqual((request.LoanCharges.CDPrincipalBalanceCharges.BuyerCredit * request.LoanCharges.CDCreditOrChargePoints.DiscountPointPercent / 100).ToString("N2"), FastDriver.NewLoan.LoanChargesCredit_ChargeBuyerCharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual("", FastDriver.NewLoan.LoanChargesCredit_ChargeSellerCharge.FAGetValue(), "Seller Charge");
            Support.AreEqual("", FastDriver.NewLoan.LoanChargesCredit_ChargeLoanEstimate.FAGetValue(), "Loan Amount");
            Reports.TestStep = "Origination Charges";
            Support.AreEqual(request.LoanCharges.CDOriginationCharges[0].BuyerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesOriginationChargebuyercharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.CDOriginationCharges[0].SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesOriginationChargeSellercharge.FAGetValue(), "Seller Charge");
            Support.AreEqual(request.LoanCharges.CDOriginationCharges[0].LEAmount.ToString("N2"), FastDriver.NewLoan.LoanChargesOriginationChargeGFEAmount.FAGetValue(), "Loan Estimate");
            Reports.TestStep = "New Loan Charges";
            Support.AreEqual(request.LoanCharges.CDNewLoanCharges[0].BuyerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.CDNewLoanCharges[0].SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesSellerCharge.FAGetValue(), "Seller Charge");
            Support.AreEqual(request.LoanCharges.CDNewLoanCharges[0].LEAmount.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesGFEAmount.FAGetValue(), "Loan Estimate");
            Reports.TestStep = "Lender Credits";
            Support.AreEqual(request.LoanCharges.CDLenderCredits[0].BuyerCredit.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharges_BuyerCredit.FAGetValue(), "Buyer Credit");
            Support.AreEqual(request.LoanCharges.CDLenderCredits[0].LEAmount.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_GFEAmount.FAGetValue(), "Loan Estimate");
            Reports.TestStep = "Future Recording Fees collected by Lender";
            Support.AreEqual(request.LoanCharges.CDFutureRecordingFeesCollectedByLender[0].BuyerCharge.ToString("N2"), FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderBuyerCharge.FAGetValue(), "Buyer Charge");
            Reports.TestStep = "Impounds";
            Support.AreEqual(request.LoanCharges.CDImpoundCharges.AAACreditChargeFlag == 1 ? "true" : "false", FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAGetAttribute("status").ToLowerInvariant(), "Credit?");
            Support.AreEqual(request.LoanCharges.CDImpoundCharges.AggregateAccountingAdjustment.BuyerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FAGetValue(), "Buyer Adjustment");
            Support.AreEqual(request.LoanCharges.CDImpoundCharges.AggregateAccountingAdjustment.SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FAGetValue(), "Seller Adjustment");
            Support.AreEqual(request.LoanCharges.CDImpoundCharges.Impounds[0].Months.ToString(), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_Months1.FAGetValue(), "Months");
            Support.AreEqual(request.LoanCharges.CDImpoundCharges.Impounds[0].MonthlyCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_MonthlyCharge.FAGetValue(), "Monthly Charge");
            Support.AreEqual(request.LoanCharges.CDImpoundCharges.Impounds[0].BuyerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_BuyerCharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.CDImpoundCharges.Impounds[0].SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_SellerCharge.FAGetValue(), "Seller Charge");
            Support.AreEqual(request.LoanCharges.CDImpoundCharges.Impounds[0].LEAmount.ToString("N2"), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_LoanEstimate.FAGetValue(), "Loan Estimate");
            Reports.TestStep = "Principal Reduction/Construction Holdback";
            Support.AreEqual(request.LoanCharges.CDPrincipalReductionOrConstructionHoldBack[0].BuyerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesPrincipalreduction_Payment_BuyerCharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.CDPrincipalReductionOrConstructionHoldBack[0].SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_SellerCharge.FAGetValue(), "Seller Charge");
            Support.AreEqual(request.LoanCharges.CDPrincipalReductionOrConstructionHoldBack[0].LEAmount.ToString("N2"), FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_LEAmount.FAGetValue(), "Loan Estimate");            
        }

        private void VerifyHUDNewLoan(NewLoanRequest request)
        {
            Reports.TestStep = "Principal Balance Charges";
            Support.AreEqual(request.LoanCharges.PrincipalBalanceCharges.BuyerCharge.ToString("N2"), FastDriver.NewLoan.BorrowerCharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.PrincipalBalanceCharges.BuyerCredit.ToString("N2"), FastDriver.NewLoan.BorrowerCredit.FAGetValue(), "Buyer Credit");
            Support.AreEqual(request.LoanCharges.PrincipalBalanceCharges.SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesSellercharge.FAGetValue(), "Seller Charge");
            Support.AreEqual(request.LoanCharges.PrincipalBalanceCharges.SellerCredit.ToString("N2"), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargessellercredit.FAGetValue(), "Seller Credit");
            Reports.TestStep = "Interest Calculation";
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.InterestTypeCdID == 433 ? "Fixed Rate" : "Unexpected/Other", FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FAGetSelectedItem(), "Interest Type");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.BasedOnDays.ToString(), FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem(), "Based On (Days)");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.InterestFlag == 1 ? "true" : "false", FastDriver.NewLoan.LoanChargesInterestCalculationPercentage.FAGetAttribute("status").ToLowerInvariant(), "Percentage?");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.PercentageRate.ToString("N4"), FastDriver.NewLoan.LoanChargesInterestCalculationPercentageRate.FAGetValue(), "Percentage Rate");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.From.ToString("MM-dd-yyyy"), FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FAGetValue(), "From Date");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.FromInclusive.ToString().ToLowerInvariant(), FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.FAGetAttribute("status").ToLowerInvariant(), "From Inclusive");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.To.ToString("MM-dd-yyyy"), FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FAGetValue(), "To Date");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.ToInclusive.ToString().ToLowerInvariant(), FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.FAGetAttribute("status").ToLowerInvariant(), "To Inclusive");
            Support.AreEqual(FixedRatedBuyerCharge(request).ToString("N2"), FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.GFEAmount.ToString("N2"), FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FAGetValue(), "GFE Amount");
            Reports.TestStep = "Origination Charges";
            Support.AreEqual(request.LoanCharges.OriginationCharges.GFEAmount.ToString("N2"), FastDriver.NewLoan.LoanChargesOriginationChargeGFEAmount.FAGetValue(), "GFE Amount");
            Support.AreEqual(request.LoanCharges.OriginationCharges.OriginationFeePercent.ToString("N4"), FastDriver.NewLoan.LoanChargesOriginationChargePercentage.FAGetValue(), "Origination Fee Percent");
            Support.AreEqual((request.LoanCharges.PrincipalBalanceCharges.BuyerCharge * request.LoanCharges.OriginationCharges.OriginationFeePercent / 100).ToString("N2"), FastDriver.NewLoan.LoanChargesOriginationChargeIRSOriginationPoints.FAGetValue(), "IRS Origination Points");
            Reports.TestStep = "Itemized Origination Charges (Only available for authorized transactions)";
            Support.AreEqual(request.LoanCharges.ItemisedOrgCharges[0].PaymentDetail.Description, FastDriver.NewLoan.LoanChargesItemizedOrginationChargeRemainingDescription2.FAGetValue(), "Description");
            Reports.TestStep = "Credit/Charge Points";
            Support.AreEqual(request.LoanCharges.CreditOrChargePoints.GFEAmount.ToString("N2"), FastDriver.NewLoan.LoanChargesCredit_ChargePointsGFEAmount.FAGetValue(), "GFE Amount");
            Support.AreEqual(request.LoanCharges.CreditOrChargePoints.DiscountPointPercent.ToString("N4"), FastDriver.NewLoan.LoanChargesCredit_ChargePointsPercentage.FAGetValue(), "Discount Point Percent");
            Support.AreEqual((request.LoanCharges.PrincipalBalanceCharges.BuyerCharge * request.LoanCharges.CreditOrChargePoints.DiscountPointPercent / 100).ToString("N2"), FastDriver.NewLoan.LoanChargesCredit_Charge_IRSDiscountPoints.FAGetValue(), "IRS Discount Points");
            Reports.TestStep = "GFE #3 New Loan Charges (Lender Selected)";
            Support.AreEqual(request.LoanCharges.GFE3LoanCharges[0].PaymentDetail.BuyerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.GFE3LoanCharges[0].PaymentDetail.BuyerCredit.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCredit.FAGetValue(), "Buyer Credit");
            Support.AreEqual(request.LoanCharges.GFE3LoanCharges[0].PaymentDetail.SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesSellerCharge.FAGetValue(), "Seller Charge");
            Support.AreEqual(request.LoanCharges.GFE3LoanCharges[0].PaymentDetail.SellerCredit.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesSellerCredit.FAGetValue(), "Seller Credit");
            Support.AreEqual(request.LoanCharges.GFE3LoanCharges[0].GFEAmount.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesGFEAmount.FAGetValue(), "GFE Amount");
            Reports.TestStep = "GFE #6 New Loan Charges (Borrower Selected)";
            Support.AreEqual(request.LoanCharges.GFE6LoanCharges[0].PaymentDetail.BuyerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharges_BuyerCharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.GFE6LoanCharges[0].PaymentDetail.BuyerCredit.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharges_BuyerCredit.FAGetValue(), "Buyer Credit");
            Support.AreEqual(request.LoanCharges.GFE6LoanCharges[0].PaymentDetail.SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharges_SellerCharge.FAGetValue(), "Seller Charge");
            Support.AreEqual(request.LoanCharges.GFE6LoanCharges[0].PaymentDetail.SellerCredit.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_SellerCredit.FAGetValue(), "Seller Credit");
            Support.AreEqual(request.LoanCharges.GFE6LoanCharges[0].GFEAmount.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharge_GFEAmount.FAGetValue(), "GFE Amount");
            Reports.TestStep = "GFE #7 Future Recording Fees collected by Lender / MB";
            Support.AreEqual(request.LoanCharges.GFE7LoanCharges[0].PaymentDetail.BuyerCharge.ToString("N2"), FastDriver.NewLoan.LoanCharges_FutureRecFeesLenderBuyerCharge.FAGetValue(), "Buyer Charge");
            Reports.TestStep = "Impounds";
            Support.AreEqual(request.LoanCharges.ImpoundCharges.InitialDepositBuyerChargeAmount.ToString("N2"), FastDriver.NewLoan.LoanCharges_InitialDepositBuyerChargeAmount.FAGetText(), "Initial Deposit Buyer Charge");
            Support.AreEqual(request.LoanCharges.ImpoundCharges.InitialDepositSellerChargeAmount.ToString("N2"), FastDriver.NewLoan.LoanCharges_InitialDepositSellerChargeAmount.FAGetText(), "Initial Deposit Seller Charge");
            Support.AreEqual(request.LoanCharges.ImpoundCharges.AggrAcctAdjBuyerChargeAmount.ToString("N2"), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FAGetValue(), "Aggregate Accounting Adjustment | Buyer Charge");
            Support.AreEqual(request.LoanCharges.ImpoundCharges.AggrAcctAdjSellerChargeAmount.ToString("N2"), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FAGetValue(), "Aggregate Accounting Adjustment | Seller Charge");
            Support.AreEqual(request.LoanCharges.ImpoundCharges.GFEAmount.ToString("N2"), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FAGetValue(), "GFE Amount");
            Support.AreEqual(request.LoanCharges.ImpoundCharges.Impounds[0].Months.ToString(), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_Months1.FAGetValue(), "Months");
            Support.AreEqual(request.LoanCharges.ImpoundCharges.Impounds[0].MonthlyCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_MonthlyCharge.FAGetValue(), "Monthly Charge");
            Support.AreEqual(request.LoanCharges.ImpoundCharges.Impounds[0].PaymentDetails.BuyerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_BuyerCharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.ImpoundCharges.Impounds[0].PaymentDetails.SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_SellerCharge.FAGetValue(), "Seller Charge");
            Reports.TestStep = "Principal Reduction/Construction holdback";
            Support.AreEqual(request.LoanCharges.PrincipalReductionOrConstructionHoldBack[0].BuyerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesPrincipalreduction_Payment_BuyerCharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.PrincipalReductionOrConstructionHoldBack[0].BuyerCredit.ToString("N2"), FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_BuyerCredit.FAGetValue(), "Buyer Credit");
            Support.AreEqual(request.LoanCharges.PrincipalReductionOrConstructionHoldBack[0].SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_SellerCharge.FAGetValue(), "Seller Charge");
            Support.AreEqual(request.LoanCharges.PrincipalReductionOrConstructionHoldBack[0].SellerCredit.ToString("N2"), FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_SellerCredit.FAGetValue(), "Seller Credit");
        }

        private void VerifyCD2ndNewLoan(NewLoanRequest request)
        {
            Reports.TestStep = "Principal Balance Charges";
            Support.AreEqual(request.LoanCharges.CDPrincipalBalanceCharges.BuyerCredit.ToString("N2"), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercredit.FAGetValue(), "Buyer Credit");
            Support.AreEqual(request.LoanCharges.CDPrincipalBalanceCharges.SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesSellercharge.FAGetValue(), "Seller Charge");
            Support.AreEqual(request.LoanCharges.CDPrincipalBalanceCharges.LEAmount.ToString("N2"), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesLEAmount.FAGetValue(), "Loan Estimate");
            Reports.TestStep = "Interest Calculation";
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.InterestTypeCdID == 433 ? "Fixed Rate" : "Unexpected/Other", FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FAGetSelectedItem(), "Interest Type");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.BasedOnDays.ToString(), FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem(), "Based On (Days)");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.InterestFlag == 1 ? "true" : "false", FastDriver.NewLoan.LoanChargesInterestCalculationPercentage.FAGetAttribute("status").ToLowerInvariant(), "Percentage?");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.PercentageRate.ToString("N4"), FastDriver.NewLoan.LoanChargesInterestCalculationPercentageRate.FAGetValue(), "Percentage Rate");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.From.ToString("MM-dd-yyyy"), FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FAGetValue(), "From Date");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.FromInclusive.ToString().ToLowerInvariant(), FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.FAGetAttribute("status").ToLowerInvariant(), "From Inclusive");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.To.ToString("MM-dd-yyyy"), FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FAGetValue(), "To Date");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.InterestCalculation.ToInclusive.ToString().ToLowerInvariant(), FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.FAGetAttribute("status").ToLowerInvariant(), "To Inclusive");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.CDChargePaymentDetails.BuyerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.CDChargePaymentDetails.SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesInterestCalculationsellercharge.FAGetValue(), "Seller Charge");
            Support.AreEqual(request.LoanCharges.CDInterestCalculationSummary.CDChargePaymentDetails.LEAmount.ToString("N2"), FastDriver.NewLoan.InterestCalculation_Loan_Estimates_Row1.FAGetValue(), "Loan Estimate");
            Reports.TestStep = "New Loan Charges";
            Support.AreEqual(request.LoanCharges.CDNewLoanCharges[0].BuyerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.CDNewLoanCharges[0].SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesSellerCharge.FAGetValue(), "Seller Charge");
            Support.AreEqual(request.LoanCharges.CDNewLoanCharges[0].LEAmount.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesGFEAmount.FAGetValue(), "Loan Estimate");
        }

        private void VerifyHUD2ndNewLoan(NewLoanRequest request) 
        {
            Reports.TestStep = "Principal Balance Charges";
            Support.AreEqual(request.LoanCharges.PrincipalBalanceCharges.BuyerCharge.ToString("N2"), FastDriver.NewLoan.BorrowerCharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.PrincipalBalanceCharges.BuyerCredit.ToString("N2"), FastDriver.NewLoan.BorrowerCredit.FAGetValue(), "Buyer Credit");
            Support.AreEqual(request.LoanCharges.PrincipalBalanceCharges.SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesSellercharge.FAGetValue(), "Seller Charge");
            Support.AreEqual(request.LoanCharges.PrincipalBalanceCharges.SellerCredit.ToString("N2"), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargessellercredit.FAGetValue(), "Seller Credit");
            Reports.TestStep = "Interest Calculation";
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.InterestTypeCdID == 433 ? "Fixed Rate" : "Unexpected/Other", FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FAGetSelectedItem(), "Interest Type");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.BasedOnDays.ToString(), FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem(), "Based On (Days)");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.InterestFlag == 1 ? "true" : "false", FastDriver.NewLoan.LoanChargesInterestCalculationPercentage.FAGetAttribute("status").ToLowerInvariant(), "Percentage?");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.PercentageRate.ToString("N4"), FastDriver.NewLoan.LoanChargesInterestCalculationPercentageRate.FAGetValue(), "Percentage Rate");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.From.ToString("MM-dd-yyyy"), FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FAGetValue(), "From Date");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.FromInclusive.ToString().ToLowerInvariant(), FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.FAGetAttribute("status").ToLowerInvariant(), "From Inclusive");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.To.ToString("MM-dd-yyyy"), FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FAGetValue(), "To Date");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.ToInclusive.ToString().ToLowerInvariant(), FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.FAGetAttribute("status").ToLowerInvariant(), "To Inclusive");
            Support.AreEqual(FixedRatedBuyerCharge(request).ToString("N2"), FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.InterestCalculationSummary.InterestCalculation.GFEAmount.ToString("N2"), FastDriver.NewLoan.LoanChargesInterestCalculationGFEAmount.FAGetValue(), "GFE Amount");
            Reports.TestStep = "New Loan Charges";
            Support.AreEqual(request.LoanCharges.NewLoanCharges[0].BuyerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.NewLoanCharges[0].BuyerCredit.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCredit.FAGetValue(), "Buyer Credit");
            Support.AreEqual(request.LoanCharges.NewLoanCharges[0].SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesSellerCharge.FAGetValue(), "Seller Charge");
            Support.AreEqual(request.LoanCharges.NewLoanCharges[0].SellerCredit.ToString("N2"), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesSellerCredit.FAGetValue(), "Seller Credit");
            Reports.TestStep = "Impounds";
            Support.AreEqual(request.LoanCharges.ImpoundCharges.InitialDepositBuyerChargeAmount.ToString("N2"), FastDriver.NewLoan.LoanCharges_InitialDepositBuyerChargeAmount.FAGetText(), "Initial Deposit Buyer Charge");
            Support.AreEqual(request.LoanCharges.ImpoundCharges.InitialDepositSellerChargeAmount.ToString("N2"), FastDriver.NewLoan.LoanCharges_InitialDepositSellerChargeAmount.FAGetText(), "Initial Deposit Seller Charge");
            Support.AreEqual(request.LoanCharges.ImpoundCharges.Impounds[0].Months.ToString(), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_Months1.FAGetValue(), "Months");
            Support.AreEqual(request.LoanCharges.ImpoundCharges.Impounds[0].MonthlyCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_MonthlyCharge.FAGetValue(), "Monthly Charge");
            Support.AreEqual(request.LoanCharges.ImpoundCharges.Impounds[0].PaymentDetails.BuyerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_BuyerCharge.FAGetValue(), "Buyer Charge");
            Support.AreEqual(request.LoanCharges.ImpoundCharges.Impounds[0].PaymentDetails.SellerCharge.ToString("N2"), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_SellerCharge.FAGetValue(), "Seller Charge");
            
        }

        [TestMethod]
        [Description("Verify updating 1st New Loan charges using UpdateNewLoan web service when File is CD")]
        public void Scenario_1_CD_Update_1st_New_Loan()
        {
            try
            {
                Reports.TestDescription = "Verify updating 1st New Loan charges using UpdateNewLoan web service when File is CD";

                FAST_Login_IIS();

                FAST_WCF_File_IIS(LenderID:"BOA");

                #region Update 1st New Loan charges with UpdateNewLoan()
                Reports.TestStep = "Update 1st New Loan charges with UpdateNewLoan()";
                var request = RequestFactory.GetNewLoanRequest(File.FileID ?? 0, seqNum: 1);
                request.LoanCharges = RequestFactory.GetCDLoanCharge();
                var response = FileService.UpdateNewLoan(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion
                
                #region Verify 1st New Loan charges are updated in FAST
                Reports.TestStep = "Verify 1st New Loan charges are updated in FAST";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickChargesTab();
                VerifyCDNewLoan(request);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify updating 2nd New Loan charges using UpdateNewLoan web service when File is CD")]
        public void Scenario_2_CD_Update_2nd_New_Loan()
        {
            try
            {
                Reports.TestDescription = "Verify updating 2nd New Loan charges using UpdateNewLoan web service when File is CD";

                FAST_Login_IIS();

                FAST_WCF_File_IIS(LenderID: "BOA");

                #region Create a second New Loan
                Reports.TestStep = "Create a second New Loan";
                FastDriver.NewLoan.Open();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FindGABCode("488");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                #endregion

                #region Update 2nd New Loan charges with UpdateNewLoan()
                Reports.TestStep = "Update 2nd New Loan charges with UpdateNewLoan()";
                var request = RequestFactory.GetNewLoanRequest(File.FileID ?? 0, seqNum: 2);
                request.LoanCharges = RequestFactory.GetCD2ndLoanCharge();
                var response = FileService.UpdateNewLoan(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion
                
                #region Verify 2nd New Loan charges are updated in FAST
                Reports.TestStep = "Verify 2nd New Loan charges are updated in FAST";
                FastDriver.NewLoanSummary.Open(2);
                FastDriver.NewLoan.ClickChargesTab();
                VerifyCD2ndNewLoan(request);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify updating 1st New Loan charges using UpdateNewLoan web service when File is HUD")]
        public void Scenario_3_HUD_Update_1st_New_Loan()
        {
            try
            {
                Reports.TestDescription = "Verify updating 1st New Loan charges using UpdateNewLoan web service when File is HUD";

                FAST_Login_IIS();

                FAST_WCF_File_IIS(LenderID: "BOA", formType: FormType.HUD);

                #region Update 1st New Loan charges with UpdateNewLoan()
                Reports.TestStep = "Update 1st New Loan charges with UpdateNewLoan()";
                var request = RequestFactory.GetNewLoanRequest(File.FileID ?? 0, seqNum: 1);
                request.LoanCharges = RequestFactory.GetHUDLoanCharge();
                var response = FileService.UpdateNewLoan(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify 1st New Loan charges are updated in FAST
                Reports.TestStep = "Verify 1st New Loan charges are updated in FAST";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickChargesTab();
                VerifyHUDNewLoan(request);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify updating 2nd New Loan charges using UpdateNewLoan web service when File is HUD")]
        public void Scenario_4_HUD_Update_2nd_New_Loan()
        {
            try
            {
                Reports.TestDescription = "Verify updating 2nd New Loan charges using UpdateNewLoan web service when File is HUD";

                FAST_Login_IIS();

                FAST_WCF_File_IIS(LenderID: "BOA", formType: FormType.HUD);


                #region Create a second New Loan
                Reports.TestStep = "Create a second New Loan";
                FastDriver.NewLoan.Open();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.FindGABCode("488");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoanSummary.WaitForScreenToLoad();
                #endregion

                #region Update 2nd New Loan charges with UpdateNewLoan()
                Reports.TestStep = "Update 2nd New Loan charges with UpdateNewLoan()";
                var request = RequestFactory.GetNewLoanRequest(File.FileID ?? 0, seqNum: 2);
                request.LoanCharges = RequestFactory.GetHUD2ndLoanCharge();
                var response = FileService.UpdateNewLoan(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify 2nd New Loan charges are updated in FAST
                Reports.TestStep = "Verify 2nd New Loan charges are updated in FAST";
                FastDriver.NewLoanSummary.Open(2);
                FastDriver.NewLoan.ClickChargesTab();
                VerifyHUD2ndNewLoan(request);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
