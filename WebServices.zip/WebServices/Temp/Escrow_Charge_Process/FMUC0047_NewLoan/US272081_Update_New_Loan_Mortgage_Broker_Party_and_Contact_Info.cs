﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0047_NewLoan
{
    [CodedUITest]
    public class US272081_Update_MBParty_Contact_Info : SlaveTestClass
    {
        [TestMethod]
        [Description("Verify Update State License ID (2 St.License ID exists) for Mortgage Broker")]
        public void Scenario_1_Update_Contact_NMLS_and_STLicenseID()
        {
            try
            {
                Reports.TestStep = "Verify Update State License ID (2 St.License ID exists) for Mortgage Broker";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = @"Create a basic file with New Loan Lender (415)";
                FAST_WCF_File_IIS(GAB: "415", GABRole: AdditionalRoleType.MortgageBroker, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000, LenderID: "415");
                #endregion

                #region Navigate to New Loan and Verify NMLS ID and ST License ID
                Reports.TestStep = "Navigate to New Loan and Verify NMLS ID and ST License ID";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.MortgageAttention.FASelectItem("automation-user");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                // give some time so FormType can be changed
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                Support.AreEqual("TEST01NMLS", FastDriver.NewLoan.NewLoanMortgage_NMLSID.FAGetValue() ?? "", "NewLoanDetails_NMLSID");
                Support.AreEqual("", FastDriver.NewLoan.NewLoanMortgage_STLICENSEID.FAGetSelectedItem() ?? "", "NewLoanDetails_STLICENSEID");
                Support.AreEqual("TEST01NMLS", FastDriver.NewLoan.NewLoanMortgage_Contact_NMLSID.FAGetValue() ?? "", "NewLoanDetails_Contact_NMLSID");
                Support.AreEqual("CA, TEST02STLENDER", FastDriver.NewLoan.NewLoanMortgage_Contact_STLICENSEID.FAGetSelectedItem() ?? "", "NewLoanDetails_Contact_STLICENSEID");
                #endregion

                #region Update New Loan information for NMLS ID and ST License ID
                Reports.TestStep = "Update New Loan information for NMLS ID and ST License ID";
                var details = FileService.GetNewLoanDetails(File.FileID ?? 0, seqNum: 1);
                var request = RequestFactory.GetNewLoanDefaultRequest(File.FileID.ToString(), seqNum: 1);
                var addressBookEntryId = (int)AdminService.GetGABAddressBookEntryId("415");
                request.MortgageBroker = new MortgageBroker()
                {
                    MorgageBrokerInformation = new FileBusinessParty()
                    {
                        AddrBookEntryID = addressBookEntryId,
                        LicenseInfo = details.MortgageBroker.MorgageBrokerInformation.Licenses[0],
                        BusOrgContact = new BusOrgContact()
                        {
                            ContactID = AdminService.GetGABByAddressBookEntryID(addressBookEntryId).GABContactID,
                            LicenseInfo = (details.MortgageBroker.MorgageBrokerInformation.BusOrgContact != null) ? details.MortgageBroker.MorgageBrokerInformation.BusOrgContact.Licenses[0] : null,
                        },
                    }
                };
                var response = FileService.UpdateNewLoan(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Navigate to New Loan and Verify NMLS ID and ST License ID after UpdateNewLoan request
                Reports.TestStep = "Navigate to New Loan and Verify NMLS ID and ST License ID after UpdateNewLoan request";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                Support.AreEqual("TEST01NMLS", FastDriver.NewLoan.NewLoanMortgage_NMLSID.FAGetValue() ?? "", "NewLoanDetails_NMLSID");
                Support.AreEqual("CA, TEST02STLENDER", FastDriver.NewLoan.NewLoanMortgage_STLICENSEID.Text ?? "", "NewLoanDetails_STLICENSEID");
                Support.AreEqual("TEST01NMLS", FastDriver.NewLoan.NewLoanMortgage_Contact_NMLSID.FAGetValue() ?? "", "NewLoanDetails_Contact_NMLSID");
                Support.AreEqual("CA, TEST02STLENDER", FastDriver.NewLoan.NewLoanMortgage_Contact_STLICENSEID.Text ?? "", "NewLoanDetails_Contact_STLICENSEID");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
