﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0047_NewLoan
{
    [CodedUITest]
    public class US271137_Retrieve_LenderBusParty_and_Contact_Info : SlaveTestClass
    {
        [TestMethod]
        [Description("Verify New Loan-Lender Business information with NMLS & STLicenseID")]
        public void Scenario_1_Get_NMLS_and_STLicenseID()
        {
            try
            {
                Reports.TestDescription = "Verify New Loan-Lender Business information with NMLS & STLicenseID";

                FAST_Init_File();

                #region Navigate to New Loan and Verify NMLS ID and ST License ID
                Reports.TestStep = "Navigate to New Loan and Verify NMLS ID and ST License ID";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.FindGABCode("415");
                FastDriver.NewLoan.LoanDetailsAttention.FASelectItem("automation-user");
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                Support.AreEqual("TEST01NMLS", FastDriver.NewLoan.NewLoanDetails_NMLSID.FAGetValue(), "NewLoanDetails_NMLSID");
                Support.AreEqual("CA, TEST02STLENDER", FastDriver.NewLoan.NewLoanDetails_STLICENSEID.Text, "NewLoanDetails_STLICENSEID");
                Support.AreEqual("TEST01NMLS", FastDriver.NewLoan.NewLoanDetails_Contact_NMLSID.FAGetValue(), "NewLoanDetails_Contact_NMLSID");
                Support.AreEqual("CA, TEST02STLENDER", FastDriver.NewLoan.NewLoanDetails_Contact_STLICENSEID.Text, "NewLoanDetails_Contact_STLICENSEID");
                #endregion

                #region Verify NMLS ID and ST License ID with GetNewLoanDetails web service
                Reports.TestStep = "Verify NMLS ID and ST License ID with GetNewLoanDetails web service";
                var details = FileService.GetNewLoanDetails(File.FileID ?? 0, seqNum: 1);
                Support.AreEqual("TEST01NMLS", details.LoanDetails.LenderInformation.LicenseInfo.NMLSLicenseNo ?? "null", "LicenseInfo.NMLSLicenseNo");
                Support.AreEqual("CA, TEST02STLENDER", details.LoanDetails.LenderInformation.LicenseInfo.StateLicenseNo ?? "null", "LicenseInfo.StateLicenseNo");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
