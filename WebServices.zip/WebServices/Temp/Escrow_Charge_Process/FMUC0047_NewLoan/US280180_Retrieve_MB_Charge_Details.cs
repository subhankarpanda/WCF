﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0047_NewLoan
{
    [CodedUITest]
    public class US280180_Retrieve_MB_Charge_Details : SlaveTestClass
    {
        #region Payment Details
        protected FASTSelenium.DataObjects.IIS.PDD paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
        {
            UseDefaultChecked = true,
            LoanEstimateUnrounded = (double)999999.99,
            LoanEstimateRounded = (double)1000000.00,
            PartOfCheckbox = false,
            BuyerChargePaymentMethod = "RBL",
            BuyerCharge = (double)1000000.00,
            BuyerAtClosing = (double)900000.00,
            BuyerBeforeClosing = (double)99999.99,
            BuyerPaidbyOther = (double)0.01,
            BuyerPaidbyOtherPaymentMethod = "POC",
            BuyerLenderCheckbox = false,
            BuyerDoubleAsteriskChecked = false,
            SellerChargePaymentMethod = "RBL",
            SellerCharge = (double)1000000.00,
            SellerPaidAtClosing = (double)900000.00,
            SellerPaidBeforeClosing = (double)99999.99,
            SellerPaidbyOthers = (double)0.01,
            SellerPaidbyOtherPaymentMthd = "POC",
            SectionBdidnotShopFor = true,
            SectionCDidShopFor = false,
            SectionHOtherCosts = false,
            TotalCharge = (double)2000000.00
        };
        #endregion

        [TestMethod]
        [Description("Verify New Loan - Mortgage Broker information using GetNewLoanDetails web service")]
        public void Scenario_1_Get_MB_Charge_Details()
        {
            try
            {
                Reports.TestDescription = "Verify New Loan - Mortgage Broker information using GetNewLoanDetails web service";

                FAST_Init_File(GABRole:AdditionalRoleType.NewLender);

                #region Navigate to New Loan and create charges for Mortgage Broker
                Reports.TestStep = "Navigate to New Loan and create charges for Mortgage Broker";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.MortgageFindGAB("501");
                FastDriver.NewLoan.MBChargesPaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.BottomFrame.Done();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.FindGABCode("488");
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.MortgageFindGAB("501");
                FastDriver.NewLoan.MBChargesPaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify New Loan - Mortgage Broker charge with GetNewLoanDetails()
                Reports.TestStep = "Verify New Loan - Mortgage Broker charge with GetNewLoanDetails()";
                FastDriver.NewLoanSummary.Open();
                var details = FileService.GetNewLoanDetails(File.FileID, seqNum: 1);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                FAST_WCF_VerifyFilePDD(details.MortgageBroker.CDMortgageBrokerCharges[0], paymentDetails);
                var details2 = FileService.GetNewLoanDetails(File.FileID, seqNum: 2);
                Support.AreEqual("1", details2.Status.ToString(), details2.StatusDescription);
                FAST_WCF_VerifyFilePDD(details2.MortgageBroker.CDMortgageBrokerCharges[0], paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
