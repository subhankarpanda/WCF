﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0049_Prorations
{
    [CodedUITest]
    public class US452226_Get_Prorations_Rent_Tax_Misc : FASTHelpers
    {
        #region Proration Object
        public FASTSelenium.PageObjects.IIS.ProrationData prorationData = new FASTSelenium.PageObjects.IIS.ProrationData()
        {
            Description = "",
            CreditSeller = true,
            DayofClosePaidbySeller = true,
            ProrationAmount = (decimal)50000.00,
            FromDate = DateTime.Today.ToDateString(),
            fromInclusive = true,
            fromProrateDate = false,
            BasedOn = "365",
            Per = "MONTH",
            ToDate = DateTime.Today.AddDays(28).ToDateString(),
            toInclusive = false,
            toProrateDate = false,
            ProrationBuyerCharge = (decimal)5000.00,
            ProrationBuyerCredit = (decimal)10000.00,
            ProrationSellerCharge = (decimal)5000.00,
            ProrationSellerCredit = (decimal)10000.00,
            ProrationUtilityLE = (decimal)9999.99,
            prorationType = "",
        };
        #endregion
        
        protected void FAST_VerifyProrationDetails(dynamic _prorationDetails, FASTSelenium.PageObjects.IIS.ProrationData pData)
        {
            var details = _prorationDetails as ProrationDetailsForCD;

            #region Verify Proration Details
            Support.AreEqual(((Decimal)pData.ProrationAmount).ToString("N2"), ((Decimal)details.Amount).ToString("N2"), "Proration.Amount");
            Support.AreEqual(pData.Per.ToLowerInvariant(), details.AmountPeriod.ToString().ToLowerInvariant(), "Proration.AmountPeriod");
            Support.AreEqual(pData.BasedOn, details.BasedOnDays.ToString(), "Proration.BasedOnDays");
            Support.AreEqual(((Decimal)pData.ProrationBuyerCharge).ToString("C2"), ((Decimal)details.BuyerCharge).ToString("C2"), "Proration.BuyerCharge");
            Support.AreEqual(((Decimal)pData.ProrationBuyerCredit).ToString("C2"), ((Decimal)details.BuyerCredit).ToString("C2"), "Proration.BuyerCredit");
            Support.AreEqual(pData.CreditSeller.ToString(), details.CreditSeller.ToString(), "Proration.CreditSeller");
            Support.AreEqual(pData.DayofClosePaidbySeller.ToString(), details.DayOfClosePaidbySeller.ToString(), "Proration.DayOfClosePaidbySeller");
            Support.AreEqual(pData.Description, details.Description, "Proration.Description");
            Support.AreEqual(pData.FromDate, details.FromDate != null ? ((DateTime)details.FromDate).ToDateString() : "", "Proration.FromDate");
            Support.AreEqual(pData.fromInclusive.ToString(), details.FromDateInclusive.ToString(), "Proration.FromDateInclusive");
            Support.AreEqual(pData.fromProrateDate.ToString(), details.FromDateIsProrateDate.ToString(), "Proration.FromDateIsProrateDate");
            Support.AreEqual(((Decimal)pData.ProrationUtilityLE).ToString("C2"), ((Decimal)details.LEAmount).ToString("C2"), "Proration.LEAmount");
            Support.AreEqual(pData.prorationType.ToLowerInvariant(), details.ProrationType.ToString().ToLowerInvariant(), "Proration.ProrationType");
            Support.AreEqual(((Decimal)pData.ProrationSellerCharge).ToString("C2"), ((Decimal)details.SellerCharge).ToString("C2"), "Proration.SellerCharge");
            Support.AreEqual(((Decimal)pData.ProrationSellerCredit).ToString("C2"), ((Decimal)details.SellerCredit).ToString("C2"), "Proration.SellerCredit");
            Support.AreEqual(pData.ToDate, details.ToDate != null ? ((DateTime)details.ToDate).ToDateString() : "", "Proration.ToDate");
            Support.AreEqual(pData.toInclusive.ToString(), details.ToDateInclusive.ToString(), "Proration.ToDateInclusive");
            Support.AreEqual(pData.toProrateDate.ToString(), details.ToDateIsProrateDate.ToString(), "Proration.ToDateIsProrateDate");
            #endregion
        }

        [TestMethod]
        [Description("Verify retrive of Proration - Rent information using GetProrationDetails web service")]
        public void Scenario_1_Get_Proration_Rent_Details()
        {
            try
            {
                Reports.TestDescription = "Verify retrive of Proration - Rent information using GetProrationDetails web service";

                FAST_Init_File();

                #region Navigate to Proration - Rent and create new
                Reports.TestStep = "Navigate to Proration - Rent and create new";
                FastDriver.ProrationRent.Open();
                FastDriver.ProrationRent.ProrationTaxTable1.Click();
                FastDriver.ProrationRent.WaitCreation(FastDriver.ProrationRent.Edit);
                FastDriver.ProrationRent.Edit.Click();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                FastDriver.ProrationDetail.SetProrarion(prorationData);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Proration - Rent information with GetProrationDetails()
                Reports.TestStep = "Verify Proration - Rent information with GetProrationDetails()";
                var request = EscrowRequestFactory.GetServiceFileRequest(File.FileID);
                var details = EscrowService.GetProrationDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                prorationData.Description = "Rents";
                prorationData.prorationType = "Rent";
                FAST_VerifyProrationDetails(details.RentSummaryForCD[0], prorationData);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify retrive of Proration - Tax information using GetProrationDetails web service")]
        public void Scenario_2_Get_Proration_Tax_Details()
        {
            try
            {
                Reports.TestDescription = "Verify retrive of Proration - Tax information using GetProrationDetails web service";

                FAST_Init_File();

                #region Navigate to Proration - Tax and create new
                Reports.TestStep = "Navigate to Proration - Tax and create new";
                FastDriver.ProrationTax.Open();
                FastDriver.ProrationTax.ProrationTaxTable1.Click();
                FastDriver.ProrationTax.WaitCreation(FastDriver.ProrationTax.Edit);
                FastDriver.ProrationTax.Edit.Click();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                FastDriver.ProrationDetail.SetProrarion(prorationData);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Proration - Tax information with GetProrationDetails()
                Reports.TestStep = "Verify Proration - Tax information with GetProrationDetails()";
                var request = EscrowRequestFactory.GetServiceFileRequest(File.FileID);
                var details = EscrowService.GetProrationDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                prorationData.Description = "City/Town Taxes";
                prorationData.prorationType = "Tax";
                FAST_VerifyProrationDetails(details.TaxSummaryForCD[0], prorationData);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify retrive of Proration - Misc information using GetProrationDetails web service")]
        public void Scenario_3_Get_Proration_Misc_Details()
        {
            try
            {
                Reports.TestDescription = "Verify retrive of Proration - Misc information using GetProrationDetails web service";

                FAST_Init_File();

                #region Navigate to Proration - Misc and create new
                Reports.TestStep = "Navigate to Proration - Misc and create new";
                FastDriver.ProrationMisc.Open();
                FastDriver.ProrationMisc.ProrationTaxTable1.Click();
                FastDriver.ProrationMisc.WaitCreation(FastDriver.ProrationMisc.Edit);
                FastDriver.ProrationMisc.Edit.Click();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                FastDriver.ProrationDetail.SetProrarion(prorationData);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Proration - Misc information with GetProrationDetails()
                Reports.TestStep = "Verify Proration - Misc information with GetProrationDetails()";
                var request = EscrowRequestFactory.GetServiceFileRequest(File.FileID);
                var details = EscrowService.GetProrationDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                prorationData.Description = "Assessments";
                prorationData.prorationType = "Miscellaneous";
                FAST_VerifyProrationDetails(details.MiscellaneousSummaryForCD[0], prorationData);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
