﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0048_PayoffLoan
{
    [CodedUITest]
    public class US282671_Create_Payoff_Loan : FASTHelpers
    {
        [TestMethod]
        [Description("Verify create Payoff Loan information using CreatePayoffLoan web service")]
        public void Scenario_1_Create_Payoff_Loan()
        {
            try 
            {
                Reports.TestDescription = "Verify create Payoff Loan information using CreatePayoffLoan web service";

                FAST_Init_File();

                #region Create PayoffLoan using CreatePayoffLoan web service
                Reports.TestStep = "Create PayoffLoan using CreatePayoffLoan web service";
                var request = RequestFactory.GetPayOffLoanRequest(File.FileID, null);
                var response = FileService.CreatePayoffLoan(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify PayoffLoan details in FAST
                Reports.TestStep = "Verify PayoffLoan details in FAST";
                FastDriver.PayoffLoanDetails.Open();
                //  Summary Info
                Support.AreEqual("$2,000,000.00", FastDriver.PayoffLoanDetails.PrincipalBalanceAmt.Text ?? "", "PayoffLoanDetails.PrincipalBalanceAmt");
                Support.AreEqual("-$1,796,821.92", FastDriver.PayoffLoanDetails.TotalChargeAmt.Text ?? "", "PayoffLoanDetails.TotalChargeAmt");
                Support.AreEqual("$203,178.08", FastDriver.PayoffLoanDetails.Payoffamt.Text ?? "", "PayoffLoanDetails.Payoffamt");
                Support.AreEqual("-$396,821.92", FastDriver.PayoffLoanDetails.CheckAmt.Text ?? "", "PayoffLoanDetails.CheckAmt");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
