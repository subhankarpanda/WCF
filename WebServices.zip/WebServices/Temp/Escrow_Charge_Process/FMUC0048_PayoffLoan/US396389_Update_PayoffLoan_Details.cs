﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0048_PayoffLoan
{
    [CodedUITest]
    public class US396389_Update_PayoffLoan_Details : FASTHelpers
    {
        [TestMethod]
        [Description("Verify update Payoff Loan information using UpdatePayoffLoan web service")]
        public void Scenario_1_Update_PayoffLoan_instance()
        {
            try
            {
                Reports.TestDescription = "Verify update Payoff Loan information using UpdatePayoffLoan web service";

                FAST_Init_File();

                #region Navigate to Payoff Loan and create a new instance
                Reports.TestStep = "Navigate to Payoff Loan and create a new instance";
                FastDriver.PayoffLoanDetails.Open();
                FastDriver.PayoffLoanDetails.FindGABCode("415");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Update PayoffLoan using UpdatePayoffLoan web service
                Reports.TestStep = "Update PayoffLoan using UpdatePayoffLoan web service";
                var request = RequestFactory.GetPayOffLoanRequest(File.FileID, 1);
                request.LenderAttentionContacID = null;
                request.TrusteeAttentionContacID = null;
                var response = FileService.UpdatePayOffLoan(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify PayoffLoan details in FAST
                Reports.TestStep = "Verify PayoffLoan details in FAST";
                FastDriver.PayoffLoanDetails.Open();
                //  Summary Info
                Support.AreEqual("$2,000,000.00", FastDriver.PayoffLoanDetails.PrincipalBalanceAmt.Text ?? "", "PayoffLoanDetails.PrincipalBalanceAmt");
                Support.AreEqual("-$1,796,821.92", FastDriver.PayoffLoanDetails.TotalChargeAmt.Text ?? "", "PayoffLoanDetails.TotalChargeAmt");
                Support.AreEqual("$203,178.08", FastDriver.PayoffLoanDetails.Payoffamt.Text ?? "", "PayoffLoanDetails.Payoffamt");
                Support.AreEqual("-$396,821.92", FastDriver.PayoffLoanDetails.CheckAmt.Text ?? "", "PayoffLoanDetails.CheckAmt");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
