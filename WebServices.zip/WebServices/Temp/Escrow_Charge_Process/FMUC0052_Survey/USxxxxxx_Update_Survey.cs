﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0052_Survey
{
    [CodedUITest]
    public class USxxxxxx_Update_Survey : FASTHelpers
    {
        #region paymentDetails
        protected FASTSelenium.DataObjects.IIS.PDD paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
        {
            AdditionalDescription = "test-description",
            UseDefaultChecked = true,
            BuyerCredit = (double)0.00,
            BuyerCreditPaymentMethod = CreditPaymentMethods.AtClosing.ToString(),
            LoanEstimateUnrounded = (double)999999.99,
            LoanEstimateRounded = (double)1000000,
            BuyerCharge = (double)1000000,
            BuyerAtClosing = (double)900000.00,
            BuyerChargePaymentMethod = AtClosingPaymentMethods.CHK.ToString(),
            BuyerBeforeClosing = (double)99999.99,
            BuyerPaidbyOther = (double)0.01,
            BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
            BuyerLenderCheckbox = false,
            SellerCharge = (double)1000000,
            SellerCredit = (double)0.00,
            SellerCreditPaymentMethod = CreditPaymentMethods.AtClosing.ToString(),
            SellerPaidAtClosing = (double)900000.00,
            SellerChargePaymentMethod = AtClosingPaymentMethods.CHK.ToString(),
            SellerPaidBeforeClosing = (double)99999.99,
            SellerPaidbyOthers = (double)0.01,
            SellerPaidbyOtherPaymentMthd = OtherPaymentMethods.POC.ToString(),
            SellerLenderCheckbox = false,
            PartOfCheckbox = false,
            SectionHOtherCosts = true,
            TotalCharge = (double)2000000,
        };
        #endregion

        [TestMethod]
        [Description("Verify update Survey instance using UpdateSurvey web service")]
        public void Scenario_1_Update_Survey()
        {
            try
            {
                Reports.TestDescription = "Verify update Survey instance using UpdateSurvey web service";

                FAST_Init_File();

                #region Navigate to Survey and create a new instance
                Reports.TestStep = "Navigate to Survey and create a new instance";
                FastDriver.SurveyDetail.Open();
                FastDriver.SurveyDetail.FindGABCode("488");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Update Survey instance with UpdateSurvey()
                Reports.TestStep = "Update Survey instance with UpdateSurvey()";
                var request = EscrowRequestFactory.GetSurveyRequest(File.FileID, seqNum: 1);
                request.oSurvey.SurveyFileBusinessParty = EscrowRequestFactory.GetFileBusinessParty("415");
                var response = EscrowService.UpdateSurvey(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Survey instance is updated in FAST
                Reports.TestStep = "Verify Survey instance is updated in FAST";
                FastDriver.SurveyDetail.Open();
                Support.AreEqual("415", FastDriver.SurveyDetail.IDcodeLabel.FAGetText(), "IDcodeLabel");
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify update Survey charge PDD using UpdateSurvey web service")]
        public void Scenario_2_Update_Survey_with_Charge_PDD()
        {
            try
            {
                Reports.TestDescription = "Verify update Survey charge PDD using UpdateSurvey web service";

                FAST_Init_File();

                #region Navigate to Survey and create a new instance
                Reports.TestStep = "Navigate to Survey and create a new instance";
                FastDriver.SurveyDetail.Open();
                FastDriver.SurveyDetail.FindGABCode("415");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Update Survey charge PDD with UpdateSurvey()
                Reports.TestStep = "Update Survey charge PDD with UpdateSurvey()";
                FastDriver.SurveyDetail.Open();
                var request = EscrowRequestFactory.GetSurveyRequest(File.FileID, seqNum: 1);
                request.oSurvey.SurveyFileBusinessParty = EscrowRequestFactory.GetFileBusinessParty("415");
                request.oSurvey.BorrowerSelectedServicesForCDFile = new FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails[]
                {
                    EscrowRequestFactory.GetCDChargePaymentDetails(),
                };
                var response = EscrowService.UpdateSurvey(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Survey instance is updated in FAST
                Reports.TestStep = "Verify Survey instance is updated in FAST";
                FastDriver.SurveyDetail.Open();
                FastDriver.SurveyDetail.BorrowerSelectedServicesPaymentDetails.FAClick();
                FAST_VerifyPDD(paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
