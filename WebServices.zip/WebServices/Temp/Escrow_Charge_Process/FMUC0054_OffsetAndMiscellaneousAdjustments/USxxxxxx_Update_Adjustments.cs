﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0054_OffsetAndMiscellaneousAdjustments
{
    [CodedUITest]
    public class USxxxxxx_Update_Adjustments : FASTHelpers
    {
        [TestMethod]
        [Description("Verify update Off-Set Adjustments information using UpdateAdjustments web service")]
        public void Scenario_1_Update_OffSet_Adjustments()
        {
            try
            {
                Reports.TestDescription = "Verify update Off-Set Adjustments information using UpdateAdjustments web service";

                FAST_Init_File();

                #region Create Off-Set Adjustments with UpdateAdjustments()
                Reports.TestStep = "Create Off-Set Adjustments with UpdateAdjustments()";
                var request = EscrowRequestFactory.GetAdjustmentRequest(File.FileID, FASTWCFHelpers.FastEscrowService.AdjustmentType.Offset);
                request.ChargeList = new FASTWCFHelpers.FastEscrowService.ChargeSet[]
                {
                    EscrowRequestFactory.GetChargeSet(10, bCharge:(decimal)15000, sCredit:(decimal)15000),
                    EscrowRequestFactory.GetChargeSet(20, bCharge:(decimal)15000, bCredit:(decimal)15000, sCharge:(decimal)15000, sCredit:(decimal)15000),
                    EscrowRequestFactory.GetChargeSet(30, bCharge:(decimal)15000, bCredit:(decimal)15000, sCharge:(decimal)15000, sCredit:(decimal)15000),
                    EscrowRequestFactory.GetChargeSet(40, bCredit:(decimal)15000, sCharge:(decimal)15000),
                    EscrowRequestFactory.GetChargeSet(50, adhocFlag:1, bCharge:(decimal)15000, bCredit:(decimal)15000, sCharge:(decimal)15000, sCredit:(decimal)15000, desc:"test-adhoc-charge"),
                };
                var response = EscrowService.UpdateAdjustments(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Off-Set Adjustments are updated in FAST
                Reports.TestStep = "Verify Off-Set Adjustments are updated in FAST";
                FastDriver.AdjustmentOffset.Open();
                //  Sale Price of Any Personal Property Included in Sale
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message, "[1]BuyerCharge");
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(2, 6, TableAction.GetInputValue).Message, "[1]SellerCredit");
                //  Assign Tenant Lease/Rent
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(3, 3, TableAction.GetInputValue).Message, "[2]BuyerCharge");
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(3, 4, TableAction.GetInputValue).Message, "[2]BuyerCredit");
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(3, 5, TableAction.GetInputValue).Message, "[2]SellerCharge");
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(3, 6, TableAction.GetInputValue).Message, "[2]SellerCredit");
                //  Assign Tenant Security Deposit
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(4, 3, TableAction.GetInputValue).Message, "[3]BuyerCharge");
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(4, 4, TableAction.GetInputValue).Message, "[3]BuyerCredit");
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(4, 5, TableAction.GetInputValue).Message, "[3]SellerCharge");
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(4, 6, TableAction.GetInputValue).Message, "[3]SellerCredit");
                //  Seller Credit
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(5, 4, TableAction.GetInputValue).Message, "[4]BuyerCredit");
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(5, 5, TableAction.GetInputValue).Message, "[4]SellerCharge");
                //  AdHoc
                Support.AreEqual("test-adhoc-charge", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(6, 1, TableAction.GetInputValue).Message, "[5]Description");
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(6, 3, TableAction.GetInputValue).Message, "[5]BuyerCharge");
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(6, 4, TableAction.GetInputValue).Message, "[5]BuyerCredit");
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(6, 5, TableAction.GetInputValue).Message, "[5]SellerCharge");
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(6, 6, TableAction.GetInputValue).Message, "[5]SellerCredit");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify update Miscellaneous Adjustments information using UpdateAdjustments web service")]
        public void Scenario_2_Update_Misc_Adjustments()
        {
            try
            {
                Reports.TestDescription = "Verify update Miscellaneous Adjustments information using UpdateAdjustments web service";

                FAST_Init_File();

                #region Create Miscellaneous Adjustments with UpdateAdjustments()
                Reports.TestStep = "Create Miscellaneous Adjustments with UpdateAdjustments()";
                var request = EscrowRequestFactory.GetAdjustmentRequest(File.FileID, FASTWCFHelpers.FastEscrowService.AdjustmentType.Miscellaneous);
                request.ChargeList = new FASTWCFHelpers.FastEscrowService.ChargeSet[]
                {
                    EscrowRequestFactory.GetChargeSet(70, bCredit:(decimal)15000, sCharge:(decimal)15000),
                    EscrowRequestFactory.GetChargeSet(80, bCredit:(decimal)15000, sCredit:(decimal)15000),
                    EscrowRequestFactory.GetChargeSet(90, adhocFlag:1, bCharge:(decimal)15000, bCredit:(decimal)15000, sCharge:(decimal)15000, sCredit:(decimal)15000, desc:"test-adhoc-charge"),
                };
                var response = EscrowService.UpdateAdjustments(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Miscellaneous Adjustments are updated in FAST
                Reports.TestStep = "Verify Miscellaneous Adjustments are updated in FAST";
                FastDriver.AdjustmentMisc.Open();
                //  Buyer Deposit Directly to Seller
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message, "[1]BuyerCredit");
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message, "[1]SellerCharge");
                //  IBA Interest Paid
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(3, 4, TableAction.GetInputValue).Message, "[2]BuyerCredit");
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(3, 6, TableAction.GetInputValue).Message, "[2]SellerCredit");
                //  AdHoc
                Support.AreEqual("test-adhoc-charge", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(4, 1, TableAction.GetInputValue).Message, "[3]Description");
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(4, 3, TableAction.GetInputValue).Message, "[3]BuyerCharge");
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(4, 4, TableAction.GetInputValue).Message, "[3]BuyerCredit");
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(4, 5, TableAction.GetInputValue).Message, "[3]SellerCharge");
                Support.AreEqual("15,000.00", FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(4, 6, TableAction.GetInputValue).Message, "[3]SellerCredit");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
