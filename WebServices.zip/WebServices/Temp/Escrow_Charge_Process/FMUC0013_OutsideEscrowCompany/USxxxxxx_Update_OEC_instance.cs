﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0013_OutsideEscrowCompany
{
    [CodedUITest]
    public class USxxxxxx_Update_OEC_instance : FASTHelpers
    {
        #region paymentDetails
        protected FASTSelenium.DataObjects.IIS.PDD paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
        {
            AdditionalDescription = "test-description",
            UseDefaultChecked = true,
            BuyerCredit = (double)0.00,
            BuyerCreditPaymentMethod = CreditPaymentMethods.AtClosing.ToString(),
            LoanEstimateUnrounded = (double)999999.99,
            BuyerAtClosing = (double)900000.00,
            BuyerBeforeClosing = (double)99999.99,
            BuyerPaidbyOther = (double)0.01,
            BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
            SellerCredit = (double)0.00,
            SellerCreditPaymentMethod = CreditPaymentMethods.AtClosing.ToString(),
            SellerPaidAtClosing = (double)900000.00,
            SellerPaidBeforeClosing = (double)99999.99,
            SellerPaidbyOthers = (double)0.01,
            SellerPaidbyOtherPaymentMthd = OtherPaymentMethods.POC.ToString(),
            PartOfCheckbox = false,
            //SectionsShoppedFor.None,
        };
        #endregion

        [TestMethod]
        [Description("Verify update instance of Outside Escrow Company using UpdateOutsideEscrowCompany web service")]
        public void Scenario_1_Update_OEC_instance()
        {
            try
            {
                Reports.TestDescription = "Verify update instance of Outside Escrow Company using UpdateOutsideEscrowCompany web service";

                FAST_Init_File();

                #region Navigate to OEC screen and add business party
                Reports.TestStep = "Navigate to OEC screen and add business party";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("488");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Update OEC business party with UpdateOutsideEscrowCompany()
                Reports.TestStep = "Update OEC business party with UpdateOutsideEscrowCompany()";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                var request = EscrowRequestFactory.GetOECRequest(File.FileID, 1);
                request.OECInformation.OECFileBusinessParty = new FASTWCFHelpers.FastEscrowService.FileBusinessParty() { AddrBookEntryID = (int)AdminService.GetGABAddressBookEntryId("415") };
                var response = EscrowService.UpdateOutsideEscrowCompany(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify OEC business party is updated in FAST
                Reports.TestStep = "Verify OEC business party is updated in FAST";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                Support.AreEqual("415", FastDriver.OutsideEscrowCompanyDetail.GABcodeLabel.FAGetText(), "GABcodeLabel");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify update charge PPD for Outside Escrow Company using UpdateOutsideEscrowCompany web service")]
        public void Scenario_2_Update_OEC_with_Charge_PDD()
        {
            try
            {
                Reports.TestDescription = "Verify update charge PPD for Outside Escrow Company using UpdateOutsideEscrowCompany web service";

                FAST_Init_File();

                #region Navigate to OEC screen and add business party
                Reports.TestStep = "Navigate to OEC screen and add business party";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("415");
                FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.Clear();
                FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FASetText("test-charge-description");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Update OEC charge PDD with UpdateOutsideEscrowCompany()
                Reports.TestStep = "Update OEC charge PDD with UpdateOutsideEscrowCompany()";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                var request = EscrowRequestFactory.GetOECRequest(File.FileID, 1);
                request.OECInformation.OECCharges = new FASTWCFHelpers.FastEscrowService.OECCharge()
                {
                    CDPaymentDetails = new FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails[] { 
                        EscrowRequestFactory.GetCDChargePaymentDetails(),
                    }
                };
                var response = EscrowService.UpdateOutsideEscrowCompany(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify OEC charge PDD is updated in FAST
                Reports.TestStep = "Verify OEC charge PDD is updated in FAST";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                FAST_VerifyPDD(paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
