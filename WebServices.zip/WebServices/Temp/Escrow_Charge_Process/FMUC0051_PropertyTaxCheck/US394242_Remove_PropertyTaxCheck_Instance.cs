﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0051_PropertyTaxCheck
{
    [CodedUITest]
    public class US394242_Remove_PropertyTaxCheck_Instance : FASTHelpers
    {
        [TestMethod]
        [Description("Verify Property Tax Check instance is removed using RemovePropertyTaxCheck web service")]
        public void Scenario_1_Remove_PropertyTaxCheck_Instance()
        {
            try 
            {
                Reports.TestDescription = "Verify Property Tax Check instance is removed using RemovePropertyTaxCheck web service";

                FAST_Init_File();

                #region Navigate to Property Tax Check create a new instance
                Reports.TestStep = "Navigate to Property Tax Check create a new instance";
                FastDriver.PropertyTaxCheck.Open();
                FastDriver.PropertyTaxCheck.FindGABCode("415");
                FastDriver.PropertyTaxCheck.AdditionalChargesbuyerCharge.FASetText("1.00");
                FastDriver.PropertyTaxCheck.AdditionalChargesSellerCharge.FASetText("2.00");
                FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("1.00");
                FastDriver.PropertyTaxCheck.PropertyTaxesSellerCharge_1.FASetText("2.00");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Remove Property Tax Check instance with RemovePropertyTaxCheck()
                Reports.TestStep = "Remove Property Tax Check instance with RemovePropertyTaxCheck()";
                var request = EscrowRequestFactory.GetPropertyTaxCheckRequest(File.FileID, seqNum: 1);
                var response = EscrowService.RemovePropertyTaxCheck(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Property Tax Check instance is removed in FAST
                Reports.TestStep = "Verify Property Tax Check instance is removed in FAST";
                FastDriver.PropertyTaxCheck.Open();
                Support.AreEqual("", FastDriver.PropertyTaxCheck.GABcodeLabel.FAGetText(), "GABcodeLabel");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
