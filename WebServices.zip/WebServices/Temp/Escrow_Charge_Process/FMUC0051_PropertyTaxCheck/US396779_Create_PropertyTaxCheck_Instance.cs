﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0051_PropertyTaxCheck
{
    [CodedUITest]
    public class US396779_Create_PropertyTaxCheck_Instance : FASTHelpers
    {
        #region payment details
        protected PDD paymentDetails = new PDD()
        {
            AdditionalDescription = "test-charge",
            UseDefaultChecked = false,
            PayeeName = "test-payee-name",
            LoanEstimateUnrounded = (double)15099.99,
            LoanEstimateRounded = (double)15100.00,
            PartOfCheckbox = true,
            BuyerCharge = (double)30000,
            BuyerAtClosing = (double)15000,
            BuyerChargePaymentMethod = "Check",
            BuyerBeforeClosing = (double)5000,
            BuyerPaidbyOther = (double)10000,
            BuyerPaidbyOtherPaymentMethod = "POC",
            BuyerDoubleAsteriskChecked = false,
            SellerCharge = (double)24000,
            SellerPaidAtClosing = (double)12000,
            SellerChargePaymentMethod = "Check",
            SellerPaidBeforeClosing = (double)6000,
            SellerPaidbyOthers = (double)6000,
            SellerPaidbyOtherPaymentMthd = "POC",
            TotalCharge = (double)54000.00
        };
        #endregion

        #region CDChargePaymentDetails
        protected FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails CdChargePaymentDetails = new FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails()
        {
            AdditionalDescription = "test-charge",
            UseDefault = false,
            PayeeNameOnCDOrSettlementStmt = "test-payee-name",
            LEAmount = (decimal)15099.99,
            PartOf = true,
            NoOfMonthsPrepaid = 5,
            Months = 3195,
            AtClosingBuyerPaymentMethodTypeID = FASTWCFHelpers.FastEscrowService.AtClosingPaymentMethods.CHK,
            PBBuyerAtClosing = (decimal)15000,
            PBBuyerBeforeClosing = (decimal)5000,
            PBOthersForBuyer = (decimal)10000,
            PBOthersForBuyerPMTypeCdID = FASTWCFHelpers.FastEscrowService.OtherPaymentMethods.POC,
            DoubleAsteriskIndicator = false,
            AtClosingSellerPaymentMethodTypeID = FASTWCFHelpers.FastEscrowService.AtClosingPaymentMethods.CHK,
            PBSellerAtClosing = (decimal)12000,
            PBSellerBeforeClosing = (decimal)6000,
            PBOthersForSeller = (decimal)6000,
            PBOthersForSellerPMTypeCdID = FASTWCFHelpers.FastEscrowService.OtherPaymentMethods.POC,
            SeqNum = 1,
        };
        #endregion

        [TestMethod]
        [Description("Verify create new Property Tax Check instance using CreatePropertyTaxCheck web service")]
        public void Scenario_1_Create_PropertyTaxCheck_Instance()
        {
            try
            {
                Reports.TestDescription = "Verify create new Property Tax Check instance using CreatePropertyTaxCheck web service";

                FAST_Init_File(GABRole: FASTWCFHelpers.FastFileService.AdditionalRoleType.NewLender);

                #region Create new Property Tax Check instance with CreatePropertyTaxCheck()
                Reports.TestStep = "Create new Property Tax Check instance with CreatePropertyTaxCheck()";
                var request = EscrowRequestFactory.GetPropertyTaxCheckRequest(File.FileID, seqNum: 1);
                request.oPropertyTaxCheckDetails.FileBusinessParty = new FASTWCFHelpers.FastEscrowService.FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"),
                };
                request.oPropertyTaxCheckDetails.AdditionalChargesListForCD = new FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails[]{
                    CdChargePaymentDetails,
                };
                request.oPropertyTaxCheckDetails.PropertyTaxesListForCD = new FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails[]{
                    CdChargePaymentDetails,
                };
                var response = EscrowService.CreatePropertyTaxCheck(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Property Tax Check instance is created in FAST
                Reports.TestStep = "Verify Property Tax Check instance is created in FAST";
                FastDriver.PropertyTaxCheck.Open();
                Support.AreEqual("415", FastDriver.PropertyTaxCheck.GABcodeLabel.FAGetText().Trim(), "GABcodeLabel");
                FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.Click();
                FAST_VerifyPDD(paymentDetails);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.Click();
                paymentDetails.NoMonthsPrepaid = "5";
                //paymentDetails.MonthPrepaidSelect = "Mos";
                FAST_VerifyPDD(paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
