﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0051_PropertyTaxCheck
{
    [CodedUITest]
    public class US393562_Retrieve_PropertyTaxCheck_Details : FASTHelpers
    {

        #region payment details
        protected PDD paymentDetails = new PDD()
        {
            UseDefaultChecked = false,
            LoanEstimateUnrounded = (double)15099.99,
            LoanEstimateRounded = (double)15100.00,
            PartOfCheckbox = true,
            BuyerCharge = (double)30000,
            BuyerAtClosing = (double)15000,
            BuyerChargePaymentMethod = "Check",
            BuyerBeforeClosing = (double)5000,
            BuyerPaidbyOther = (double)10000,
            BuyerPaidbyOtherPaymentMethod = "POC",
            BuyerDoubleAsteriskChecked = false,
            SellerCharge = (double)24000,
            SellerPaidAtClosing = (double)12000,
            SellerChargePaymentMethod = "Check",
            SellerPaidBeforeClosing = (double)6000,
            SellerPaidbyOthers = (double)6000,
            SellerPaidbyOtherPaymentMthd = "POC",
            TotalCharge = (double)54000.00
        };

        protected PDD paymentDetails2 = new PDD()
        {
            UseDefaultChecked = false,
            LoanEstimateUnrounded = (double)15099.99,
            LoanEstimateRounded = (double)15100.00,
            PartOfCheckbox = true,
            BuyerCharge = (double)30000,
            BuyerAtClosing = (double)15000,
            BuyerChargePaymentMethod = "CHK",
            BuyerBeforeClosing = (double)5000,
            BuyerPaidbyOther = (double)10000,
            BuyerPaidbyOtherPaymentMethod = "POC",
            BuyerCredit = 0,
            BuyerCreditPaymentMethod = "AtClosing",
            BuyerDoubleAsteriskChecked = false,
            SellerCharge = (double)24000,
            SellerPaidAtClosing = (double)12000,
            SellerChargePaymentMethod = "CHK",
            SellerPaidBeforeClosing = (double)6000,
            SellerPaidbyOthers = (double)6000,
            SellerPaidbyOtherPaymentMthd = "POC",
            SellerCredit = 0,
            SellerCreditPaymentMethod = "AtClosing",
            TotalCharge = (double)54000.00,
            NoMonthsPrepaid = "0",
        };
        #endregion

        protected void FAST_VerifyCDChargePaymentDetails(dynamic _pdd, PDD paymentDetails)
        {
            #region Verify Fee Payment Details
            var pdd = _pdd as FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails;

            //  BuyerCredit
            Support.AreEqual(paymentDetails.BuyerCredit != null ? ((Decimal)paymentDetails.BuyerCredit).ToString("C2"):"null", pdd.BuyerCredit != null ? ((Decimal)pdd.BuyerCredit).ToString("C2") : "null", "BuyerCredit");
            Support.AreEqual(paymentDetails.BuyerCreditPaymentMethod.ToString().ToLowerInvariant(), pdd.BuyerCreditPaymentMethodTypeCdID.ToString().ToLowerInvariant(), "BuyerCreditPaymentMethodTypeCdID");
            //  BuyerDetails
            Support.AreEqual(((Decimal)paymentDetails.BuyerCharge).ToString("C2"), ((Decimal)pdd.BuyerCharge).ToString("C2"), "BuyerCharge");
            Support.AreEqual(paymentDetails.BuyerLenderCheckbox.ToString().ToLowerInvariant(), pdd.DisplayLBuyer.ToString().ToLowerInvariant(), "DisplayLBuyer");
            Support.AreEqual(((Decimal)paymentDetails.BuyerAtClosing).ToString("C2"), ((Decimal)pdd.PBBuyerAtClosing).ToString("C2"), "PBBuyerAtClosing");
            Support.AreEqual(((Decimal)paymentDetails.BuyerBeforeClosing).ToString("C2"), ((Decimal)pdd.PBBuyerBeforeClosing).ToString("C2"), "PBBuyerBeforeClosing");
            Support.AreEqual(((Decimal)paymentDetails.BuyerPaidbyOther).ToString("C2"), ((Decimal)pdd.PBOthersForBuyer).ToString("C2"), "PBOthersForBuyer");
            Support.AreEqual(paymentDetails.BuyerPaidbyOtherPaymentMethod.ToLowerInvariant(), pdd.PBOthersForBuyerPMTypeCdID.ToString().ToLowerInvariant(), "PBOthersForBuyerPMTypeCdID");
            Support.AreEqual(paymentDetails.BuyerChargePaymentMethod.ToLowerInvariant(), pdd.AtClosingBuyerPaymentMethodTypeID.ToString().ToLowerInvariant(), "AtClosingBuyerPaymentMethodTypeID");
            //
            Support.AreEqual(paymentDetails.ChargeDescription, pdd.Description, "Description");
            Support.AreEqual("False", pdd.DisplayBrokenLinkFlag.ToString(), "DisplayBrokenLinkFlag");
            Support.AreEqual(paymentDetails.BuyerDoubleAsteriskChecked.ToString().ToLowerInvariant(), pdd.DoubleAsteriskIndicator.ToString().ToLowerInvariant(), "DoubleAsteriskIndicator");
            //
            Support.AreEqual("0", pdd.IsDisbursed.ToString(), "IsDisbursed");
            //  Loan Estimate
            Support.AreEqual(((Decimal)paymentDetails.LoanEstimateUnrounded).ToString("N2"), ((Decimal)pdd.LEAmount).ToString("N2"), "LEAmount");
            Support.AreEqual(((Decimal)paymentDetails.LoanEstimateRounded).ToString("N2"), ((Decimal)pdd.RoundedLEAmount).ToString("N2"), "RoundedLEAmount");
            //
            Support.AreEqual(paymentDetails.NoMonthsPrepaid ?? "0", pdd.NoOfMonthsPrepaid.ToString(), "NoMonthsPrepaid");
            // 
            Support.AreEqual(paymentDetails.PartOfCheckbox.ToString().ToLowerInvariant(), pdd.PartOf.ToString().ToLowerInvariant(), "PartOf");
            Support.IsTrue(!string.IsNullOrEmpty(pdd.PayTo), "PayTo= " + pdd.PayTo);
            Support.IsTrue(!string.IsNullOrEmpty(pdd.PayeeNameOnCDOrSettlementStmt), "PayeeNameOnCDOrSettlementStmt= " + pdd.PayeeNameOnCDOrSettlementStmt);
            //  SectionShopDetails
            if (pdd.eSectionShop == FASTWCFHelpers.FastEscrowService.SectionsShoppedFor.SectionBdidNotShopFor)
                Support.IsTrue(paymentDetails.SectionBdidnotShopFor, "SectionBdidnotShopFor");
            else if (pdd.eSectionShop == FASTWCFHelpers.FastEscrowService.SectionsShoppedFor.SectionCdidShopFor)
                Support.IsTrue(paymentDetails.SectionCDidShopFor, "SectionCDidShopFor");
            else if (pdd.eSectionShop == FASTWCFHelpers.FastEscrowService.SectionsShoppedFor.SectionHotherCosts)
                Support.IsTrue(paymentDetails.SectionHOtherCosts, "SectionHOtherCosts");
            //  SellerCredit
            Support.AreEqual(paymentDetails.SellerCreditPaymentMethod.ToString().ToLowerInvariant(), pdd.SellerCreditPaymentMethodTypeCdID.ToString().ToLowerInvariant(), "SellerCreditPaymentMethodTypeCdID");
            //  SellerDetails
            Support.AreEqual(((Decimal)paymentDetails.SellerCharge).ToString("C2"), ((Decimal)pdd.SellerCharge).ToString("C2"), "SellerCharge");
            Support.AreEqual(paymentDetails.SellerLenderCheckbox.ToString().ToLowerInvariant(), pdd.DisplayLSeller.ToString().ToLowerInvariant(), "DisplayLSeller");
            Support.AreEqual(((Decimal)paymentDetails.SellerPaidAtClosing).ToString("C2"), ((Decimal)pdd.PBSellerAtClosing).ToString("C2"), "PBSellerAtClosing");
            Support.AreEqual(((Decimal)paymentDetails.SellerPaidBeforeClosing).ToString("C2"), ((Decimal)pdd.PBSellerBeforeClosing).ToString("C2"), "PBSellerBeforeClosing");
            Support.AreEqual(((Decimal)paymentDetails.SellerPaidbyOthers).ToString("C2"), ((Decimal)pdd.PBOthersForSeller).ToString("C2"), "PBOthersForSeller");
            Support.AreEqual(paymentDetails.SellerPaidbyOtherPaymentMthd.ToLowerInvariant(), pdd.PBOthersForSellerPMTypeCdID.ToString().ToLowerInvariant(), "PBOthersForSellerPMTypeCdID");
            Support.AreEqual(paymentDetails.SellerChargePaymentMethod.ToLowerInvariant(), pdd.AtClosingSellerPaymentMethodTypeID.ToString().ToLowerInvariant(), "AtClosingSellerPaymentMethodTypeID");
            //
            Support.AreEqual(((Decimal)paymentDetails.TotalCharge).ToString("C2"), ((Decimal)pdd.TotalCharge).ToString("C2"), "TotalCharge");
            #endregion
        }

        [TestMethod]
        [Description("Verify retrieve Property Tax Check information using GetPropertyTaxDetails web service")]
        public void Scenario_1_Retrieve_PropertyTaxCheck_with_charge_PDD()
        {
            try
            {
                Reports.TestDescription = "Verify retrieve Property Tax Check information using GetPropertyTaxDetails web service";

                FAST_Init_File(GABRole: FASTWCFHelpers.FastFileService.AdditionalRoleType.NewLender);

                #region Navigate to Property Tax Check and create a new instance with charge PDD
                Reports.TestStep = "Navigate to Property Tax Check and create a new instance with charge PDD";
                FastDriver.PropertyTaxCheck.Open();
                FastDriver.PropertyTaxCheck.FindGABCode("415");
                //  Additional Charge
                var additionalChargeDescription = FastDriver.PropertyTaxCheck.AdditionalChargesDescription.FAGetValue();
                FastDriver.PropertyTaxCheck.AdditionalChargesPaymentDetails.Click();
                var pddUpdate = paymentDetails;
                FAST_UpdatePDD(pddUpdate);
                FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                //  Property Taxes
                var propertyChargeDescription = FastDriver.PropertyTaxCheck.PropertyTaxesDesc_1.FAGetValue();
                FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.Click();
                pddUpdate.NoMonthsPrepaid = "5";
                //pddUpdate.MonthPrepaidSelect = "Mos";
                FAST_UpdatePDD(pddUpdate);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Property Tax Check information with GetPropertyTaxDetails()
                Reports.TestStep = "Verify Property Tax Check information with GetPropertyTaxDetails()";
                var details = EscrowService.GetPropertyTaxCheckDetails(File.FileID);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                //  Additional Charge
                Reports.TestStep = "Verify PDD for Additional Charge";
                var pddCheck = paymentDetails2;
                pddCheck.ChargeDescription = additionalChargeDescription;
                FAST_VerifyCDChargePaymentDetails(details.PropTaxCheckSummary[0].AdditionalChargesListForCD[0], pddCheck);
                //  Property Taxes
                Reports.TestStep = "Verify PDD for Property Taxes Charge";
                pddCheck.NoMonthsPrepaid = "5";
                pddCheck.ChargeDescription = propertyChargeDescription;
                FAST_VerifyCDChargePaymentDetails(details.PropTaxCheckSummary[0].PropertyTaxesListForCD[0], pddCheck);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
