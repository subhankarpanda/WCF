﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Linq;


namespace Web_Services_Regression.File_Management.FMUC0111_ServiceFees
{
    [CodedUITest]
    public class US282674_Get_Calculation_Fees : FASTHelpers
    {
        private FACCSummary[] faccSummary = null;
        private FACCRecordingFee faccRecordingFee = null;
        private TransactionInformation transactionInfo = null;
        private string faccUnderwriter = null;

        private FASTWCFHelpers.FastFileService.Product[] GetProducts()
        {
            return new FASTWCFHelpers.FastFileService.Product[] {
                new FASTWCFHelpers.FastFileService.Product() {
                    ObjectCD = "ALTAEXLN06",
                    ProductID = 1317,
                },
                new FASTWCFHelpers.FastFileService.Product() {
                    ObjectCD = "ALTAEXOW06",
                    ProductID = 1318,
                },
                new FASTWCFHelpers.FastFileService.Product() {
                    ObjectCD = "ALTASTLN06",
                    ProductID = 1320,
                },
                new FASTWCFHelpers.FastFileService.Product() {
                    ObjectCD = "ALTASTOW06",
                    ProductID = 1321,
                },
            };
        }

        private void TestGetCalculationFees(FASTWCFHelpers.FastFileService.FormType formType, bool titleOffice, bool escrowOffice, string transactionObjectCD = "SALE")
        {
            FAST_Login_IIS();

            FAST_WCF_File_IIS(formType: formType, isTO: titleOffice, isEO: escrowOffice, TTOCD: transactionObjectCD, LenderID: "BOA", loanAmt: (decimal)1500000, SPAmt: (decimal)2000000, products: GetProducts());

            FAST_AddCalculatedFees(faccSummary, faccUnderwriter);

            FAST_WCF_VerifyCalculatedFees(faccSummary, faccRecordingFee, transactionInfo, faccUnderwriter);
        }

        [TestMethod]
        [Description("Verify File Fees using GetCalculationFees web service when File as CD + Title")]
        public void Scenario_1_CD_TO_GetCalculationFees()
        {
            try
            {
                Reports.TestDescription = "Verify File Fees using GetCalculationFees web service when File as CD + Title";

                #region Test Data
                faccSummary = new FACCSummary[]
                {
                    new FACCSummary() { BuyerCharge = (decimal)50000, CalculatedRate = 2475, ChargeTo = "BUYER", ChargeToCdID = 54, FACCFeeDescription = "ALTA Loan Policy - Extended", FASTFeeDescription = "1064_Title_Lender_Policy", FASTProductCategory = 408, FeeCalcTypeCdID = 1594, FeeTypeCdID = 834, IsFACCCalculated = true, OverrideAmount = (decimal)50000, OverrideID = 2434, OverrideReason = "Centralized Loan Rate", TotalCharge = (decimal)50000 },
                    new FACCSummary() { BuyerCharge = (decimal)50000, CalculatedRate = 0, ChargeTo = "BUYER", ChargeToCdID = 54, FACCFeeDescription = "[ALTA 1-06] Street Assessments", FASTFeeDescription = "Endorsement L", FASTProductCategory = 408, FeeCalcTypeCdID = 1595, FeeTypeCdID = 1796, IsFACCCalculated = true, OverrideAmount = (decimal)50000, OverrideID = 1802, OverrideReason = "Permitted Rate Surcharge", TotalCharge = (decimal)50000 },
                    new FACCSummary() { BuyerCharge = (decimal)50000, CalculatedRate = 9, ChargeTo = "BUYER", ChargeToCdID = 54, FACCFeeDescription = "MORTGAGE - Recording Fee", FASTFeeDescription = "FACC E Recording Fee - Release", FASTProductCategory = null, FeeCalcTypeCdID = 1596, FeeTypeCdID = 71, IsFACCCalculated = true, OverrideAmount = (decimal)50000, OverrideID = 1802, OverrideReason = "Permitted Rate Surcharge", TotalCharge = (decimal)50000 }
                };
                faccRecordingFee = new FACCRecordingFee() { ConsiderationAmnt = (decimal)1500000, IsFACCCalculated = true, Pages = 1, RecordDocumentFACCDescr = "MORTGAGE - Recording Fee", RecordDocumentName = "Mortgage", RecordDocumentObjectCD = "MORTGAGE - Recording Fee", RecordDocumentTypeID = 1605 };
                transactionInfo = new TransactionInformation() { City = "Santa Ana", County = "Orange", FirstNewLoanLiabilityAmnt = (decimal)1500000, FirstOwnerPolicyLiabilityAmnt = (decimal)2000000, LoanAmount = (decimal)1500000, SalesPriceAmount = (decimal)2000000, State = "CA", TransactionTypeDescr = "Sale w/Mortgage", TransactionTypeID = 1, UnderWriterDescr = "First American Title Insurance Company", UnderWriterID = 39, ZipCode = "92701" };
                #endregion

                TestGetCalculationFees(FASTWCFHelpers.FastFileService.FormType.CD, titleOffice: true, escrowOffice: false);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify File Fees using GetCalculationFees web service when File as HUD + Title")]
        public void Scenario_2_HUD_TO_GetCalculationFees()
        {
            try
            {
                Reports.TestDescription = "Verify File Fees using GetCalculationFees web service when File as HUD + Title";

                #region Test Data
                faccSummary = new FACCSummary[]
                {
                    new FACCSummary() { BuyerCharge = (decimal)50000, CalculatedRate = 2475, ChargeTo = "BUYER", ChargeToCdID = 54, FACCFeeDescription = "ALTA Loan Policy - Extended", FASTFeeDescription = "Eagle Lender Policy - 1", FASTProductCategory = 408, FeeCalcTypeCdID = 1594, FeeTypeCdID = 834, IsFACCCalculated = true, OverrideAmount = (decimal)50000, OverrideID = 2434, OverrideReason = "Centralized Loan Rate", TotalCharge = (decimal)50000 },
                    new FACCSummary() { BuyerCharge = (decimal)50000, CalculatedRate = 0, ChargeTo = "BUYER", ChargeToCdID = 54, FACCFeeDescription = "[ALTA 1-06] Street Assessments", FASTFeeDescription = "Endorsement L", FASTProductCategory = 408, FeeCalcTypeCdID = 1595, FeeTypeCdID = 1796, IsFACCCalculated = true, OverrideAmount = (decimal)50000, OverrideID = 1802, OverrideReason = "Permitted Rate Surcharge", TotalCharge = (decimal)50000 },
                    new FACCSummary() { BuyerCharge = (decimal)50000, CalculatedRate = 9, ChargeTo = "BUYER", ChargeToCdID = 54, FACCFeeDescription = "MORTGAGE - Recording Fee", FASTFeeDescription = "1064_Recording_Fee_Deed", FASTProductCategory = null, FeeCalcTypeCdID = 1596, FeeTypeCdID = 69, IsFACCCalculated = true, OverrideAmount = (decimal)50000, OverrideID = 1802, OverrideReason = "Permitted Rate Surcharge", TotalCharge = (decimal)50000 }
                };
                faccRecordingFee = new FACCRecordingFee() { ConsiderationAmnt = (decimal)1500000, IsFACCCalculated = true, Pages = 1, RecordDocumentFACCDescr = "MORTGAGE - Recording Fee", RecordDocumentName = "Mortgage", RecordDocumentObjectCD = "MORTGAGE - Recording Fee", RecordDocumentTypeID = 1605 };
                transactionInfo = new TransactionInformation() { City = "Santa Ana", County = "Orange", FirstNewLoanLiabilityAmnt = (decimal)1500000, FirstOwnerPolicyLiabilityAmnt = (decimal)2000000, LoanAmount = (decimal)1500000, SalesPriceAmount = (decimal)2000000, State = "CA", TransactionTypeDescr = "Sale w/Mortgage", TransactionTypeID = 1, UnderWriterDescr = "First American Title Insurance Company", UnderWriterID = 39, ZipCode = "92701" };
                #endregion

                TestGetCalculationFees(FASTWCFHelpers.FastFileService.FormType.HUD, titleOffice: true, escrowOffice: false);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify File Fees using GetCalculationFees web service when File as CD + Escrow")]
        public void Scenario_3_CD_EO_GetCalculationFees()
        {
            try
            {
                Reports.TestDescription = "Verify File Fees using GetCalculationFees web service when File as CD + Escrow";

                #region Test Data
                faccSummary = new FACCSummary[]
                {
                    new FACCSummary() { BuyerCharge = (decimal)50000, CalculatedRate = 2475, ChargeTo = "BUYER", ChargeToCdID = 54, FACCFeeDescription = "ALTA Loan Policy - Extended", FASTFeeDescription = "Eagle Lender Policy - 1", FASTProductCategory = 408, FeeCalcTypeCdID = 1594, FeeTypeCdID = 834, IsFACCCalculated = true, OverrideAmount = (decimal)50000, OverrideID = 2434, OverrideReason = "Centralized Loan Rate", TotalCharge = (decimal)50000 },
                    new FACCSummary() { BuyerCharge = (decimal)50000, CalculatedRate = 0, ChargeTo = "BUYER", ChargeToCdID = 54, FACCFeeDescription = "[ALTA 1-06] Street Assessments", FASTFeeDescription = "Endorsement L", FASTProductCategory = 408, FeeCalcTypeCdID = 1595, FeeTypeCdID = 1796, IsFACCCalculated = true, OverrideAmount = (decimal)50000, OverrideID = 1802, OverrideReason = "Permitted Rate Surcharge", TotalCharge = (decimal)50000 },
                    new FACCSummary() { BuyerCharge = (decimal)50000, CalculatedRate = 9, ChargeTo = "BUYER", ChargeToCdID = 54, FACCFeeDescription = "MORTGAGE - Recording Fee", FASTFeeDescription = "FACC E Recording Fee - Release", FASTProductCategory = null, FeeCalcTypeCdID = 1596, FeeTypeCdID = 71, IsFACCCalculated = true, OverrideAmount = (decimal)50000, OverrideID = 1802, OverrideReason = "Permitted Rate Surcharge", TotalCharge = (decimal)50000 }
                };
                faccRecordingFee = new FACCRecordingFee() { ConsiderationAmnt = (decimal)1500000, IsFACCCalculated = true, Pages = 1, RecordDocumentFACCDescr = "MORTGAGE - Recording Fee", RecordDocumentName = "Mortgage", RecordDocumentObjectCD = "MORTGAGE - Recording Fee", RecordDocumentTypeID = 1605 };
                transactionInfo = new TransactionInformation() { City = "Santa Ana", County = "Orange", FirstNewLoanLiabilityAmnt = (decimal)1500000, FirstOwnerPolicyLiabilityAmnt = (decimal)2000000, LoanAmount = (decimal)1500000, SalesPriceAmount = (decimal)2000000, State = "CA", TransactionTypeDescr = "Sale w/Mortgage", TransactionTypeID = 1, UnderWriterDescr = "", UnderWriterID = 0, ZipCode = "92701" };
                faccUnderwriter = "True";
                #endregion

                TestGetCalculationFees(FASTWCFHelpers.FastFileService.FormType.CD, titleOffice: false, escrowOffice: true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify File Fees using GetCalculationFees web service when File as HUD + Escrow")]
        public void Scenario_4_HUD_EO_GetCalculationFees()
        {
            try
            {
                Reports.TestDescription = "Verify File Fees using GetCalculationFees web service when File as HUD + Escrow";

                #region Test Data
                faccSummary = new FACCSummary[]
                {
                    new FACCSummary() { BuyerCharge = (decimal)50000, CalculatedRate = 2475, ChargeTo = "BUYER", ChargeToCdID = 54, FACCFeeDescription = "ALTA Loan Policy - Extended", FASTFeeDescription = "Eagle Lender Policy - 1", FASTProductCategory = 408, FeeCalcTypeCdID = 1594, FeeTypeCdID = 834, IsFACCCalculated = true, OverrideAmount = (decimal)50000, OverrideID = 2434, OverrideReason = "Centralized Loan Rate", TotalCharge = (decimal)50000 },
                    new FACCSummary() { BuyerCharge = (decimal)50000, CalculatedRate = 0, ChargeTo = "BUYER", ChargeToCdID = 54, FACCFeeDescription = "[ALTA 1-06] Street Assessments", FASTFeeDescription = "Endorsement L", FASTProductCategory = 408, FeeCalcTypeCdID = 1595, FeeTypeCdID = 1796, IsFACCCalculated = true, OverrideAmount = (decimal)50000, OverrideID = 1802, OverrideReason = "Permitted Rate Surcharge", TotalCharge = (decimal)50000 },
                    new FACCSummary() { BuyerCharge = (decimal)50000, CalculatedRate = 9, ChargeTo = "BUYER", ChargeToCdID = 54, FACCFeeDescription = "MORTGAGE - Recording Fee", FASTFeeDescription = "1064_Recording_Fee_Deed", FASTProductCategory = null, FeeCalcTypeCdID = 1596, FeeTypeCdID = 69, IsFACCCalculated = true, OverrideAmount = (decimal)50000, OverrideID = 1802, OverrideReason = "Permitted Rate Surcharge", TotalCharge = (decimal)50000 }
                };
                faccRecordingFee = new FACCRecordingFee() { ConsiderationAmnt = (decimal)1500000, IsFACCCalculated = true, Pages = 1, RecordDocumentFACCDescr = "MORTGAGE - Recording Fee", RecordDocumentName = "Mortgage", RecordDocumentObjectCD = "MORTGAGE - Recording Fee", RecordDocumentTypeID = 1605 };
                transactionInfo = new TransactionInformation() { City = "Santa Ana", County = "Orange", FirstNewLoanLiabilityAmnt = (decimal)1500000, FirstOwnerPolicyLiabilityAmnt = (decimal)2000000, LoanAmount = (decimal)1500000, SalesPriceAmount = (decimal)2000000, State = "CA", TransactionTypeDescr = "Sale w/Mortgage", TransactionTypeID = 1, UnderWriterDescr = "", UnderWriterID = 0, ZipCode = "92701" };
                faccUnderwriter = "True";
                #endregion

                TestGetCalculationFees(FASTWCFHelpers.FastFileService.FormType.HUD, titleOffice: false, escrowOffice: true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify File Fees using GetCalculationFees web service when File as CD + Title + Escrow + Refi")]
        public void Scenario_5_CD_TEO_REFI_GetCalculationFees()
        {
            try
            {
                Reports.TestDescription = "Verify File Fees using GetCalculationFees web service when File as CD + Title + Escrow + Refi";

                #region Test Data
                faccSummary = new FACCSummary[]
                {
                    new FACCSummary() { BuyerCharge = (decimal)50000, CalculatedRate = 2475, ChargeTo = "BUYER", ChargeToCdID = 54, FACCFeeDescription = "ALTA Loan Policy - Extended", FASTFeeDescription = "1064_Title_Lender_Policy", FASTProductCategory = 408, FeeCalcTypeCdID = 1594, FeeTypeCdID = 834, IsFACCCalculated = true, OverrideAmount = (decimal)50000, OverrideID = 2434, OverrideReason = "Centralized Loan Rate", TotalCharge = (decimal)50000 },
                    new FACCSummary() { BuyerCharge = (decimal)50000, CalculatedRate = 0, ChargeTo = "BUYER", ChargeToCdID = 54, FACCFeeDescription = "[ALTA 1-06] Street Assessments", FASTFeeDescription = "Endorsement L", FASTProductCategory = 408, FeeCalcTypeCdID = 1595, FeeTypeCdID = 1796, IsFACCCalculated = true, OverrideAmount = (decimal)50000, OverrideID = 1802, OverrideReason = "Permitted Rate Surcharge", TotalCharge = (decimal)50000 },
                    new FACCSummary() { BuyerCharge = (decimal)50000, CalculatedRate = 9, ChargeTo = "BUYER", ChargeToCdID = 54, FACCFeeDescription = "MORTGAGE - Recording Fee", FASTFeeDescription = "FACC E Recording Fee - Release", FASTProductCategory = null, FeeCalcTypeCdID = 1596, FeeTypeCdID = 71, IsFACCCalculated = true, OverrideAmount = (decimal)50000, OverrideID = 1802, OverrideReason = "Permitted Rate Surcharge", TotalCharge = (decimal)50000 }
                };
                faccRecordingFee = new FACCRecordingFee() { ConsiderationAmnt = (decimal)1500000, IsFACCCalculated = true, Pages = 1, RecordDocumentFACCDescr = "MORTGAGE - Recording Fee", RecordDocumentName = "Mortgage", RecordDocumentObjectCD = "MORTGAGE - Recording Fee", RecordDocumentTypeID = 1605 };
                transactionInfo = new TransactionInformation() { City = "Santa Ana", County = "Orange", FirstNewLoanLiabilityAmnt = (decimal)1500000, FirstOwnerPolicyLiabilityAmnt = (decimal)2000000, LoanAmount = (decimal)1500000, SalesPriceAmount = (decimal)0, State = "CA", TransactionTypeDescr = "Refinance", TransactionTypeID = 3, UnderWriterDescr = "First American Title Insurance Company", UnderWriterID = 39, ZipCode = "92701" };
                #endregion

                TestGetCalculationFees(FASTWCFHelpers.FastFileService.FormType.CD, titleOffice: true, escrowOffice: false, transactionObjectCD: "REFI");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
