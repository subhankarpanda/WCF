﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace Web_Services_Regression.File_Management.FMUC0023_FileHomePage
{
    [CodedUITest]
    public class US501082_Get_License_Info : FASTHelpers
    {
        private void VerifyLicenseInfo(FormType formType)
        {
            FAST_Login_IIS();

            FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.NewLender, isTO: false, isEO: true);

            #region Navigate to File Homepage for setting up License Information
            Reports.TestStep = "Navigate to File Homepage for setting up License Information";
            FastDriver.FileHomepage.Open();
            FastDriver.FileHomepage.OfficeLicense.FASelectItem("CA, TEST04STOFFICER");
            FastDriver.BottomFrame.Done();
            #endregion

            #region Navigate to New Loan for setting up License Information
            Reports.TestStep = "Navigate to New Loan for setting up License Information";
            FastDriver.NewLoan.Open();
            FastDriver.NewLoan.NewLoanDetails_STLICENSEID.FASelectItem("CA, TEST02STLENDER");
            FastDriver.BottomFrame.Done();
            #endregion

            #region Verify License Information with GetOrderDetails()
            Reports.TestStep = "Verify License Information with GetOrderDetails()";
            var details = FileService.GetOrderDetails(File.FileID ?? 0);
            details.NewLoan[0].FileBusinessParty.LicenseInfo.CompareTo(new LicenseDetails() { NMLSLicenseNo = "TEST01NMLS", StateLicenseNo = "TEST02STLENDER" });
            details.Services[0].OfficeInfo.CompareTo(new OfficeInfo(){ OfficeSTLicenseNo ="CA, TEST04STOFFICER"});
            #endregion
        }

        [TestMethod]
        [Description("Verify License Information using GetOrderDetails web service when File is CD")]
        public void Scenario_1_CD_Get_License_Info()
        {
            try
            {
                Reports.TestDescription = "Verify License Information using GetOrderDetails web service when File is CD";

                VerifyLicenseInfo(FormType.CD);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify License Information using GetOrderDetails web service when File is HUD")]
        public void Scenario_2_HUD_Get_License_Info()
        {
            try
            {
                Reports.TestDescription = "Verify License Information using GetOrderDetails web service when File is HUD";

                VerifyLicenseInfo(FormType.HUD);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
