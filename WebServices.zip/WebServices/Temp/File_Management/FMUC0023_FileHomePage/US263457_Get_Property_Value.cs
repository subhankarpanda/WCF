﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace Web_Services_Regression.File_Management.FMUC0023_FileHomePage
{
    [CodedUITest]
    public class US263457_Get_Property_Value : FASTHelpers
    {
        [TestMethod]
        [Description("Verify Property Value and Type; Est, Appraised")]
        public void Scenario_1_Get_Property_Value()
        {
            try
            {
                Reports.TestDescription = "Verify Property Value and Type; Est, Appraised";

                FAST_Login_IIS();

                FAST_WCF_File_IIS(BSOCD: "RESIDENTAL", TTOCD: "REFI", SPAmt:0);

                #region Verify Property Value and Type with GetOrderDetails()
                Reports.TestStep = "Verify Property Value and Type with GetOrderDetails()";
                Support.IsTrue(!File.HasProperty("PropertyValue"), "PropertyValue not defined in OrderDetailsResponse");                
                #endregion

                #region Verify Property Value and Type in Terms/Dates/Status
                Reports.TestStep = "Verify Property Value and Type in Terms/Dates/Status";
                FastDriver.TermsDatesStatus.Open();
                //
                Reports.TestStep = "Verify Property Value and Type";
                Support.AreEqual("", FastDriver.TermsDatesStatus.PropertyValue.FAGetValue(), "PropertyValue");
                Support.AreEqual("true", FastDriver.TermsDatesStatus.AppraisedPropValue.FAGetAttribute("status").ToLowerInvariant(), "AppraisedPropValue");
                //
                Reports.TestStep = "Modify Property Value and Type";
                FastDriver.TermsDatesStatus.PropertyValue.FASetText("2000000.00");
                FastDriver.TermsDatesStatus.EstimatedPropValue.FAClick();
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                //
                Reports.TestStep = "Verify Property Value and Type with GetTermsDatesStatus()";
                var details = FileService.GetTermsDatesStatusDetails(File.FileID ?? 0);
                Support.AreEqual("Open", details.Status.ToString(), "Status");
                Support.AreEqual("2,000,000.00", details.PropertyValue.ToString("N2"), "PropertyValue");
                Support.AreEqual("2556", details.PropertyValueTypeCD.ToString(), "PropertyValueTypeCD");
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
