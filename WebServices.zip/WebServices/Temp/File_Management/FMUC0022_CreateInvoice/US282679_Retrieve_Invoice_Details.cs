﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.File_Management.FMUC0022_CreateInvoice
{
    [CodedUITest]
    public class US282679_Retrieve_Invoice_Details : FASTHelpers
    {
        [TestMethod]
        [Description("Verify Invoice details")]
        public void Scenario_1_Retrieve_Invoice_Details()
        {
            try
            {
                Reports.TestDescription = "Verify Invoice details";

                FAST_Init_File();

                #region Navigate to File Fees and add Recording Fees
                Reports.TestStep = "Navigate to File Fees and add Recording Fees";
                FAST_AddFileFees(new PDD[]{
                    new PDD() { ChargeDescription = "E Recording Fee Deed1", BuyerAtClosing = 999999.99, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 999999.99, SellerChargePaymentMethod = "Fee" },
                    new PDD() { ChargeDescription = "E Recording Fee Mortgage1", BuyerAtClosing = 999999.99, BuyerChargePaymentMethod = "Check", SellerPaidAtClosing = 999999.99, SellerChargePaymentMethod = "Check" },
                    new PDD() { ChargeDescription = "E Recording Fee Misc. description1", BuyerAtClosing = 999999.99, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 999999.99, SellerChargePaymentMethod = "Fee" },
                    new PDD() { ChargeDescription = "E Recording Fee - Release1", BuyerAtClosing = 999999.99, BuyerChargePaymentMethod = "Check", SellerPaidAtClosing = 999999.99, SellerChargePaymentMethod = "Check" },
                }, isTE: false);
                FAST_AddFileFees(new PDD[] { 
                    new PDD() { ChargeDescription = "CD - E Transfer Tax Deed1", BuyerAtClosing = 999999.99, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 999999.99, SellerChargePaymentMethod = "Fee" },
                    new PDD() { ChargeDescription = "CD - Transfer Tax – Miscellaneous", BuyerAtClosing = 999999.99, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 999999.99, SellerChargePaymentMethod = "Fee" },
                    new PDD() { ChargeDescription = "CD - E Transfer Tax – Mortgage", BuyerAtClosing = 999999.99, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 999999.99, SellerChargePaymentMethod = "Fee" },
                }, isTE: false);
                FAST_AddFileFeesFACC(
                    recFees: new string[,] { 
                    { "Assignment", "89", "999999.99" }, 
                    { "Deed", "890", "999999.99" }, 
                    { "Mortgage", "986", "999999.99" }, 
                    { "Satisfaction", "878", "999999.99" }, },
                    summary: new string[,] {  
                    {"ASSIGNMENT - Recording Fee","","273.00","FACC E Recording Fee Misc. description","Seller","Premium Split","999,999.99","10","","899,999.99","100,000.00","999,999.99" }, 
                    {"DEED - Recording Fee","","2,673.00","FACC E Recording Fee Deed","Buyer","Premium Split", "999,999.99","10","","100,000.00","899,999.99","999,999.99" },
                    {"DEED - Documentary Transfer Tax","","1,100.00","FACC E Recording Fee Deed2","Seller","Premium Split","999,999.99","10","","899,999.99","100,000.00","999,999.99"},
                    {"MORTGAGE - Recording Fee","","2,964.00","FACC E Recording Fee Mortgage","Buyer","Premium Split","999,999.99","10","","100,000.00","899,999.99","999,999.99"},
                    {"SATISFACTION - Recording Fee","","2,640.00","FACC E Recording Fee - Release","Buyer","Premium Split","999,999.99","10","","100,000.00","899,999.99","999,999.99"}
                });
                #endregion

                #region Navigate to File Fees and add Title/Escrow Fees
                Reports.TestStep = "Navigate to File Fees and add Title/Escrow Fees";
                FAST_AddFileFees(new PDD[]{
                    new PDD() { ChargeDescription = "Closing Service Coordination", BuyerAtClosing = 999999.99, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 999999.99, SellerChargePaymentMethod = "Fee" },
                    new PDD() { ChargeDescription = "ALTA Extended Loan - 115% liability", BuyerAtClosing = 999999.99, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 999999.99, SellerChargePaymentMethod = "Fee" },
                    new PDD() { ChargeDescription = "New Home Rate (Title Only)", BuyerAtClosing = 999999.99, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 999999.99, SellerChargePaymentMethod = "Fee" }
                });
                #endregion

                #region Verify Invoice details using GetInvoiceDetails web service
                Reports.TestStep = "Verify Invoice details using GetInvoiceDetails web service";
                var details = FileService.GetInvoiceDetails(File.FileID ?? 0);
                Support.AreEqual("false", details.BuyerSellerFormat.ToString().ToLowerInvariant());
                Support.AreEqual("13", details.Fees.Count().ToString());
                Support.AreEqual("1", details.Invoices.Count().ToString());
                Support.AreEqual("101 Meadowview Center,Kankakee,IL,60901", details.Invoices[0].BillToAddr);
                Support.AreEqual("true", details.PaymentToInfo.ToString().ToLowerInvariant());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
