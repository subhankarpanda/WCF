﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.File_Management.FMUC0008_FeeEntry
{
    [CodedUITest]
    public class US389413_Update_TitleService_TitleInsurance_RecordingTax : FASTHelpers
    {
        #region Updates to Title Services and Title Insurance and Recording Tax for CD File:Non Simultaneous-NonFACC

        [TestMethod]
        [Description("File Services -UpdateFeeEntryDetails- Updates to Title Services and Title Insurance and Recording Tax for CD File:Non Simultaneous-NonFACC")]
        public void Scenario_1_UpdateFeeEntryDetails_Rec_and_Tax()
        {
            try
            {
                Reports.TestDescription = "File Services -UpdateFeeEntryDetails- Updates to Title Services and Title Insurance and Recording Tax for CD File:Non Simultaneous-NonFACC";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FAST_WCF_File_IIS(GAB: "508", isTO: true, isEO: true, LenderID: "", SPAmt: 0);
                #endregion

                #region Verify FileFees
                FastDriver.FileFees.Open();
                //  Title and Escrow
                Reports.TestStep = "Title and Escrow Tab";
                Reports.TestStep = "Verify: Change \"GFE Amount\" to \"Loan Estimate Unrounded\"";
                Support.AreEqual("Loan Estimate Unrounded", FastDriver.FileFees.lblLEUnrounded.Text);
                Reports.TestStep = "Verify: Change \"Title Services / Lender Title Ins.\" to \"Premium Amount\"";
                Support.AreEqual("Premium Amount", FastDriver.FileFees.TitlePolicyCalcForCD.PerformTableAction(1, 2, TableAction.GetText).Message);
                Reports.TestStep = "Change \"Owners Title Insurance\" to \"Loan Estimate - Unrounded\"";
                Support.AreEqual("Loan Estimate - Unrounded", FastDriver.FileFees.TitlePolicyCalcForCD.PerformTableAction(1, 3, TableAction.GetText).Message);
                var TitlePolicyCalcForCD_Text = FastDriver.FileFees.TitlePolicyCalcForCD.Text;
                Support.IsTrue(!TitlePolicyCalcForCD_Text.Contains("Lender Selected Provider Group"), "Removed \"Lender Selected Provider Group\"");
                Support.IsTrue(!(TitlePolicyCalcForCD_Text.Contains("GFE #7") && TitlePolicyCalcForCD_Text.Contains("GFE #8")), "Removed \"GFE #7\" and \"GFE #8\"");
                Support.IsTrue(!TitlePolicyCalcForCD_Text.Contains("Split/LSP"), "Removed \"Split/LSP\"");
                Reports.TestStep = "Verify payment Adjust using primary policy";
                Support.IsTrue(FastDriver.FileFees.OwnerAdjAmnt.IsReadOnly() || !FastDriver.FileFees.OwnerAdjAmnt.Enabled, "Premium amount should be read only or disabled");
                //  Recording and Tax section
                Reports.TestStep = "Recording and Tax section Tab";
                FastDriver.FileFees.RecordingandTax.Click();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                Reports.TestStep = "Change \"Government Recording Charges – GFE Amount\" to \"Government Recording Charges – Loan Estimate Unrounded and Rounded\"";
                Support.AreEqual("Government Recording Charges – Loan Estimate Unrounded and Rounded", FastDriver.FileFees.lblGRC.Text);
                Reports.TestStep = "Change \"Transfer Tax – GFE Amount\" to \"Transfer Tax – Loan Estimate - Unrounded and Rounded\"";
                Support.AreEqual("Transfer Tax – Loan Estimate - Unrounded and Rounded", FastDriver.FileFees.lblTTax.Text);
                var RecordingFeesAndTransferTaxes = FastDriver.FileFees.RecordingFeesAndTransferTaxes.Text;
                Support.IsTrue(!RecordingFeesAndTransferTaxes.Contains("Tolerance Cure"), "Removed \"Tolerance Cure\"");
                #endregion

                #region Send a WCF UpdateFeeEntryDetails request
                Reports.TestStep = "Send a WCF UpdateFeeEntryDetails request";
                var updateReq = RequestFactory.GetFeeEntryRequest();
                updateReq.FileID = File.FileID ?? 0;
                updateReq.RecordingAndTax.GovernmentRecordingAndTransferTaxes.CdTransferTax.LoanEstimateRounded = (Decimal)10.00;
                updateReq.RecordingAndTax.GovernmentRecordingAndTransferTaxes.CdTransferTax.LoanEstimateUnRounded = (Decimal)9.99;
                updateReq.RecordingAndTax.GovernmentRecordingAndTransferTaxes.GovernmentCdRecordingCharges.LoanEstimateRounded = (Decimal)10.00;
                updateReq.RecordingAndTax.GovernmentRecordingAndTransferTaxes.GovernmentCdRecordingCharges.LoanEstimateUnRounded = (Decimal)9.99;
                updateReq.TitleAndEscrow.CdBSSplitDetail = null;
                updateReq.TitleAndEscrow.TitlePolicyCalculationsForCD.DisclosedOwnerPremium.AdjustedOrPremiumAmount = null;
                updateReq.TitleAndEscrow.TitlePolicyCalculationsForCD.DisclosedOwnerPremium.LoanEstimateUnrounded = (Decimal)9.99;
                updateReq.TitleAndEscrow.TitlePolicyCalculationsForCD.DisclosedOwnerPremium.PrimaryPolicyDescription = null;
                updateReq.TitleAndEscrow.TitlePolicyCalculationsForCD.FullLoanPremium.AdjustedOrPremiumAmount = null;
                updateReq.TitleAndEscrow.TitlePolicyCalculationsForCD.FullLoanPremium.LoanEstimateUnrounded = (Decimal)9.99;
                updateReq.TitleAndEscrow.TitlePolicyCalculationsForCD.FullLoanPremium.PrimaryPolicyDescription = null;
                updateReq.TitleAndEscrow.TitlePolicyCalculationsForCD.TitlePremiumAdjustmentAmount = null;
                updateReq.TitleAndEscrow.TitleServicesAndTitleInsurance.OwnersTitleInsurance = null;
                updateReq.TitleAndEscrow.TitleServicesAndTitleInsurance.TitleServicesOrLenderTitleIns = null;
                var updateRes = FileService.UpdateFeeEntryDetails(updateReq);
                Assert.AreEqual("1", updateRes.Status.ToString());
                Support.IsTrue(true, "UpdateFeeEntryDetails.Status SUCCESS");
                #endregion

                #region Send a WCF GetFeeEntryDetails request
                Reports.TestStep = "Send a WCF GetFeeEntryDetails request";
                var details = FileService.GetFeeEntryDetails(File.FileID ?? 0);
                Assert.AreEqual("1", details.Status.ToString());
                Support.IsTrue(true, "GetFeeEntryDetails.Status SUCCESS");
                Support.AreEqual("10.00", ((Decimal)details.RecordingAndTax.GovernmentRecordingAndTransferTaxes.CdTransferTax.LoanEstimateRounded).ToString("N2"), "RecordingAndTax.GovernmentRecordingAndTransferTaxes.CdTransferTax.LoanEstimateRounded");
                Support.AreEqual("9.99", ((Decimal)details.RecordingAndTax.GovernmentRecordingAndTransferTaxes.CdTransferTax.LoanEstimateUnRounded).ToString("N2"), "RecordingAndTax.GovernmentRecordingAndTransferTaxes.CdTransferTax.LoanEstimateUnRounded");
                Support.IsTrue(details.RecordingAndTax.GovernmentRecordingAndTransferTaxes.CdTransferTax.DisplayBrokenLinkFlag == false, "details.RecordingAndTax.GovernmentRecordingAndTransferTaxes.CdTransferTax.DisplayBrokenLinkFlag");
                Support.AreEqual("10.00", ((Decimal)details.RecordingAndTax.GovernmentRecordingAndTransferTaxes.GovernmentCdRecordingCharges.LoanEstimateRounded).ToString("N2"), "RecordingAndTax.GovernmentRecordingAndTransferTaxes.GovernmentCdRecordingCharges.LoanEstimateRounded");
                Support.AreEqual("9.99", ((Decimal)details.RecordingAndTax.GovernmentRecordingAndTransferTaxes.GovernmentCdRecordingCharges.LoanEstimateUnRounded).ToString("N2"), "RecordingAndTax.GovernmentRecordingAndTransferTaxes.GovernmentCdRecordingCharges.LoanEstimateUnRounded");
                Support.IsTrue(details.RecordingAndTax.GovernmentRecordingAndTransferTaxes.GovernmentCdRecordingCharges.DisplayBrokenLinkFlag == false, "details.RecordingAndTax.GovernmentRecordingAndTransferTaxes.GovernmentCdRecordingCharges.DisplayBrokenLinkFlag");
                Support.IsTrue(details.TitleAndEscrow.TitlePolicyCalculationsForCD.DisclosedOwnerPremium.AdjustedOrPremiumAmount == null, "TitleAndEscrow.TitlePolicyCalculationsForCD.DisclosedOwnerPremium.AdjustedOrPremiumAmount is NULL");
                Support.AreEqual("9.99", ((Decimal)details.TitleAndEscrow.TitlePolicyCalculationsForCD.DisclosedOwnerPremium.LoanEstimateUnrounded).ToString("N2"), "TitleAndEscrow.TitlePolicyCalculationsForCD.DisclosedOwnerPremium.LoanEstimateUnrounded");
                Support.IsTrue(details.TitleAndEscrow.TitlePolicyCalculationsForCD.DisclosedOwnerPremium.PrimaryPolicyDescription == null, "TitleAndEscrow.TitlePolicyCalculationsForCD.DisclosedOwnerPremium.PrimaryPolicyDescription is NULL");
                Support.IsTrue(details.TitleAndEscrow.TitlePolicyCalculationsForCD.FullLoanPremium.AdjustedOrPremiumAmount == null, "TitleAndEscrow.TitlePolicyCalculationsForCD.FullLoanPremium.AdjustedOrPremiumAmount is NULL");
                Support.AreEqual("9.99", ((Decimal)details.TitleAndEscrow.TitlePolicyCalculationsForCD.FullLoanPremium.LoanEstimateUnrounded).ToString("N2"), "TitleAndEscrow.TitlePolicyCalculationsForCD.FullLoanPremium.LoanEstimateUnrounded");
                Support.IsTrue(details.TitleAndEscrow.TitlePolicyCalculationsForCD.FullLoanPremium.PrimaryPolicyDescription == null, "TitleAndEscrow.TitlePolicyCalculationsForCD.FullLoanPremium.PrimaryPolicyDescription is NULL");
                Support.IsTrue(details.TitleAndEscrow.TitlePolicyCalculationsForCD.TitlePremiumAdjustmentAmount == null, "TitleAndEscrow.TitlePolicyCalculationsForCD.TitlePremiumAdjustmentAmount is NULL");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
