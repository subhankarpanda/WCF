﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.File_Management.FMUC0008_FeeEntry
{
    [CodedUITest]
    public class US371593_Retrieve_FileFees_PDD_Info : FASTHelpers
    {
        #region payment details
        protected PDD paymentDetails = new PDD()
        {
            ChargeDescription = "test-charge-description",
            AdditionalDescription = "",
            UseDefaultChecked = false,
            PayeeName = "test-payee-name",
            PayTo = "Continental Mortgage Corporation",
            LoanEstimateUnrounded = (double)15099.99,
            LoanEstimateRounded = (double)15100.00,
            PartOfCheckbox = true,
            SectionCDidShopFor = true,
            BuyerCharge = (double)30000,
            BuyerAtClosing = (double)15000,
            BuyerChargePaymentMethod = "Fee",
            BuyerBeforeClosing = (double)5000,
            BuyerPaidbyOther = (double)10000,
            BuyerPaidbyOtherPaymentMethod = "Lender",
            BuyerCreditPaymentMethod = "Lender",
            //  BuyerLenderCheckbox is out of this scope
            BuyerLenderCheckbox = true,
            BuyerDoubleAsteriskChecked = false,
            SellerCharge = (double)24000,
            SellerPaidAtClosing = (double)12000,
            SellerChargePaymentMethod = "Fee",
            SellerPaidBeforeClosing = (double)6000,
            SellerPaidbyOthers = (double)6000,
            SellerPaidbyOtherPaymentMthd = "Lender",
            SellerCreditPaymentMethod = "Lender",
            TotalCharge = (double)54000.00,
            SellerLenderCheckbox = true,
        };
        #endregion

        protected void FAST_VerifyFeePaymentDetails(dynamic _pdd)
        {
            #region Verify Fee Payment Details
            var pdd = _pdd as FASTWCFHelpers.FastFileService.CdFeePaymentDetails;
            //
            Support.AreEqual("", pdd.AdditionalDescription ?? "", "AdditionalDescription");
            //  BuyerChargeDetails
            Support.AreEqual("True", pdd.BuyerChargeDetails.buyerChargeEditable.ToString(), "BuyerChargeDetails.buyerChargeEditable");
            Support.AreEqual("True", pdd.BuyerChargeDetails.paidByBuyerEditable.ToString(), "BuyerChargeDetails.paidByBuyerEditable");
            Support.AreEqual("True", pdd.BuyerChargeDetails.paidByLenderEditable.ToString(), "BuyerChargeDetails.paidByLenderEditable");
            Support.AreEqual("False", pdd.BuyerChargeDetails.paidByMortgageBrokerEditable.ToString(), "BuyerChargeDetails.paidByMortgageBrokerEditable");
            Support.AreEqual("True", pdd.BuyerChargeDetails.paymentMethodEditable.ToString(), "BuyerChargeDetails.paymentMethodEditable");
            //  BuyerCredit
            Support.AreEqual("null", pdd.BuyerCredit != null ? ((Decimal)pdd.BuyerCredit).ToString("C2") : "null", "BuyerCredit");
            Support.AreEqual("null", pdd.BuyerCreditCDSection ?? "null", "BuyerCreditCDSection");
            Support.AreEqual("none", pdd.BuyerCreditPaymentMethodTypeCdID.ToString().ToLowerInvariant(), "BuyerCreditPaymentMethodTypeCdID");
            //  BuyerDetails
            Support.AreEqual(((Decimal)paymentDetails.BuyerCharge).ToString("C2"), ((Decimal)pdd.BuyerDetails.ChargeAmount).ToString("C2"), "BuyerDetails.ChargeAmount");
            Support.AreEqual(paymentDetails.BuyerLenderCheckbox.ToString().ToLowerInvariant(), pdd.BuyerDetails.DisplayLOnCD.ToString().ToLowerInvariant(), "BuyerDetails.DisplayLOnCD");
            Support.AreEqual(paymentDetails.BuyerLenderCheckbox.ToString().ToLowerInvariant(), pdd.BuyerDetails.IsDisplayLOnCDEditable.ToString().ToLowerInvariant(), "BuyerDetails.IsDisplayLOnCDEditable");
            Support.AreEqual(((Decimal)paymentDetails.BuyerAtClosing).ToString("C2"), ((Decimal)pdd.BuyerDetails.PaidByAtClosing).ToString("C2"), "BuyerDetails.PaidByAtClosing");
            Support.AreEqual(((Decimal)paymentDetails.BuyerBeforeClosing).ToString("C2"), ((Decimal)pdd.BuyerDetails.PaidByBeforeClosing).ToString("C2"), "BuyerDetails.PaidByBeforeClosing");
            Support.AreEqual(((Decimal)paymentDetails.BuyerPaidbyOther).ToString("C2"), ((Decimal)pdd.BuyerDetails.PaidByOthers).ToString("C2"), "BuyerDetails.PaidByOthers");
            Support.AreEqual(paymentDetails.BuyerPaidbyOtherPaymentMethod.ToLowerInvariant(), pdd.BuyerDetails.PaidByOthersPMTypeCdID.ToString().ToLowerInvariant(), "BuyerDetails.PaidByOthersPMTypeCdID");
            Support.AreEqual(paymentDetails.BuyerChargePaymentMethod.ToLowerInvariant(), pdd.BuyerDetails.ePaymentMethod.ToString().ToLowerInvariant(), "BuyerDetails.ePaymentMethod");
            //
            Support.AreEqual(paymentDetails.ChargeDescription, pdd.Description, "Description");
            Support.AreEqual("False", pdd.DisplayBrokenLinkFlag.ToString(), "DisplayBrokenLinkFlag");
            Support.AreEqual(paymentDetails.BuyerDoubleAsteriskChecked.ToString().ToLowerInvariant(), pdd.DoubleAsteriskIndicator.ToString().ToLowerInvariant(), "DoubleAsteriskIndicator");
            //  FACC Fee Info
            Support.AreEqual("null", pdd.FACCFeeFlag != null ? pdd.FACCFeeFlag.ToString():"null", "FACCFeeFlag");
            Support.AreEqual("null", pdd.FACCServiceFileFeeID != null ? pdd.FACCServiceFileFeeID.ToString() : "null", "FACCServiceFileFeeID");
            //  Fee Info
            Support.Match("[1-9][0-9]+", pdd.FeeID.ToString(), "FeeID");
            Support.Match("(Title - Lenders Policy)|(string)", pdd.FeeType, "FeeType");
            Support.Match("(834)|(number)", pdd.FeeTypeCdID != null ? pdd.FeeTypeCdID.ToString() : "null", "FeeTypeCdID");
            Support.Match("[1-9][0-9]+", pdd.ServiceFileFeeId.ToString(), "ServiceFileFeeId");
            //  GFE
            Support.AreEqual("null", pdd.GfeEntryEditableFlag != null ? pdd.GfeEntryEditableFlag.ToString() : "null", "GfeEntryEditableFlag");
            Support.AreEqual("null", pdd.GfeLenderDirectedFlag != null ? pdd.GfeLenderDirectedFlag.ToString() : "null", "GfeLenderDirectedFlag");
            Support.AreEqual("null", pdd.GfeLenderDirEditableFlag != null ? pdd.GfeLenderDirEditableFlag.ToString() : "null", "GfeLenderDirEditableFlag");
            Support.AreEqual("null", pdd.GfePOBOBFlag != null ? pdd.GfePOBOBFlag.ToString() : "null", "GfePOBOBFlag");
            //
            Support.AreEqual("null", pdd.IsSplitLSPModified != null ? pdd.IsSplitLSPModified.ToString() : "null", "IsSplitLSPModified");
            //  Loan Estimate
            Support.AreEqual(paymentDetails.LEDescription, pdd.LoanEstimateDescription, "LoanEstimateDescription");
            Support.AreEqual(((Decimal)paymentDetails.LoanEstimateUnrounded).ToString("N2"), ((Decimal)pdd.LoanEstimateUnrounded).ToString("N2"), "LoanEstimateUnrounded");
            Support.AreEqual(((Decimal)paymentDetails.LoanEstimateRounded).ToString("N2"), ((Decimal)pdd.LoanestimateRounded).ToString("N2"), "LoanestimateRounded");
            // 
            Support.AreEqual(paymentDetails.PartOfCheckbox.ToString().ToLowerInvariant(), pdd.PartOf.ToString().ToLowerInvariant(), "PartOf");
            Support.IsTrue(!string.IsNullOrEmpty(pdd.PayTo), "PayTo= " + pdd.PayTo);
            Support.AreEqual("False", pdd.PayToFlag.ToString(), "PayToFlag");
            Support.IsTrue(!string.IsNullOrEmpty(pdd.PayeeNameOnCDOrSettlementStmt), "PayeeNameOnCDOrSettlementStmt= " + pdd.PayeeNameOnCDOrSettlementStmt);
            Support.IsTrue(pdd.PrimaryPolicy ?? false, "PrimaryPolicy");
            //  SectionShopDetails
            Support.AreEqual("False", pdd.SectionShopDetails.IsLenderAffiliateFlagEditable.ToString(), "SectionShopDetails.IsLenderAffiliateFlagEditable");
            Support.AreEqual("True", pdd.SectionShopDetails.IsSectionBEditable.ToString(), "SectionShopDetails.IsSectionBEditable");
            Support.AreEqual("True", pdd.SectionShopDetails.IsSectionCEditable.ToString(), "SectionShopDetails.IsSectionCEditable");
            Support.AreEqual("True", pdd.SectionShopDetails.IsSectionHEditable.ToString(), "SectionShopDetails.IsSectionHEditable");
            Support.AreEqual("False", pdd.SectionShopDetails.LenderAffiliateFlag.ToString(), "SectionShopDetails.LenderAffiliateFlag");
            if (pdd.SectionShopDetails.SectionShopped == FASTWCFHelpers.FastFileService.SectionsShoppedFor.SectionBdidNotShopFor)
                Support.IsTrue(paymentDetails.SectionBdidnotShopFor, "SectionBdidnotShopFor");
            else if (pdd.SectionShopDetails.SectionShopped == FASTWCFHelpers.FastFileService.SectionsShoppedFor.SectionCdidShopFor)
                Support.IsTrue(paymentDetails.SectionCDidShopFor, "SectionCDidShopFor");
            else if (pdd.SectionShopDetails.SectionShopped == FASTWCFHelpers.FastFileService.SectionsShoppedFor.SectionHotherCosts)
                Support.IsTrue(paymentDetails.SectionHOtherCosts, "SectionHOtherCosts");
            Support.AreEqual("null", pdd.SellerChargeCDSection ?? "null", "SellerChargeCDSection");
            //  SellerChargeDetails
            Support.AreEqual("True", pdd.SellerChargeDetails.sellerChargeEditable.ToString(), "SellerChargeDetails.sellerChargeEditable");
            Support.AreEqual("True", pdd.SellerChargeDetails.paidBySellerEditable.ToString(), "SellerChargeDetails.paidBySellerEditable");
            Support.AreEqual("True", pdd.SellerChargeDetails.paidByLenderEditable.ToString(), "SellerChargeDetails.paidByLenderEditable");
            Support.AreEqual("False", pdd.SellerChargeDetails.paidByMortgageBrokerEditable.ToString(), "SellerChargeDetails.paidByMortgageBrokerEditable");
            Support.AreEqual("True", pdd.SellerChargeDetails.paymentMethodEditable.ToString(), "SellerChargeDetails.paymentMethodEditable");
            //  SellerCredit
            Support.AreEqual("none", pdd.SellerCreditPaymentMethodTypeCdID.ToString().ToLowerInvariant(), "SellerCreditPaymentMethodTypeCdID");
            //  SellerDetails
            Support.AreEqual(((Decimal)paymentDetails.SellerCharge).ToString("C2"), ((Decimal)pdd.SellerDetails.ChargeAmount).ToString("C2"), "SellerDetails.ChargeAmount");
            Support.AreEqual(paymentDetails.SellerLenderCheckbox.ToString().ToLowerInvariant(), pdd.SellerDetails.DisplayLOnCD.ToString().ToLowerInvariant(), "SellerDetails.DisplayLOnCD");
            Support.AreEqual(paymentDetails.SellerLenderCheckbox.ToString().ToLowerInvariant(), pdd.SellerDetails.IsDisplayLOnCDEditable.ToString().ToLowerInvariant(), "SellerDetails.IsDisplayLOnCDEditable");
            Support.AreEqual(((Decimal)paymentDetails.SellerPaidAtClosing).ToString("C2"), ((Decimal)pdd.SellerDetails.PaidByAtClosing).ToString("C2"), "SellerDetails.PaidByAtClosing");
            Support.AreEqual(((Decimal)paymentDetails.SellerPaidBeforeClosing).ToString("C2"), ((Decimal)pdd.SellerDetails.PaidByBeforeClosing).ToString("C2"), "SellerDetails.PaidByBeforeClosing");
            Support.AreEqual(((Decimal)paymentDetails.SellerPaidbyOthers).ToString("C2"), ((Decimal)pdd.SellerDetails.PaidByOthers).ToString("C2"), "SellerDetails.PaidByOthers");
            Support.AreEqual(paymentDetails.SellerPaidbyOtherPaymentMthd.ToLowerInvariant(), pdd.SellerDetails.PaidByOthersPMTypeCdID.ToString().ToLowerInvariant(), "SellerDetails.PaidByOthersPMTypeCdID");
            Support.AreEqual(paymentDetails.SellerChargePaymentMethod.ToLowerInvariant(), pdd.SellerDetails.ePaymentMethod.ToString().ToLowerInvariant(), "SellerDetails.ePaymentMethod");
            //
            Support.AreEqual("False", pdd.ThirdPartyPayeeFlag.ToString(), "ThirdPartyPayeeFlag");
            Support.AreEqual(((Decimal)paymentDetails.TotalCharge).ToString("C2"), ((Decimal)pdd.TotalCharge).ToString("C2"), "TotalCharge");
            Support.AreEqual("none", pdd.ePaymentMethodType.ToString().ToLowerInvariant(), "ePaymentMethodType");
            Support.AreEqual("False", pdd.isDescriptionEditable.ToString(), "isDescriptionEditable");
            #endregion
        }
        
        [TestMethod]
        [Description("Verify retrieve File Fees - Title and Escrow fee payment information using GetFeeEntryDetails web service")]
        public void Scenario_1_Retrieve_TitleAndEscrowFees_PDD_Info()
        {
            try
            {
                Reports.TestDescription = "Verify retrieve File Fees - Title and Escrow fee payment information using GetFeeEntryDetails web service";

                FAST_Init_File(GABRole: FASTWCFHelpers.FastFileService.AdditionalRoleType.NewLender);

                #region Navigate to File Fees and add Fees with PDD
                Reports.TestStep = "Navigate to File Fees and add Fees with PDD";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.SelectCheckbox.FASetCheckbox(true);
                paymentDetails.ChargeDescription = FastDriver.FileFees.FeeDescription.FAGetText();
                paymentDetails.LEDescription = paymentDetails.ChargeDescription;
                FastDriver.FileFees.FeeDetails.Click();
                FAST_UpdatePDD( paymentDetails );
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify File Fees - Title and Escrow fee payment details with GetFeeEntryDetails()
                Reports.TestStep = "Verify File Fees - Title and Escrow fee payment details with GetFeeEntryDetails()";
                FastDriver.FileFees.Open();
                var details = FileService.GetFeeEntryDetails(File.FileID ?? 0);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                FAST_VerifyFeePaymentDetails(details.TitleAndEscrow.CdFileFees[0].FeePaymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify retrieve File Fees - Recording and Tax fee payment information using GetFeeEntryDetails web service")]
        public void Scenario_2_Retrieve_RecordingAndTaxFees_PDD_Info()
        {
            try
            {
                Reports.TestDescription = "Verify retrieve File Fees - Recording and Tax fee payment information using GetFeeEntryDetails web service";

                FAST_Init_File(GABRole: FASTWCFHelpers.FastFileService.AdditionalRoleType.NewLender);

                #region Navigate to File Fees and add Fees with PDD
                Reports.TestStep = "Navigate to File Fees and add Fees with PDD";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.RecordingandTax.Click();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.SelectRecording.FASetCheckbox(true);
                paymentDetails.ChargeDescription = FastDriver.FileFees.FeeDescriptionRecording.FAGetText();
                paymentDetails.LEDescription = paymentDetails.ChargeDescription;
                FastDriver.FileFees.RecordingTaxFeeDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify File Fees - Recording and Tax fee payment details with GetFeeEntryDetails()
                Reports.TestStep = "Verify File Fees - Recording and Tax fee payment details with GetFeeEntryDetails()";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.RecordingandTax.Click();
                var details = FileService.GetFeeEntryDetails(File.FileID ?? 0);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
