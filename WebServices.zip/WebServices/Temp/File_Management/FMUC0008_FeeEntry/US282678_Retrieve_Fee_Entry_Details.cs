﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Linq;

namespace Web_Services_Regression.File_Management.FMUC0008_FeeEntry
{
    [CodedUITest]
    public class US282678_Retrieve_Fee_Entry_Details : FASTHelpers
    {
        [TestMethod]
        [Description("Verify retrieve File Fee's datails")]
        public void Scenario_1_Retrieve_Fee_Entry_Details()
        {
            try
            {
                Reports.TestDescription = "Verify retrieve File Fee's datails";

                FAST_Init_File();

                #region Navigate to File Fees and add Recording Fees
                Reports.TestStep = "Navigate to File Fees and add Recording Fees";
                FAST_AddFileFees(new PDD[]{
                    new PDD() { ChargeDescription = "E Recording Fee Deed1", BuyerAtClosing = 999999.99, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 999999.99, SellerChargePaymentMethod = "Fee" },
                    new PDD() { ChargeDescription = "E Recording Fee Mortgage1", BuyerAtClosing = 999999.99, BuyerChargePaymentMethod = "Check", SellerPaidAtClosing = 999999.99, SellerChargePaymentMethod = "Check" },
                    new PDD() { ChargeDescription = "E Recording Fee Misc. description1", BuyerAtClosing = 999999.99, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 999999.99, SellerChargePaymentMethod = "Fee" },
                    new PDD() { ChargeDescription = "E Recording Fee - Release1", BuyerAtClosing = 999999.99, BuyerChargePaymentMethod = "Check", SellerPaidAtClosing = 999999.99, SellerChargePaymentMethod = "Check" },
                }, isTE: false);
                FAST_AddFileFees(new PDD[] { 
                    new PDD() { ChargeDescription = "CD - E Transfer Tax Deed1", BuyerAtClosing = 999999.99, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 999999.99, SellerChargePaymentMethod = "Fee" },
                    new PDD() { ChargeDescription = "CD - Transfer Tax – Miscellaneous", BuyerAtClosing = 999999.99, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 999999.99, SellerChargePaymentMethod = "Fee" },
                    new PDD() { ChargeDescription = "CD - E Transfer Tax – Mortgage", BuyerAtClosing = 999999.99, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 999999.99, SellerChargePaymentMethod = "Fee" },
                }, isTE: false);
                FAST_AddFileFeesFACC(
                    recFees: new string[,] { 
                    { "Assignment", "89", "999999.99" }, 
                    { "Deed", "890", "999999.99" }, 
                    { "Mortgage", "986", "999999.99" }, 
                    { "Satisfaction", "878", "999999.99" }, },
                    summary: new string[,] {  
                    {"ASSIGNMENT - Recording Fee","","273.00","FACC E Recording Fee Misc. description","Seller","Premium Split","999,999.99","10","","899,999.99","100,000.00","999,999.99" }, 
                    {"DEED - Recording Fee","","2,673.00","FACC E Recording Fee Deed","Buyer","Premium Split", "999,999.99","10","","100,000.00","899,999.99","999,999.99" },
                    {"DEED - Documentary Transfer Tax","","1,100.00","FACC E Recording Fee Deed2","Seller","Premium Split","999,999.99","10","","899,999.99","100,000.00","999,999.99"},
                    {"MORTGAGE - Recording Fee","","2,964.00","FACC E Recording Fee Mortgage","Buyer","Premium Split","999,999.99","10","","100,000.00","899,999.99","999,999.99"},
                    {"SATISFACTION - Recording Fee","","2,640.00","FACC E Recording Fee - Release","Buyer","Premium Split","999,999.99","10","","100,000.00","899,999.99","999,999.99"}
                });
                #endregion

                #region Navigate to File Fees and add Title/Escrow Fees
                Reports.TestStep = "Navigate to File Fees and add Title/Escrow Fees";
                FAST_AddFileFees(new PDD[]{
                    new PDD() { ChargeDescription = "Closing Service Coordination", BuyerAtClosing = 999999.99, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 999999.99, SellerChargePaymentMethod = "Fee" },
                    new PDD() { ChargeDescription = "ALTA Extended Loan - 115% liability", BuyerAtClosing = 999999.99, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 999999.99, SellerChargePaymentMethod = "Fee" },
                    new PDD() { ChargeDescription = "New Home Rate (Title Only)", BuyerAtClosing = 999999.99, BuyerChargePaymentMethod = "Fee", SellerPaidAtClosing = 999999.99, SellerChargePaymentMethod = "Fee" }
                });
                FastDriver.BottomFrame.Done();
                Playback.Wait(6000);
                #endregion


                #region Verify File Fees information using GetFeeEntryDetails web service
                Reports.TestStep = "Verify File Fees information using GetFeeEntryDetails web service";
                var details = FileService.GetFeeEntryDetails(File.FileID ?? 0);
                //  Summary Info
                Support.AreEqual("1,999,999.98", ((Decimal)details.FileFeeRecap.Fees.Escrow).ToString("N2"));
                Support.AreEqual("12,999,999.87", ((Decimal)details.FileFeeRecap.Fees.Recording).ToString("N2"));
                Support.AreEqual("3,999,999.96", ((Decimal)details.FileFeeRecap.Fees.Title).ToString("N2"));
                Support.AreEqual("24,999,999.75", ((Decimal)details.FileFeeRecap.Fees.TotalFees).ToString("N2"));
                Support.AreEqual("5,999,999.94", ((Decimal)details.FileFeeRecap.Fees.TransferTax).ToString("N2"));
                //  Title and Escrow
                Support.AreEqual("3", details.TitleAndEscrow.CdFileFees.Count().ToString());
                //  Recording and Tax
                Support.AreEqual("6,099,999.94", ((Decimal)details.RecordingAndTax.GovernmentRecordingAndTransferTaxes.GovernmentCdRecordingCharges.Buyer).ToString("N2"));
                Support.AreEqual("12", details.RecordingAndTax.CdFileFees.Count().ToString());
                Support.AreEqual("12", details.RecordingAndTax.RecordingFeesTranferTaxDisbursement.ChargeDetails.Count().ToString());
                Support.AreEqual("6,999,999.93", ((Decimal)details.RecordingAndTax.RecordingFeesTranferTaxDisbursement.PayeeInformation[0].CheckAmount).ToString("N2"));
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
