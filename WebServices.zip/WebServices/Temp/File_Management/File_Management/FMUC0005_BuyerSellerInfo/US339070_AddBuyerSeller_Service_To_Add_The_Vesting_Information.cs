﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using FASTSelenium.DataObjects;
using Microsoft.Win32;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using OpenQA.Selenium;
using System.Linq;
using System.Collections.Generic;
using FASTWCFHelpers.FastFileService;
using System.Text.RegularExpressions;
using System.Threading;
//using AutoIt;


namespace Web_Services_Regression.File_Management.FMUC0005_BuyerSellerInfo
{
    [CodedUITest]
    public class US339070_AddBuyerSeller_Service_To_Add_The_Vesting_Information : MasterTestClass
    {
        [TestMethod]
        public void US339070_TC818133()
        {
            try
            {
                Reports.TestDescription = "To test US#339070, AddBuyerSeller Service to add the vesting information.";

                Reports.TestStep = " Create a basic file";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1815 SW Marlow Ave";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Portland";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "CA";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Multnomah";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "92701";
                fileRequest.File.Buyers[0].Type = null;
                fileRequest.File.Sellers[0].Type = null;
                fileRequest.Source = "EOS";
                int? FileID = FileService.CreateFile(fileRequest).FileID;

                Reports.TestStep = "";
                var AddBS = new FASTWCFHelpers.FastFileService.AddBuyerSellerRequest();
                AddBS.BuyerSeller.BuyerSellerTypeID = 48;
                AddBS.BuyerSeller.MaritalStatusCdID = 35;
                AddBS.BuyerSeller.VestingTypeCdID = 50;
                AddBS.FileID = (int)FileID;
                AddBS.PrincipalType = "Buyer";
                AddBS.Source = "EOS";


                Reports.TestDescription = "Go to Fast IIS and Verify the Buyer/seller was created.";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers");
                FastDriver.BuyerSellerSummary.BuyerSellerSummaryTable
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }      
        }
    }
}
/*Reports.TestStep = "Click on Run and verify the response";
                var response = EscrowService.UpdateRealEstateBroker(REBrequest);
                Support.AreEqual("REBroker of type BUYER with Sequence No: 1 Updated successfully", response.StatusDescription);
                var test = new FASTWCFHelpers.FastFileService.AddBuyerSellerRequest();*/