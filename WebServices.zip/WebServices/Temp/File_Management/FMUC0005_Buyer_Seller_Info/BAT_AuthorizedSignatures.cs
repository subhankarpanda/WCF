﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.DataObjects;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Linq;

namespace Web_Services_Regression.File_Management.FMUC0005_Buyer_Seller_Info
{
    [CodedUITest]
    public class BAT_AuthorizedSignatures : FASTHelpers
    {
        #region BUYER BAT
        [TestMethod]
        [Description("Retrieve a Buyer's Authorized Signatures")]
        public void BUYER_BAT0001()
        {
            try
            {
                Reports.TestDescription = "Retrieve a Buyer's Authorized Signatures";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Individual Buyer type
                Reports.TestStep = "Request new Individual Buyer type";
                var request = RequestFactory.GetAddBuyerSellerRequest(BuyerSellerTypeOCD.Individual);
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Create Authorized Signature for Individual
                Reports.TestStep = "Create Authorized Signature for Individual";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 1);
                FastDriver.BuyerSellerSetup.Expand(FastDriver.BuyerSellerSetup.IndividualAuthorizeddrop);
                FastDriver.BuyerSellerSetup.IndividualAuthorizedSignatureName.FASetText("test signature");
                FastDriver.BuyerSellerSetup.IndividualApply.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify with GetAuthorizedSignatures web service
                Reports.TestStep = "Verify with GetAuthorizedSignatures web service";
                var details = FileService.GetAuthorizedSignatures(File.FileID ?? 0);
                Support.IsTrue(details.authorizedSignatures.Count() > 0, "authorizedSignatures is not an empty set");
                Support.AreEqual("test signature", details.authorizedSignatures[0].AuthSignatureName, "authorizedSignatures[0].AuthSignatureName");
                Support.AreEqual(AuthorizedSignatureTypeCdID.AttorneyInFact.ToString(), details.authorizedSignatures[0].AuthSignatureTypeCdID.ToString(), "authorizedSignatures[0].AuthSignatureTypeCdID");
                #endregion

                #region Request new HusbandAndWife Buyer type
                Reports.TestStep = "Request new HusbandAndWife Buyer type";
                request = RequestFactory.GetAddBuyerSellerRequest("husband/wife");
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Create Authorized Signature for HusbandAndWife
                Reports.TestStep = "Create Authorized Signature for HusbandAndWife";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 2);
                FastDriver.BuyerSellerSetup.Expand(FastDriver.BuyerSellerSetup.HusbandAuthorizeddrop);
                FastDriver.BuyerSellerSetup.HusbandAuthorizedSignatureName.FASetText("test signature");
                FastDriver.BuyerSellerSetup.HusbandApply.FAClick();
                FastDriver.BuyerSellerSetup.Expand(FastDriver.BuyerSellerSetup.AuthorizedSignatureHusSpouse2Drop);
                FastDriver.BuyerSellerSetup.Husbandspouse2TrusteeName.FASetText("test signature");
                FastDriver.BuyerSellerSetup.HusbandSpouse2Apply.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify with GetAuthorizedSignatures web service
                Reports.TestStep = "Verify with GetAuthorizedSignatures web service";
                details = FileService.GetAuthorizedSignatures(File.FileID ?? 0);
                Support.IsTrue(details.authorizedSignatures.Count() > 2, "authorizedSignatures is not an empty set");
                Support.AreEqual("test signature", details.authorizedSignatures[1].AuthSignatureName, "authorizedSignatures[1].AuthSignatureName");
                Support.AreEqual(AuthorizedSignatureTypeCdID.AttorneyInFact.ToString(), details.authorizedSignatures[1].AuthSignatureTypeCdID.ToString(), "authorizedSignatures[1].AuthSignatureTypeCdID");
                Support.AreEqual("Spouse1", details.authorizedSignatures[1].IsHusbandAndWife, "authorizedSignatures[1].IsHusbandAndWife");
                Support.AreEqual("test signature", details.authorizedSignatures[2].AuthSignatureName, "authorizedSignatures[2].AuthSignatureName");
                Support.AreEqual(AuthorizedSignatureTypeCdID.AttorneyInFact.ToString(), details.authorizedSignatures[2].AuthSignatureTypeCdID.ToString(), "authorizedSignatures[2].AuthSignatureTypeCdID");
                Support.AreEqual("Spouse2", details.authorizedSignatures[2].IsHusbandAndWife, "authorizedSignatures[2].IsHusbandAndWife");
                #endregion

                #region Request new Trust Buyer type
                Reports.TestStep = "Request new Trust Buyer type";
                request = RequestFactory.GetAddBuyerSellerRequest("trust");
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Create Authorized Signature for Trust
                Reports.TestStep = "Create Authorized Signature for Trust";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 3);
                FastDriver.BuyerSellerSetup.TrustNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.TrustAuthorizedName);
                FastDriver.BuyerSellerSetup.TrustAuthorizedName.FASetText("test signature");
                FastDriver.BuyerSellerSetup.TrustAuthorizedType.FASelectItem("Trustee");
                FastDriver.BuyerSellerSetup.TrustApply.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify with GetAuthorizedSignatures web service
                Reports.TestStep = "Verify with GetAuthorizedSignatures web service";
                details = FileService.GetAuthorizedSignatures(File.FileID ?? 0);
                Support.IsTrue(details.authorizedSignatures.Count() > 3, "authorizedSignatures is not an empty set");
                Support.AreEqual("test signature", details.authorizedSignatures[3].AuthSignatureName, "authorizedSignatures[3].AuthSignatureName");
                Support.AreEqual(AuthorizedSignatureTypeCdID.Trustee.ToString(), details.authorizedSignatures[3].AuthSignatureTypeCdID.ToString(), "authorizedSignatures[3].AuthSignatureTypeCdID");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Update a Buyer's Authorized Signatures")]
        public void BUYER_BAT0002()
        {
            try
            {
                Reports.TestDescription = "Update a Buyer's Authorized Signatures";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Individual Buyer type
                Reports.TestStep = "Request new Individual Buyer type";
                var request = RequestFactory.GetAddBuyerSellerRequest(BuyerSellerTypeOCD.Individual);
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Create Authorized Signature for Individual
                Reports.TestStep = "Create Authorized Signature for Individual";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 1);
                FastDriver.BuyerSellerSetup.Expand(FastDriver.BuyerSellerSetup.IndividualAuthorizeddrop);
                FastDriver.BuyerSellerSetup.IndividualAuthorizedSignatureName.FASetText("test signature");
                FastDriver.BuyerSellerSetup.IndividualApply.FAClick();
                FastDriver.BottomFrame.Done();
                var details = FileService.GetAuthorizedSignatures(File.FileID ?? 0);
                Support.IsTrue(details.authorizedSignatures.Count() > 0, "authorizedSignatures is not an empty set");
                #endregion

                #region Update Authorized Signatures for Individual
                Reports.TestStep = "Update Authorized Signatures for Individual";
                var updateReq = RequestFactory.GetAuthorizedSignatureRequest(details.authorizedSignatures[0].PrincipalID);
                updateReq.authorizedSignatures = details.authorizedSignatures;
                updateReq.authorizedSignatures[0].AuthSignatureName = "updated signature";
                updateReq.authorizedSignatures[0].eunmOperationType = FASTWCFHelpers.FastFileService.OperationType.Update;
                var updateResponse = FileService.UpdateAuthorizedSignature(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Request new Husband/Wife Buyer type
                Reports.TestStep = "Request new Husband/Wife Buyer type";
                request = RequestFactory.GetAddBuyerSellerRequest("husband/wife");
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Create Authorized Signature for Husband/Wife
                Reports.TestStep = "Create Authorized Signature for Husband/Wife";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 2);
                FastDriver.BuyerSellerSetup.Expand(FastDriver.BuyerSellerSetup.HusbandAuthorizeddrop);
                FastDriver.BuyerSellerSetup.HusbandAuthorizedSignatureName.FASetText("test signature");
                FastDriver.BuyerSellerSetup.HusbandApply.FAClick();
                FastDriver.BuyerSellerSetup.Expand(FastDriver.BuyerSellerSetup.AuthorizedSignatureHusSpouse2Drop);
                FastDriver.BuyerSellerSetup.Husbandspouse2TrusteeName.FASetText("test signature");
                FastDriver.BuyerSellerSetup.HusbandSpouse2Apply.FAClick();
                FastDriver.BottomFrame.Done();
                details = FileService.GetAuthorizedSignatures(File.FileID ?? 0);
                Support.IsTrue(details.authorizedSignatures.Count() > 1, "authorizedSignatures is not an empty set");
                #endregion

                #region Update Authorized Signatures for Husband/Wife
                Reports.TestStep = "Update Authorized Signatures for Husband/Wife";
                updateReq = RequestFactory.GetAuthorizedSignatureRequest(details.authorizedSignatures[1].PrincipalID);
                updateReq.authorizedSignatures = new AuthorizedSignatures[] { details.authorizedSignatures[1] };
                updateReq.authorizedSignatures[0].AuthSignatureName = "updated signature";
                updateReq.authorizedSignatures[0].eunmOperationType = OperationType.Update;
                updateReq.eSpouseDetail = SpouseDetail.Spouse1;
                updateResponse = FileService.UpdateAuthorizedSignature(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                //
                updateReq = RequestFactory.GetAuthorizedSignatureRequest(details.authorizedSignatures[2].PrincipalID);
                updateReq.authorizedSignatures = new AuthorizedSignatures[] { details.authorizedSignatures[2] };
                updateReq.authorizedSignatures[0].AuthSignatureName = "updated signature";
                updateReq.authorizedSignatures[0].eunmOperationType = OperationType.Update;
                updateReq.eSpouseDetail = SpouseDetail.Spouse2;
                updateResponse = FileService.UpdateAuthorizedSignature(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Request new Trust Buyer type
                Reports.TestStep = "Request new Trust Buyer type";
                request = RequestFactory.GetAddBuyerSellerRequest("trust");
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Create Authorized Signature for Trust
                Reports.TestStep = "Create Authorized Signature for Trust";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 3);
                FastDriver.BuyerSellerSetup.TrustNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.TrustAuthorizedName);
                FastDriver.BuyerSellerSetup.TrustAuthorizedName.FASetText("test signature");
                FastDriver.BuyerSellerSetup.TrustAuthorizedType.FASelectItem("Trustee");
                FastDriver.BuyerSellerSetup.TrustApply.FAClick();
                FastDriver.BottomFrame.Done();
                details = FileService.GetAuthorizedSignatures(File.FileID ?? 0);
                Support.IsTrue(details.authorizedSignatures.Count() > 1, "authorizedSignatures is not an empty set");
                #endregion

                #region Update Authorized Signatures for Trust
                Reports.TestStep = "Update Authorized Signatures for Trust";
                updateReq = RequestFactory.GetAuthorizedSignatureRequest(details.authorizedSignatures[3].PrincipalID);
                updateReq.authorizedSignatures = new AuthorizedSignatures[] { details.authorizedSignatures[3] };
                updateReq.authorizedSignatures[0].AuthSignatureName = "updated signature";
                updateReq.authorizedSignatures[0].eunmOperationType = OperationType.Update;
                updateResponse = FileService.UpdateAuthorizedSignature(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Verify that Authorized Signature is updated in FAST
                Reports.TestStep = "Verify that Authorized Signature is updated in FAST";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true);
                var summaryText = FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.FAGetText();
                Support.Match("1 [A-Za-z/ ]+ updated signature", summaryText);
                Support.Match("2 [A-Za-z/ ]+ updated signature", summaryText);
                Support.Match("3 [A-Za-z/ ]+ updated signature", summaryText);
                Support.Match("4 [A-Za-z/ ]+ updated signature", summaryText);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Retrieve a Buyer's Business Entity Signature")]
        public void BUYER_BAT0003()
        {
            try
            {
                Reports.TestDescription = "Retrieve a Buyer's Business Entity Signature";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Business Entity Buyer type
                Reports.TestStep = "Request new Business Entity Buyer type";
                var request = RequestFactory.GetAddBuyerSellerRequest("business entity");
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Modify the Buyer BS Entity Signature
                Reports.TestStep = "Modify the Buyer BS Entity Signature";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 1);
                FastDriver.BuyerSellerSetup.Signatures.FAClick();
                FastDriver.BuyerSellerEntitySignatures.WaitForScreenToLoad();
                FastDriver.BuyerSellerEntitySignatures.NewAuthorized.FAClick();
                FastDriver.BuyerSellerEntitySignatures.AuthorizedSignatureNameOne.FASetText("test signature");
                FastDriver.BuyerSellerEntitySignatures.AuthorizedSignatureCorpTitleOne.FASetText("test corporate title");
                FastDriver.BuyerSellerEntitySignatures.ApplyAuthorized.FAClick();
                FastDriver.BuyerSellerEntitySignatures.AddNewByEntityDetails("test entity", "", "", "");
                FastDriver.BuyerSellerEntitySignatures.NewAuthorizedSignature.FAClick();
                FastDriver.BuyerSellerEntitySignatures.ByEntityAuthorizedSignatureName.FASetText("test signature");
                FastDriver.BuyerSellerEntitySignatures.ByEntityAuthorizedSignatureCorpTitle.FASetText("test corporate title");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Get BS Entity Signature
                Reports.TestStep = "Get BS Entity Signature";
                var bsEntitySignature = FileService.GetBSEntitySignature(File.FileID ?? 0);
                //Support.AreEqual("1", bsEntitySignature.Status.ToString(), bsEntitySignature.StatusDescription);
                Support.IsTrue(bsEntitySignature.BSEntitySignatures.Count() > 0, "BSEntitySignatures is not an empty set");
                Support.IsTrue(bsEntitySignature.BSEntitySignatures[0].ByEntities.ByEntitySummaries.Count() > 0, "BSEntitySignatures[0].ByEntities.ByEntitySummaries is not an empty set");
                Support.IsTrue(bsEntitySignature.BSEntitySignatures[0].ByEntities.ByEntitySummaries[0].authorizedSignatures.Count() > 0, "BSEntitySignatures[0].ByEntities.ByEntitySummaries[0].authorizedSignatures is not an empty set");
                Support.AreEqual("test signature", bsEntitySignature.BSEntitySignatures[0].ByEntities.ByEntitySummaries[0].authorizedSignatures[0].AuthSignatureName, "BSEntitySignatures[0].ByEntities.ByEntitySummaries[0].authorizedSignatures[0].AuthSignatureName");
                Support.AreEqual("test corporate title", bsEntitySignature.BSEntitySignatures[0].ByEntities.ByEntitySummaries[0].authorizedSignatures[0].OtherTitle, "bsEntitySignature.BSEntitySignatures[0].ByEntities.ByEntitySummaries[0].authorizedSignatures[0].OtherTitle");
                Support.AreEqual("test entity", bsEntitySignature.BSEntitySignatures[0].ByEntities.ByEntitySummaries[0].objEntityOrByEntity.NameOfEntity, "BSEntitySignatures[0].ByEntities.ByEntitySummaries[0].objEntityOrByEntity.NameOfEntity");
                Support.IsTrue(bsEntitySignature.BSEntitySignatures[0].NameEntity.authorizedSignatures.Count() > 0, "BSEntitySignatures[0].NameEntity.authorizedSignatures is not an empty set");
                Support.AreEqual("test signature", bsEntitySignature.BSEntitySignatures[0].NameEntity.authorizedSignatures[0].AuthSignatureName, "BSEntitySignatures[0].NameEntity.authorizedSignatures[0].AuthSignatureName");
                Support.AreEqual("test corporate title", bsEntitySignature.BSEntitySignatures[0].NameEntity.authorizedSignatures[0].OtherTitle, "bsEntitySignature.BSEntitySignatures[0].NameEntity.authorizedSignatures[0].OtherTitle");
                Support.AreEqual("BusinessEntity", bsEntitySignature.BSEntitySignatures[0].NameEntity.objEntityOrByEntity.NameOfEntity, "BSEntitySignatures[0].NameEntity.objEntityOrByEntity.NameOfEntity");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region SELLER BAT
        [TestMethod]
        [Description("Retrieve a Seller's Authorized Signatures")]
        public void SELLER_BAT0001()
        {
            try
            {
                Reports.TestDescription = "Retrieve a Seller's Authorized Signatures";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Individual Seller type
                Reports.TestStep = "Request new Individual Seller type";
                var request = RequestFactory.GetAddBuyerSellerRequest(BuyerSellerTypeOCD.Individual);
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Create Authorized Signature for Individual
                Reports.TestStep = "Create Authorized Signature for Individual";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false, index: 1);
                FastDriver.BuyerSellerSetup.Expand(FastDriver.BuyerSellerSetup.IndividualAuthorizeddrop);
                FastDriver.BuyerSellerSetup.IndividualAuthorizedSignatureName.FASetText("test signature");
                FastDriver.BuyerSellerSetup.IndividualApply.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify with GetAuthorizedSignatures web service
                Reports.TestStep = "Verify with GetAuthorizedSignatures web service";
                var details = FileService.GetAuthorizedSignatures(File.FileID ?? 0);
                Support.IsTrue(details.authorizedSignatures.Count() > 0, "authorizedSignatures is not an empty set");
                Support.AreEqual("test signature", details.authorizedSignatures[0].AuthSignatureName, "authorizedSignatures[0].AuthSignatureName");
                Support.AreEqual(AuthorizedSignatureTypeCdID.AttorneyInFact.ToString(), details.authorizedSignatures[0].AuthSignatureTypeCdID.ToString(), "authorizedSignatures[0].AuthSignatureTypeCdID");
                #endregion

                #region Request new HusbandAndWife Seller type
                Reports.TestStep = "Request new HusbandAndWife Seller type";
                request = RequestFactory.GetAddBuyerSellerRequest("husband/wife");
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Create Authorized Signature for HusbandAndWife
                Reports.TestStep = "Create Authorized Signature for HusbandAndWife";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false, index: 2);
                FastDriver.BuyerSellerSetup.Expand(FastDriver.BuyerSellerSetup.HusbandAuthorizeddrop);
                FastDriver.BuyerSellerSetup.HusbandAuthorizedSignatureName.FASetText("test signature");
                FastDriver.BuyerSellerSetup.HusbandApply.FAClick();
                FastDriver.BuyerSellerSetup.Expand(FastDriver.BuyerSellerSetup.AuthorizedSignatureHusSpouse2Drop);
                FastDriver.BuyerSellerSetup.Husbandspouse2TrusteeName.FASetText("test signature");
                FastDriver.BuyerSellerSetup.HusbandSpouse2Apply.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify with GetAuthorizedSignatures web service
                Reports.TestStep = "Verify with GetAuthorizedSignatures web service";
                details = FileService.GetAuthorizedSignatures(File.FileID ?? 0);
                Support.IsTrue(details.authorizedSignatures.Count() > 2, "authorizedSignatures is not an empty set");
                Support.AreEqual("test signature", details.authorizedSignatures[1].AuthSignatureName, "authorizedSignatures[1].AuthSignatureName");
                Support.AreEqual(AuthorizedSignatureTypeCdID.AttorneyInFact.ToString(), details.authorizedSignatures[1].AuthSignatureTypeCdID.ToString(), "authorizedSignatures[1].AuthSignatureTypeCdID");
                Support.AreEqual("Spouse1", details.authorizedSignatures[1].IsHusbandAndWife, "authorizedSignatures[1].IsHusbandAndWife");
                Support.AreEqual("test signature", details.authorizedSignatures[2].AuthSignatureName, "authorizedSignatures[2].AuthSignatureName");
                Support.AreEqual(AuthorizedSignatureTypeCdID.AttorneyInFact.ToString(), details.authorizedSignatures[2].AuthSignatureTypeCdID.ToString(), "authorizedSignatures[2].AuthSignatureTypeCdID");
                Support.AreEqual("Spouse2", details.authorizedSignatures[2].IsHusbandAndWife, "authorizedSignatures[2].IsHusbandAndWife");
                #endregion

                #region Request new Trust Seller type
                Reports.TestStep = "Request new Trust Seller type";
                request = RequestFactory.GetAddBuyerSellerRequest("trust");
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Create Authorized Signature for Trust
                Reports.TestStep = "Create Authorized Signature for Trust";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false, index: 3);
                FastDriver.BuyerSellerSetup.TrustNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.TrustAuthorizedName);
                FastDriver.BuyerSellerSetup.TrustAuthorizedName.FASetText("test signature");
                FastDriver.BuyerSellerSetup.TrustAuthorizedType.FASelectItem("Trustee");
                FastDriver.BuyerSellerSetup.TrustApply.FAClick();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify with GetAuthorizedSignatures web service
                Reports.TestStep = "Verify with GetAuthorizedSignatures web service";
                details = FileService.GetAuthorizedSignatures(File.FileID ?? 0);
                Support.IsTrue(details.authorizedSignatures.Count() > 3, "authorizedSignatures is not an empty set");
                Support.AreEqual("test signature", details.authorizedSignatures[3].AuthSignatureName, "authorizedSignatures[3].AuthSignatureName");
                Support.AreEqual(AuthorizedSignatureTypeCdID.Trustee.ToString(), details.authorizedSignatures[3].AuthSignatureTypeCdID.ToString(), "authorizedSignatures[3].AuthSignatureTypeCdID");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Update a Seller's Authorized Signatures")]
        public void SELLER_BAT0002()
        {
            try
            {
                Reports.TestDescription = "Update a Seller's Authorized Signatures";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Individual Seller type
                Reports.TestStep = "Request new Individual Seller type";
                var request = RequestFactory.GetAddBuyerSellerRequest(BuyerSellerTypeOCD.Individual);
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Create Authorized Signature for Individual
                Reports.TestStep = "Create Authorized Signature for Individual";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false, index: 1);
                FastDriver.BuyerSellerSetup.Expand(FastDriver.BuyerSellerSetup.IndividualAuthorizeddrop);
                FastDriver.BuyerSellerSetup.IndividualAuthorizedSignatureName.FASetText("test signature");
                FastDriver.BuyerSellerSetup.IndividualApply.FAClick();
                FastDriver.BottomFrame.Done();
                var details = FileService.GetAuthorizedSignatures(File.FileID ?? 0);
                Support.IsTrue(details.authorizedSignatures.Count() > 0, "authorizedSignatures is not an empty set");
                #endregion

                #region Update Authorized Signatures for Individual
                Reports.TestStep = "Update Authorized Signatures for Individual";
                var updateReq = RequestFactory.GetAuthorizedSignatureRequest(details.authorizedSignatures[0].PrincipalID);
                updateReq.authorizedSignatures = details.authorizedSignatures;
                updateReq.authorizedSignatures[0].AuthSignatureName = "updated signature";
                updateReq.authorizedSignatures[0].eunmOperationType = OperationType.Update;
                var updateResponse = FileService.UpdateAuthorizedSignature(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Request new Husband/Wife Seller type
                Reports.TestStep = "Request new Husband/Wife Seller type";
                request = RequestFactory.GetAddBuyerSellerRequest("husband/wife");
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Create Authorized Signature for Husband/Wife
                Reports.TestStep = "Create Authorized Signature for Husband/Wife";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false, index: 2);
                FastDriver.BuyerSellerSetup.Expand(FastDriver.BuyerSellerSetup.HusbandAuthorizeddrop);
                FastDriver.BuyerSellerSetup.HusbandAuthorizedSignatureName.FASetText("test signature");
                FastDriver.BuyerSellerSetup.HusbandApply.FAClick();
                FastDriver.BuyerSellerSetup.Expand(FastDriver.BuyerSellerSetup.AuthorizedSignatureHusSpouse2Drop);
                FastDriver.BuyerSellerSetup.Husbandspouse2TrusteeName.FASetText("test signature");
                FastDriver.BuyerSellerSetup.HusbandSpouse2Apply.FAClick();
                FastDriver.BottomFrame.Done();
                details = FileService.GetAuthorizedSignatures(File.FileID ?? 0);
                Support.IsTrue(details.authorizedSignatures.Count() > 1, "authorizedSignatures is not an empty set");
                #endregion

                #region Update Authorized Signatures for Husband/Wife
                Reports.TestStep = "Update Authorized Signatures for Husband/Wife";
                updateReq = RequestFactory.GetAuthorizedSignatureRequest(details.authorizedSignatures[1].PrincipalID);
                updateReq.authorizedSignatures = new AuthorizedSignatures[] { details.authorizedSignatures[1] };
                updateReq.authorizedSignatures[0].AuthSignatureName = "updated signature";
                updateReq.authorizedSignatures[0].eunmOperationType = OperationType.Update;
                updateReq.eSpouseDetail = SpouseDetail.Spouse1;
                updateResponse = FileService.UpdateAuthorizedSignature(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                //
                updateReq = RequestFactory.GetAuthorizedSignatureRequest(details.authorizedSignatures[2].PrincipalID);
                updateReq.authorizedSignatures = new AuthorizedSignatures[] { details.authorizedSignatures[2] };
                updateReq.authorizedSignatures[0].AuthSignatureName = "updated signature";
                updateReq.authorizedSignatures[0].eunmOperationType = OperationType.Update;
                updateReq.eSpouseDetail = SpouseDetail.Spouse2;
                updateResponse = FileService.UpdateAuthorizedSignature(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Request new Trust Buyer type
                Reports.TestStep = "Request new Trust Buyer type";
                request = RequestFactory.GetAddBuyerSellerRequest("trust");
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Create Authorized Signature for Trust
                Reports.TestStep = "Create Authorized Signature for Trust";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false, index: 3);
                FastDriver.BuyerSellerSetup.TrustNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitCreation(FastDriver.BuyerSellerSetup.TrustAuthorizedName);
                FastDriver.BuyerSellerSetup.TrustAuthorizedName.FASetText("test signature");
                FastDriver.BuyerSellerSetup.TrustAuthorizedType.FASelectItem("Trustee");
                FastDriver.BuyerSellerSetup.TrustApply.FAClick();
                FastDriver.BottomFrame.Done();
                details = FileService.GetAuthorizedSignatures(File.FileID ?? 0);
                Support.IsTrue(details.authorizedSignatures.Count() > 1, "authorizedSignatures is not an empty set");
                #endregion

                #region Update Authorized Signatures for Trust
                Reports.TestStep = "Update Authorized Signatures for Trust";
                updateReq = RequestFactory.GetAuthorizedSignatureRequest(details.authorizedSignatures[3].PrincipalID);
                updateReq.authorizedSignatures = new AuthorizedSignatures[] { details.authorizedSignatures[3] };
                updateReq.authorizedSignatures[0].AuthSignatureName = "updated signature";
                updateReq.authorizedSignatures[0].eunmOperationType = OperationType.Update;
                updateResponse = FileService.UpdateAuthorizedSignature(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Verify that Authorized Signature is updated in FAST
                Reports.TestStep = "Verify that Authorized Signature is updated in FAST";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false);
                var summaryText = FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.FAGetText();
                Support.Match("1 [A-Za-z/ ]+ updated signature", summaryText);
                Support.Match("2 [A-Za-z/ ]+ updated signature", summaryText);
                Support.Match("3 [A-Za-z/ ]+ updated signature", summaryText);
                Support.Match("4 [A-Za-z/ ]+ updated signature", summaryText);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Retrieve a Seller's Business Entity Signature")]
        public void SELLER_BAT0003()
        {
            try
            {
                Reports.TestDescription = "Retrieve a Seller's Business Entity Signature";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Business Entity Seller type
                Reports.TestStep = "Request new Business Entity Seller type";
                var request = RequestFactory.GetAddBuyerSellerRequest("business entity");
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Modify the Seller BS Entity Signature
                Reports.TestStep = "Modify the Seller BS Entity Signature";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false, index: 1);
                FastDriver.BuyerSellerSetup.Signatures.FAClick();
                FastDriver.BuyerSellerEntitySignatures.WaitForScreenToLoad();
                FastDriver.BuyerSellerEntitySignatures.NewAuthorized.FAClick();
                FastDriver.BuyerSellerEntitySignatures.AuthorizedSignatureNameOne.FASetText("test signature");
                FastDriver.BuyerSellerEntitySignatures.AuthorizedSignatureCorpTitleOne.FASetText("test corporate title");
                FastDriver.BuyerSellerEntitySignatures.ApplyAuthorized.FAClick();
                FastDriver.BuyerSellerEntitySignatures.AddNewByEntityDetails("test entity", "", "", "");
                FastDriver.BuyerSellerEntitySignatures.NewAuthorizedSignature.FAClick();
                FastDriver.BuyerSellerEntitySignatures.ByEntityAuthorizedSignatureName.FASetText("test signature");
                FastDriver.BuyerSellerEntitySignatures.ByEntityAuthorizedSignatureCorpTitle.FASetText("test corporate title");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Get BS Entity Signature
                Reports.TestStep = "Get BS Entity Signature";
                var bsEntitySignature = FileService.GetBSEntitySignature(File.FileID ?? 0);
                //Support.AreEqual("1", bsEntitySignature.Status.ToString(), bsEntitySignature.StatusDescription);
                Support.IsTrue(bsEntitySignature.BSEntitySignatures.Count() > 0, "BSEntitySignatures is not an empty set");
                Support.IsTrue(bsEntitySignature.BSEntitySignatures[0].ByEntities.ByEntitySummaries.Count() > 0, "BSEntitySignatures[0].ByEntities.ByEntitySummaries is not an empty set");
                Support.IsTrue(bsEntitySignature.BSEntitySignatures[0].ByEntities.ByEntitySummaries[0].authorizedSignatures.Count() > 0, "BSEntitySignatures[0].ByEntities.ByEntitySummaries[0].authorizedSignatures is not an empty set");
                Support.AreEqual("test signature", bsEntitySignature.BSEntitySignatures[0].ByEntities.ByEntitySummaries[0].authorizedSignatures[0].AuthSignatureName, "BSEntitySignatures[0].ByEntities.ByEntitySummaries[0].authorizedSignatures[0].AuthSignatureName");
                Support.AreEqual("test corporate title", bsEntitySignature.BSEntitySignatures[0].ByEntities.ByEntitySummaries[0].authorizedSignatures[0].OtherTitle, "BSEntitySignatures[0].ByEntities.ByEntitySummaries[0].authorizedSignatures[0].OtherTitle");
                Support.AreEqual("test entity", bsEntitySignature.BSEntitySignatures[0].ByEntities.ByEntitySummaries[0].objEntityOrByEntity.NameOfEntity, "BSEntitySignatures[0].ByEntities.ByEntitySummaries[0].objEntityOrByEntity.NameOfEntity");
                Support.IsTrue(bsEntitySignature.BSEntitySignatures[0].NameEntity.authorizedSignatures.Count() > 0, "BSEntitySignatures[0].NameEntity.authorizedSignatures is not an empty set");
                Support.AreEqual("test signature", bsEntitySignature.BSEntitySignatures[0].NameEntity.authorizedSignatures[0].AuthSignatureName, "BSEntitySignatures[0].NameEntity.authorizedSignatures[0].AuthSignatureName");
                Support.AreEqual("test corporate title", bsEntitySignature.BSEntitySignatures[0].NameEntity.authorizedSignatures[0].OtherTitle, "BSEntitySignatures[0].NameEntity.authorizedSignatures[0].OtherTitle");
                Support.AreEqual("BusinessEntity", bsEntitySignature.BSEntitySignatures[0].NameEntity.objEntityOrByEntity.NameOfEntity, "BSEntitySignatures[0].NameEntity.objEntityOrByEntity.NameOfEntity");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region BUYER SELLER BAT
        [TestMethod]
        [Description("Retrieve a Buyer & Seller's Authorized Signatures Types")]
        public void BUYER_SELLER_BAT0001()
        {
            try
            {
                Reports.TestDescription = "Retrieve a Buyer & Seller's Authorized Signatures Types";

                #region get all authorized signature types
                Reports.TestStep = "get all authorized signature types";
                var request = RequestFactory.GetBuyerSellerSignaturesTypesRequest();
                var types = FileService.GetBuyerSellerAuthorizedSignatureType(request);
                Support.AreEqual("1", types.Status.ToString(), types.StatusDescription);
                #endregion

                #region verify authorized signature types
                Reports.TestStep = "verify authorized signature types";
                VerifyIndividualSignatureTypes(AuthorizedSignatureTypes.Individual, types.IndividualSignatureTypes);
                VerifyHusbandWifeSignatureTypes(AuthorizedSignatureTypes.HusbandWife, types.HusbandWifeSignatureTypes);
                VerifyTrustEstateSignatureTypes(AuthorizedSignatureTypes.Trustee, types.TrustEstateSignatureTypes);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region Private Members
        private void VerifyIndividualSignatureTypes(IndividualSignatureType[] expectedTypes, IndividualSignatureType[] receivedTypes)
        {
            Support.AreEqual(expectedTypes.Count().ToString(), receivedTypes.Count().ToString(), "expected IndividualSignatureTypes size");
            for (int i = 0; i < expectedTypes.Count(); i++)
            {
                Support.AreEqual(expectedTypes[i].Description, receivedTypes[i].Description, "Description");
                Support.AreEqual(expectedTypes[i].ObjectCD, receivedTypes[i].ObjectCD, "ObjectCD");
                Support.AreEqual(expectedTypes[i].TypeCdID.ToString(), receivedTypes[i].TypeCdID.ToString(), "TypeCdID");
            }
        }

        private void VerifyHusbandWifeSignatureTypes(HusbandWifeSignatureType[] expectedTypes, HusbandWifeSignatureType[] receivedTypes)
        {
            Support.AreEqual(expectedTypes.Count().ToString(), receivedTypes.Count().ToString(), "expected HusbandWifeSignatureTypes size");
            for (int i = 0; i < expectedTypes.Count(); i++)
            {
                Support.AreEqual(expectedTypes[i].Description, receivedTypes[i].Description, "Description");
                Support.AreEqual(expectedTypes[i].ObjectCD, receivedTypes[i].ObjectCD, "ObjectCD");
                Support.AreEqual(expectedTypes[i].TypeCdID.ToString(), receivedTypes[i].TypeCdID.ToString(), "TypeCdID");
            }
        }

        private void VerifyTrustEstateSignatureTypes(TrustEstateSignatureType[] expectedTypes, TrustEstateSignatureType[] receivedTypes)
        {
            Support.AreEqual(expectedTypes.Count().ToString(), receivedTypes.Count().ToString(), "expected TrustEstateSignatureTypes size");
            for (int i = 0; i < expectedTypes.Count(); i++)
            {
                Support.AreEqual(expectedTypes[i].Description, receivedTypes[i].Description, "Description");
                Support.AreEqual(expectedTypes[i].ObjectCD, receivedTypes[i].ObjectCD, "ObjectCD");
                Support.AreEqual(expectedTypes[i].TypeCdID.ToString(), receivedTypes[i].TypeCdID.ToString(), "TypeCdID");
            }
        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
