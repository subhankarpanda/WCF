﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.DataObjects;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Linq;

namespace Web_Services_Regression.File_Management.FMUC0005_Buyer_Seller_Info
{
    [CodedUITest]
    public class BAT_UpdateBuyerSeller : FASTHelpers
    {
        #region BUYER BAT
        [TestMethod]
        [Description("Update Individual Buyer")]
        public void BUYER_BAT0001()
        {
            try
            {
                Reports.TestDescription = "Update Individual Buyer";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Individual Buyer type
                Reports.TestStep = "Request new Individual Buyer type";
                var request = RequestFactory.GetAddBuyerSellerRequest(BuyerSellerTypeOCD.Individual);
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Update the newly created instance
                Reports.TestStep = "Update the newly created instance";
                var updateReq = GetIndividualBuyerSellerRequest();
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.Individual;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Validate Individual Buyer details
                Reports.TestStep = "Validate Individual Buyer details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 1);
                ValidateIndividualBuyerSeller(updateReq);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Update Husband/Wife Buyer")]
        public void BUYER_BAT0002()
        {
            try
            {
                Reports.TestDescription = "Update Husband/Wife Buyer";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Husband/Wife Buyer type
                Reports.TestStep = "Request new Husband/Wife Buyer type";
                var request = RequestFactory.GetAddBuyerSellerRequest("husband/wife");
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Update the newly created instance
                Reports.TestStep = "Update the newly created instance";
                var updateReq = GetHusbandWifeBuyerSellerRequest();
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.HusbandAndWife;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Validate Husband/Wife Buyer details
                Reports.TestStep = "Validate Husband/Wife Buyer details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 1);
                ValidateHusbandWifeBuyerSeller(updateReq);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Update Trust/Estate Buyer")]
        public void BUYER_BAT0003()
        {
            try
            {
                Reports.TestDescription = "Update Trust/Estate Buyer";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Trust/Estate Buyer type
                Reports.TestStep = "Request new Trust/Estate Buyer type";
                var request = RequestFactory.GetAddBuyerSellerRequest("trust");
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Update the newly created instance
                Reports.TestStep = "Update the newly created instance";
                var updateReq = GetTrustEstateBuyerSellerRequest();
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.TrustEstate;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Validate Trust/Estate Buyer details
                Reports.TestStep = "Validate Trust/Estate Buyer details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 1);
                ValidateTrustEstateBuyerSeller(updateReq);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Update Business Trust Buyer")]
        public void BUYER_BAT0004()
        {
            try
            {
                Reports.TestDescription = "Update Business Trust Buyer";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Business Trust Buyer type
                Reports.TestStep = "Request new Business Trust Buyer type";
                var request = RequestFactory.GetAddBuyerSellerRequest("business entity");
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Update the newly created instance
                Reports.TestStep = "Update the newly created instance";
                var updateReq = GetBusinessTrustBuyerSellerRequest();
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.BusinessEntity;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Validate Business Trust Buyer details
                Reports.TestStep = "Validate Business Trust Buyer details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 1);
                ValidateBusinessBuyerSeller(updateReq);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Modify Buyer types")]
        public void BUYER_BAT0005()
        {
            try
            {
                Reports.TestDescription = "Modify Buyer types";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Individual Buyer type
                Reports.TestStep = "Request new Individual Buyer type";
                var request = RequestFactory.GetAddBuyerSellerRequest(BuyerSellerTypeOCD.Individual);
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Change Buyer instance to Husband/Wife
                Reports.TestStep = "Change Buyer instance to Husband/Wife";
                var updateReq = GetHusbandWifeBuyerSellerRequest();
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.HusbandAndWife;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Change Buyer instance to Trust/Estate
                Reports.TestStep = "Change Buyer instance to Trust/Estate";
                updateReq = GetTrustEstateBuyerSellerRequest();
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.TrustEstate;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Change Buyer instance to Business Trust
                Reports.TestStep = "Change Buyer instance to Business Trust";
                updateReq = GetTrustEstateBuyerSellerRequest();
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.BusinessEntity;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Change Buyer instance to Trust/Estate
                Reports.TestStep = "Change Buyer instance to Trust/Estate";
                updateReq = GetTrustEstateBuyerSellerRequest();
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.TrustEstate;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Change Buyer instance to Husband/Wife
                Reports.TestStep = "Change Buyer instance to Husband/Wife";
                updateReq = GetHusbandWifeBuyerSellerRequest();
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.HusbandAndWife;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Change Buyer instance to Individual
                Reports.TestStep = "Change Buyer instance to Individual";
                updateReq = GetIndividualBuyerSellerRequest();
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.Individual;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Validate Individual Buyer details
                Reports.TestStep = "Validate Individual Buyer details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 1);
                ValidateIndividualBuyerSeller(updateReq);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        
        #endregion

        #region SELLER BAT
        [TestMethod]
        [Description("Update Individual Seller")]
        public void SELLER_BAT0001()
        {
            try
            {
                Reports.TestDescription = "Update Individual Seller";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Individual Seller type
                Reports.TestStep = "Request new Individual Seller type";
                var request = RequestFactory.GetAddBuyerSellerRequest("individual");
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Update the newly created instance
                Reports.TestStep = "Update the newly created instance";
                var updateReq = GetIndividualBuyerSellerRequest();
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.Individual;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Validate Individual Seller details
                Reports.TestStep = "Validate Individual Seller details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false, index: 1);
                ValidateIndividualBuyerSeller(updateReq);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Update Husband/Wife Seller")]
        public void SELLER_BAT0002()
        {
            try
            {
                Reports.TestDescription = "Update Husband/Wife Seller";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Husband/Wife Seller type
                Reports.TestStep = "Request new Husband/Wife Seller type";
                var request = RequestFactory.GetAddBuyerSellerRequest("husband/wife");
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Update the newly created instance
                Reports.TestStep = "Update the newly created instance";
                var updateReq = GetHusbandWifeBuyerSellerRequest();
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.HusbandAndWife;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Validate Husband/Wife Seller details
                Reports.TestStep = "Validate Husband/Wife Seller details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false, index: 1);
                ValidateHusbandWifeBuyerSeller(updateReq);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Update Trust/Estate Seller")]
        public void SELLER_BAT0003()
        {
            try
            {
                Reports.TestDescription = "Update Trust/Estate Seller";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Trust/Estate Seller type
                Reports.TestStep = "Request new Trust/Estate Seller type";
                var request = RequestFactory.GetAddBuyerSellerRequest("trust");
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Update the newly created instance
                Reports.TestStep = "Update the newly created instance";
                var updateReq = GetTrustEstateBuyerSellerRequest();
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.TrustEstate;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Validate Trust/Estate Seller details
                Reports.TestStep = "Validate Trust/Estate Seller details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false, index: 1);
                ValidateTrustEstateBuyerSeller(updateReq);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Update Business Trust Seller")]
        public void SELLER_BAT0004()
        {
            try
            {
                Reports.TestDescription = "Update Business Trust Seller";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Business Trust Seller type
                Reports.TestStep = "Request new Business Trust Seller type";
                var request = RequestFactory.GetAddBuyerSellerRequest("business entity");
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Update the newly created instance
                Reports.TestStep = "Update the newly created instance";
                var updateReq = GetBusinessTrustBuyerSellerRequest();
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.BusinessEntity;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Validate Business Trust Seller details
                Reports.TestStep = "Validate Business Trust Seller details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false, index: 1);
                ValidateBusinessBuyerSeller(updateReq);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        
        [TestMethod]
        [Description("Modify Seller types")]
        public void SELLER_BAT0005()
        {
            try
            {
                Reports.TestDescription = "Modify Seller types";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Individual Seller type
                Reports.TestStep = "Request new Individual Seller type";
                var request = RequestFactory.GetAddBuyerSellerRequest(BuyerSellerTypeOCD.Individual);
                request.FileID = File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Change Seller instance to Husband/Wife
                Reports.TestStep = "Change Seller instance to Husband/Wife";
                var updateReq = GetHusbandWifeBuyerSellerRequest();
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.HusbandAndWife;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Change Seller instance to Trust/Estate
                Reports.TestStep = "Change Seller instance to Trust/Estate";
                updateReq = GetTrustEstateBuyerSellerRequest();
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.TrustEstate;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Change Seller instance to Business Trust
                Reports.TestStep = "Change Seller instance to Business Trust";
                updateReq = GetTrustEstateBuyerSellerRequest();
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.BusinessEntity;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Change Seller instance to Trust/Estate
                Reports.TestStep = "Change Seller instance to Trust/Estate";
                updateReq = GetTrustEstateBuyerSellerRequest();
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.TrustEstate;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Change Seller instance to Husband/Wife
                Reports.TestStep = "Change Seller instance to Husband/Wife";
                updateReq = GetHusbandWifeBuyerSellerRequest();
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.HusbandAndWife;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Change Seller instance to Individual
                Reports.TestStep = "Change Seller instance to Individual";
                updateReq = GetIndividualBuyerSellerRequest();
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.Individual;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Validate Individual Seller details
                Reports.TestStep = "Validate Individual Seller details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false, index: 1);
                ValidateIndividualBuyerSeller(updateReq);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
                
        #endregion

        #region Private Methods
        private UpdateBuyerSellerRequest GetBuyerSellerRequest()
        {
            var request = RequestFactory.GetUpdateBuyerSellerRequest(BuyerSellerTypeOCD.Individual);
            request.FileID = File.FileID ?? 0;
            request.BuyerSeller.SeqNum = 1;
            request.BuyerSeller.CurrentAddress = new FASTWCFHelpers.FastFileService.BuyerSellerAddress()
            {
                AddrLine1 = "CurrentAddress",
                AddrLine2 = "street line 2",
                AddrLine3 = "street line 3",
                AddrLine4 = "street line 4",
                BuyerSellerAddressTypeCdID = 80,
                City = "CurrentCity",
                Country = "USA",
                County = "Orange",
                State = "CA",
                Zip = "92130"
            };
            request.BuyerSeller.ForwardingAddress = new FASTWCFHelpers.FastFileService.BuyerSellerAddress()
            {
                AddrLine1 = "CurrentAddress",
                AddrLine2 = "street line 2",
                AddrLine3 = "street line 3",
                AddrLine4 = "street line 4",
                BuyerSellerAddressTypeCdID = 80,
                City = "CurrentCity",
                Country = "USA",
                County = "Orange",
                State = "CA",
                Zip = "92130"
            };
            request.BuyerSeller.ContactAddresses = new FASTWCFHelpers.FastFileService.ContactAddress[]
            {
                new FASTWCFHelpers.FastFileService.ContactAddress()
                {
                    ContextTypeCdID = ContextTypeCdID.Current,
                    Value = "(991)889-8383",
                    TypeCdID = ContactAddressTypeCdID.HomePhone,
                },
                new FASTWCFHelpers.FastFileService.ContactAddress()
                {
                    ContextTypeCdID = ContextTypeCdID.Forwarding,
                    Value = "(991)889-8383",
                    TypeCdID = ContactAddressTypeCdID.HomePhone,
                }
            };

            return request;
        }

        private UpdateBuyerSellerRequest GetIndividualBuyerSellerRequest()
        {
            var request = GetBuyerSellerRequest();
            request.BuyerSeller.LoanApplicant = true;
            request.BuyerSeller.FirstName = "John";
            request.BuyerSeller.MiddleName = "Peter";
            request.BuyerSeller.LastName = "Colwyn";
            request.BuyerSeller.Suffix = "Jr.";
            request.BuyerSeller.SSN = "123456789";
            request.BuyerSeller.MaritalStatusCdID = BuyerSellerMaritalStatusCdID.SingleMan;
            request.BuyerSeller.VestingTypeCdID = BuyerSellerVestingCdID.ToBeDetermined;
            request.BuyerSeller.Salutation = "Dear Maestro";

            return request;
        }

        private UpdateBuyerSellerRequest GetHusbandWifeBuyerSellerRequest()
        {
            var request = GetBuyerSellerRequest();
            request.BuyerSeller.LoanApplicant = true;
            request.BuyerSeller.SpouseLoanApplicant = false;
            request.BuyerSeller.FirstName = "John";
            request.BuyerSeller.MiddleName = "Peter";
            request.BuyerSeller.LastName = "Colwyn";
            request.BuyerSeller.Suffix = "Jr.";
            request.BuyerSeller.SSN = "123456789";
            request.BuyerSeller.MaritalStatusCdID = BuyerSellerMaritalStatusCdID.MarriedMan;
            request.BuyerSeller.VestingTypeCdID = BuyerSellerVestingCdID.ToBeDetermined;
            request.BuyerSeller.Salutation = "Dear Mr. & Mrs. Colwyn";
            request.BuyerSeller.SpouseFirstName = "Linda";
            request.BuyerSeller.SpouseMiddleName = "Elizabeth";
            request.BuyerSeller.SpouseLastName = "Colwyn";
            request.BuyerSeller.SpouseSuffix = "1st";
            request.BuyerSeller.SpouseSSN = "123456781";

            return request;
        }

        private UpdateBuyerSellerRequest GetTrustEstateBuyerSellerRequest()
        {
            var request = GetBuyerSellerRequest();
            request.BuyerSeller.LoanApplicant = true;
            request.BuyerSeller.ShortName = "FAST Trust";
            request.BuyerSeller.Dated = DateTime.Today.AddYears(-1);
            request.BuyerSeller.TrustNumber = "12345678";
            request.BuyerSeller.SSN = "123456789";
            request.BuyerSeller.Salutation = "FAST Trust and Associates";

            return request;
        }

        private UpdateBuyerSellerRequest GetBusinessTrustBuyerSellerRequest()
        {
            var request = GetBuyerSellerRequest();
            request.BuyerSeller.LoanApplicant = false;
            request.BuyerSeller.ShortName = "FAST Business Trust";
            request.BuyerSeller.SSN = "123456789";
            request.BuyerSeller.Salutation = "FAST Trust and Associates";
            request.BuyerSeller.StateOfIncorporationID = BuyerSellerStateOfIncorporationCdID.California;
            request.BuyerSeller.EntityTypeID = BuyerSellerEntityTypeCdID.BusinessTrust;

            return request;
        }

        private void ValidateIndividualBuyerSeller(UpdateBuyerSellerRequest request)
        {
            var IndvidByrDictry = FastDriver.BuyerSellerSetup.GetIndivByrDtls;
            Support.AreEqual(request.BuyerSeller.FirstName, IndvidByrDictry["Indi First Name"], "Indi First Name");
            Support.AreEqual(request.BuyerSeller.MiddleName, IndvidByrDictry["Indi Middle Name"], "Indi Middle Name");
            Support.AreEqual(request.BuyerSeller.LastName, IndvidByrDictry["Indi Last Name"], "Indi Last Name");
            Support.AreEqual(request.BuyerSeller.Suffix, IndvidByrDictry["Indi Sufix"], "Indi Sufix");
            Support.AreEqual(request.BuyerSeller.SSN, IndvidByrDictry["Indi Ssn"].Replace("-", ""), "Indi Ssn");
            if (request.PrincipalType == BuyerSellerPrincipalTypeOCD.Buyer)
            {
                Support.AreEqual(request.BuyerSeller.LoanApplicant.ToString().ToLowerInvariant(), IndvidByrDictry["LoanApplicant"], "Loan Applicant");
            }
            //
            var VestiNSalutDictry = FastDriver.BuyerSellerSetup.GetIndiviVestgNdSalutio;
            Support.AreEqual("a single man", VestiNSalutDictry["Marital Status"], "Marital Status");
            Support.AreEqual(string.IsNullOrEmpty(VestiNSalutDictry["Vesting"]) ? "":"(vesting to be determined)", VestiNSalutDictry["Vesting"], "Vesting");
            Support.AreEqual(string.IsNullOrEmpty(VestiNSalutDictry["Addl Vesting"]) ? "":"Full Vesting", VestiNSalutDictry["Addl Vesting"], "Addl Vesting");
            Support.AreEqual("", VestiNSalutDictry["Misc Ref 1"], "Misc Ref 1");
            Support.AreEqual("", VestiNSalutDictry["Misc Ref 2"], "Misc Ref 2");
            //
            ValidateAddressAndContactDetails(request);
        }

        private void ValidateHusbandWifeBuyerSeller(UpdateBuyerSellerRequest request)
        {
            var HuWfAndVestDictry = FastDriver.BuyerSellerSetup.GetHusWfDtlsAuthSign(false);
            Support.AreEqual(request.BuyerSeller.FirstName, HuWfAndVestDictry["Husband1FirstName"], "Husband1FirstName");
            Support.AreEqual(request.BuyerSeller.LastName, HuWfAndVestDictry["Husband2LastName"], "Husband 2 LastName");
            Support.AreEqual(request.BuyerSeller.SpouseFirstName, HuWfAndVestDictry["HusbandSpouseFirstName"], "HusbandSpouse FirstName");
            Support.AreEqual(request.BuyerSeller.SpouseMiddleName, HuWfAndVestDictry["HusbandSpouseMiddleName"], "HusbandSpouse MiddleName");
            Support.AreEqual(request.BuyerSeller.SpouseLastName, HuWfAndVestDictry["HusbandSpouseLastName"], "HusbandSpouse LastName");
            Support.AreEqual(request.BuyerSeller.SpouseSuffix, HuWfAndVestDictry["HusbandSpouseSuffix"], "HusbandSpouse Suffix");
            if (request.PrincipalType == BuyerSellerPrincipalTypeOCD.Buyer)
            {
                Support.AreEqual(request.BuyerSeller.LoanApplicant.ToString().ToLowerInvariant(), HuWfAndVestDictry["HusbandLoanApplicant"], " Husband Loan Applicant");
                Support.AreEqual(request.BuyerSeller.SpouseLoanApplicant.ToString().ToLowerInvariant(), HuWfAndVestDictry["SpouseLoanApplicant"], "Spouse Loan Applicant");
            }
            //
            var VestiNSalutDictry = FastDriver.BuyerSellerSetup.GetIndiviVestgNdSalutio;
            Support.AreEqual("a married man", VestiNSalutDictry["Marital Status"], "Marital Status");
            Support.AreEqual("(vesting to be determined)", VestiNSalutDictry["Vesting"], "Vesting");
            Support.AreEqual("Full Vesting", VestiNSalutDictry["Addl Vesting"], "Addl Vesting");
            Support.AreEqual("", VestiNSalutDictry["Misc Ref 1"], "Misc Ref 1");
            Support.AreEqual("", VestiNSalutDictry["Misc Ref 2"], "Misc Ref 2");
            //
            ValidateAddressAndContactDetails(request);
        }

        private void ValidateTrustEstateBuyerSeller(UpdateBuyerSellerRequest request)
        {
            var TrstEstByrDictry = FastDriver.BuyerSellerSetup.GetTrstestByrDtls(false);
            Support.AreEqual(request.BuyerSeller.ShortName, TrstEstByrDictry["TrusteeShortName"], "Trustee Short Name");
            Support.AreEqual(DateTime.Today.AddYears(-1).ToDateString(), TrstEstByrDictry["TrustDated"], "Trust Dated");
            Support.AreEqual(request.BuyerSeller.TrustNumber, TrstEstByrDictry["TrustNumber"], "Trust Number");
            Support.AreEqual("123-45-6789", TrstEstByrDictry["TrustSSNtext"], "Trust Ssn Text");
            if (request.PrincipalType == BuyerSellerPrincipalTypeOCD.Buyer)
            {
                Support.AreEqual(request.BuyerSeller.LoanApplicant.ToString().ToLowerInvariant(), TrstEstByrDictry["LoanApplicant"], "Loan Applicant");
            }
            ValidateAddressAndContactDetails(request);
        }

        private void ValidateBusinessBuyerSeller(UpdateBuyerSellerRequest request)
        {
            var BusEntByrDictry = FastDriver.BuyerSellerSetup.GetBusEntByrDtls;
            Support.AreEqual(request.BuyerSeller.ShortName, BusEntByrDictry["BusinessEntityShortname"], "Bus Entity Shortname");
            Support.AreEqual("California", BusEntByrDictry["StateofIncorp"], "State of Incorp");
            Support.AreEqual("Business Trust", BusEntByrDictry["EntityType"], "Entity Type");
            Support.AreEqual("123-45-6789", BusEntByrDictry["BusinessEntitySSN"], "Business Entity Ssn");
            if (request.PrincipalType == BuyerSellerPrincipalTypeOCD.Buyer)
            {
                Support.AreEqual(request.BuyerSeller.LoanApplicant.ToString().ToLowerInvariant(), BusEntByrDictry["LoanApplicant"], "Loan Applicant");
            }
            ValidateAddressAndContactDetails(request);
        }

        private void ValidateAddressAndContactDetails(UpdateBuyerSellerRequest request)
        {
            var CurAddrDictry = FastDriver.BuyerSellerSetup.GetCurrAddrDtls;
            Support.AreEqual(request.BuyerSeller.CurrentAddress.AddrLine1, CurAddrDictry["Curr Addr Street 1"], "Curr Addr Street 1");
            Support.AreEqual(request.BuyerSeller.CurrentAddress.AddrLine2, CurAddrDictry["Curr Addr Street 2"], "Curr Addr Street 2");
            Support.AreEqual(request.BuyerSeller.CurrentAddress.AddrLine3, CurAddrDictry["Curr Addr Street 3"], "Curr Addr Street 3");
            Support.AreEqual(request.BuyerSeller.CurrentAddress.AddrLine4, CurAddrDictry["Curr Addr Street 4"], "Curr Addr City");
            Support.AreEqual(request.BuyerSeller.CurrentAddress.City, CurAddrDictry["Curr Addr City"], "Curr Addr City");
            Support.AreEqual(request.BuyerSeller.CurrentAddress.State, CurAddrDictry["Curr Addr State"], "Curr Addr State");
            Support.AreEqual(request.BuyerSeller.CurrentAddress.County, CurAddrDictry["Curr Addr County"], "Curr Addr County");
            Support.AreEqual(request.BuyerSeller.CurrentAddress.Country, CurAddrDictry["Curr Addr Country"], "Curr Addr Country");
            //
            var ForwdAdrDictry = FastDriver.BuyerSellerSetup.GetForwdAdrDtls;
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.AddrLine1, ForwdAdrDictry["Forward Addr Street 1"], "Forward Addr Street 1");
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.AddrLine2, ForwdAdrDictry["Forward Addr Street 2"], "Forward Addr Street 2");
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.AddrLine3, ForwdAdrDictry["Forward Addr Street 3"], "Forward Addr Street 3");
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.AddrLine4, ForwdAdrDictry["Forward Addr Street 4"], "Forward Addr City");
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.City, ForwdAdrDictry["Forward Addr City"], "Forward Addr City");
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.State, ForwdAdrDictry["Forward Addr State"], "Forward Addr State");
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.Country, ForwdAdrDictry["Forward Addr Country"], "Forward Addr Country");
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.County, ForwdAdrDictry["Forward Addr County"], "Forward Addr County");
            //
            var CurrPhoDictry = FastDriver.BuyerSellerSetup.GetCurrentPhoneDetails();
            Support.AreEqual("(991)889-8383", CurrPhoDictry["Home Phone"].First(), "Current PhoneNum");
            var ForwdPhoDictry = FastDriver.BuyerSellerSetup.GetForwardingPhoneDetails();
            Support.AreEqual("(991)889-8383", ForwdPhoDictry["Home Fax"].First(), "Forwarding PhoneNum");
        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
