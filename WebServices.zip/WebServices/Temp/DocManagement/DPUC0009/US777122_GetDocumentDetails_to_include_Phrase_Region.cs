﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using OpenQA.Selenium;
using FASTWCFHelpers.FastFileService;
using OpenQA.Selenium.Support.UI;
using FASTSelenium.PageObjects;
using System.Diagnostics;
using Microsoft.Win32;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.DataObjects.ADM;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using System.Linq;
using System.Collections.Generic;
using OpenQA.Selenium.Interactions;
using System.Windows.Input;


namespace Web_Services_Regression.DocManagement.DPUC0009
{
    [CodedUITest]
    public class US777122_GetDocumentDetails_to_include_Phrase_Region : MasterTestClass
    {
        [TestMethod]
        public void US777122_TC779594()
        {
            try
            {
                Reports.TestDescription = "To test US#777122 - Verify GetDocumentDetails response correctly contains Document Phrase RegionID";
                #region Data Setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                string templateDesc = Support.RandomString("AAAAA");
                #endregion

                #region Create Template
                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Template Maintenance screen";
                FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();

                Reports.TestStep = "From the Template Type dropdown select Form and click on New";
                FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem("Form");
                FastDriver.TemplateMaintenanceSummary.New.FAClick();

                Reports.TestStep = "Enter Name for the Form, Enter Description, Uncheck the Under Construction option";
                FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
                string netCheckForm = Support.RandomString("NANAN");
                FastDriver.TemplateMaintenanceInformation.InformationTemplateName.FASetText(netCheckForm);
                FastDriver.TemplateMaintenanceInformation.InformationDescription.FASetText(templateDesc);
                FastDriver.TemplateMaintenanceInformation.InformationUnderConstruction.FASetCheckbox(false);

                Reports.TestStep = "Click on Phrases tab, Click on Add button";
                FastDriver.TemplateMaintenanceInformation.ClickOnPhraseTab();
                FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();

                Reports.TestStep = "From Phrase Type dropdwon Select Exception Phrase";
                FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
                FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Exception Phrase");
                Playback.Wait(1000);

                Reports.TestStep = "From Phrase Group select the newly created phrase";
                FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItemByIndex(1);
                Playback.Wait(1000);

                Reports.TestStep = "Select the newly from the Results Grid and click on Done";
                FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, 1, TableAction.DoubleClick);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Formatting Tab";
                FastDriver.TemplateMaintenanceInformation.ClickFormattingTab();
                FastDriver.TemplateMaintenanceFormating.WaitForScreenToLoad();

                Reports.TestStep = "Click on First, Middle, Page Before Last and Last pages";
                FastDriver.TemplateMaintenanceFormating.FirstPage.FAClick();
                FastDriver.TemplateMaintenanceFormating.MiddlePages.FAClick();
                FastDriver.TemplateMaintenanceFormating.PageBeforeLast.FAClick();
                FastDriver.TemplateMaintenanceFormating.LastPage.FAClick();

                Reports.TestStep = "Select the Filtering Tab";
                FastDriver.TemplateMaintenanceFormating.ClickFilteringTab();
                FastDriver.TemplateMaintenanceFiltering.WaitForScreenToLoad();

                Reports.TestStep = "Select All under Service Type, Owning Office, Property Type, Product Type,Transaction Type, Business Segment, Search Type, Program Type";
                FastDriver.TemplateMaintenanceFiltering.FilteringAdd.FAClick();
                FastDriver.TemplateFilterSelectionDlg.WaitForScreenToLoad();
                FastDriver.TemplateFilterSelectionDlg.ServiceTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.OwningOfficeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.PropertyTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.ProductTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.TrassactionTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.BusinessSegmentSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.SearchTypeSelectAll.FASetCheckbox(true);
                FastDriver.TemplateFilterSelectionDlg.ProgrammeTypeSelectAll.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click on Save and Done buttons";
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                #endregion

                Reports.TestStep = "Login to FAST IIS";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic File";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));

                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();

                Reports.TestStep = "Add a Document (Form) and click on Create/Save";
                FastDriver.DocumentRepository.FilteredTemplatesTab.FAClick();
                FastDriver.DocumentRepository.WaitForScreenToLoad(FastDriver.DocumentRepository.SearchResultsTable);
                FastDriver.DocumentRepository.Add.FAClick();
                FastDriver.AdHocDocuments.WaitForScreenToLoad();
                FastDriver.AdHocDocuments.TemplateType.FASelectItem("Form");
                FastDriver.AdHocDocuments.TemplateDescription.FASetText(templateDesc);
                FastDriver.AdHocDocuments.FindNow.FAClick();
                FastDriver.AdHocDocuments.WaitForResultsToLoad();
                FastDriver.AdHocDocuments.SearchResultsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.AdHocDocuments.CreateSave.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);

                Reports.TestStep = "Once the document is created click on Edit";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DocumentRepository.Edit.FAClick();

                Reports.TestStep = "Insert some Phrases of different Regions";
                //1st Phrase
                FastDriver.DocumentPreparation.WaitForScreenToLoad(FastDriver.DocumentPreparation.PhraseArea);
                AddPhareToVerifyRegion("QA-Canada"); // Region ID = 2161
                //2nd Phrase
                FastDriver.DocumentPreparation.WaitForScreenToLoad(FastDriver.DocumentPreparation.PhraseArea);
                AddPhareToVerifyRegion("QA SANDPOINTE REGION"); // Region ID = 191
                FastDriver.DocumentPreparation.WaitForScreenToLoad(FastDriver.DocumentPreparation.PhraseArea);

                Reports.TestStep = "Select the document and click on Details";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository").WaitForScreenToLoad();
                FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DocumentRepository.Details.FAClick();

                Reports.TestStep = "Get the DocID and ServiceFileID";
                FastDriver.DocumentDetailsScreen.WaitForScreenToLoad();
                int docID = int.Parse(FastDriver.DocumentDetailsScreen.DocID.FAGetText().Clean());
                int fileID = int.Parse(FastDriver.DocumentDetailsScreen.FileID.FAGetText().Clean());

                Reports.TestStep = "Call the GetDocumentDetails() method and add the DocID as the documentID and ServiceFileID as FileID";
                var response = FileService.GetDocumentDetails(fileID, docID);

                Reports.TestStep = "Verified the response DocumentPhrase and verified that each DocumentPhrase RegionID is the same as the inserted";
                Support.AreEqual("3", response.Phrases.Count().ToString(), "Phrases count");
                Support.AreEqual("189", response.Phrases[1].RegionID.ToString());
                Support.AreEqual("2161", response.Phrases[2].RegionID.ToString());
            }
            catch (Exception ex)
            {                
                FailTest(ex.Message);
            }            
        }

        #region Methods
        private void AddPhareToVerifyRegion(string region)
        {
            Keyboard.SendKeys("%P");
            Playback.Wait(2000);
            Keyboard.SendKeys("%P");
            FastDriver.WebDriver.HandleDialogMessage();
            FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
            FastDriver.PhraseSelectDlg.Source.FASelectItem(region);
            FastDriver.PhraseSelectDlg.Search.FAClick();
            FastDriver.PhraseSelectDlg.WaitForScreenToLoad(FastDriver.PhraseSelectDlg.ResultsTable);
            FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, 1, TableAction.DoubleClick);
            FastDriver.DialogBottomFrame.ClickDone();
            FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }

}
