﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using OpenQA.Selenium;
using FASTWCFHelpers.FastFileService;
using OpenQA.Selenium.Support.UI;
using FASTSelenium.PageObjects;
using System.Diagnostics;
using Microsoft.Win32;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.DataObjects.ADM;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using System.Linq;
using System.Collections.Generic;
using OpenQA.Selenium.Interactions;
using System.Windows.Input;


namespace Web_Services_Regression.DocManagement.DPUC0009
{
    [CodedUITest]
    public class US851283_GetDocumentDetails_receives_default_values_for_the_phrases_in_a_DocGen_File : FASTHelpers
    {
        [TestMethod]
        public void US851283_TC852743()
        {
            try
            {
                Reports.TestDescription = "To test US#851283 - Verify GetDocumentDetails() receives default values for the phrases in a DocGen File";
                #region Data Setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                string TemplateDesc = "ab";
                #endregion

                Reports.TestStep = "Login to FAST IIS and Navigate DocGen Office";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>("Home>Others>Select Office").WaitForScreenToLoad(FastDriver.SecuritySelectRegionOffice.SearchbyBUID);
                FastDriver.SecuritySelectRegionOffice.EnterBUID("12839");

                Reports.TestStep = "Create a basic DocGen File";
                createBasicFile();

                Reports.TestStep = "Create a document with data elements (Document should not be Form or Fax Cover Sheet, also status should no be Finalized)";
                FastDriver.LeftNavigation.Navigate<DocumentRepository>("Home>Order Entry>Document Repository");
                FastDriver.NextGenDocumentRepository.WaitForScreenToLoad();
                FastDriver.NextGenDocumentRepository.CreateDocumentFromTemplate(TemplateDesc, null, null, "Title Reports");

                Reports.TestStep = "Right click on the created document and select 'Phrase View/Edit' option";
                FastDriver.NextGenDocumentRepository.DocumentsTable.PerformTableAction(1, 7, TableAction.DoubleClick);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 30);
                FastDriver.NextGenDocumentRepository.WaitForPhaseviewTabToLoad();

                Reports.TestStep = "Click on Details tab and obtain the DocumentID and ServiceFileID values";
                FastDriver.NextGenDocumentRepository.DetailsTab.FAClick();
                int fileID = int.Parse(FastDriver.NextGenDocumentRepository.DetailsTable1.PerformTableAction(10, 2, TableAction.GetText).Message.Clean());
                int docID = int.Parse(FastDriver.NextGenDocumentRepository.DocumentID.FAGetText().Clean());

                Reports.TestStep = "Call method GetDocumentDetails() using DocumentID and ServiceFileID values";
                var response = FileService.GetDocumentDetails(fileID, docID);

                Reports.TestStep = "Make sure default values are obtained the DocumentPhraseElements";
                Support.AreEqual("1BUNAMEa", response.Phrases[4].PhraseElements[0].FormFieldName);
                Support.AreEqual("Donald Trump", response.Phrases[4].PhraseElements[0].FormFieldValue);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);                
            }

        }

        #region HelpMethods
        public void createBasicFile()
        {
            FastDriver.LeftNavigation.Navigate<QuickFileEntry>("Home>Order Entry>Quick File Entry");
            FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
            FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
            FastDriver.QuickFileEntry.WaitForScreenToLoad();
            FastDriver.QuickFileEntry.BusinessSourceGABcode.FASetText("242");
            FastDriver.QuickFileEntry.BusinessSourceFind.FAClick();
            FastDriver.QuickFileEntry.Title.FASetCheckbox(true);
            FastDriver.QuickFileEntry.Escrow.FASetCheckbox(true);
            FastDriver.QuickFileEntry.SelectTransactionType("Refinance");
            FastDriver.QuickFileEntry.PropertyCity.FASetText("Santa Ana");
            FastDriver.QuickFileEntry.PropertyState.FASelectItem("CA");
            FastDriver.QuickFileEntry.PropertyCounty.FASetText("Orange");
            FastDriver.QuickFileEntry.Buyer1Type.FASelectItem("Individual");
            FastDriver.QuickFileEntry.Buyer1FirstName.FASetText("Donald");
            FastDriver.QuickFileEntry.Buyer1LastName.FASetText("Trump");
            FastDriver.QuickFileEntry.Seller1Type.FASelectItem("Individual");
            FastDriver.QuickFileEntry.Seller1FirstName.FASetText("Hillary");
            FastDriver.QuickFileEntry.Seller1LastName.FASetText("Clinton");
            FastDriver.BottomFrame.Done();
        }

        public void AddPhraseWithDataElementToTemplate(string[] dataElement, string TemplateDesc, string TemplateType)
        {
            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

            Reports.TestStep = "Login to FAST ADM Home at Region Level";
            FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);
            FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
            FastDriver.SecuritySelectRegionOffice.EnterBUID("12837");

            Reports.TestStep = "Navigate to Document Preparation, Select Phrase Maintenance";
            FastDriver.LeftNavigation.Navigate<PhraseGroupMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Phrase Maintenance").WaitForScreenToLoad();

            Reports.TestStep = "Click on New Button";
            FastDriver.PhraseGroupMaintenanceSummary.New.FAClick();
            FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();

            Reports.TestStep = "Enter a Name for Phrase, Enter a Description";
            string groupName = Support.RandomString("NANA");
            FastDriver.PhraseGroupMaintenance.Name.FASetText(groupName);
            FastDriver.PhraseGroupMaintenance.Descritption.FASetText("Group US# 851283");
            FastDriver.PhraseGroupMaintenance.PhraseType.FASelectItem("Miscellaneous Phrase");
            FastDriver.BottomFrame.Save();
            FastDriver.PhraseGroupMaintenance.WaitForScreenToLoad();
            FastDriver.PhraseGroupMaintenance.Add.FAClick();
            FastDriver.PhraseMaintenance.WaitForScreenToLoad();

            Reports.TestStep = "Click on Phrase Editor";
            string phraseName = Support.RandomString("NANA");
            FastDriver.PhraseMaintenance.PhraseName.FASetText(phraseName);
            FastDriver.PhraseMaintenance.Description.FASetText("Phrase US# 851283");
            FastDriver.BottomFrame.Save();
            FastDriver.PhraseMaintenance.WaitForScreenToLoad();
            FastDriver.PhraseMaintenance.PhraseEditor.FAClick();

            foreach (string dataE in dataElement)
            {
                Reports.TestStep = "Insert Data Elements";
                FastDriver.PhraseEditorDlg.WaitForScreenToLoad();

                Reports.TestStep = "Right Click and Select 'Insert Data Element'";
                FastDriver.PhraseEditorDlg.InsertDataElement.FAClick();
                FastDriver.DataElementSelectionDlg.WaitForScreenToLoad();

                Reports.TestStep = "Under Data Element select the Data element";
                FastDriver.DataElementSelectionDlg.DataElement.FASetText(dataE);
                FastDriver.DialogBottomFrame.ClickDone();
                Playback.Wait(3000);
            }

            Reports.TestStep = "Click on Save, Done";
            FastDriver.DialogBottomFrame.ClickSave();
            FastDriver.DialogBottomFrame.ClickDone();

            Reports.TestStep = "Click on Save, Done";
            FastDriver.BottomFrame.Save();
            FastDriver.BottomFrame.Done();

            Reports.TestStep = "Select Template Maintenance";
            FastDriver.LeftNavigation.Navigate<TemplateMaintenanceSummary>(@"Home>System Maintenance>Document Preparation>Template Maintenance").WaitForScreenToLoad();

            Reports.TestStep = "From the Template Type dropdown select Form and click on New";
            FastDriver.TemplateMaintenanceSummary.TemplateType.FASelectItem(TemplateType);
            FastDriver.TemplateMaintenanceSummary.Description.FASetText(TemplateDesc);
            FastDriver.TemplateMaintenanceSummary.FindNow.FAClick();
            FastDriver.TemplateMaintenanceSummary.WaitForResultsTableToLoad();
            FastDriver.TemplateMaintenanceSummary.Results.PerformTableAction(1, 1, TableAction.Click);
            FastDriver.TemplateMaintenanceSummary.Edit.FAClick();

            Reports.TestStep = "Click on Phrases tab, Click on Add button";
            FastDriver.TemplateMaintenanceInformation.WaitForScreenToLoad();
            FastDriver.TemplateMaintenanceInformation.linkPhrases.FAClick();
            FastDriver.TemplateMaintenancePhrase.PhrasesAdd.FAClick();

            Reports.TestStep = "From Phrase Type dropdwon Select Miscellaneous Phrase";
            FastDriver.PhraseSelectDlg.WaitForScreenToLoad();
            FastDriver.PhraseSelectDlg.PhraseType.FASelectItem("Miscellaneous Phrase");
            Playback.Wait(1000);

            Reports.TestStep = "From Phrase Group select the newly created phrase";
            FastDriver.PhraseSelectDlg.PhraseGroup.FASelectItem("Group US# 851283" + "[" + groupName + "]");
            Playback.Wait(1000);

            Reports.TestStep = "Select the newly from the Results Grid and click on Done";
            FastDriver.PhraseSelectDlg.ResultsTable.PerformTableAction(1, 1, TableAction.DoubleClick);
            FastDriver.DialogBottomFrame.ClickDone();

            Reports.TestStep = "Click on Save and Done buttons";
            FastDriver.BottomFrame.Save();
            FastDriver.BottomFrame.Done();
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }  
    }
}
