﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Transactions.FMUC0120_ClosingDisclosureForm.LoanDisclosure
{
    [CodedUITest]
    public class US264120_Get_Data_From_Loan_Disclosures_AP_Table : FASTHelpers
    {
        [TestMethod]
        [Description("Verify Adjustment Payment(AP) Table is appearing and different Payment methods are displaying")]
        public void Scenario_1_AP_Table()
        {
            try
            {
                Reports.TestDescription = "Verify Adjustment Payment(AP) Table is appearing and different Payment methods are displaying.";

                FAST_Init_File();

                #region Verify CD Section AP & AIR
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.AP_AIR.Click();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APTableChkBox);
                Reports.TestStep = "Verify option 'Include Adjustable Payment (AP) Table' is unchecked";
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APTableChkBox.GetAttribute("status").ToString().ToLowerInvariant(), "false");
                Reports.TestStep = "Verify option 'Interest Only Payments?' is NO";
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APInterestOnlyDrpDwn.GetAttribute("selectedIndex"), "0");
                Reports.TestStep = "Verify option 'Optional Payments?' is NO";
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APOptionalPaymentsDrpDwn.GetAttribute("selectedIndex"), "0");
                Reports.TestStep = "Verify option 'Step Payments?' is NO";
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APStepPaymentsDrpDwn.GetAttribute("selectedIndex"), "0");
                Reports.TestStep = "Verify option 'Seasonal Payments?' is NO";
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APSeasonalPaymentsDrpDwn.GetAttribute("selectedIndex"), "0");
                #endregion

                #region Modify CD Section AP & AIR
                Reports.TestStep = "Modify CD Section AP & AIR";
                //  Interest Only Payments?
                FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APTableChkBox.Click();
                FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APInterestOnlyDrpDwn.FASelectItemBySendingKeys("YES");
                FastDriver.ClosingDisclosure.InterestOnlyPayments_PlusIcon.Click();
                Support.AreEqual(FastDriver.ClosingDisclosure.rbInterestOnlyPaymentId1.GetAttribute("status").ToString().ToLowerInvariant(), "true");
                FastDriver.ClosingDisclosure.PaymentCustomOption.Click();
                FastDriver.ClosingDisclosure.PaymentCustomText.FASetText("test1");
                FastDriver.ClosingDisclosure.PaymentSchedule_Done.Click();
                //  Optional Payments?
                FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APOptionalPaymentsDrpDwn.FASelectItemBySendingKeys("YES");
                FastDriver.ClosingDisclosure.OptionalPayments_PlusIcon.Click();
                Support.AreEqual(FastDriver.ClosingDisclosure.rbInterestOnlyPaymentId1.GetAttribute("status").ToString().ToLowerInvariant(), "true");
                FastDriver.ClosingDisclosure.PaymentCustomOption.Click();
                FastDriver.ClosingDisclosure.PaymentCustomText.FASetText("test2");
                FastDriver.ClosingDisclosure.PaymentSchedule_Done.Click();
                //  Step Payments?
                FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APStepPaymentsDrpDwn.FASelectItemBySendingKeys("YES");
                FastDriver.ClosingDisclosure.StepPayments_PlusIcon.Click();
                Support.AreEqual(FastDriver.ClosingDisclosure.rbInterestOnlyPaymentId1.GetAttribute("status").ToString().ToLowerInvariant(), "true");
                FastDriver.ClosingDisclosure.PaymentCustomOption.Click();
                FastDriver.ClosingDisclosure.PaymentCustomText.FASetText("test3");
                FastDriver.ClosingDisclosure.PaymentSchedule_Done.Click();
                //  Seasonal Payments?
                FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APSeasonalPaymentsDrpDwn.FASelectItemBySendingKeys("YES");
                FastDriver.ClosingDisclosure.SeasonalPayments_PlusIcon.Click();
                Support.AreEqual(FastDriver.ClosingDisclosure.rbInterestOnlyPaymentId1.GetAttribute("status").ToString().ToLowerInvariant(), "true");
                FastDriver.ClosingDisclosure.PaymentCustomOption.Click();
                FastDriver.ClosingDisclosure.PaymentCustomText.FASetText("test4");
                FastDriver.ClosingDisclosure.PaymentSchedule_Done.Click();
                //
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify with GetCDDetails web service
                Reports.TestStep = "Verify with GetCDDetails web service";
                var request = CDRequestFactory.GetCDDetailsRequest();
                request.FileID = File.FileID ?? 0;
                request.CDFilter = FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.ApAir;
                Playback.Wait(3000);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.IsTrue(details.ClosingDisclosureApAir.AdjustablePayment.IncludeAdjustablePaymentAPTable, "ClosingDisclosureApAir.AdjustablePayment.IncludeAdjustablePaymentAPTable");
                //  Interest Only Payments?
                Support.AreEqual(details.ClosingDisclosureApAir.AdjustablePayment.InterestOnlyPaymentsOption, "YES");
                Support.AreEqual(details.ClosingDisclosureApAir.AdjustablePayment.InterestOnlyPaymentsPaymentSchedule, "test1");
                //  Optional Payments?
                Support.AreEqual(details.ClosingDisclosureApAir.AdjustablePayment.OptionalPaymentsOption, "YES");
                Support.AreEqual(details.ClosingDisclosureApAir.AdjustablePayment.OptionalPaymentsPaymentSchedule, "test2");
                //  Step Payments?
                Support.AreEqual(details.ClosingDisclosureApAir.AdjustablePayment.StepPaymentsOption, "YES");
                Support.AreEqual(details.ClosingDisclosureApAir.AdjustablePayment.StepPaymentsPaymentSchedule, "test3");
                //  Seasonal Payments?
                Support.AreEqual(details.ClosingDisclosureApAir.AdjustablePayment.SeasonalPaymentsOption, "YES");
                Support.AreEqual(details.ClosingDisclosureApAir.AdjustablePayment.SeasonalPaymentsPaymentSchedule, "test4");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify display of Monthly Principal and Interest Payments in Adjustment Payment(AP) Table")]
        public void Scenario_2_AP_Table_schedule()
        {
            try
            {
                Reports.TestDescription = "Verify Adjustment Payment(AP) Table is appearing and different Payment methods are displaying.";

                FAST_Init_File();

                #region Verify CD Section AP & AIR
                Reports.TestStep = "Verify CD Section AP & AIR";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.AP_AIR.Click();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APTableChkBox);
                Reports.TestStep = "Verify option 'Include Adjustable Payment (AP) Table' is unchecked";
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APTableChkBox.GetAttribute("status").ToString().ToLowerInvariant(), "false");
                Reports.TestStep = "Verify ClosingDisclosure.Sec9_APnAIRtable_APFirstChangeValue is empty";
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APFirstChangeValue.Text, "");
                Reports.TestStep = "Verify ClosingDisclosure.Sec9_APnAIRtable_APSubsequentChangesValue is empty";
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APSubsequentChangesValue.Text, "");
                Reports.TestStep = "Verify ClosingDisclosure.Sec9_APnAIRtable_APMaximumPaymentValue is empty";
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APMaximumPaymentValue.Text, "");
                #endregion

                #region Modify CD Section AP & AIR
                Reports.TestStep = "Modify CD Section AP & AIR";
                FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APTableChkBox.Click();
                FastDriver.ClosingDisclosure.imgddlMonthlyPayments.Click();
                Reports.TestStep = "First Change/Amount => $1000.00 at 12";
                FastDriver.ClosingDisclosure.Sec9_APnAIRtable_txtFirstChargeAmount1.FASetText("ABCD1500$%");
                FastDriver.ClosingDisclosure.Sec9_APnAIRtable_txtFirstChargeAmount2.FASetText("ABCD12$%");
                Reports.TestStep = "Subsequent changes => 1";
                FastDriver.ClosingDisclosure.Sec9_APnAIRtable_txtSubsequentChange1.FASetText("ABCD1$%");
                Reports.TestStep = "Maximum payment => $150 starting at $50";
                FastDriver.ClosingDisclosure.Sec9_APnAIRtable_txtMaximumPayment1.FASetText("ABCD150$%");
                FastDriver.ClosingDisclosure.Sec9_APnAIRtable_txtMaximumPayment2.FASetText("ABCD50$%");
                FastDriver.ClosingDisclosure.Sec9_APnAIRtable_btnMonthlyPaymentDone.Click();
                //
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify with GetCDDetails web service
                Reports.TestStep = "Verify with GetCDDetails web service";
                var request = CDRequestFactory.GetCDDetailsRequest();
                request.FileID = File.FileID ?? 0;
                request.CDFilter = FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.ApAir;
                Playback.Wait(3000);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.IsTrue(details.ClosingDisclosureApAir.AdjustablePayment.IncludeAdjustablePaymentAPTable, "ClosingDisclosureApAir.AdjustablePayment.IncludeAdjustablePaymentAPTable");
                Support.AreEqual("$1,500 at 12th payment", details.ClosingDisclosureApAir.AdjustablePayment.FirstChangeAmountsPaymentSchedule, "AdjustablePayment.FirstChangeAmountsPaymentSchedule");
                Support.AreEqual("Every year", details.ClosingDisclosureApAir.AdjustablePayment.SubSequentChangesPaymentSchedule, "AdjustablePayment.SubSequentChangesPaymentSchedule");
                Support.AreEqual("$150 starting at 50th payment", details.ClosingDisclosureApAir.AdjustablePayment.MaximumPaymentPaymentSchedule, "AdjustablePayment.MaximumPaymentPaymentSchedule");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
