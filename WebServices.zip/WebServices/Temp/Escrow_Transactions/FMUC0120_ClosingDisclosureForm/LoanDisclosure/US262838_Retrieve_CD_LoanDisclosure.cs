﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Transactions.FMUC0120_ClosingDisclosureForm.LoanDisclosures
{
    [CodedUITest]
    public class US262838_Retrieve_CD_LoanDisclosure : FASTHelpers
    {
        [TestMethod]
        [Description("Verify Closing Disclosure - Loan Disclosure information using GetCDDetails web service")]
        public void Scenario_1_Get_LoanDisclosure_Details()
        {
            try
            {
                Reports.TestDescription = "Verify Closing Disclosure - Loan Disclosure information using GetCDDetails web service";

                FAST_Init_File(GABRole: AdditionalRoleType.NewLender, loanAmt: 1500000, salesPrice: 1350000);

                #region Navigate to Closing Disclosure and complete Loan Disclosure details
                Reports.TestStep = "Navigate to Closing Disclosure and complete Loan Disclosure details";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.LoanDisclosures.Click();
                FastDriver.ClosingDisclosure.AllowAssumption.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.HasDemandFeature.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.SMSFastSMSgesicon_breakAg.Click();
                FastDriver.ClosingDisclosure.NumberOfDays.FASetText("365");
                FastDriver.ClosingDisclosure.LatePaymentDollar.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.LatePaymentFeeDollar);
                FastDriver.ClosingDisclosure.LatePaymentFeeDollar.SendKeys("15,001.00");
                FastDriver.ClosingDisclosure.btnFTDone.Click();
                FastDriver.ClosingDisclosure.EscrowAccount_check.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.NonEscrowedPropertyOverYear1Amount.FASetText("1,380,001.00");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify CD Loan Disclosure details with GetCDDetails()
                Reports.TestStep = "Verify CD Loan Disclosure details with GetCDDetails()";
                var request = CDRequestFactory.GetCDRequest(File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.LoanDisclosures);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                Support.AreEqual("1", details.LoanDisclosures.AllowAssumption.ToString(), "AllowAssumption");
                Support.AreEqual("1", details.LoanDisclosures.HasDemandFeature.ToString(), "HasDemandFeature");
                Support.AreEqual("365", details.LoanDisclosures.DelayedbyDays.ToString(), "DelayedbyDays");
                Support.AreEqual("$15,001.00", details.LoanDisclosures.DisplayLateFeeAmountInDollars, "DisplayLateFeeAmountInDollars");
                Support.AreEqual("1", details.LoanDisclosures.HasEscrowAccount.ToString(), "HasEscrowAccount");
                Support.AreEqual("$1,380,001.00", details.LoanDisclosures.DisplayNonEscrowedPropertyCostForYear, "DisplayEscrowedPropertyCostForYear");
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
