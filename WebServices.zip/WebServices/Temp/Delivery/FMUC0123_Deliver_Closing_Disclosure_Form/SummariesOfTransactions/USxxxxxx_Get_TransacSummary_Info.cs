﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Delivery.FMUC0123_Deliver_Closing_Disclosure_Form.SummariesOfTransactions
{
    [CodedUITest]
    public class USxxxxxx_Get_TransacSummary_Info : FASTHelpers
    {
        #region Proration Object
        public FASTSelenium.PageObjects.IIS.ProrationData prorationData = new FASTSelenium.PageObjects.IIS.ProrationData()
        {
            Description = "",
            CreditSeller = true,
            DayofClosePaidbySeller = true,
            ProrationAmount = (decimal)50000.00,
            FromDate = DateTime.Today.ToDateString(),
            fromInclusive = true,
            fromProrateDate = false,
            BasedOn = "365",
            Per = "MONTH",
            ToDate = DateTime.Today.AddDays(28).ToDateString(),
            toInclusive = false,
            toProrateDate = false,
            ProrationBuyerCharge = (decimal)5000.00,
            ProrationBuyerCredit = (decimal)10000.00,
            ProrationSellerCharge = (decimal)5000.00,
            ProrationSellerCredit = (decimal)10000.00,
            ProrationUtilityLE = (decimal)9999.99,
            prorationType = "",
        };
        #endregion

        protected void AddChargesForSectionH()
        {
            #region Navigate to Outside Escrow Company and complete charge for section H
            Reports.TestStep = "Navigate to Outside Escrow Company and complete charge for section H";
            FastDriver.OutsideEscrowCompanyDetail.Open();
            FastDriver.OutsideEscrowCompanyDetail.FindGAB("415");
            FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FASetText("test-charge");
            FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
            FAST_UpdatePDD(new FASTSelenium.DataObjects.IIS.PDD
            {
                LoanEstimateUnrounded = (double)1249999.99,
                BuyerAtClosing = (double)500000,
                BuyerBeforeClosing = (double)250000,
                BuyerPaidbyOther = (double)250000,
                BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
                SellerPaidAtClosing = (double)150000,
                SellerPaidBeforeClosing = (double)50000,
                SellerPaidbyOthers = (double)50000,
                SellerPaidbyOtherPaymentMthd = OtherPaymentMethods.POC.ToString(),
                SectionHOtherCosts = true,
            });
            FastDriver.BottomFrame.Done();
            #endregion
        }
        protected void AddChargesForSectionKnM()
        {
            #region Navigate to Escrow Charge Processes > Adjustments > Off-Set and complete charges for sections K & M
            Reports.TestStep = "Navigate to Escrow Charge Processes > Adjustments > Off-Set and complete charges for sections K & M";
            FastDriver.AdjustmentOffset.Open();
            //  Sale Price of Any Personal Property Included in Sale
            FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(2, 3, TableAction.SetText, "15000.00");
            FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(2, 6, TableAction.SetText, "15000.00");
            //  Assign Tenant Lease/Rent
            FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(3, 3, TableAction.SetText, "15000.00");
            FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(3, 4, TableAction.SetText, "15000.00");
            FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(3, 5, TableAction.SetText, "15000.00");
            //  Assign Tenant Security Deposit
            FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(4, 3, TableAction.SetText, "15000.00");
            FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(4, 4, TableAction.SetText, "15000.00");
            FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(4, 5, TableAction.SetText, "15000.00");
            //  Seller Credit
            FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(5, 4, TableAction.SetText, "15000.00");
            FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(5, 5, TableAction.SetText, "15000.00");
            FastDriver.BottomFrame.Done();
            #endregion

            #region Navigate to Escrow Charge Processes > Proration > Tax and complete charges for sections K & M
            Reports.TestStep = "Navigate to Escrow Charge Processes > Proration > Tax and complete charges for sections K & M";
            FastDriver.ProrationTax.Open();
            //  City/Town Taxes
            FastDriver.ProrationTax.ProrationTaxTable1.Click();
            FastDriver.ProrationTax.WaitCreation(FastDriver.ProrationTax.Edit);
            FastDriver.ProrationTax.Edit.Click();
            FastDriver.ProrationDetail.WaitForScreenToLoad();
            FastDriver.ProrationDetail.SetProrarion(prorationData);
            FastDriver.BottomFrame.Done();
            //  County Taxes
            FastDriver.ProrationTax.WaitForScreenToLoad();
            FastDriver.ProrationTax.ProrationTaxTable2.Click();
            FastDriver.ProrationTax.WaitCreation(FastDriver.ProrationTax.Edit);
            FastDriver.ProrationTax.Edit.Click();
            FastDriver.ProrationDetail.WaitForScreenToLoad();
            FastDriver.ProrationDetail.SetProrarion(prorationData);
            FastDriver.BottomFrame.Done();
            //  Assessments
            FastDriver.ProrationTax.WaitForScreenToLoad();
            FastDriver.ProrationTax.ProrationTaxTable3.Click();
            FastDriver.ProrationTax.WaitCreation(FastDriver.ProrationTax.Edit);
            FastDriver.ProrationTax.Edit.Click();
            FastDriver.ProrationDetail.WaitForScreenToLoad();
            FastDriver.ProrationDetail.SetProrarion(prorationData);
            FastDriver.BottomFrame.Done();
            //
            FastDriver.BottomFrame.Done();
            #endregion
        }

        [TestMethod]
        [Description("Verify Closing Disclosure - Summary of Transactions section K information using GetCDDetails web service")]
        public void Scenario_1_Get_SectionK_Details()
        {
            try
            {
                Reports.TestDescription = "Verify Closing Disclosure - Summary of Transactions section K information using GetCDDetails web service";

                FAST_Init_File(LenderID: "415", loanAmt: (decimal)2500000, salesPrice: (decimal)3000000);

                AddChargesForSectionH();

                AddChargesForSectionKnM();
                
                #region Verify Closing Disclosure - Summary of Transactions section K with GetCDDetails()
                Reports.TestStep = "Verify Closing Disclosure - Summary of Transactions section K with GetCDDetails()";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionK);
                var sectionMTotalamt = FastDriver.ClosingDisclosure.SectionKHeader_Amt.FAGetText();
                //
                var request = CDRequestFactory.GetCDRequest(File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.SummariesOfTransactions);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                //
                Support.AreEqual(sectionMTotalamt, details.TransactionSummary.SectionKBuyerCharge.DisplayTotal, "SectionKBuyerCharge.DisplayTotal");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Closing Disclosure - Summary of Transactions section M information using GetCDDetails web service")]
        public void Scenario_2_Get_SectionM_Details()
        {
            try
            {
                Reports.TestDescription = "Verify Closing Disclosure - Summary of Transactions section M information using GetCDDetails web service";

                FAST_Init_File(LenderID: "415", loanAmt: (decimal)2500000, salesPrice: (decimal)3000000);

                AddChargesForSectionH();

                AddChargesForSectionKnM();
                
                #region Verify Closing Disclosure - Summary of Transactions section M with GetCDDetails()
                Reports.TestStep = "Verify Closing Disclosure - Summary of Transactions section M with GetCDDetails()";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Summary_Of_Trans.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.SectionK);
                var sectionKTotalamt = FastDriver.ClosingDisclosure.SectionMHeader_Amt.FAGetText();
                //
                var request = CDRequestFactory.GetCDRequest(File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.SummariesOfTransactions);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                //
                Support.AreEqual(sectionKTotalamt, details.TransactionSummary.SectionMSellerCredit.DisplayTotal, "SectionMSellerCredit.DisplayTotal");
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
