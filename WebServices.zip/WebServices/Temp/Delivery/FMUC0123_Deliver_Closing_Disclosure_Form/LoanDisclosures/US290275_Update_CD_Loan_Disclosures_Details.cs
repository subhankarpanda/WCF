﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Delivery.FMUC0123_Deliver_Closing_Disclosure_Form.LoanDisclosures
{
    [CodedUITest]
    public class US290275_Update_CD_Loan_Disclosures_Details : FASTHelpers
    {
        [TestMethod]
        [Description("Verify update Closing Disclosure - Loan Disclosures information using UpdateCDDetails web service")]
        public void Scenario_1_Update_CD_Loan_Disclosures_Details()
        {
            try 
            {
                Reports.TestDescription = "Verify update Closing Disclosure - Loan Disclosures information using UpdateCDDetails web service";

                FAST_Init_File(GABRole: AdditionalRoleType.NewLender, loanAmt: 1500000, salesPrice: 1350000);

                #region Update CD Loan Disclosure information using UpdateCDDetails()
                Reports.TestStep = "Update CD Loan Disclosure information using UpdateCDDetails()";
                var request1 = CDRequestFactory.GetCDLoanDisclosuresRequest(File.FileID ?? 0);
                request1.ClosingDisclosure.LoanDisclosures.AllowAssumption = 1;
                request1.ClosingDisclosure.LoanDisclosures.DelayedbyDays = 365;
                request1.ClosingDisclosure.LoanDisclosures.InitialEscrowPayment = 14001;
                request1.ClosingDisclosure.LoanDisclosures.HasDemandFeature = 1;
                request1.ClosingDisclosure.LoanDisclosures.HasEscrowAccount = 1;
                request1.ClosingDisclosure.LoanDisclosures.LateFeeAmountInDollars = 15001;
                request1.ClosingDisclosure.LoanDisclosures.NoNegativeAmortization = 1;
                request1.ClosingDisclosure.LoanDisclosures.NoPartialPayments = 1;
                request1.ClosingDisclosure.LoanDisclosures.NonEscrowedPropertyCostForYear = 1380001;
                var response1 = ClosingDisclosureService.UpdateCDDetails(request1);
                Support.AreEqual("1", response1.Status.ToString(), response1.StatusDescription);
                #endregion

                #region Verify CD Loan Disclosure information in FAST
                Reports.TestStep = "Verify CD Loan Disclosure information in FAST";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Loan_Disclosures.Click();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.AllowAssumption);
                Support.AreEqual("true", FastDriver.ClosingDisclosure.AllowAssumption.GetAttribute("status").ToLowerInvariant(), "AllowAssumption");
                Support.AreEqual("true", FastDriver.ClosingDisclosure.HasDemandFeature.GetAttribute("status").ToLowerInvariant(), "HasDemandFeature");
                Support.AreEqual("365", FastDriver.ClosingDisclosure.sLatePaymentDays.Text, "LatePaymentDays");
                Support.AreEqual("$15,001.00", FastDriver.ClosingDisclosure.sLatePaymentPercentORDollar.Text.TrimEnd('.'), "LatePaymentPercentORDollar");
                Support.AreEqual("true", FastDriver.ClosingDisclosure.EscrowAccount_check.GetAttribute("status").ToLowerInvariant(), "EscrowAccount");
                Support.AreEqual("$1,380,001.00", FastDriver.ClosingDisclosure.NonEscrowedPropertyOverYear1Amount.Text, "NonEscrowedPropertyOverYear1Amount");
                //Support.AreEqual("1450002", FastDriver.ClosingDisclosure.EstimatedEscrowedPropertyOverYear1Editable.Text, "EscrowedPropertyOverYear1Editable");
                #endregion

                #region Update CD Loan Disclosure information using UpdateCDDetails()
                Reports.TestStep = "Update CD Loan Disclosure information using UpdateCDDetails()";
                var request2 = CDRequestFactory.GetCDLoanDisclosuresRequest(File.FileID ?? 0);
                request2.ClosingDisclosure.LoanDisclosures.DontAllowAssumption = 1;
                request2.ClosingDisclosure.LoanDisclosures.DelayedbyDays = 232;
                request2.ClosingDisclosure.LoanDisclosures.Declined = 1;
                request2.ClosingDisclosure.LoanDisclosures.EstimatedPropertyCostsForyear = 1450002;
                request2.ClosingDisclosure.LoanDisclosures.NoDemandFeature = 1;
                request2.ClosingDisclosure.LoanDisclosures.NoEscrowAccount = 1;
                request2.ClosingDisclosure.LoanDisclosures.LateFeeAmountInPercentage = 5;
                request2.ClosingDisclosure.LoanDisclosures.NoNegativeAmortization = 1;
                request2.ClosingDisclosure.LoanDisclosures.AcceptPayments = 1;
                request2.ClosingDisclosure.LoanDisclosures.EscrowWaiverFee = 250101;
                var response2 = ClosingDisclosureService.UpdateCDDetails(request2);
                Support.AreEqual("1", response2.Status.ToString(), response2.StatusDescription);
                #endregion

                #region Verify CD Loan Disclosure information in FAST
                Reports.TestStep = "Verify CD Loan Disclosure information in FAST";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Loan_Disclosures.Click();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.AllowAssumption);
                Support.AreEqual("true", FastDriver.ClosingDisclosure.DontAllowAssumption.GetAttribute("status").ToLowerInvariant(), "DontAllowAssumption");
                Support.AreEqual("true", FastDriver.ClosingDisclosure.HasNoDemandFeature.GetAttribute("status").ToLowerInvariant(), "HasNoDemandFeature");
                Support.AreEqual("232", FastDriver.ClosingDisclosure.sLatePaymentDays.Text, "LatePaymentDays");
                Support.AreEqual("5% of the monthly principal and interest payment.", FastDriver.ClosingDisclosure.sLatePaymentPercentORDollar.Text, "LatePaymentPercentORDollar");
                Support.AreEqual("true", FastDriver.ClosingDisclosure.AcceptPayments.GetAttribute("status").ToLowerInvariant(), "AcceptPayments");
                Support.AreEqual("true", FastDriver.ClosingDisclosure.WillNotHaveEscrowAccountChkBox.GetAttribute("status").ToLowerInvariant(), "NoEscrowAccount");
                Support.AreEqual("true", FastDriver.ClosingDisclosure.YouDeclinedChkBox.GetAttribute("status").ToLowerInvariant(), "Declined");
                Support.AreEqual("$1,450,002.00", FastDriver.ClosingDisclosure.spnEstimatedPropertyCostPerYear.Text, "EstimatedPropertyCostPerYear");
                Support.AreEqual("$250,101.00", FastDriver.ClosingDisclosure.spnEscrowWaverFeeTxtbox.Text, "EscrowWaverFee");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
