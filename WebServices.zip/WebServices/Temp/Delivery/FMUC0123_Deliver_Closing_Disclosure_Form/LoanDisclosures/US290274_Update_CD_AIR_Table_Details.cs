﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Delivery.FMUC0123_Deliver_Closing_Disclosure_Form.LoanDisclosures
{
    [CodedUITest]
    public class US290274_Update_CD_AIR_Table_Details : FASTHelpers
    {
        [TestMethod]
        [Description("Verify update Closing Disclosure - AIR Table information using UpdateCDDetails")]
        public void Scenario_1_Update_CD_AIR_Table_Details()
        {
            try
            {
                Reports.TestStep = "Verify update Closing Disclosure - AIR Table information using UpdateCDDetails";

                FAST_Init_File();

                #region Update CD AIR Table details using UpdateCDDetails()
                Reports.TestStep = "Update CD AIR Table details using UpdateCDDetails()";
                var updateReq = CDRequestFactory.GetCDApAirRequest(File.FileID ?? 0, withAIR: true);
                var response = ClosingDisclosureService.UpdateCDDetails(updateReq);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Navigate to Closing Disclosure and verify AIR Table
                Reports.TestStep = "Navigate to Closing Disclosure and verify AIR Table";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.AP_AIR.Click();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APTableChkBox, 5);
                Support.AreEqual("true", FastDriver.ClosingDisclosure.Sec9_APnAIRtable_AIRTableChkBox.GetAttribute("status").ToLowerInvariant(), "Include Adjustable Interest Rate (AIR) Table");
                //  Index, Margin, Interest
                Support.AreEqual("123456789012345678901234567890 + 5%", FastDriver.ClosingDisclosure.Sec9_AIRTable_DisplayIndexMargin.Text, "Index + Margin");
                Support.AreEqual("20%", FastDriver.ClosingDisclosure.Sec9_AIRTable_DisplayInitialIR.Text, "Initial Interest Rate");
                Support.AreEqual("2% Min / 29.9999% Max", FastDriver.ClosingDisclosure.Sec9_AIRTable_DisplayMaxMinIR.Text, "Minimum/Maximum Interest Rate");
                //  Change Frequency
                Support.AreEqual("Beginning of 12th month", FastDriver.ClosingDisclosure.Sec9_AIRTable_DisplayFreqFirstChange.Text, "First Change");
                Support.AreEqual("Every 12 months after first change", FastDriver.ClosingDisclosure.Sec9_AIRTable_DisplayFreqSubChange.Text, "Subsequent Changes");
                //  Limits On Interest Rate Changes
                Support.AreEqual("3.9999%", FastDriver.ClosingDisclosure.Sec9_AIRTable_DisplayLimitsFirstChange.Text, "First Change");
                Support.AreEqual("0.9999%", FastDriver.ClosingDisclosure.Sec9_AIRTable_DisplayLimitsSubChange.Text, "Subsequent Changes");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
