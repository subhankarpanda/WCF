﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Delivery.FMUC0123_Deliver_Closing_Disclosure_Form.OtherDisclosures
{
    [CodedUITest]
    public class US290277_Update_OtherDisclosures_Info : FASTHelpers
    {
        [TestMethod]
        [Description("Verify update to Closing Disclosure - Other Disclosures information using UpdateCDDetails web service")]
        public void Scenario_1_Update_Section11_Details()
        {
            try
            {
                Reports.TestDescription = "Verify update to Closing Disclosure - Other Disclosures information using UpdateCDDetails web service";

                FAST_Init_File();

                #region Update Closing Disclosure - Other Disclosures information with UpdateCDDetails()
                Reports.TestStep = "Update Closing Disclosure - Other Disclosures information with UpdateCDDetails()";
                var request = CDRequestFactory.GetUpdateCDDetailsRequest(File.FileID);
                request.ClosingDisclosure.OtherDisclosures = new FASTWCFHelpers.FastClosingDisclosureService.ClosingDisclosureOtherDisclosuresSection()
                {
                    IsRequiredSectionSave = true,
                    ProtectedbyStateLaw = 0,
                    NotProtectedbyStateLaw = 1,
                };
                var response = ClosingDisclosureService.UpdateCDDetails(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify update to Closing Disclosure - Other Disclosures in FAST
                Reports.TestStep = "Verify update to Closing Disclosure - Other Disclosures in FAST";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Other_Disclosures.Click();
                Support.IsTrue(FastDriver.ClosingDisclosure.ProtectedbyStateLaw.GetAttribute("status").ToString().ToLowerInvariant() == "false", "ClosingDisclosure.ProtectedbyStateLaw");
                Support.IsTrue(FastDriver.ClosingDisclosure.NotProtectedbyStateLaw.GetAttribute("status").ToString().ToLowerInvariant() == "true", "ClosingDisclosure.NotProtectedbyStateLaw");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
    }
}
