﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Delivery.FMUC0123_Deliver_Closing_Disclosure_Form.OtherCosts
{
    [CodedUITest]
    public class USxxxxxx_Read_OtherCosts_Information : FASTHelpers
    {
        protected void AddChargesForSectionE()
        {
            #region Navigate to File Fees and complete Taxes & Other Government Fees for section E
            Reports.TestStep = "Navigate to File Fees and complete Taxes & Other Government Fees for section E";
            FAST_AddFileFees(new PDD[]{
                    new PDD() { 
                        ChargeDescription = "CD - E Transfer Tax – Mortgage2", 
                        BuyerAtClosing = (double)50000,
                        BuyerBeforeClosing = (double)25000,
                        BuyerPaidbyOther = (double)25000,
                        BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
                        SellerPaidAtClosing = (double)15000,
                        SellerPaidBeforeClosing = (double)5000,
                        SellerPaidbyOthers = (double)5000,
                        SellerPaidbyOtherPaymentMthd = OtherPaymentMethods.POC.ToString(), 
                    },
                    new PDD() { 
                        ChargeDescription = "E Recording Fee - Release1", 
                        BuyerAtClosing = (double)50000,
                        BuyerBeforeClosing = (double)25000,
                        BuyerPaidbyOther = (double)25000,
                        BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
                        SellerPaidAtClosing = (double)15000,
                        SellerPaidBeforeClosing = (double)5000,
                        SellerPaidbyOthers = (double)5000,
                        SellerPaidbyOtherPaymentMthd = OtherPaymentMethods.POC.ToString(), 
                    },
                }, isTE: false);
            FAST_UpdateRecTaxLEAmounts(new double[,] { { 49999.99, 50000.00 }, { 49999.99, 50000.00 } });
            #endregion
        }

        protected void AddChargesForSectionF()
        {
            #region Navigate to Insurance and add an instance of Fire with charges for section F
            Reports.TestStep = "Navigate to Insurance and add an instance of Fire with charges for section F";
            FastDriver.InsuranceFire.Open();
            FastDriver.InsuranceFire.FindGAB("415");
            FastDriver.InsuranceFire.FirePremium.FASetText("15000");
            FastDriver.InsuranceFire.FiretextTerm.FASetText("24");
            FastDriver.InsuranceFire.FireoptMonths.FAClick();
            FastDriver.InsuranceFire.FirePaymentDetails.FAClick();
            FAST_UpdatePDD(new FASTSelenium.DataObjects.IIS.PDD
            {
                LoanEstimateUnrounded = (double)1249999.99,
                BuyerAtClosing = (double)500000,
                BuyerBeforeClosing = (double)250000,
                BuyerPaidbyOther = (double)250000,
                BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
                SellerPaidAtClosing = (double)150000,
                SellerPaidBeforeClosing = (double)50000,
                SellerPaidbyOthers = (double)50000,
                SellerPaidbyOtherPaymentMthd = OtherPaymentMethods.POC.ToString(),
            });
            FastDriver.BottomFrame.Done();
            #endregion
            
            #region Navigate to New Loan - Loan Charges and complete Interest Calculation & New Loan Charges for section F
            Reports.TestStep = "Navigate to New Loan - Loan Charges and complete Interest Calculation & New Loan Charges for section F";
            FastDriver.NewLoan.Open();
            FastDriver.NewLoan.ClickChargesTab();
            FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItem("Fixed Rate");
            FastDriver.NewLoan.LoanChargesInterestCalculationPercentage.FAClick();
            FastDriver.NewLoan.LoanChargesInterestCalculationPercentageRate.FASetText("10");
            FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText(DateTime.Today.ToDateString());
            FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText(DateTime.Today.AddDays(365).ToDateString());
            FastDriver.NewLoan.LoanChargesInterestCalculationbuyercharge.FAClick();
            FastDriver.NewLoan.LoanChargesInterestCalculationPaymentDetails.FAClick();
            FAST_UpdatePDD(new FASTSelenium.DataObjects.IIS.PDD
            {
                LoanEstimateUnrounded = (double)249999.99,
                BuyerAtClosing = (double)200000,
                BuyerBeforeClosing = (double)25000,
                BuyerPaidbyOther = (double)25000,
                BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
            });
            FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
            FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction(1, "Mortgage Insurance Premium", 3, TableAction.Click);
            FastDriver.NewLoan.NewLoanChargesPaymentDetails.FAClick();
            FAST_UpdatePDD(new FASTSelenium.DataObjects.IIS.PDD
            {
                LoanEstimateUnrounded = (double)1249999.99,
                BuyerAtClosing = (double)500000,
                BuyerBeforeClosing = (double)250000,
                BuyerPaidbyOther = (double)250000,
                BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
                SellerPaidAtClosing = (double)150000,
                SellerPaidBeforeClosing = (double)50000,
                SellerPaidbyOthers = (double)50000,
                SellerPaidbyOtherPaymentMthd = OtherPaymentMethods.POC.ToString(),
            });
            FastDriver.BottomFrame.Done();
            #endregion

            #region Navigate to Property Tax Check and complete charge for section F
            Reports.TestStep = "Navigate to Property Tax Check and complete charge for section F";
            FastDriver.PropertyTaxCheck.Open();
            FastDriver.PropertyTaxCheck.FindGABCode("415");
            FastDriver.PropertyTaxCheck.PropertyTaxesPaymentDetails.FAClick();
            FAST_UpdatePDD(new FASTSelenium.DataObjects.IIS.PDD
            {
                LoanEstimateUnrounded = (double)1249999.99,
                BuyerAtClosing = (double)500000,
                BuyerBeforeClosing = (double)250000,
                BuyerPaidbyOther = (double)250000,
                BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
                SellerPaidAtClosing = (double)150000,
                SellerPaidBeforeClosing = (double)50000,
                SellerPaidbyOthers = (double)50000,
                SellerPaidbyOtherPaymentMthd = OtherPaymentMethods.POC.ToString(),
            });
            FastDriver.BottomFrame.Done();
            #endregion
        }

        protected void AddChargesForSectionG()
        {
            #region Navigate to New Loan - Loan Charges and complete Future Recording Fees collected by Lender for section G
            Reports.TestStep = "Navigate to New Loan - Loan Charges and complete Future Recording Fees collected by Lender for section G";
            FastDriver.NewLoan.Open();
            FastDriver.NewLoan.ClickChargesTab();
            FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentCharge.FAClick();
            FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentBuyer.FASetText("50000");
            FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustmentSeller.FASetText("50000");
            var paymentDetails = new FASTSelenium.DataObjects.IIS.PDD
            {
                LoanEstimateUnrounded = (double)124999.99,
                BuyerAtClosing = (double)50000,
                BuyerBeforeClosing = (double)25000,
                BuyerPaidbyOther = (double)25000,
                BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
                SellerPaidAtClosing = (double)15000,
                SellerPaidBeforeClosing = (double)5000,
                SellerPaidbyOthers = (double)5000,
                SellerPaidbyOtherPaymentMthd = OtherPaymentMethods.POC.ToString(),
            };
            FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(1, "Homeowner's Insurance", 3, TableAction.Click);
            FastDriver.NewLoan.LoanChargesmpountPaymentDetails.FAClick();
            FAST_UpdatePDD(paymentDetails);
            FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
            FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(1, "Mortgage Insurance", 3, TableAction.Click);
            FastDriver.NewLoan.LoanChargesmpountPaymentDetails.FAClick();
            FAST_UpdatePDD(paymentDetails);
            FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
            FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction(1, "City Property Taxes", 3, TableAction.Click);
            FastDriver.NewLoan.LoanChargesmpountPaymentDetails.FAClick();
            FAST_UpdatePDD(paymentDetails);
            FastDriver.BottomFrame.Done();
            #endregion        
        }

        protected void AddChargesForSectionH()
        {
            #region Navigate to Outside Escrow Company and complete charge for section H
            Reports.TestStep = "Navigate to Outside Escrow Company and complete charge for section H";
            FastDriver.OutsideEscrowCompanyDetail.Open();
            FastDriver.OutsideEscrowCompanyDetail.FindGAB("415");
            FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FASetText("test-charge");
            FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
            FAST_UpdatePDD(new FASTSelenium.DataObjects.IIS.PDD
            {
                LoanEstimateUnrounded = (double)1249999.99,
                BuyerAtClosing = (double)500000,
                BuyerBeforeClosing = (double)250000,
                BuyerPaidbyOther = (double)250000,
                BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
                SellerPaidAtClosing = (double)150000,
                SellerPaidBeforeClosing = (double)50000,
                SellerPaidbyOthers = (double)50000,
                SellerPaidbyOtherPaymentMthd = OtherPaymentMethods.POC.ToString(),
                SectionHOtherCosts = true,
            });
            FastDriver.BottomFrame.Done();
            #endregion
        }

        [TestMethod]
        [Description("Verify Closing Disclosure - Other Costs Section E information using GetCDDetails web service")]
        public void Scenario_1_Get_SectionE_Details()
        {
            try
            {
                Reports.TestDescription = "Verify Closing Disclosure - Other Costs Section E information using GetCDDetails web service";

                FAST_Init_File();

                AddChargesForSectionE(); 
                
                #region Verify Closing Disclosure - Loan Costs Section E details in FAST
                Reports.TestStep = "Verify Closing Disclosure - Loan Costs Section E details in FAST";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Other_Costs.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.OCSectionETable);
                //  
                var sectionDetails = FastDriver.ClosingDisclosure.OCSectionETable;
                Support.AreEqual("E. Taxes and Other Government Fees", sectionDetails.PerformTableAction(1, 1, TableAction.GetText).Message, "Column Name");
                Support.AreEqual("$150,000.00", sectionDetails.PerformTableAction(1, 2, TableAction.GetText).Message, "Borrower Total");
                //
                Support.AreEqual("01. Recording Fees Deed: Mortgage:", sectionDetails.PerformTableAction(2, 1, TableAction.GetText).Message, "Description");
                Support.AreEqual("$50,000.00", sectionDetails.PerformTableAction(2, 2, TableAction.GetText).Message, "Borrower At Closing");
                Support.AreEqual("$25,000.00", sectionDetails.PerformTableAction(2, 3, TableAction.GetText).Message, "Borrower Before Closing");
                Support.AreEqual("$15,000.00", sectionDetails.PerformTableAction(2, 4, TableAction.GetText).Message, "Seller At Closing");
                Support.AreEqual("$5,000.00", sectionDetails.PerformTableAction(2, 5, TableAction.GetText).Message, "Seller Before Closing");
                Support.AreEqual("$25,000.00", sectionDetails.PerformTableAction(2, 6, TableAction.GetText).Message, "Paid By Others");
                Support.AreEqual("$49,999.99", sectionDetails.PerformTableAction(2, 7, TableAction.GetText).Message, "Loan Estimate Unrounded");
                Support.AreEqual("$50,000.00", sectionDetails.PerformTableAction(2, 8, TableAction.GetText).Message, "Loan Estimate Rounded");
                //
                var sectionDetailsPlus = FastDriver.ClosingDisclosure.OCSectionEplusTable;
                Support.AreEqual("02. CD - E2 Transfer Tax - Mo", sectionDetailsPlus.PerformTableAction(1, 1, TableAction.GetText).Message, "Description");
                Support.AreEqual("$50,000.00", sectionDetailsPlus.PerformTableAction(1, 2, TableAction.GetText).Message, "Borrower At Closing");
                Support.AreEqual("$25,000.00", sectionDetailsPlus.PerformTableAction(1, 3, TableAction.GetText).Message, "Borrower Before Closing");
                Support.AreEqual("$15,000.00", sectionDetailsPlus.PerformTableAction(1, 4, TableAction.GetText).Message, "Seller At Closing");
                Support.AreEqual("$5,000.00", sectionDetailsPlus.PerformTableAction(1, 5, TableAction.GetText).Message, "Seller Before Closing");
                Support.AreEqual("$25,000.00", sectionDetailsPlus.PerformTableAction(1, 6, TableAction.GetText).Message, "Paid By Others");
                Support.AreEqual("$49,999.99", sectionDetails.PerformTableAction(3, 2, TableAction.GetText).Message, "Loan Estimate Unrounded");
                Support.AreEqual("$50,000.00", sectionDetails.PerformTableAction(3, 3, TableAction.GetText).Message, "Loan Estimate Rounded");
                #endregion

                #region Verify Closing Disclosure - Loan Costs Section E details with GetCDDetails()
                Reports.TestStep = "Verify Closing Disclosure - Loan Costs Section E details with GetCDDetails()";
                var request = CDRequestFactory.GetCDRequest(File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.OtherCosts);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                //  
                Support.AreEqual("$150,000.00", details.OtherCosts.SectionECharges.DisplayTotal, "SectionECharges.DisplayTotal");
                var sectionChargeTax = details.OtherCosts.SectionECharges.Charges[0];
                Support.AreEqual("Deed: Mortgage:", sectionChargeTax.DisplayDescription, "sectionChargeTax DisplayDescription");
                Support.AreEqual("$49,999.99", sectionChargeTax.DisplayLEAmount, "sectionChargeTax DisplayLEAmount");
                Support.AreEqual("$50,000.00", sectionChargeTax.DisplayPaidByBuyerAtClosing, "sectionChargeTax DisplayPaidByBuyerAtClosing");
                Support.AreEqual("$25,000.00", sectionChargeTax.DisplayPaidByBuyerBeforeClosing, "sectionChargeTax DisplayPaidByBuyerBeforeClosing");
                Support.AreEqual("$25,000.00", sectionChargeTax.DisplayPaidByOthersForBuyer, "sectionChargeTax DisplayPaidByOthersForBuyer");
                Support.AreEqual("$5,000.00", sectionChargeTax.DisplayPaidByOthersForSeller, "sectionChargeTax DisplayPaidByOthersForSeller");
                Support.AreEqual("$15,000.00", sectionChargeTax.DisplayPaidBySellerAtClosing, "sectionChargeTax DisplayPaidBySellerAtClosing");
                Support.AreEqual("$5,000.00", sectionChargeTax.DisplayPaidBySellerBeforeClosing, "sectionChargeTax DisplayPaidBySellerBeforeClosing");
                //
                var sectionChargeRec = details.OtherCosts.SectionECharges.Charges[1];
                Support.AreEqual("CD - E2 Transfer Tax - Mo", sectionChargeRec.DisplayDescription, "sectionChargeRec DisplayDescription");
                //Support.AreEqual("$49,999.99", sectionChargeRec.DisplayLEAmount, "sectionChargeRec DisplayLEAmount");
                Support.AreEqual("$50,000.00", sectionChargeRec.DisplayPaidByBuyerAtClosing, "sectionChargeRec DisplayPaidByBuyerAtClosing");
                Support.AreEqual("$25,000.00", sectionChargeRec.DisplayPaidByBuyerBeforeClosing, "sectionChargeRec DisplayPaidByBuyerBeforeClosing");
                Support.AreEqual("$25,000.00", sectionChargeRec.DisplayPaidByOthersForBuyer, "sectionChargeRec DisplayPaidByOthersForBuyer");
                Support.AreEqual("$5,000.00", sectionChargeRec.DisplayPaidByOthersForSeller, "sectionChargeRec DisplayPaidByOthersForSeller");
                Support.AreEqual("$15,000.00", sectionChargeRec.DisplayPaidBySellerAtClosing, "sectionChargeRec DisplayPaidBySellerAtClosing");
                Support.AreEqual("$5,000.00", sectionChargeRec.DisplayPaidBySellerBeforeClosing, "sectionChargeRec DisplayPaidBySellerBeforeClosing");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Closing Disclosure - Other Costs Section F information using GetCDDetails web service")]
        public void Scenario_2_Get_SectionF_Details()
        {
            try
            {
                Reports.TestDescription = "Verify Closing Disclosure - Other Costs Section F information using GetCDDetails web service";

                FAST_Init_File(LenderID: "415", loanAmt: (decimal)2500000);

                AddChargesForSectionF();
                
                #region Verify Closing Disclosure - Loan Costs Section F details in FAST
                Reports.TestStep = "Verify Closing Disclosure - Loan Costs Section F details in FAST";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Other_Costs.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.OtherCostsSectionFTable);
                //  
                var sectionDetails = FastDriver.ClosingDisclosure.OtherCostsSectionFTable;
                Support.AreEqual("F. Prepaids", sectionDetails.PerformTableAction(1, 1, TableAction.GetText).Message, "Column Name");
                Support.AreEqual("$2,475,000.00", sectionDetails.PerformTableAction(1, 2, TableAction.GetText).Message, "Borrower Total");
                //
                Support.AreEqual("01. Homeowner's Insurance Premium ( mo.) to Continental Mortgage", sectionDetails.PerformTableAction(2, 1, TableAction.GetText).Message, "Description");
                Support.AreEqual("$500,000.00", sectionDetails.PerformTableAction(2, 2, TableAction.GetText).Message, "Borrower At Closing");
                Support.AreEqual("$250,000.00", sectionDetails.PerformTableAction(2, 3, TableAction.GetText).Message, "Borrower Before Closing");
                Support.AreEqual("$150,000.00", sectionDetails.PerformTableAction(2, 4, TableAction.GetText).Message, "Seller At Closing");
                Support.AreEqual("$50,000.00", sectionDetails.PerformTableAction(2, 5, TableAction.GetText).Message, "Seller Before Closing");
                Support.AreEqual("$250,000.00", sectionDetails.PerformTableAction(2, 6, TableAction.GetText).Message, "Paid By Others");
                Support.AreEqual("$1,249,999.99", sectionDetails.PerformTableAction(2, 7, TableAction.GetText).Message, "Loan Estimate Unrounded");
                Support.AreEqual("$1,250,000.00", sectionDetails.PerformTableAction(2, 8, TableAction.GetText).Message, "Loan Estimate Rounded");
                //
                Support.AreEqual("02. Mortgage Insurance Premium ( mo.) to Continental Mortgage", sectionDetails.PerformTableAction(3, 1, TableAction.GetText).Message, "Description");
                Support.AreEqual("$500,000.00", sectionDetails.PerformTableAction(3, 2, TableAction.GetText).Message, "Borrower At Closing");
                Support.AreEqual("$250,000.00", sectionDetails.PerformTableAction(3, 3, TableAction.GetText).Message, "Borrower Before Closing");
                Support.AreEqual("$150,000.00", sectionDetails.PerformTableAction(3, 4, TableAction.GetText).Message, "Seller At Closing");
                Support.AreEqual("$50,000.00", sectionDetails.PerformTableAction(3, 5, TableAction.GetText).Message, "Seller Before Closing");
                Support.AreEqual("$250,000.00", sectionDetails.PerformTableAction(3, 6, TableAction.GetText).Message, "Paid By Others");
                Support.AreEqual("$1,249,999.99", sectionDetails.PerformTableAction(3, 7, TableAction.GetText).Message, "Loan Estimate Unrounded");
                Support.AreEqual("$1,250,000.00", sectionDetails.PerformTableAction(3, 8, TableAction.GetText).Message, "Loan Estimate Rounded");
                //
                Support.AreEqual("03. Prepaid Interest ( per day from " + DateTime.Today.ToString("M/d/yy") + " to " + DateTime.Today.AddDays(365).ToString("M/d/yy") + " ) to Continental", sectionDetails.PerformTableAction(4, 1, TableAction.GetText).Message, "Description");
                Support.AreEqual("$200,000.00", sectionDetails.PerformTableAction(4, 2, TableAction.GetText).Message, "Borrower At Closing");
                Support.AreEqual("$25,000.00", sectionDetails.PerformTableAction(4, 3, TableAction.GetText).Message, "Borrower Before Closing");
                Support.AreEqual("", sectionDetails.PerformTableAction(4, 4, TableAction.GetText).Message, "Seller At Closing");
                Support.AreEqual("", sectionDetails.PerformTableAction(4, 5, TableAction.GetText).Message, "Seller Before Closing");
                Support.AreEqual("$25,000.00", sectionDetails.PerformTableAction(4, 6, TableAction.GetText).Message, "Paid By Others");
                Support.AreEqual("$249,999.99", sectionDetails.PerformTableAction(4, 7, TableAction.GetText).Message, "Loan Estimate Unrounded");
                Support.AreEqual("$250,000.00", sectionDetails.PerformTableAction(4, 8, TableAction.GetText).Message, "Loan Estimate Rounded");
                //
                Support.AreEqual("04. Property Taxes ( mo.) to Continental Mortgage", sectionDetails.PerformTableAction(5, 1, TableAction.GetText).Message, "Description");
                Support.AreEqual("$500,000.00", sectionDetails.PerformTableAction(5, 2, TableAction.GetText).Message, "Borrower At Closing");
                Support.AreEqual("$250,000.00", sectionDetails.PerformTableAction(5, 3, TableAction.GetText).Message, "Borrower Before Closing");
                Support.AreEqual("$150,000.00", sectionDetails.PerformTableAction(5, 4, TableAction.GetText).Message, "Seller At Closing");
                Support.AreEqual("$50,000.00", sectionDetails.PerformTableAction(5, 5, TableAction.GetText).Message, "Seller Before Closing");
                Support.AreEqual("$250,000.00", sectionDetails.PerformTableAction(5, 6, TableAction.GetText).Message, "Paid By Others");
                Support.AreEqual("$1,249,999.99", sectionDetails.PerformTableAction(5, 7, TableAction.GetText).Message, "Loan Estimate Unrounded");
                Support.AreEqual("$1,250,000.00", sectionDetails.PerformTableAction(5, 8, TableAction.GetText).Message, "Loan Estimate Rounded");
                #endregion

                #region Verify Closing Disclosure - Loan Costs Section E details with GetCDDetails()
                Reports.TestStep = "Verify Closing Disclosure - Loan Costs Section E details with GetCDDetails()";
                var request = CDRequestFactory.GetCDRequest(File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.OtherCosts);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                //  
                Support.AreEqual("$2,475,000.00", details.OtherCosts.SectionFCharges.DisplayTotal, "sectionFCharge1.DisplayTotal");
                var sectionFCharge1 = details.OtherCosts.SectionFCharges.Charges[0];
                Support.AreEqual("Homeowner's Insurance Premium", sectionFCharge1.DisplayDescription, "sectionFCharge1 DisplayDescription");
                Support.AreEqual("$1,249,999.99", sectionFCharge1.DisplayLEAmount, "sectionFCharge1 DisplayLEAmount");
                Support.AreEqual("$500,000.00", sectionFCharge1.DisplayPaidByBuyerAtClosing, "sectionFCharge1 DisplayPaidByBuyerAtClosing");
                Support.AreEqual("$250,000.00", sectionFCharge1.DisplayPaidByBuyerBeforeClosing, "sectionFCharge1 DisplayPaidByBuyerBeforeClosing");
                Support.AreEqual("$250,000.00", sectionFCharge1.DisplayPaidByOthersForBuyer, "sectionFCharge1 DisplayPaidByOthersForBuyer");
                Support.AreEqual("$50,000.00", sectionFCharge1.DisplayPaidByOthersForSeller, "sectionFCharge1 DisplayPaidByOthersForSeller");
                Support.AreEqual("$150,000.00", sectionFCharge1.DisplayPaidBySellerAtClosing, "sectionFCharge1 DisplayPaidBySellerAtClosing");
                Support.AreEqual("$50,000.00", sectionFCharge1.DisplayPaidBySellerBeforeClosing, "sectionFCharge1 DisplayPaidBySellerBeforeClosing");
                //
                var sectionFCharge2 = details.OtherCosts.SectionFCharges.Charges[1];
                Support.AreEqual("Mortgage Insurance Premium", sectionFCharge2.DisplayDescription, "sectionFCharge2 DisplayDescription");
                Support.AreEqual("$1,249,999.99", sectionFCharge2.DisplayLEAmount, "sectionFCharge2 DisplayLEAmount");
                Support.AreEqual("$500,000.00", sectionFCharge2.DisplayPaidByBuyerAtClosing, "sectionFCharge2 DisplayPaidByBuyerAtClosing");
                Support.AreEqual("$250,000.00", sectionFCharge2.DisplayPaidByBuyerBeforeClosing, "sectionFCharge2 DisplayPaidByBuyerBeforeClosing");
                Support.AreEqual("$250,000.00", sectionFCharge2.DisplayPaidByOthersForBuyer, "sectionFCharge2 DisplayPaidByOthersForBuyer");
                Support.AreEqual("$50,000.00", sectionFCharge2.DisplayPaidByOthersForSeller, "sectionFCharge2 DisplayPaidByOthersForSeller");
                Support.AreEqual("$150,000.00", sectionFCharge2.DisplayPaidBySellerAtClosing, "sectionFCharge2 DisplayPaidBySellerAtClosing");
                Support.AreEqual("$50,000.00", sectionFCharge2.DisplayPaidBySellerBeforeClosing, "sectionFCharge2 DisplayPaidBySellerBeforeClosing");
                //
                var sectionFCharge3 = details.OtherCosts.SectionFCharges.Charges[2];
                Support.AreEqual("Prepaid Interest", sectionFCharge3.DisplayDescription, "sectionFCharge3 DisplayDescription");
                Support.AreEqual("$249,999.99", sectionFCharge3.DisplayLEAmount, "sectionFCharge3 DisplayLEAmount");
                Support.AreEqual("$200,000.00", sectionFCharge3.DisplayPaidByBuyerAtClosing, "sectionFCharge3 DisplayPaidByBuyerAtClosing");
                Support.AreEqual("$25,000.00", sectionFCharge3.DisplayPaidByBuyerBeforeClosing, "sectionFCharge3 DisplayPaidByBuyerBeforeClosing");
                Support.AreEqual("$25,000.00", sectionFCharge3.DisplayPaidByOthersForBuyer, "sectionFCharge3 DisplayPaidByOthersForBuyer");
                Support.AreEqual("", sectionFCharge3.DisplayPaidByOthersForSeller, "sectionFCharge3 DisplayPaidByOthersForSeller");
                Support.AreEqual("", sectionFCharge3.DisplayPaidBySellerAtClosing, "sectionFCharge3 DisplayPaidBySellerAtClosing");
                Support.AreEqual("", sectionFCharge3.DisplayPaidBySellerBeforeClosing, "sectionFCharge3 DisplayPaidBySellerBeforeClosing");
                //
                var sectionFCharge4 = details.OtherCosts.SectionFCharges.Charges[3];
                Support.AreEqual("Property Taxes", sectionFCharge4.DisplayDescription, "sectionFCharge4 DisplayDescription");
                Support.AreEqual("$1,249,999.99", sectionFCharge4.DisplayLEAmount, "sectionFCharge4 DisplayLEAmount");
                Support.AreEqual("$500,000.00", sectionFCharge4.DisplayPaidByBuyerAtClosing, "sectionFCharge4 DisplayPaidByBuyerAtClosing");
                Support.AreEqual("$250,000.00", sectionFCharge4.DisplayPaidByBuyerBeforeClosing, "sectionFCharge4 DisplayPaidByBuyerBeforeClosing");
                Support.AreEqual("$250,000.00", sectionFCharge4.DisplayPaidByOthersForBuyer, "sectionFCharge4 DisplayPaidByOthersForBuyer");
                Support.AreEqual("$50,000.00", sectionFCharge4.DisplayPaidByOthersForSeller, "sectionFCharge4 DisplayPaidByOthersForSeller");
                Support.AreEqual("$150,000.00", sectionFCharge4.DisplayPaidBySellerAtClosing, "sectionFCharge4 DisplayPaidBySellerAtClosing");
                Support.AreEqual("$50,000.00", sectionFCharge4.DisplayPaidBySellerBeforeClosing, "sectionFCharge4 DisplayPaidBySellerBeforeClosing");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Closing Disclosure - Other Costs Section G information using GetCDDetails web service")]
        public void Scenario_3_Get_SectionG_Details()
        {
            try
            {
                Reports.TestDescription = "Verify Closing Disclosure - Other Costs Section G information using GetCDDetails web service";

                FAST_Init_File(LenderID: "415", loanAmt: (decimal)2500000);

                AddChargesForSectionG();
                
                #region Verify Closing Disclosure - Loan Costs Section G details in FAST
                Reports.TestStep = "Verify Closing Disclosure - Loan Costs Section G details in FAST";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Other_Costs.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.TableOtherCostSectionG);
                //  
                var sectionDetails = FastDriver.ClosingDisclosure.TableOtherCostSectionG;
                Support.AreEqual("G. Initial Escrow Payment at Closing", sectionDetails.PerformTableAction(1, 1, TableAction.GetText).Message, "Column Name");
                Support.AreEqual("$275,000.00", sectionDetails.PerformTableAction(1, 2, TableAction.GetText).Message, "Borrower Total");
                //
                Support.AreEqual("01. Homeowner's Insurance per month for mo.", sectionDetails.PerformTableAction(2, 1, TableAction.GetText).Message, "Description");
                Support.AreEqual("$50,000.00", sectionDetails.PerformTableAction(2, 2, TableAction.GetText).Message, "Borrower At Closing");
                Support.AreEqual("$25,000.00", sectionDetails.PerformTableAction(2, 3, TableAction.GetText).Message, "Borrower Before Closing");
                Support.AreEqual("$15,000.00", sectionDetails.PerformTableAction(2, 4, TableAction.GetText).Message, "Seller At Closing");
                Support.AreEqual("$5,000.00", sectionDetails.PerformTableAction(2, 5, TableAction.GetText).Message, "Seller Before Closing");
                Support.AreEqual("$25,000.00", sectionDetails.PerformTableAction(2, 6, TableAction.GetText).Message, "Paid By Others");
                Support.AreEqual("$124,999.99", sectionDetails.PerformTableAction(2, 7, TableAction.GetText).Message, "Loan Estimate Unrounded");
                Support.AreEqual("$125,000.00", sectionDetails.PerformTableAction(2, 8, TableAction.GetText).Message, "Loan Estimate Rounded");
                //
                Support.AreEqual("02. Mortgage Insurance per month for mo.", sectionDetails.PerformTableAction(3, 1, TableAction.GetText).Message, "Description");
                Support.AreEqual("$50,000.00", sectionDetails.PerformTableAction(3, 2, TableAction.GetText).Message, "Borrower At Closing");
                Support.AreEqual("$25,000.00", sectionDetails.PerformTableAction(3, 3, TableAction.GetText).Message, "Borrower Before Closing");
                Support.AreEqual("$15,000.00", sectionDetails.PerformTableAction(3, 4, TableAction.GetText).Message, "Seller At Closing");
                Support.AreEqual("$5,000.00", sectionDetails.PerformTableAction(3, 5, TableAction.GetText).Message, "Seller Before Closing");
                Support.AreEqual("$25,000.00", sectionDetails.PerformTableAction(3, 6, TableAction.GetText).Message, "Paid By Others");
                Support.AreEqual("$124,999.99", sectionDetails.PerformTableAction(3, 7, TableAction.GetText).Message, "Loan Estimate Unrounded");
                Support.AreEqual("$125,000.00", sectionDetails.PerformTableAction(3, 8, TableAction.GetText).Message, "Loan Estimate Rounded");
                //
                Support.AreEqual("03. Property Taxes per month for mo.", sectionDetails.PerformTableAction(4, 1, TableAction.GetText).Message, "Description");
                Support.AreEqual("$50,000.00", sectionDetails.PerformTableAction(4, 2, TableAction.GetText).Message, "Borrower At Closing");
                Support.AreEqual("$25,000.00", sectionDetails.PerformTableAction(4, 3, TableAction.GetText).Message, "Borrower Before Closing");
                Support.AreEqual("$15,000.00", sectionDetails.PerformTableAction(4, 4, TableAction.GetText).Message, "Seller At Closing");
                Support.AreEqual("$5,000.00", sectionDetails.PerformTableAction(4, 5, TableAction.GetText).Message, "Seller Before Closing");
                Support.AreEqual("$25,000.00", sectionDetails.PerformTableAction(4, 6, TableAction.GetText).Message, "Paid By Others");
                Support.AreEqual("$124,999.99", sectionDetails.PerformTableAction(4, 7, TableAction.GetText).Message, "Loan Estimate Unrounded");
                Support.AreEqual("$125,000.00", sectionDetails.PerformTableAction(4, 8, TableAction.GetText).Message, "Loan Estimate Rounded");
                //
                Support.AreEqual("04. Aggregate Adjustment", sectionDetails.PerformTableAction(5, 1, TableAction.GetText).Message, "Description");
                Support.AreEqual("50,000.00", sectionDetails.PerformTableAction(5, 2, TableAction.GetText).Message, "Borrower At Closing");
                Support.AreEqual("", sectionDetails.PerformTableAction(5, 3, TableAction.GetText).Message, "Borrower Before Closing");
                Support.AreEqual("50,000.00", sectionDetails.PerformTableAction(5, 4, TableAction.GetText).Message, "Seller At Closing");
                Support.AreEqual("", sectionDetails.PerformTableAction(5, 5, TableAction.GetText).Message, "Seller Before Closing");
                Support.AreEqual("", sectionDetails.PerformTableAction(5, 6, TableAction.GetText).Message, "Paid By Others");
                Support.AreEqual("", sectionDetails.PerformTableAction(5, 7, TableAction.GetText).Message, "Loan Estimate Unrounded");
                Support.AreEqual("", sectionDetails.PerformTableAction(5, 8, TableAction.GetText).Message, "Loan Estimate Rounded");
                #endregion
                
                #region Verify Closing Disclosure - Loan Costs Section G details with GetCDDetails()
                Reports.TestStep = "Verify Closing Disclosure - Loan Costs Section G details with GetCDDetails()";
                var request = CDRequestFactory.GetCDRequest(File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.OtherCosts);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                //  
                Support.AreEqual("$275,000.00", details.OtherCosts.SectionGCharges.DisplayTotal, "SectionECharges.DisplayTotal");
                var sectionGCharge1 = details.OtherCosts.SectionGCharges.Charges[0];
                Support.AreEqual("Homeowner's Insurance", sectionGCharge1.DisplayDescription, "sectionGCharge1 DisplayDescription");
                Support.AreEqual("$124,999.99", sectionGCharge1.DisplayLEAmount, "sectionGCharge1 DisplayLEAmount");
                Support.AreEqual("$50,000.00", sectionGCharge1.DisplayPaidByBuyerAtClosing, "sectionGCharge1 DisplayPaidByBuyerAtClosing");
                Support.AreEqual("$25,000.00", sectionGCharge1.DisplayPaidByBuyerBeforeClosing, "sectionGCharge1 DisplayPaidByBuyerBeforeClosing");
                Support.AreEqual("$25,000.00", sectionGCharge1.DisplayPaidByOthersForBuyer, "sectionGCharge1 DisplayPaidByOthersForBuyer");
                Support.AreEqual("$5,000.00", sectionGCharge1.DisplayPaidByOthersForSeller, "sectionGCharge1 DisplayPaidByOthersForSeller");
                Support.AreEqual("$15,000.00", sectionGCharge1.DisplayPaidBySellerAtClosing, "sectionGCharge1 DisplayPaidBySellerAtClosing");
                Support.AreEqual("$5,000.00", sectionGCharge1.DisplayPaidBySellerBeforeClosing, "sectionGCharge1 DisplayPaidBySellerBeforeClosing");
                //
                var sectionGCharge2 = details.OtherCosts.SectionGCharges.Charges[1];
                Support.AreEqual("Mortgage Insurance", sectionGCharge2.DisplayDescription, "sectionGCharge2 DisplayDescription");
                Support.AreEqual("$124,999.99", sectionGCharge2.DisplayLEAmount, "sectionGCharge2 DisplayLEAmount");
                Support.AreEqual("$50,000.00", sectionGCharge2.DisplayPaidByBuyerAtClosing, "sectionGCharge2 DisplayPaidByBuyerAtClosing");
                Support.AreEqual("$25,000.00", sectionGCharge2.DisplayPaidByBuyerBeforeClosing, "sectionGCharge2 DisplayPaidByBuyerBeforeClosing");
                Support.AreEqual("$25,000.00", sectionGCharge2.DisplayPaidByOthersForBuyer, "sectionGCharge2 DisplayPaidByOthersForBuyer");
                Support.AreEqual("$5,000.00", sectionGCharge2.DisplayPaidByOthersForSeller, "sectionGCharge2 DisplayPaidByOthersForSeller");
                Support.AreEqual("$15,000.00", sectionGCharge2.DisplayPaidBySellerAtClosing, "sectionGCharge2 DisplayPaidBySellerAtClosing");
                Support.AreEqual("$5,000.00", sectionGCharge2.DisplayPaidBySellerBeforeClosing, "sectionGCharge2 DisplayPaidBySellerBeforeClosing");
                //
                var sectionGCharge3 = details.OtherCosts.SectionGCharges.Charges[2];
                Support.AreEqual("Property Taxes", sectionGCharge3.DisplayDescription, "sectionGCharge3 DisplayDescription");
                Support.AreEqual("$124,999.99", sectionGCharge3.DisplayLEAmount, "sectionGCharge3 DisplayLEAmount");
                Support.AreEqual("$50,000.00", sectionGCharge3.DisplayPaidByBuyerAtClosing, "sectionGCharge3 DisplayPaidByBuyerAtClosing");
                Support.AreEqual("$25,000.00", sectionGCharge3.DisplayPaidByBuyerBeforeClosing, "sectionGCharge3 DisplayPaidByBuyerBeforeClosing");
                Support.AreEqual("$25,000.00", sectionGCharge3.DisplayPaidByOthersForBuyer, "sectionGCharge3 DisplayPaidByOthersForBuyer");
                Support.AreEqual("$5,000.00", sectionGCharge3.DisplayPaidByOthersForSeller, "sectionGCharge3 DisplayPaidByOthersForSeller");
                Support.AreEqual("$15,000.00", sectionGCharge3.DisplayPaidBySellerAtClosing, "sectionGCharge3 DisplayPaidBySellerAtClosing");
                Support.AreEqual("$5,000.00", sectionGCharge3.DisplayPaidBySellerBeforeClosing, "sectionGCharge3 DisplayPaidBySellerBeforeClosing");
                //
                var sectionGCharge4 = details.OtherCosts.SectionGCharges.Charges[3];
                Support.AreEqual("Aggregate Adjustment", sectionGCharge4.DisplayDescription, "sectionGCharge4 DisplayDescription");
                Support.AreEqual("$0", sectionGCharge4.DisplayLEAmount, "sectionGCharge4 DisplayLEAmount");
                Support.AreEqual("50,000.00", sectionGCharge4.DisplayPaidByBuyerAtClosing, "sectionGCharge4 DisplayPaidByBuyerAtClosing");
                Support.AreEqual("", sectionGCharge4.DisplayPaidByBuyerBeforeClosing, "sectionGCharge4 DisplayPaidByBuyerBeforeClosing");
                Support.AreEqual("", sectionGCharge4.DisplayPaidByOthersForBuyer, "sectionGCharge4 DisplayPaidByOthersForBuyer");
                Support.AreEqual("", sectionGCharge4.DisplayPaidByOthersForSeller, "sectionGCharge4 DisplayPaidByOthersForSeller");
                Support.AreEqual("50,000.00", sectionGCharge4.DisplayPaidBySellerAtClosing, "sectionGCharge4 DisplayPaidBySellerAtClosing");
                Support.AreEqual("", sectionGCharge4.DisplayPaidBySellerBeforeClosing, "sectionGCharge4 DisplayPaidBySellerBeforeClosing");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Closing Disclosure - Other Costs Section H information using GetCDDetails web service")]
        public void Scenario_4_Get_SectionH_Detail()
        {
            try
            {
                Reports.TestDescription = "Verify Closing Disclosure - Other Costs Section H information using GetCDDetails web service";

                FAST_Init_File();

                AddChargesForSectionH();

                #region Verify Closing Disclosure - Loan Costs Section H details in FAST
                Reports.TestStep = "Verify Closing Disclosure - Loan Costs Section H details in FAST";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Other_Costs.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.TableOtherCostSectionH);
                //  
                var sectionDetails = FastDriver.ClosingDisclosure.TableOtherCostSectionH;
                Support.AreEqual("H. Other", sectionDetails.PerformTableAction(1, 1, TableAction.GetText).Message, "Column Name");
                Support.AreEqual("$750,000.00", sectionDetails.PerformTableAction(1, 2, TableAction.GetText).Message, "Borrower Total");
                //
                Support.AreEqual("01. test-charge to Continental Mortgage", sectionDetails.PerformTableAction(2, 1, TableAction.GetText).Message, "Description");
                Support.AreEqual("$500,000.00", sectionDetails.PerformTableAction(2, 2, TableAction.GetText).Message, "Borrower At Closing");
                Support.AreEqual("$250,000.00", sectionDetails.PerformTableAction(2, 3, TableAction.GetText).Message, "Borrower Before Closing");
                Support.AreEqual("$150,000.00", sectionDetails.PerformTableAction(2, 4, TableAction.GetText).Message, "Seller At Closing");
                Support.AreEqual("$50,000.00", sectionDetails.PerformTableAction(2, 5, TableAction.GetText).Message, "Seller Before Closing");
                Support.AreEqual("(L)$250,000.00", sectionDetails.PerformTableAction(2, 6, TableAction.GetText).Message, "Paid By Others");
                Support.AreEqual("$1,249,999.99", sectionDetails.PerformTableAction(2, 7, TableAction.GetText).Message, "Loan Estimate Unrounded");
                Support.AreEqual("$1,250,000.00", sectionDetails.PerformTableAction(2, 8, TableAction.GetText).Message, "Loan Estimate Rounded");
                #endregion

                #region Verify Closing Disclosure - Loan Costs Section H details with GetCDDetails()
                Reports.TestStep = "Verify Closing Disclosure - Loan Costs Section H details with GetCDDetails()";
                var request = CDRequestFactory.GetCDRequest(File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.OtherCosts);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                //  
                Support.AreEqual("$750,000.00", details.OtherCosts.SectionHCharges.DisplayTotal, "sectionHCharge1.DisplayTotal");
                var sectionHCharge1 = details.OtherCosts.SectionHCharges.Charges.First(x => x.PayeeRoleType == "OutsideEscrow");
                Support.AreEqual("test-charge", sectionHCharge1.DisplayDescription, "sectionHCharge1 DisplayDescription");
                Support.AreEqual("$1,249,999.99", sectionHCharge1.DisplayLEAmount, "sectionHCharge1 DisplayLEAmount");
                Support.AreEqual("$500,000.00", sectionHCharge1.DisplayPaidByBuyerAtClosing, "sectionHCharge1 DisplayPaidByBuyerAtClosing");
                Support.AreEqual("$250,000.00", sectionHCharge1.DisplayPaidByBuyerBeforeClosing, "sectionHCharge1 DisplayPaidByBuyerBeforeClosing");
                Support.AreEqual("(L)$250,000.00", sectionHCharge1.DisplayPaidByOthersForBuyer, "sectionHCharge1 DisplayPaidByOthersForBuyer");
                Support.AreEqual("$50,000.00", sectionHCharge1.DisplayPaidByOthersForSeller, "sectionHCharge1 DisplayPaidByOthersForSeller");
                Support.AreEqual("$150,000.00", sectionHCharge1.DisplayPaidBySellerAtClosing, "sectionHCharge1 DisplayPaidBySellerAtClosing");
                Support.AreEqual("$50,000.00", sectionHCharge1.DisplayPaidBySellerBeforeClosing, "sectionHCharge1 DisplayPaidBySellerBeforeClosing");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Closing Disclosure - Other Costs Section I information using GetCDDetails web service")]
        public void Scenario_5_Get_SectionI_Details()
        {
            try
            {
                Reports.TestDescription = "Verify Closing Disclosure - Other Costs Section I information using GetCDDetails web service";

                FAST_Init_File(LenderID: "415", loanAmt: (decimal)2500000);

                AddChargesForSectionE();
                AddChargesForSectionF();
                AddChargesForSectionG();
                AddChargesForSectionH();
                
                #region Verify Closing Disclosure - Loan Costs Section I details in FAST
                Reports.TestStep = "Verify Closing Disclosure - Loan Costs Section I details in FAST";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Other_Costs.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.TableOtherCostSectionI);
                //  TableLoanCostSectionB
                var sectionDetails = FastDriver.ClosingDisclosure.TableOtherCostSectionI;
                Support.AreEqual("I. TOTAL OTHER COSTS (Borrower-Paid)", sectionDetails.PerformTableAction(1, 1, TableAction.GetText).Message, "Column Name");
                Support.AreEqual("$3,650,000.00", sectionDetails.PerformTableAction(1, 2, TableAction.GetText).Message, "Borrower Total");
                Support.AreEqual("Other Costs Subtotals (E + F + G + H)", sectionDetails.PerformTableAction(2, 1, TableAction.GetText).Message, "Description");
                Support.AreEqual("$2,500,000.00", sectionDetails.PerformTableAction(2, 2, TableAction.GetText).Message, "Borrower At Closing");
                Support.AreEqual("$1,150,000.00", sectionDetails.PerformTableAction(2, 3, TableAction.GetText).Message, "Borrower Before Closing");
                Support.AreEqual("", sectionDetails.PerformTableAction(2, 4, TableAction.GetText).Message, "Seller At Closing");
                Support.AreEqual("", sectionDetails.PerformTableAction(2, 5, TableAction.GetText).Message, "Seller Before Closing");
                Support.AreEqual("", sectionDetails.PerformTableAction(2, 6, TableAction.GetText).Message, "Paid By Others");
                Support.AreEqual("", sectionDetails.PerformTableAction(2, 7, TableAction.GetText).Message, "Loan Estimate Unrounded");
                Support.AreEqual("", sectionDetails.PerformTableAction(2, 8, TableAction.GetText).Message, "Loan Estimate Rounded");
                #endregion

                #region Verify Closing Disclosure - Loan Costs Section I details with GetCDDetails()
                Reports.TestStep = "Verify Closing Disclosure - Loan Costs Section I details with GetCDDetails()";
                var request = CDRequestFactory.GetCDRequest(File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.OtherCosts);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                //  
                Support.AreEqual("$3,650,000.00", details.OtherCosts.SectionICharges.DisplayTotal, "DisplayTotal");
                var sectionCharge = details.OtherCosts.SectionICharges.Charges.First();
                Support.AreEqual("$2,500,000.00", sectionCharge.DisplayPaidByBuyerAtClosing, "DisplayPaidByBuyerAtClosing");
                Support.AreEqual("$1,150,000.00", sectionCharge.DisplayPaidByBuyerBeforeClosing, "DisplayPaidByBuyerBeforeClosing");
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Closing Disclosure - Other Costs Section J information using GetCDDetails web service")]
        public void Scenario_6_Get_SectionJ_Details()
        {
            try
            {
                Reports.TestDescription = "Verify Closing Disclosure - Other Costs Section J information using GetCDDetails web service";

                FAST_Init_File(LenderID: "415", loanAmt: (decimal)2500000);

                AddChargesForSectionE();
                AddChargesForSectionF();
                AddChargesForSectionG();
                AddChargesForSectionH();
                
                #region Verify Closing Disclosure - Loan Costs Section J details in FAST
                Reports.TestStep = "Verify Closing Disclosure - Loan Costs Section J details in FAST";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Other_Costs.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.TableOtherCostSectionJ);
                //  TableLoanCostSectionB
                var sectionDetails = FastDriver.ClosingDisclosure.TableOtherCostSectionJ;
                Support.AreEqual("J. TOTAL CLOSING COSTS (Borrower-Paid)", sectionDetails.PerformTableAction(1, 1, TableAction.GetText).Message, "Column Name");
                Support.AreEqual("$3,650,000.00", sectionDetails.PerformTableAction(1, 2, TableAction.GetText).Message, "Borrower Total");
                Support.AreEqual("Closing Costs Subtotals (D + I)", sectionDetails.PerformTableAction(2, 1, TableAction.GetText).Message, "Description");
                Support.AreEqual("$2,500,000.00", sectionDetails.PerformTableAction(2, 2, TableAction.GetText).Message, "Borrower At Closing");
                Support.AreEqual("$1,150,000.00", sectionDetails.PerformTableAction(2, 3, TableAction.GetText).Message, "Borrower Before Closing");
                Support.AreEqual("$725,000.00", sectionDetails.PerformTableAction(2, 4, TableAction.GetText).Message, "Seller At Closing");
                Support.AreEqual("$225,000.00", sectionDetails.PerformTableAction(2, 5, TableAction.GetText).Message, "Seller Before Closing");
                Support.AreEqual("$1,150,000.00", sectionDetails.PerformTableAction(2, 6, TableAction.GetText).Message, "Paid By Others");
                Support.AreEqual("", sectionDetails.PerformTableAction(2, 7, TableAction.GetText).Message, "Loan Estimate Unrounded");
                Support.AreEqual("", sectionDetails.PerformTableAction(2, 8, TableAction.GetText).Message, "Loan Estimate Rounded");
                #endregion

                #region Verify Closing Disclosure - Loan Costs Section J details with GetCDDetails()
                Reports.TestStep = "Verify Closing Disclosure - Loan Costs Section J details with GetCDDetails()";
                var request = CDRequestFactory.GetCDRequest(File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.OtherCosts);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                //  
                Support.AreEqual("$3,650,000.00", details.OtherCosts.SectionJCharges.DisplayTotal, "DisplayTotal");
                var sectionCharge = details.OtherCosts.SectionJCharges.Charges.First();
                Support.AreEqual("$2,500,000.00", sectionCharge.DisplayPaidByBuyerAtClosing, "DisplayPaidByBuyerAtClosing");
                Support.AreEqual("$1,150,000.00", sectionCharge.DisplayPaidByBuyerBeforeClosing, "DisplayPaidByBuyerBeforeClosing");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
