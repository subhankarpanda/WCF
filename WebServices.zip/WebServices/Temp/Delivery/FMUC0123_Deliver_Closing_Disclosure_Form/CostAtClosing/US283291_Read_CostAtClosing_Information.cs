﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Delivery.FMUC0123_Deliver_Closing_Disclosure_Form.CostAtClosing
{
    [CodedUITest]
    public class US283291_Read_CostAtClosing_Information : FASTHelpers
    {
        [TestMethod]
        [Description("Verify Closing Disclosure - Cost At Closing information using GetCDDetails web service")]
        public void Scenario_1_Get_CostAtClosing_Details()
        {
            try
            {
                Reports.TestDescription = "Verify Closing Disclosure - Cost At Closing information using GetCDDetails web service";

                FAST_Init_File();

                #region Navigate to Closing Disclosure - Cost At Closing and modify the statements
                Reports.TestStep = "Navigate to Closing Disclosure - Cost At Closing and modify the statements";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Costs_at_Closing.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsAmount);
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatement1.Clear();
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatement1.FASetText("BorrowerCostAtClosing");
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatement2.Clear();
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatement2.FASetText("SectionIBorrowerPaidAmt");
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatement3.Clear();
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatement3.FASetText("BorrowerLenderCredits");
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatement4.Clear();
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatement4.FASetText("and more...");
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_CashtoCloseStemenetSpan.Clear();
                FastDriver.ClosingDisclosure.Section4_CostsatClosing_CashtoCloseStemenetSpan.FASetText("this is an statement.");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Closing Disclosure - Cost At Closing details with GetCDDetails()
                Reports.TestStep = "Verify Closing Disclosure - Cost At Closing details with GetCDDetails()";
                var request = CDRequestFactory.GetCDDetailsRequest();
                request.FileID = File.FileID ?? 0;
                request.CDFilter = FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.CostsAtClosing;
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                var costsAtClosing = details.CostAtClosing;
                Support.AreEqual("this is an statement.", costsAtClosing.CashToClose, "CashToClose");
                Support.AreEqual("BorrowerCostAtClosing", costsAtClosing.ClosingCostDisplayText1, "ClosingCostDisplayText1");
                Support.AreEqual("SectionIBorrowerPaidAmt", costsAtClosing.ClosingCostDisplayText2, "ClosingCostDisplayText2");
                Support.AreEqual("BorrowerLenderCredits", costsAtClosing.ClosingCostDisplayText3, "ClosingCostDisplayText3");
                Support.AreEqual("and more...", costsAtClosing.ClosingCostDisplayText4, "ClosingCostDisplayText4");
                Support.AreEqual("$0", costsAtClosing.DisplayCashToCloseAmount, "DisplayCashToCloseAmount");
                Support.AreEqual("$0", costsAtClosing.DisplayClosingCostsAmount, "DisplayClosingCostsAmount");
                Support.AreEqual("$0", costsAtClosing.DisplayLenderCreditBorrowerPaidAmount, "DisplayLenderCreditBorrowerPaidAmount");
                Support.AreEqual("$0", costsAtClosing.DisplaySectionDBorrowerPaidAmount, "DisplaySectionDBorrowerPaidAmount");
                Support.AreEqual("$0", costsAtClosing.DisplaySectionIBorrowerPaidAmount, "DisplaySectionIBorrowerPaidAmount");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
