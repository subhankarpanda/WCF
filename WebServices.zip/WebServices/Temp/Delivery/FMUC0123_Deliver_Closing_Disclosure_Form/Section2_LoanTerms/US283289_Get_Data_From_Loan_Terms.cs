﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Delivery.FMUC0123_Deliver_Closing_Disclosure_Form.LoanTerms
{
    [CodedUITest]
    public class US283289_Get_Data_From_Loan_Terms : FASTHelpers
    {
        [TestMethod]
        [Description("Verify Closing Disclosure - Loan Terms information using GetCDDetails web service")]
        public void Scenario_1_Retrieve_CD_Loan_Terms_Details()
        {
            try
            {
                Reports.TestDescription = "Verify Closing Disclosure - Loan Terms information using GetCDDetails web service";

                FAST_Init_File(LenderID: "415", loanAmt: (decimal)1000000);

                #region Navigate to Closing Disclosure and fill in Loan Terms details
                Reports.TestStep = "Navigate to Closing Disclosure and fill in Loan Terms details";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.Click();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.Section2_LoanTerms_LoanAmountValue);
                //  Loan Amount
                Support.AreEqual("$1,000,000", FastDriver.ClosingDisclosure.Section2_LoanTerms_LoanAmountValue.Text, "Section2_LoanTerms_LoanAmountValue");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_LoanAmountDropdown.FASelectItemBySendingKeys("YES");
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_plusIcon.Click();
                FastDriver.ClosingDisclosure.LoanTerm_PlusPanel_checkbox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_CanGo_DrpDwn.FASelectItemBySendingKeys("Can go");
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_Amount.FASetText("2000000");
                FastDriver.ClosingDisclosure.LoanTerm_PlusPanel_checkbox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_year.FASetText("5");
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.Click();
                //  Interest Rate
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FASetText("14");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown.FASelectItemBySendingKeys("YES");
                FastDriver.ClosingDisclosure.LoanTerm_InterestRate_plusIcon.Click();
                FastDriver.ClosingDisclosure.LoanTerm_PlusPanel_checkbox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_IR_Adjust_Year.FASetText("1");
                FastDriver.ClosingDisclosure.LoanTerm_IR_FirstRate_Year.FASetText("1");
                FastDriver.ClosingDisclosure.LoanTerm_PlusPanel_checkbox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_IR_CeilingRate.FASetText("19");
                FastDriver.ClosingDisclosure.LoanTerm_IR_Effective_Year.FASetText("5");
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.Click();
                //  Monthly Principal & Interest
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPlusIcon.Click();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyDropDown.FASelectItemBySendingKeys("Annual");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPopupDone.Click();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FASetText("100000");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FASelectItemBySendingKeys("YES");
                FastDriver.ClosingDisclosure.LoanTerm_PI_plusIcon.Click();
                FastDriver.ClosingDisclosure.LoanTerm_PlusPanel_checkbox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_Adjust_Year.FASetText("1");
                FastDriver.ClosingDisclosure.LoanTerm_PI_FirstRate_Year.FASetText("1");
                FastDriver.ClosingDisclosure.LoanTerm_PlusPanel_checkbox2.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PI_MaxAmmount.FASetText("150000");
                FastDriver.ClosingDisclosure.LoanTerm_PI_Effective_Year.FASetText("5");
                FastDriver.ClosingDisclosure.LoanTerm_PI_InterestOnly_Year.FASetText("3");
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.Click();
                //  Prepayment Penalty
                FastDriver.ClosingDisclosure.Section2_LoanTerms_PrepaymentPenaltyDropdown.FASelectItemBySendingKeys("YES");
                FastDriver.ClosingDisclosure.LoanTerm_PP_plusIcon.Click();
                FastDriver.ClosingDisclosure.LoanTerm_PlusPanel_checkbox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_PP_MaxAmmount.FASetText("110000");
                FastDriver.ClosingDisclosure.LoanTerm_PP_Expiration_Year.FASetText("2");
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.Click();
                //  Balloon Payment
                FastDriver.ClosingDisclosure.Section2_LoanTerms_BalloonPaymentDropdown.FASelectItemBySendingKeys("YES");
                FastDriver.ClosingDisclosure.LoanTerm_BP_plusIcon.Click();
                FastDriver.ClosingDisclosure.LoanTerm_PlusPanel_checkbox1.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanTerm_BP_MaxAmmount.FASetText("50000");
                FastDriver.ClosingDisclosure.LoanTerm_LoanAmount_DoneBtn.Click();
                //
                FastDriver.BottomFrame.Done();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                #endregion
                
                #region Verify Closing Disclosure - Loan Terms details with GetCDDetails
                Reports.TestStep = "Verify Closing Disclosure - Loan Terms details with GetCDDetails";
                var request = CDRequestFactory.GetCDDetailsRequest();
                request.FileID = File.FileID ?? 0;
                request.CDFilter = FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.LoanTerms;
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                //  Loan Amount
                Support.AreEqual("1,000,000.00", ((Decimal)details.ClosingDisclosureLoanTerm.LoanAmount).ToString("N2"), "LoanAmount");
                Support.AreEqual("yes", details.ClosingDisclosureLoanTerm.CanLoanAmountIncrease.ToString().ToLowerInvariant(), "CanLoanAmountIncrease");
                Support.AreEqual("1", details.ClosingDisclosureLoanTerm.LoanAmountCanGoAsHighAsIndicator.ToString(), "LoanAmountCanGoAsHighAsIndicator");
                Support.AreEqual("5", details.ClosingDisclosureLoanTerm.NegativeAmortizationLimitYearsCount, "NegativeAmortizationLimitYearsCount");
                Support.AreEqual("$2,000,000.00", details.ClosingDisclosureLoanTerm.NegativeAmortizationMaximumLoadBalanceAmount, "NegativeAmortizationMaximumLoadBalanceAmount");
                //  Interest Rate
                Support.AreEqual("yes", details.ClosingDisclosureLoanTerm.CanInterestRateIncrease.ToString().ToLowerInvariant(), "CanInterestRateIncrease");
                Support.AreEqual("14", details.ClosingDisclosureLoanTerm.InterestRate.ToString(), "InterestRate");
                Support.AreEqual("1", details.ClosingDisclosureLoanTerm.InterestRateAdjustEveryYear, "InterestRateAdjustEveryYear");
                Support.AreEqual("19%", details.ClosingDisclosureLoanTerm.InterestRateCeilingRatePercent, "InterestRateCeilingRatePercent");
                Support.AreEqual("1", details.ClosingDisclosureLoanTerm.InterestRateFirstRateChangeYearsCount, "InterestRateFirstRateChangeYearsCount");
                //  Monthly Principal & Interest
                Support.AreEqual("Annual", details.ClosingDisclosureLoanTerm.displaytempPrincipalAndInterestTerm, "displaytempPrincipalAndInterestTerm");
                Support.AreEqual("100,000.00", ((Decimal)details.ClosingDisclosureLoanTerm.MonthlyPrincipalInterest).ToString("N2"), "MonthlyPrincipalInterest");
                Support.AreEqual("yes", details.ClosingDisclosureLoanTerm.PrincipalAndInterestCanIncrease.ToString().ToLowerInvariant(), "PrincipalAndInterestCanIncrease");
                Support.AreEqual("$150,000.00", details.ClosingDisclosureLoanTerm.PrincipalAndInterestPaymentMaximumAmount, "PrincipalAndInterestPaymentMaximumAmount");
                Support.AreEqual("5", details.ClosingDisclosureLoanTerm.CeilingRatePercentEarliestEffectiveYearsCount, "CeilingRatePercentEarliestEffectiveYearsCount");
                Support.AreEqual("1", details.ClosingDisclosureLoanTerm.FirstPrincipalAndInterestPaymentChangeYearsCount, "FirstPrincipalAndInterestPaymentChangeYearsCount");
                Support.AreEqual("1", details.ClosingDisclosureLoanTerm.PerChangePrincipalInterestPaymentAdjustFrequencyYearsCount, "PerChangePrincipalInterestPaymentAdjustFrequencyYearsCount");
                Support.AreEqual("5", details.ClosingDisclosureLoanTerm.PrincipalAndInterestPaymentMaximumAmountEarliestEffectiveYearsCount, "PrincipalAndInterestPaymentMaximumAmountEarliestEffectiveYearsCount");
                //  Prepayment Penalty
                Support.AreEqual("yes", details.ClosingDisclosureLoanTerm.PrePaymentPenaltyCanIncrease.ToString().ToLowerInvariant(), "PrePaymentPenaltyCanIncrease");
                Support.AreEqual("2", details.ClosingDisclosureLoanTerm.PrepaymentPenaltyExpirationYearsCount, "PrepaymentPenaltyExpirationYearsCount");
                Support.AreEqual("$110,000.00", details.ClosingDisclosureLoanTerm.PrepaymentPenaltyMaximumLifeOfLoanAmount, "PrepaymentPenaltyMaximumLifeOfLoanAmount");
                //  Balloon Payment
                Support.AreEqual("yes", details.ClosingDisclosureLoanTerm.BallonPaymentCanIncrease.ToString().ToLowerInvariant(), "BallonPaymentCanIncrease");
                Support.AreEqual("$50,000.00", details.ClosingDisclosureLoanTerm.BalloonPaymentAmount, "BalloonPaymentAmount");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
