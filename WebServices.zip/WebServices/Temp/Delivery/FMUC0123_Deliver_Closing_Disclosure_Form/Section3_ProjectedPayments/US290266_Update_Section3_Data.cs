﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Delivery.FMUC0123_Deliver_Closing_Disclosure_Form.ProjectedPayments
{
    [CodedUITest]
    public class US290266_Update_Section3_Data : FASTHelpers
    {
        [TestMethod]
        [Description("Verify update Closing Disclosure - Projected Payments information using UpdateCDDetails web service")]
        public void Scenario_1_Update_ProjectedPaymentDetails()
        {
            try
            {
                Reports.TestDescription = "Verify update Closing Disclosure - Projected Payments information using UpdateCDDetails web service";

                FAST_Init_File(LenderID: "415", loanAmt: (decimal)1000000);

                #region Update Closing Disclosure - Projected Payment details with UpdateCDDetails()
                Reports.TestStep = "Update Closing Disclosure - Projected Payment details with UpdateCDDetails()";
                var updateReq = CDRequestFactory.GetUpdateCDDetailsRequest(File.FileID);
                updateReq.ClosingDisclosure.ClosingDisclosureProjectedPayment = new FASTWCFHelpers.FastClosingDisclosureService.ClosingDisclosureProjectedPayment()
                {
                    EstimatedTaxInsuranceAssesment = "$800.00",
                    HomeOwnerInsuranceInEscrowID = 3145,
                    IsHomeOwnerInsurance = 1,
                    IsProjectedPaymentEstimateOther = 1,
                    IsPropertyTax = 1,
                    ProjectedPaymentEstimateOther = "test-value",
                    ProjectedPaymentEstimateOtherInEscrowID = 2992,
                    ProjectedPaymentEstimateOtherText = "test-value",
                    PPAdditionalEstimatedPropertyCosts = new FASTWCFHelpers.FastClosingDisclosureService.PPAdditionalEstimatedPropertyCosts[]{
                        new FASTWCFHelpers.FastClosingDisclosureService.PPAdditionalEstimatedPropertyCosts(){
                            EstimateIncludeID = "2992",
                            InEscrow = true,
                            ShowOnForm = true,
                        },
                    },
                    PPEstimateIncludesOtherInEscrowID = 3094,
                    ProjectedPaymentRanges = new FASTWCFHelpers.FastClosingDisclosureService.ClosingDisclosureProjectedPaymentRange[] { 
                        new FASTWCFHelpers.FastClosingDisclosureService.ClosingDisclosureProjectedPaymentRange(){
                            EndRange = 1,
                            EstimatedEscrow = "5000.00",
                            Interest = 0,
                            IsInterestOnly = 0,
                            MaxEstimatedTotalMonthlyPayment = 420000,
                            MaxPrincipal = 400000,
                            MinEstimatedTotalMonthlyPayment = 353333,
                            MinPrincipal = 333333,
                            MortgageInsurance = "15000.00",
                            PrincipalInterest = 0,
                            StartRange = 1,
                        },
                        new FASTWCFHelpers.FastClosingDisclosureService.ClosingDisclosureProjectedPaymentRange(){
                            EndRange = 2,
                            EstimatedEscrow = "2500.00",
                            Interest = 0,
                            IsInterestOnly = 0,
                            MaxEstimatedTotalMonthlyPayment = 410000,
                            MaxPrincipal = 400000,
                            MinEstimatedTotalMonthlyPayment = 343333,
                            MinPrincipal = 333333,
                            MortgageInsurance = "7500.00",
                            PrincipalInterest = 0,
                            StartRange = 2,
                        },
                        new FASTWCFHelpers.FastClosingDisclosureService.ClosingDisclosureProjectedPaymentRange(){
                            EndRange = 3,
                            EstimatedEscrow = "1250.00",
                            EstimatedTotalMonthlyPayment = (decimal)338333.00,
                            Interest = 0,
                            IsInterestOnly = 2,
                            MaxPrincipal = 0,
                            MinPrincipal = 0,
                            MortgageInsurance = "3750.00",
                            PrincipalInterest = (double)333333,
                            StartRange = 3,
                        },
                    },
                    PropertyTaxInEscrowID = 2623,
                    YearRange = 3,
                };
                var response = ClosingDisclosureService.UpdateCDDetails(updateReq);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify updates to Closing Disclosure - Project Payments in FAST
                Reports.TestStep = "Verify updates to Closing Disclosure - Project Payments in FAST";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Projected_Payments.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.Section3_ProjectedPaymentPlusIcon);
                FastDriver.ClosingDisclosure.Section3_ProjectedPaymentPlusIcon.Click();
                Support.AreEqual("3", FastDriver.ClosingDisclosure.ProjectedPayment_PaymentCalculation_YearRange.FAGetSelectedItem(), "ProjectedPayment_PaymentCalculation_YearRange");
                FastDriver.ClosingDisclosure.YearRangeCancel.FAClick();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                //  Year 1
                Support.AreEqual("Year", FastDriver.ClosingDisclosure.ProjectedPayment_ddlYearRanges1.FAGetSelectedItem(), "ProjectedPayment_ddlYearRanges1");
                Support.AreEqual("1", FastDriver.ClosingDisclosure.ProjectedPayment_txtStartYear1.FAGetValue(), "ProjectedPayment_txtStartYear1");
                Support.AreEqual("$333,333 min $400,000 max", FastDriver.ClosingDisclosure.ProjectedPayment_PrincInterestYear1.FAGetText(), "ProjectedPayment_PrincInterestYear1");
                Support.AreEqual("15,000.00", FastDriver.ClosingDisclosure.Section3_MortgageInsurance.FAGetValue(), "Section3_MortgageInsurance");
                Support.AreEqual("5,000.00", FastDriver.ClosingDisclosure.Section3_EstimatedEscrow.FAGetValue(), "Section3_EstimatedEscrow");
                Support.AreEqual("$353,333 - $420,000", FastDriver.ClosingDisclosure.ProjectedPayment_EstimatedTotalYear1.FAGetText(), "ProjectedPayment_EstimatedTotalYear1");
                //  Year 2
                Support.AreEqual("Year", FastDriver.ClosingDisclosure.ProjectedPayment_ddlYearRanges2.FAGetSelectedItem(), "ProjectedPayment_ddlYearRanges2");
                Support.AreEqual("2", FastDriver.ClosingDisclosure.ProjectedPayment_txtStartYear2.FAGetValue(), "ProjectedPayment_txtStartYear2");
                Support.AreEqual("$333,333 min $400,000 max", FastDriver.ClosingDisclosure.ProjectedPayment_PrincInterestYear2.FAGetText(), "ProjectedPayment_PrincInterestYear2");
                Support.AreEqual("7,500.00", FastDriver.ClosingDisclosure.ProjectedPayment_txtMortInsAmt1.FAGetValue(), "ProjectedPayment_txtMortInsAmt1");
                Support.AreEqual("2,500.00", FastDriver.ClosingDisclosure.ProjectedPayment_txtEstEscAmt1.FAGetValue(), "ProjectedPayment_txtEstEscAmt1");
                Support.AreEqual("$343,333 - $410,000", FastDriver.ClosingDisclosure.ProjectedPayment_EstimatedTotalYear2.FAGetText(), "ProjectedPayment_EstimatedTotalYear2");
                //  Final Year
                Support.AreEqual("Year", FastDriver.ClosingDisclosure.ProjectedPayment_ddlYearRanges3.FAGetSelectedItem(), "ProjectedPayment_ddlYearRanges3");
                Support.AreEqual("3", FastDriver.ClosingDisclosure.ProjectedPayment_txtStartYear3.FAGetValue(), "ProjectedPayment_txtStartYear3");
                Support.AreEqual("$333,333.00", FastDriver.ClosingDisclosure.ProjectedPayment_PrincInterestYear3.FAGetText(), "ProjectedPayment_PrincInterestYear3");
                Support.AreEqual("3,750.00", FastDriver.ClosingDisclosure.ProjectedPayment_txtMortInsAmt2.FAGetValue(), "ProjectedPayment_txtMortInsAmt2");
                Support.AreEqual("1,250.00", FastDriver.ClosingDisclosure.ProjectedPayment_txtEstEscAmt2.FAGetValue(), "ProjectedPayment_txtEstEscAmt2");
                Support.AreEqual("$338,333.00", FastDriver.ClosingDisclosure.ProjectedPayment_EstimatedTotalYear3.FAGetText(), "ProjectedPayment_EstimatedTotalYear3");
                //  Estimates
                Support.AreEqual("$800.00", FastDriver.ClosingDisclosure.ProjectedPayment_Estimated_TI_Amount.FAGetValue(), "ProjectedPayment_Estimated_TI_Amount");
                Support.AreEqual("true", FastDriver.ClosingDisclosure.Section3_PropertyTax.FAGetAttribute("status"), "Section3_PropertyTax");
                Support.AreEqual("SOME", FastDriver.ClosingDisclosure.Section3_PropertyTaxInEscrow.FAGetSelectedItem(), "Section3_PropertyTaxInEscrow");
                Support.AreEqual("true", FastDriver.ClosingDisclosure.Section3_HomeownersInsurance.FAGetAttribute("status"), "Section3_HomeownersInsurance");
                Support.AreEqual("SOME", FastDriver.ClosingDisclosure.Section3_HomeownersInsuranceInEscrow.FAGetSelectedItem(), "Section3_HomeownersInsuranceInEscrow");
                Support.AreEqual("test-value", FastDriver.ClosingDisclosure.Section3_EstimateOtherInEscrowText.FAGetText(), "Section3_EstimateOtherInEscrowText");
                Support.AreEqual("YES", FastDriver.ClosingDisclosure.Section3_lblEstimateIncludesInEscrowID.FAGetText(), "Section3_lblEstimateIncludesInEscrowID");
                FastDriver.ClosingDisclosure.Section3_OthersInEscrowPlus.FAClick();
                Support.AreEqual("true", FastDriver.ClosingDisclosure.Section3_EstimateIncludesID_2992.FAGetAttribute("status"), "Section3_EstimateIncludesID_2992");
                Support.AreEqual("true", FastDriver.ClosingDisclosure.Section3_InEscrowID_2992.FAGetAttribute("status"), "Section3_InEscrowID_2992");
                Support.AreEqual("test-value", FastDriver.ClosingDisclosure.txtPOPupEstimateOther.FAGetValue(), "txtPOPupEstimateOther");
                FastDriver.ClosingDisclosure.Section3_btnPPOtherCancel.FAClick();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
